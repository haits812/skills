# eval-loop-kit セットアップ手順 (Claude 実行用ランブック)

あなた (Claude) はこの `setup.md` を読み、**この PC に eval-loop 品質ループ一式をセットアップする**。
ユーザーはこの zip を展開し、あなたにこのファイルを見せた状態。**KIT_ROOT = この setup.md があるディレクトリ**。

## これで入るもの

- **eval-loop プラグイン** … 品質スコアが閾値に達するまで generator→evaluator を Stop hook で自律ループさせる primitive (`/eval-loop:run-eval-loop` 等)。plugin (hook 付き)。
- **guided-build スキル** … 「〇〇作りたい」の自然文で発火し、clarify→eval-loop を一気通貫させる dispatcher。user skill。
- **clarify-goal スキル** … 曖昧なゴールを質問で確定し `goal.json` を出す有界 clarify。user skill。
- **run-skill-live-trial-sdk スキル** … skill を別プロセスの fresh headless セッション(Claude Code SDK `query()`)で実走させ受け入れ確認する **Windows ネイティブ harness (tmux 不要)**。**node 必須**。自己完結・plain-text gate の skill 向け(eval-loop 系の自走 acceptance と AskUserQuestion gate は headless の限界で不可 — 詳細は当該 SKILL.md)。

構成: `guided-build`(発火) → `clarify-goal`(要件確定) → `eval-loop`(品質ループ自走)。開発時の受け入れ確認に `run-skill-live-trial-sdk`。

---

## Step 0: 前提ツール確認 (必須)

次を bash で実行し、欠けているものをユーザーに知らせる:

```bash
for t in git jq python bash; do printf "%-8s " "$t"; command -v "$t" >/dev/null 2>&1 && echo OK || echo "MISSING (必須)"; done
printf "%-8s " node; command -v node >/dev/null 2>&1 && echo "OK (任意)" || echo "任意 (SDK live-trial 検証にのみ使用)"
```

- **git / jq / bash / python が必須。** eval-loop の orchestration は bash + jq を使う。python は生成物のビルド/テストで一般に要る。
- MISSING があれば導入を案内する (Windows 例: `winget install jqlang.jq` / `winget install Git.Git` / python.org)。**Windows では Git Bash を使う** (eval-loop のスクリプトは POSIX sh 前提)。
- **node は `run-skill-live-trial-sdk` を使うなら必須** (Claude Code SDK 経由の受け入れ確認に使用)。ランタイム本体(eval-loop/guided-build/clarify-goal)だけなら node 不要。live-trial の driver は `npm root -g`/@anthropic-ai/claude-code から SDK を自動解決するが、見つからない場合は環境変数 `CLAUDE_SDK` に `sdk.mjs` の絶対パスを指定する。

## Step 1: 自作スキルを導入 (コピーのみ・設定不要)

user skill は `~/.claude/skills/` に置くだけで自動発見される (enablement 設定は不要)。KIT_ROOT を実際のパスに置換して実行:

```bash
mkdir -p ~/.claude/skills
cp -r "<KIT_ROOT>/skills/guided-build" ~/.claude/skills/
cp -r "<KIT_ROOT>/skills/clarify-goal" ~/.claude/skills/
ls ~/.claude/skills/guided-build/SKILL.md ~/.claude/skills/clarify-goal/SKILL.md
```

両 SKILL.md が存在すれば成功。

## Step 2: eval-loop プラグインを導入 (★ user スコープ厳守)

プラグインは hook を持つため `/plugin` 機構で入れる。**`claude plugin` CLI にインストール機能は無い**ので、対話 `/plugin` メニューはユーザー操作。あなたはユーザーに **次の正確な手順**を提示する:

> Claude Code の中で以下を実行してください:
> 1. `/plugin marketplace add <KIT_ROOT>/eval-loop-marketplace`
> 2. `/plugin install eval-loop@eval-loop`
> 3. スコープを聞かれたら **必ず「user」を選ぶ** (project を選ぶと、そのフォルダでしか動かない ← 典型的な事故)
> 4. 有効化 (enable) する

**なぜ user スコープが必須か (最重要)**: project スコープで入れると `installed_plugins.json` に `projectPath` が紐づき、**別フォルダでは `Unknown skill` になる**。「どこでも `guided-build` から呼べる」ためには user スコープ + グローバル有効化が要る。

(参考: グローバル有効化は `~/.claude/settings.json` の `enabledPlugins` に `"eval-loop@eval-loop": true` として入る。`/plugin` がこれを正しい場所へ書くので、**自分で settings.json を手編集しない** — Claude 管理ファイルで壊れやすく、config 保護 deny で弾かれることもある。)

## Step 3: 再起動

プラグインの skill/hook は**セッション起動時にロード**される。設定後は Claude Code を一度再起動する必要がある、とユーザーに伝える。

## Step 4: 検証 (再起動後)

再起動後の新セッションで、**sandbox 以外の任意フォルダ**にて:

1. `/eval-loop` と打ち、`run-eval-loop` 等が候補に出れば **user スコープ有効化が成功**。
2. 出なければ user スコープになっていない (Step 2 をやり直す。応急処置として、そのフォルダに `.claude/settings.json` を作り `{"enabledPlugins":{"eval-loop@eval-loop":true}}` を置けばそのフォルダでは効く)。
3. 総合動作: 「テキスト整形の小さな CLI を作りたい」と投げ、guided-build → clarify(数問) → eval-loop 自走、まで通れば完成。

---

## 地雷メモ (Claude はこれを守ること)

1. **プラグインは user スコープ** (project スコープ厳禁。別フォルダで壊れる)。
2. **eval-loop の task/goal に Windows 絶対パスを埋めない** (`D:/...` `C:\...`)。eval-loop の orchestration は Git Bash + jq を通り、MSYS 自動パス変換が絶対パスを破壊する (実測: `D:/local/...` → `D;C:\Program Files\Git\local\...`)。成果物位置は **cwd 相対**で指定する (例 `out/`)。guided-build には既にこのルールが入っている。
3. **`MSYS2_ARG_CONV_EXCL='*'` を使わない**。変換を全無効化すると native Windows jq が POSIX パス引数のファイルを開けなくなり、orchestration の jq が全滅する。「相対パスで化けさせない」が正解で、guard で殺すのは逆効果。
4. **settings.json を手編集しない**。プラグイン有効化は `/plugin` に任せる。
5. run-eval-loop を Skill 起動したら **init と iter0 を1ターンで完遂**する (init 直後にターンを終えると Stop hook が中途半端な state で発火し state.json が競合する)。
