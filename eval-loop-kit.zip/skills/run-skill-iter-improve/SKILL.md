---
name: run-skill-iter-improve
template: core
description: 既存 skill の品質を反復改善したい場面で発動。PASS 詐欺 / goal-proxy 乖離 / context 汚染 / 評価縮退を構造的に防ぐ。「skill 改善ループ」「meta iter」で発動。
user-invocable: true
argument-hint: "<target-skill-name> <task-args> --goal=\"<真の goal を 1 文>\" [--n=3] [--max-iter=5] [--threshold=90]"
---

# run-skill-iter-improve

target skill の品質を「fresh-context Agent N 並列 → eval 取得 → 弱点 diagnose → target skill ファイル直接 Edit → commit → loop」で反復改善する **メタ skill** (skill が skill を改善する)。

`run-eval-loop` 系 (artifact 単体改善) と違い、改善対象は **target skill の writer-prompt / SKILL.md / scripts そのもの**。

本 skill は skill 改善ループで起きやすい事故を構造的に防ぐ。**この 8 つの不変条件 (INVARIANTS) を破る改善ループは、score がいくら上がっても失敗である。**

## 8 INVARIANTS (これを破ったら即停止・巻き戻し)

1. **PASS 詐欺禁止**: score を上げる手段に「evaluator を緩める / 採点 mode を易しい方に倒す / rubric の閾値を下げる / 採点対象を goal から外す」が含まれていたら、それは改善ではなく詐欺。手段 (target file 編集 / spec・入力編集 / 引数 / 環境変数 / 評価手順そのものの差し替え) を問わず、採点 mode・threshold・採点対象範囲・評価方法を易化するものは全て PASS 詐欺とみなす。Step C/D で毎回自己審問する。
2. **context 汚染回避**: 改善の正否は改善履歴を知らない fresh-context agent にしか判定させない。orchestrator 自身の「前回より良くなった」体感は証拠にしない。
3. **goal ≠ proxy**: score は goal の代理にすぎない。iter 0 で `--goal` を 1 文宣言し、収束時に score でなく goal そのものを fresh agent に検証させる。
4. **構造改善 > 対症療法**: 同じ弱点が複数 sample で再現したら、artifact (個別入力) でなく skill 層 (SKILL.md / writer-prompt / scripts / schema) を直す。
5. **1 iter 1-2 件**: 1 iter で投入する改善は 1-2 件。3 件以上は消化不良で後退する (実証済み: 一括投入で平均 88→72)。
6. **eval-driven commit**: commit は eval data を見てから。speculative な先回り改善は regression の温床。
7. **自己適用安全**: メタ skill が自分自身または親類 skill を改善する場合、エンジン (本 skill) は温存し、被験体は別個体 (コピー) にする。エンジンと被験体を同一にしない。
8. **評価方法の縮退禁止**: 「実走が重い」を理由に成果物の実評価を設計書 (SKILL.md) の静的レビューへ置換するのは、evaluator を緩めるのと同型の PASS 詐欺 (INVARIANT 1 の特殊形)。**学習が実挙動を変えたかは、実走の行動ログ / 成果物でしか判定できない。** 静的レビューは弱点の当たりをつける補助に過ぎず、収束判定の主証拠にしてはならない。PASS 詐欺自己審問 (Step C-5) も orchestrator の自己申告 Yes/No を単一障害点にせず、score 急変 iter では外部 fresh agent に独立判定させる (この skill 自身を dogfood して実観測した事故)。

## WHY

artifact 単体の改善ループは LLM 主観評価 ±3-5pt のブレに律速され平均スコアが plateau に張り付く。skill 自体を改善すれば構造的改善 (prompt rules / script logic / schema 制約) で plateau を 1-2pt 押し上げ + 並列衝突 / orchestrator stall / hallucination 等の実 bug を E2E で discover できる。

**だが skill 改善ループは generator でなく evaluator から腐る。** score を上げる方法は 2 つある — generator を本当に良くするか、evaluator を緩めて score を通すか。後者の方が速く score が上がるので、規律が無いと必ずそちらに流れる (Goodhart の法則)。INVARIANT 1/3 はこの事故への構造防御である。

artifact 改善より skill 改善が効くケース:
- 同 task に対して評価結果が再現性高く plateau (writer-prompt 不足 / source 設計欠落 / Phase 境界 bug)
- ±3-5pt ブレを越える +2pt 以上の structural lift を狙いたい
- 公開向けの skill 品質を堅牢化したい (本番運用 stall や collision を炙り出す)

## 改善対象の階層 (3 層分離 + 構造改善原則)

| 層 | 改善対象 | 担当 skill |
|---|---|---|
| artifact 層 | 個別の生成物 1 つ | `run-eval-loop` 系 |
| **skill 層** | **target の SKILL.md / writer-prompt / scripts / schema** | **本 skill (主スコープ)** |
| rubric 層 | evaluator 自体の盲点 | 本 skill の target を当該 evaluator skill に切替 |

**構造改善原則 (INVARIANT 4)**: 弱点を観測したら「これは 1 つの入力固有か、複数入力で再現するか」を必ず判定する。複数 sample で同じ弱点が出たら、その入力を手で直す (対症療法) のは敗北。skill 層に safety net (defensive guard の自動注入 / schema 制約 / writer-prompt rule) を入れる。1 箇所の skill 改修が全入力に波及する改善だけが plateau を破る。

## アーキテクチャ

```
[target skill + task args + --goal + N + threshold]
        |
iter 0: GOAL DECLARATION (必須、INVARIANT 3)
        |  --goal を 1 文で明文化。「この score は goal の良い代理か?」を
        |  Yes/No + 1 行根拠で記録。No なら rubric 層へ target 切替を検討
        v
1 iter = 1 main turn:
        |
Step A: fan-out (~5s)  — main から N 個の Agent を同一メッセージで並列発火
        v
Step B: block + aggregate (target skill 所要時間)  — file polling で N evals 集計
        v
Step C: diagnose (~30s)  — 共通 weak を 1-2 個 + PASS 詐欺自己審問 (INVARIANT 1)
        v
Step D: edit (~2 min)  — skill 層を 1-2 件修正 (構造改善優先、INVARIANT 4/5)
        v
Step E: commit (~10s)  — eval data 後に 1 ロジック 1 commit (INVARIANT 6)
        v
Step F: loop or stop  — 収束前に GOAL VERIFICATION (score でなく goal、INVARIANT 3)
        v
[improved target skill + iter log + commits + goal-verified 判定]
```

## Input

| パラメータ | 必須 | デフォルト | 説明 |
|---|---|---|---|
| target skill name | Yes | — | 改善対象 (例: SEO ブログ生成 skill) |
| task args | Yes | — | target skill に渡す引数 |
| `--goal` | **Yes** | — | **真の goal を 1 文**。score でなく「人が見て / 使って何が達成されればこの skill は成功か」。INVARIANT 3 の起点 |
| N (parallel agents) | No | 3 | 1 iter あたり並列起動数 |
| max iter | No | 5 | 上限回数 |
| convergence | No | avg ≥ threshold AND goal-verified OR 2 iter +0 | 収束判定 |

## iter 0: GOAL DECLARATION (必須)

ループ開始前に必ず実施する。これを飛ばした改善は INVARIANT 3 違反。

1. `--goal` を 1 文で記録 (例: 「fresh user が書いた spec で、人が見て"使いたい"と思う成果物が安定して出る」)。
2. **proxy 妥当性審問**: 「evaluator の score はこの goal の良い代理か?」を Yes/No + 1 行根拠で記録。
   - No (score が goal の一部しか見ていない) → このループは score を上げても goal に届かない。target を当該 evaluator skill に切り替え rubric を直すのが先。
   - Partial → goal-level の補助検証 (Step F) を必ず有効化。
3. **緩め禁止リスト**を宣言: この target で「これをやったら PASS 詐欺」になる操作を列挙 (例: 採点 mode を易しい方に固定 / threshold を下げる / 採点対象 section を減らす)。**境界定義 (INVARIANT 1)**: 手段が target skill ファイル編集か / spec・入力編集か / 引数か / 環境変数か / 評価手順そのものの差し替えかを問わず、「採点 mode・threshold・採点対象範囲・評価方法を易化して score を通す」効果を持つものは全て緩め禁止操作。spec 経由で evaluator mode を緩い方に固定するのも、実走評価を静的レビューに置換するのも、ここに含む。Step C/D で毎回照合する。

## Step A: fan-out (~5s) — main からのみ

main orchestrator が **同一メッセージ内に N 個の Agent ツール呼び出し** を並列発火。各 Agent prompt の核:

```
あなたは context-fresh agent (この skill の改善履歴を一切知らない前提)。
Skill({skill: "<target>", args: "<task args>"}) を起動し、完走後 work_dir/work/eval-output.json を Read。
さらに **--goal「<goal 文>」が達成されているかを score と独立に 1-100 で自己採点**し、その根拠を 3 行。
**skill ファイル絶対編集禁止** (改善は main の責務)。
報告: overall_score / breakdown / high / medium top3 / 体感弱点 3 行 / goal 達成度 (score と別立て) 3 行。
```

各 Agent は `run_in_background: true` で投げ、完了通知を別ターンで受ける。

**重要制約**:
- `Skill → Agent 不可` — 本 skill 自体が Skill 経由で呼ばれた場合 Agent ツールが使えない。**`context: main` でのみ動く**
- `Agent 並列可、Skill 直列のみ` — 並列性は Agent 層で確保
- **INVARIANT 2**: Agent prompt に必ず「改善履歴を知らない前提」を明記。orchestrator の体感を混ぜない

## Step B: block + aggregate (target skill 所要時間)

ファイル polling ループを `Bash(run_in_background=true)` で起動して N evals 完了を待つ:

```bash
until [ $(ls output/<work-dir-prefix>*/work/eval-output.json 2>/dev/null | wc -l) -ge N ] \
   || [ $(date +%s) -ge $deadline ]; do
  sleep 60
done
```

完了後、各 eval-output.json から `overall_score` + `breakdown` + `feedback_structured.high`/`medium` を集計。**加えて各 Agent の goal 達成度 (score と別立て) を集計** — score 平均と goal 平均が乖離していたら INVARIANT 3 の警告。

**TaskOutput 多重 block は禁止** — 複数 BG task を `block=true` で同時 wait すると orchestrator が無限 stall。必ずファイル polling を使う。

## Step C: diagnose (~30s) — PASS 詐欺自己審問を含む

集計結果から:

1. **N runs 共通の weak observation** を 1-2 個に絞る
2. **直近 iter からの変化** (新発見 / 再現 / 解決) を 1 行で
3. **構造改善判定 (INVARIANT 4)**: その weak は 1 入力固有か / 複数 sample 再現か。再現なら artifact でなく skill 層に safety net を入れる方向で改善対象ファイルを特定
4. **rubric 起因の疑い**: 同 weak が 3 iter 連続で出て Step D の直接修正でも +0pt なら rubric 側 bug を 8 割疑う。target を当該 evaluator skill に切替
5. **★ PASS 詐欺自己審問 (INVARIANT 1、必須・毎 iter)**: これから打つ改善案について次を Yes/No で自問し記録する:
   - 「この改善は generator (成果物を作る側) を良くするか? それとも evaluator を緩める / 採点を易しくする / 緩め禁止リストの操作か?」
   - 後者なら **その改善は破棄**。score が上がっても INVARIANT 1 違反。別の generator 改善を探す
   - score が前 iter から急上昇 (例 +15pt 超) した場合、上昇が generator 改善由来か evaluator 緩和由来かを必ず切り分けて記録
   - **★ 外部独立判定 (INVARIANT 8、自己申告を単一障害点にしない)**: 自己審問の Yes/No だけで確定しない。次のいずれかに該当する iter は、その改善 diff を **fresh agent に渡し「generator 改善か / 評価を緩める操作か」を独立判定**させ、自己審問と一致するか照合する: (a) score が +10pt 超急上昇、(b) 改善が評価経路・mode・閾値・採点対象・評価手順・収束条件・Step F/C ロジックに触れる、(c) orchestrator が「速く回したい」動機を自覚した時。**(b) は客観条件であり (c) の自覚有無に関わらず必須** ((c) 自己申告を最後の砦にしない。評価経路に触れる改善は自覚を申告しなくても (b) で必ず起動する)。独立判定が「緩め」と出たら自己審問より外部判定を優先し破棄。**判定者独立性 (必須)**: この外部判定 fresh agent は Step F-2 GOAL VERIFICATION の fresh agent と **別個体**。同一 agent 兼任不可・履歴非共有・orchestrator は結論を予見させる情報 (期待する答え / 改善履歴 / score) を渡さない

## Step D: edit (~2 min)

orchestrator が target skill のファイルを Edit ツールで直接修正。**1 iter で投入する改善は 1-2 件に絞る** (INVARIANT 5、3 件以上は消化不良で後退):

- writer-prompt の追加 rule (用語リスト数 / Self-review 項目 / 期待出力規約 等)
- SKILL.md の手順明文化 (stall / collision 対策の defensive 規範)
- scripts の bug fix / **defensive guard の自動注入** (構造改善、INVARIANT 4)
- schema の制約強化 (mode enum / required fields 等)

**禁止**: evaluator skill / rubric / 採点 mode を「score を通すために」緩める編集 (INVARIANT 1)。rubric が goal の悪い代理だと判明した場合は、それは「緩める」のではなく「goal に寄せて作り直す」改善であり、target を evaluator skill に切り替えて別途行う。

## Step E: commit (~10s)

ロジック単位で `git add` + `git commit`。message に iter N / どの run / どの finding (観測根拠) / 期待効果。複数ロジックを 1 commit に混ぜない (revert 可能性を保つ)。**commit は eval data 後** (INVARIANT 6)。

## Step F: loop or stop — GOAL VERIFICATION 必須

収束判定は 2 段。**score だけで停止してはいけない (INVARIANT 3)。**

1. **score gate**: avg overall ≥ threshold か / max iter 到達か / 連続 2 iter +0 か
2. **★ GOAL VERIFICATION (必須)**: score gate を通っても、停止前に fresh agent 1 体に「score を見ず、--goal「<goal 文>」が達成されているか」だけを判定させる。**判定プロトコル (合否基準を曖昧にしない)**:
   - 入力: fresh agent に target を実走させた **成果物 / 行動ログ実体** を渡す (SKILL.md の静的レビューで代替しない — INVARIANT 8)。score・breakdown・改善履歴は渡さない
   - **判定者独立性 (必須)**: この GOAL VERIFICATION agent は Step C-5 外部独立判定 agent と別個体。同一 agent 兼任不可・履歴非共有
   - 出力契約: `PASS | FAIL` の二値 + 1 行根拠 + **blocker 列挙** (goal に対して何が欠けているか)。「点数」は出させない (proxy 化を防ぐ)
   - 合否: blocker が 1 つでも残れば **FAIL**。全 blocker が解消されて初めて PASS
   - goal 達成 (PASS) → **真の収束、停止**
   - score は閾値超だが FAIL → **PASS 詐欺の疑い**。blocker を次 iter の改善対象にしてループ続行 (score gate は無視)
   - max iter 到達かつ FAIL → 停止するが「score X / goal FAIL / 残 blocker: ...」と明示報告 (INVARIANT 3、前提を隠さない)

停止時の最終出力:
- 全 iter scores summary (iter N / N samples / avg / range) **+ goal 達成度の推移**
- 全 commits 一覧 (commit hash + 1 行要約)
- **PASS 詐欺自己審問ログ** (各 iter で何を破棄したか)
- 残課題 (plateau 突破に必要な structural change の候補)
- **評価の前提明示**: 最終 score が「どの mode / どの rubric / どの前提」で出たかを 1 段落で明記 (同一成果物が文脈で点数割れするのを防ぐ)

issue 更新 / close / push は呼び元責務。

## Self-application safety (INVARIANT 7)

本 skill またはその親類 skill (skill 改善メタ skill) を改善対象にする場合:

- **エンジンと被験体を分離**: 改善ループを駆動する skill (エンジン) は変更せず温存。改善されるのは別個体のコピー (被験体)。同一ファイルをエンジン兼被験体にすると、改善の途中で壊れたエンジンが自分を壊し続け、検証手段ごと失う
- **被験体の評価は実走の行動ログ / 成果物ベースで行う (INVARIANT 8、最重要)**: 「実走の二重メタは重い」を理由に *fresh agent に SKILL.md を読ませて INVARIANT 耐性を rubric 採点させる静的レビュー* を主評価にしてはならない。これは評価方法そのものを proxy にすり替える PASS 詐欺であり、本 skill を dogfood した際に orchestrator が実際にこの罠に落ちた (= 実観測事故)。歯止めは質的宣言でなく以下の量的・必須ルールで固定する:
  - **静的レビューの収束寄与はゼロ (量的境界)**: 静的レビューは弱点の当たり付けにのみ用い、収束 PASS|FAIL の根拠に 1 文字も使わない。「補助として薄く添える」体で実質 rubric 平均が判断を駆動するグレー運用も禁止 (収束判定への寄与重み = 実走行動ログ/成果物 100% / 静的レビュー 0%)
  - **軽量実走でも対照群は必須 (推奨でない)**: 二重メタが重いなら被験体を軽量 target で 1 iter だけ実走でよいが、**必ず対照群 (エンジン版に同一シナリオを実走) を取り行動差分で判定**する。対照無しの単発実走で「INVARIANT が発火した」と orchestrator が自己申告するのは INVARIANT 8 違反 (発火の有無は差分でのみ客観判定できる)
  - **軽量実走の判定は Step F-2 契約を適用**: 軽量実走ログの合否も orchestrator が自己判定せず、Step F-2 の独立 fresh agent + `PASS|FAIL` + blocker 列挙契約に従う (Self-application 文脈でも Step F-2 と同一規律)
- 改善が一巡したら、被験体をオリジナルに昇格するか別 skill として残すかは呼び元が決める (skill カタログ汚染を避けるため迂闊に増やさない)

## Gotchas

- **`context: main` 必須** — Skill → Agent 不可制約。常に main から起動
- **TaskOutput 多重 block 禁止** — ファイル polling に切り替える
- **同題材並列実行は collision** — target 側 init で mktemp -d (random suffix) 必須。無ければ最初の iter で必ず fix
- **LLM 主観評価は ±3-5pt ブレ** — 1-2pt 上下は noise、3pt 以上の連続 or breakdown structural 変化を真の signal とする
- **score 急上昇を疑え** — +10pt 超の急上昇は generator 改善より evaluator 緩和の方が起こしやすい。Step C で必ず由来を切り分ける (INVARIANT 1)
- **plateau 構造を認識** — writer-prompt 単独で 90+ は構造的に困難。multi-evaluator ensemble / model swap / source 深度 等の structural change を別 iter で
- **1 iter 1-2 件厳守** (INVARIANT 5) — 3 件以上の同時投入は消化不良で後退 (実証)
- **/goal hook 併用推奨** — ループを 1 turn で完結させない場合、Stop hook が「skill を改善し続ける」条件で turn を切らせない
- **commit は eval data 後** (INVARIANT 6) — speculative な先回りは regression の温床
- **plateau 2 iter 連続時は variant 化** — N agents を同 prompt でなく model swap / persona / source depth / 文字数帯で variant 化して再 iter
- **rubric bug を疑う閾値** — 3 iter 連続同 high feedback かつ直接修正で +0pt なら rubric bug を 8 割疑う。target を evaluator skill に切替
- **goal と score の乖離を常に監視** (INVARIANT 3) — score 平均と goal 平均が iter を追って開いていく場合、generator でなく評価が壊れている兆候

## Additional resources

- `ref-agent-skill` — skill 設計の 4 軸 + 決定木
- `ref-skill-component-design` — skill の構造規約 + ペア / 三組制約
- `run-eval-loop` 系 — 1 agent がシーケンシャルに単体 artifact を改善するループ (本 skill との対比軸: あちらは生成物 1 つ、本 skill は skill そのものを改善)

---

## 汎用 skill への適用 (eval-loop 系以外を磨くとき — kit ローカル追記)

本 skill の Step A は既定で「target を実走 → `work_dir/work/eval-output.json` を Read」を前提とする (eval-loop 系 target 向け)。**eval-output.json を出さない汎用 skill を磨くときは、fan-out Agent に成果物を self-score させる** ([[empirical-prompt-tuning]] と同型)。fan-out Agent プロンプト雛形:

```
あなたは context-fresh agent（この skill の改善履歴を一切知らない前提）。
1. <target skill の SKILL.md 絶対パス> を Read し、その指示に忠実にだけ従って成果物を生成する（裁量で"良く"しない）。
2. 生成物を --goal「<goal 文>」に対して 1-100 で自己採点する（根拠3行）。
3. 客観計測（goal に紐づく定量指標）を出す。
skill ファイルは絶対に編集しない（改善は main の責務）。
報告: 成果物 / 計測 / goal達成度(1-100)+根拠3行 / 体感弱点top3
```

集計 (Step B) → 診断 (Step C) → skill を直接 Edit (Step D) → 再走 (Step F) は本文のプロトコルをそのまま使う。**Agent ツールが要る＝context:main で起動する** (Skill 経由の入れ子起動では Agent が使えない)。tmux は不要。

## Attribution / 出所

- **Source**: `anti-goodhart-main` repo (`D:\Downloads\anti-goodhart-main` から取り込み)。**作者・ライセンス明示なし** — 再配布/商用は要確認、個人利用の範囲で使用すること。
- **兄弟 skill**: `run-skill-live-trial`(tmux版, Windows不可) の代替として本 kit は [[project-windows-live-trial-sdk]] を同梱。iter-improve は tmux 非依存なので本体をそのまま使える。
- **動作検証済み (2026-07-02, Windows 実セッション)**: 汎用被験体 tweet-writer で goal 56.5→88 (2サンプル再現)。fan-out(Agentツール, tmux不要)→集計→診断(PASS詐欺自己審問込み)→skill 自動 Edit→再走で改善確認、まで全 Step 機能を確認。
