---
name: run-skill-live-trial-sdk
description: skill を別プロセスの fresh headless セッション(Claude Code SDK query())で実走させ、受け入れ確認する Windows ネイティブ acceptance harness。tmux 不要。「skill 実走確認」「live trial」「受け入れ確認」で発動。
user-invocable: true
argument-hint: "<name|plugin:skill> --cwd <abs> [--args ...] [--marker <相対パス>] [--goal \"<1文>\"]"
---

# run-skill-live-trial-sdk

対象 skill を **別プロセスの fresh headless Claude セッション**(`@anthropic-ai/claude-code` の `sdk.mjs` `query()`)で実走させ、期待どおり動くか(受け入れ)を確認する。tmux 版 `run-skill-live-trial` が Windows で動かない問題を、SDK headless で置き換えたもの(実測で確立)。

## スコープ (実測に基づく — 誇張しない)

**できる**: 自己完結 skill を headless で起動 → plain-text 質問 gate を `--answer`(既定「推奨で」)で自動応答(resume) → 完了マーカー/成果物の出現で完走判定 → 任意で fresh agent が goal 適合を独立判定。

**できない (実測済みの限界。ここを守らないと誤検証)**:
- **`AskUserQuestion` は headless に存在しない** → 対象 skill は plain-text + 推奨形式で質問する設計にする(そうでない gate は再現不能)。
- **eval-loop 系の Stop hook 自走は headless で arm されない** → 自走 acceptance はこの harness では不可。実アプリセッションで確認する。
- **自然文 auto-trigger は raw headless では発火しない** → `--trigger-check` で枠組みを注入し description 品質のみ測る(実発火の最終確認は実アプリ)。

判断: 「対象 skill が Skill を入れ子で呼ぶ/Stop hook で自走する」なら本 harness では届かない領域がある。自己完結・plain-text gate の skill が主対象。

## 前提

- **node** が PATH にあること(この harness にのみ必要)。`sdk.mjs` は `npm root -g`/@anthropic-ai/claude-code から自動解決。見つからなければ環境変数 `CLAUDE_SDK` に絶対パスを指定。
- 対象 skill が project skill なら `--cwd` をそのプロジェクトルートにする(cwd=root で slash_commands に載る)。

## 手順

1. 引数から target skill / args / cwd / marker / goal を決める。**marker は cwd 相対**(絶対パスは MSYS 変換で壊れる原則と同じ思想で相対推奨)。
2. ドライバを実行する(`<skill-dir>` は本 SKILL.md のあるディレクトリ):

```bash
node "<skill-dir>/scripts/live-trial-sdk.mjs" \
  --skill "<name|plugin:skill>" \
  --cwd "<abs project dir>" \
  --args "<skill args>" \
  --marker "<cwd相対の完了マーカー 例: goal.json>" \
  --goal "<受け入れ基準を 1 文>" \
  --answer "推奨で" --max-turns 6
```

3. 標準出力の JSON レポートを読む:
   - `skill_invoked` … SlashCommand で起動できたか
   - `investigated_codebase` … 質問前に調査したか(該当 skill のみ意味あり)
   - `question_turns` … plain-text gate を何回自動応答したか
   - `marker_present` … 完了マーカー/成果物が出たか
   - `goal_verdict` … (goal 指定時)fresh agent の `SCORE/VERDICT`
   - `verdict` … `PASS` / `REVIEW`
4. `verdict: REVIEW` なら stderr の各ターン tail を読み、どこで止まったか(未起動/質問ループ/マーカー未出)を切り分けて報告する。

## auto-trigger の description チェック (任意)

自然文で狙いどおり発火するかの品質確認(枠組み注入):

```bash
node "<skill-dir>/scripts/live-trial-sdk.mjs" --skill "<name>" --cwd "<abs>" --trigger-check "<自然文の依頼>"
```

`fired` が非 null なら、その枠組み下で description が正しくマッチしている。

## Gotchas

- **marker はワイルドカードにしない**。中間生成物で偽陽性になる。完了時に1つだけ書かれるファイル(例 `goal.json`)を指す。
- **対象 skill が AskUserQuestion を使うと gate を越えられない**。plain-text 質問形式の skill を対象にする。
- **eval-loop 系は対象外**(headless で arm されない)。実アプリセッションで受け入れる。
- SDK パッケージ `@anthropic-ai/claude-code` は将来 `@anthropic-ai/claude-agent-sdk` へ移行予定。解決に失敗したら `CLAUDE_SDK` で新パッケージの sdk を指す。
