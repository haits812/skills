#!/usr/bin/env node
// live-trial-sdk.mjs — Windows ネイティブ skill 受け入れ確認ドライバ (tmux 不要)
//
// Claude Code SDK (@anthropic-ai/claude-code の sdk.mjs) の query() で、対象 skill を
// 別プロセスの fresh headless セッションで実走させ、受け入れ確認する。
// 実証済みパターン (eval-loop-sandbox の smoke6/smoke8) を汎用化したもの。
//
// できること: 自己完結 skill を headless で起動→plain-text 質問 gate を --answer で自動応答(resume)
//             →完了マーカー/成果物の出現で完走判定→(任意)fresh agent で goal 適合を独立判定。
// できないこと(実測): (1)AskUserQuestion は headless に存在しない→対象 skill は plain-text 質問形式にする。
//             (2)eval-loop 系の Stop hook 自走は headless で arm されない→自走 acceptance は実セッションで。
//             (3)自然文 auto-trigger は raw headless では発火しない(--trigger-check で枠組み注入して description 品質のみ測る)。
//
// Usage:
//   node live-trial-sdk.mjs --skill "<name|plugin:skill>" --cwd "<abs project dir>" \
//        [--args "<skill args>"] [--marker "<cwd相対の完了マーカーパス>"] [--goal "<1文>"] \
//        [--answer "推奨で"] [--max-turns 6] [--per-turn-max 30] [--trigger-check "<自然文>"]
//
// SDK 解決: 環境変数 CLAUDE_SDK でパス直指定可。無ければ `npm root -g`/@anthropic-ai/claude-code/sdk.mjs を探す。

import { existsSync } from "node:fs";
import { join } from "node:path";
import { execSync } from "node:child_process";
import { pathToFileURL } from "node:url";

function parseArgs(argv) {
  const o = {};
  for (let i = 0; i < argv.length; i += 2) {
    const k = argv[i];
    if (!k?.startsWith("--")) continue;
    o[k.slice(2)] = argv[i + 1];
  }
  return o;
}

function resolveSdk() {
  if (process.env.CLAUDE_SDK && existsSync(process.env.CLAUDE_SDK)) return process.env.CLAUDE_SDK;
  const candidates = [];
  try {
    const gr = execSync("npm root -g", { encoding: "utf8" }).trim();
    candidates.push(join(gr, "@anthropic-ai", "claude-code", "sdk.mjs"));
  } catch {}
  try {
    // nvm-windows: node_modules は node バイナリと同階層
    const nodeDir = join(process.execPath, "..");
    candidates.push(join(nodeDir, "node_modules", "@anthropic-ai", "claude-code", "sdk.mjs"));
  } catch {}
  for (const c of candidates) if (existsSync(c)) return c;
  throw new Error(
    "sdk.mjs が見つかりません。CLAUDE_SDK 環境変数で絶対パスを指定してください。探索: " + candidates.join(" , ")
  );
}

const a = parseArgs(process.argv.slice(2));
if (!a.skill || !a.cwd) {
  console.error("ERROR: --skill と --cwd は必須");
  process.exit(2);
}
const SKILL = a.skill;
const CWD = a.cwd;
const ARGS = a.args ?? "";
const MARKER = a.marker ? join(CWD, a.marker) : null;
const GOAL = a.goal ?? "";
const ANSWER = a.answer ?? "推奨で";
const MAX_TURNS = Number(a["max-turns"] ?? 6);
const PER_TURN_MAX = Number(a["per-turn-max"] ?? 30);
const TRIGGER = a["trigger-check"] ?? "";

const sdkPath = resolveSdk();
const { query } = await import(pathToFileURL(sdkPath).href);

const usedTools = []; // 実イベントストリーム(assistant tool_use)から採取 = 正確
async function canUseTool(name, input) {
  return { behavior: "allow", updatedInput: input };
}

function isQuestion(text) {
  return /###\s*Q\d/.test(text) || /推奨\s*[:：]/.test(text) || /[?？]\s*$/.test(text.trim());
}

async function drive() {
  let sessionId = null;
  let questionTurns = 0;
  let done = false;
  let lastText = "";

  for (let t = 0; t < MAX_TURNS && !done; t++) {
    const first = t === 0;
    const prompt = first
      ? `SlashCommand ツールで "/${SKILL}${ARGS ? " " + ARGS : ""}" を実行し、その skill の手順に忠実に従って最後まで自走してください。` +
        `途中で人間に質問せず、判断が要る所は skill の推奨に従って進めてください。`
      : `${ANSWER}。続けて、完了条件を満たすまで自走してください。`;
    const opts = { cwd: CWD, maxTurns: PER_TURN_MAX, canUseTool };
    if (sessionId) opts.resume = sessionId;

    const q = query({ prompt, options: opts });
    let turnText = "";
    let resultText = "";
    for await (const msg of q) {
      if (msg.type === "system" && msg.subtype === "init") sessionId = msg.session_id;
      if (msg.type === "assistant") {
        for (const b of msg.message?.content ?? []) {
          if (b.type === "tool_use") { usedTools.push(b.name); console.error(`  [tool] ${b.name} ${JSON.stringify(b.input).slice(0, 90)}`); }
          else if (b.type === "text" && b.text.trim()) turnText = b.text;
        }
      }
      if (msg.type === "result") resultText = msg.result || "";
    }
    lastText = turnText + "\n" + resultText;
    console.error(`── turn ${t} tail: ${lastText.slice(-160).replace(/\n/g, " ")}`);

    if (MARKER && existsSync(MARKER)) { done = true; break; }
    if (isQuestion(lastText)) { questionTurns++; continue; }
    done = true; // 質問でも未完でもない → 完走扱い
  }

  const invoked = usedTools.includes("SlashCommand");
  const investigated = usedTools.some((n) => ["Bash", "Glob", "Grep", "Read"].includes(n));
  const markerOk = MARKER ? existsSync(MARKER) : null;

  const report = {
    skill: SKILL,
    cwd: CWD,
    sdk: sdkPath,
    skill_invoked: invoked,
    investigated_codebase: investigated,
    question_turns: questionTurns,
    tools_used: [...new Set(usedTools)],
    marker: MARKER,
    marker_present: markerOk,
    goal: GOAL || null,
    goal_verdict: null,
  };

  // 任意: goal 適合を fresh agent に独立判定させる (成果物マーカーの中身を渡す)
  if (GOAL && markerOk) {
    const q = query({
      prompt:
        `次のファイル ${MARKER} を Read し、「${GOAL}」が達成されているかを score(0-100) と PASS/FAIL で判定して。` +
        `出力は必ず "SCORE:<n> VERDICT:<PASS|FAIL> 理由:<1行>" の1行だけ。`,
      options: { cwd: CWD, maxTurns: 4, canUseTool },
    });
    let jt = "";
    for await (const msg of q) if (msg.type === "result") jt = msg.result || "";
    report.goal_verdict = jt.trim().slice(0, 200);
  }

  const pass = invoked && (markerOk === null || markerOk === true) &&
    (!GOAL || /VERDICT:\s*PASS/i.test(report.goal_verdict || ""));
  report.verdict = pass ? "PASS" : "REVIEW";

  console.log(JSON.stringify(report, null, 2));
  process.exit(0);
}

// 任意: 自然文 auto-trigger の description 品質チェック (枠組み注入版。raw headless は auto-trigger 非再現)
async function triggerCheck() {
  const framing =
    `利用可能な user skill があり、ユーザーのリクエストが skill の目的に一致する場合、` +
    `他の応答より先に SlashCommand ツールで "/<skill名>" を起動すること。一致しなければ通常対応。`;
  const q = query({ prompt: TRIGGER, options: { cwd: CWD, maxTurns: 2, canUseTool, appendSystemPrompt: framing } });
  for await (const msg of q) {
    if (msg.type === "assistant") {
      for (const b of msg.message?.content ?? []) {
        if (b.type === "tool_use" && b.name === "SlashCommand") {
          console.log(JSON.stringify({ trigger_check: TRIGGER, fired: JSON.stringify(b.input) }, null, 2));
          process.exit(0);
        }
      }
    }
    if (msg.type === "result") break;
  }
  console.log(JSON.stringify({ trigger_check: TRIGGER, fired: null }, null, 2));
  process.exit(0);
}

(TRIGGER ? triggerCheck() : drive()).catch((e) => {
  console.error("FATAL", e?.message || e);
  process.exit(1);
});
