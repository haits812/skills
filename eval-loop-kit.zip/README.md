# eval-loop-kit

別 PC に「eval-loop 品質ループ + 自然文発火フロント」を丸ごと移植するためのキット。

## 使い方 (超要約)

1. この zip を任意の場所に展開する。
2. その PC で Claude Code を開き、**`setup.md` を Claude に見せて「これに従ってセットアップして」**と言う。
3. Claude が手順を実行し、最後に「Claude Code を再起動して」と言うので再起動する。
4. 任意のフォルダで「〇〇作りたい」と投げれば、要件確定 → 品質ループまで自走する。

詳細・注意点はすべて [setup.md](./setup.md) にある。

## 中身

| パス | 中身 |
|---|---|
| `setup.md` | **セットアップ手順 (Claude 実行用ランブック)。これが主役。** |
| `skills/guided-build/` | 「作りたい」で発火する dispatcher スキル |
| `skills/clarify-goal/` | 曖昧ゴールを確定する clarify スキル |
| `skills/run-skill-live-trial-sdk/` | skill を fresh headless セッションで実走・受け入れ確認する Windows ネイティブ harness (tmux 不要, node 必須) |
| `skills/run-skill-iter-improve/` | skill を fresh Agent 並列実走→診断→自動 Edit で反復改善するメタ skill (道具のメンテ, tmux 不要, git 推奨, 出所 anti-goodhart) |
| `eval-loop-marketplace/` | eval-loop プラグイン (marketplace 同梱・版固定 0.1.0) |

## 前提

git / jq / bash (Windows は Git Bash) / python が必須。**node は `run-skill-live-trial-sdk` を使う場合のみ必須**(ランタイム本体は node 不要)。

## 最重要の落とし穴

- eval-loop プラグインは **user スコープ**で入れる (project スコープだと別フォルダで `Unknown skill`)。
- eval-loop に渡す task に **Windows 絶対パスを埋めない** (Git Bash の MSYS 変換で壊れる)。相対パスで。

いずれも setup.md に詳述。
