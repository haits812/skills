"use strict";

const fs = require("fs");
const path = require("path");
const PptxGenJS = require("pptxgenjs");
const { PERSOL_THEME } = require("../assets/pptx-starter/persol-theme");

const ROOT = path.join(__dirname, "..");
const OUTPUT_ROOT = path.join(ROOT, "output");
const IMAGE_MODE = (process.env.PERSOL_IMAGE_MODE || "path").toLowerCase();
const DECK_BASENAME = process.env.DECK_BASENAME || "persol-template-starter";

const pptx = new PptxGenJS();
pptx.layout = PERSOL_THEME.layout;
pptx.author = "Codex";
pptx.company = "OpenAI";
pptx.subject = "PERSOL slide template starter";
pptx.title = "PERSOL Template Starter";
pptx.lang = "ja-JP";
pptx.theme = {
  headFontFace: PERSOL_THEME.fonts.title,
  bodyFontFace: PERSOL_THEME.fonts.body,
  lang: "ja-JP",
};

const ShapeType = pptx.ShapeType;
const C = PERSOL_THEME.colors;
const F = PERSOL_THEME.fonts;
const A = PERSOL_THEME.archetypes;
const S = PERSOL_THEME.structuralPanels;

function timestampToken() {
  const now = new Date();
  const pad = (value) => String(value).padStart(2, "0");
  return [
    now.getFullYear(),
    pad(now.getMonth() + 1),
    pad(now.getDate()),
  ].join("") + "-" + [pad(now.getHours()), pad(now.getMinutes())].join("");
}

function resolveRunOutputDir(outputRoot, requestedBaseName) {
  if (!fs.existsSync(outputRoot)) {
    fs.mkdirSync(outputRoot, { recursive: true });
  }

  const baseFolderName = `${timestampToken()}-${requestedBaseName}`;
  let counter = 1;
  let candidateDir = path.join(outputRoot, baseFolderName);
  while (fs.existsSync(candidateDir)) {
    counter += 1;
    candidateDir = path.join(outputRoot, `${baseFolderName}-${String(counter).padStart(2, "0")}`);
  }
  fs.mkdirSync(candidateDir, { recursive: true });
  return candidateDir;
}

function inferMimeType(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  if (ext === ".jpg" || ext === ".jpeg") return "image/jpeg";
  if (ext === ".svg") return "image/svg+xml";
  return "image/png";
}

function imageSource(relativePath) {
  const absolutePath = path.join(ROOT, relativePath);
  if (IMAGE_MODE === "base64") {
    const mimeType = inferMimeType(absolutePath);
    const base64 = fs.readFileSync(absolutePath).toString("base64");
    return { data: `${mimeType};base64,${base64}` };
  }
  return { path: absolutePath };
}

function addFooter(slide, pageNo, showBrand = true) {
  if (showBrand) {
    slide.addImage({
      ...imageSource(path.join("assets", "logo", "persol-logo-small.png")),
      x: PERSOL_THEME.pageFurniture.topRightBrandImage.x,
      y: PERSOL_THEME.pageFurniture.topRightBrandImage.y,
      w: PERSOL_THEME.pageFurniture.topRightBrandImage.w,
      h: PERSOL_THEME.pageFurniture.topRightBrandImage.h,
    });
  }

  slide.addText("Copyright © PERSOL HOLDINGS CO., LTD. All Rights Reserved.", {
    x: PERSOL_THEME.pageFurniture.copyright.x,
    y: PERSOL_THEME.pageFurniture.copyright.y,
    w: PERSOL_THEME.pageFurniture.copyright.w,
    h: 0.15,
    fontFace: F.numeric,
    fontSize: 7.5,
    color: C.footerGray,
    align: "center",
    margin: 0,
  });

  slide.addText(String(pageNo), {
    x: PERSOL_THEME.pageFurniture.pageNo.x,
    y: PERSOL_THEME.pageFurniture.pageNo.y,
    w: PERSOL_THEME.pageFurniture.pageNo.w,
    h: PERSOL_THEME.pageFurniture.pageNo.h,
    fontFace: F.numeric,
    fontSize: 9,
    color: C.footerGray,
    align: "right",
    margin: 0,
  });
}

function addStandardFrame(slide, pageNo) {
  slide.background = { color: C.white };
  slide.addShape(ShapeType.rect, {
    x: 0,
    y: 0,
    w: 0.05,
    h: 7.5,
    line: { color: C.frameGray, transparency: 100 },
    fill: { color: C.frameGray },
  });
  addFooter(slide, pageNo);
}

function addMeasuredRightPanel(slide, fillColor) {
  slide.addShape(ShapeType.custGeom, {
    x: S.rightPanelPolygon.x,
    y: S.rightPanelPolygon.y,
    w: S.rightPanelPolygon.w,
    h: S.rightPanelPolygon.h,
    points: S.rightPanelPolygon.points,
    line: { color: fillColor, transparency: 100 },
    fill: { color: fillColor },
  });
}

function addCoverSlide() {
  const slide = pptx.addSlide();
  slide.background = { color: C.white };
  addMeasuredRightPanel(slide, C.panelGray);

  slide.addImage({
    ...imageSource(path.join("assets", "logo", "persol-logo-lockup.png")),
    x: A.cover.logoLockup.x,
    y: A.cover.logoLockup.y,
    w: A.cover.logoLockup.w,
    h: A.cover.logoLockup.h,
  });

  slide.addText("FY2026 Q2 サンプル資料", {
    x: A.cover.title.x,
    y: A.cover.title.y,
    w: A.cover.title.w,
    h: A.cover.title.h,
    fontFace: F.title,
    fontSize: A.cover.title.fontSize,
    bold: true,
    color: C.darkGray,
    margin: 0,
  });
  slide.addText("2026年4月16日", {
    x: A.cover.metaDate.x,
    y: A.cover.metaDate.y,
    w: A.cover.metaDate.w,
    h: A.cover.metaDate.h,
    fontFace: F.body,
    fontSize: A.cover.metaDate.fontSize,
    color: C.darkGray,
    align: "right",
    margin: 0,
  });
  slide.addText("Template Strategy Office", {
    x: A.cover.metaCompany.x,
    y: A.cover.metaCompany.y,
    w: A.cover.metaCompany.w,
    h: A.cover.metaCompany.h,
    fontFace: F.body,
    fontSize: A.cover.metaCompany.fontSize,
    color: C.darkGray,
    align: "right",
    margin: 0,
  });
  addFooter(slide, 1, false);
}

function addSummaryBulletSlide() {
  const slide = pptx.addSlide();
  addStandardFrame(slide, 2);
  slide.addText("主メッセージ + 箇条書き", {
    x: A.standardContent.title.x,
    y: A.standardContent.title.y,
    w: 7.2,
    h: A.standardContent.title.h,
    fontFace: F.title,
    fontSize: A.standardContent.title.fontSize,
    bold: true,
    color: C.black,
    margin: 0,
  });

  slide.addShape(ShapeType.rect, {
    x: A.textSummaryBullets.summaryBand.x,
    y: A.textSummaryBullets.summaryBand.y,
    w: A.textSummaryBullets.summaryBand.w,
    h: A.textSummaryBullets.summaryBand.h,
    line: { color: C.aquaTint, transparency: 100 },
    fill: { color: "#ECEBE8" },
  });
  slide.addText("右画像が不要なときは、灰色帯に1つの結論を書いて、下に補足箇条書きを積む", {
    x: A.textSummaryBullets.summaryText.x,
    y: A.textSummaryBullets.summaryText.y,
    w: A.textSummaryBullets.summaryText.w,
    h: A.textSummaryBullets.summaryText.h,
    fontFace: F.title,
    fontSize: A.textSummaryBullets.summaryText.fontSize,
    bold: true,
    color: C.darkGray,
    margin: 0,
  });

  const bullets = [
    "ロゴや右画像は imageSource() を経由して呼ぶ",
    "PERSOL_IMAGE_MODE=path が既定。画像パスで通る環境ならそのままでよい",
    "画像パスが壊れる sandbox では PERSOL_IMAGE_MODE=base64 へ切り替える",
    "表紙の灰色パネルや章扉の斜めは画像ではなく native shape で描く",
  ];
  bullets.forEach((text, index) => {
    const y = A.textSummaryBullets.bodyY + index * A.textSummaryBullets.rowGap;
    slide.addShape(ShapeType.rect, {
      x: A.textSummaryBullets.bodyX,
      y: y + 0.08,
      w: 0.08,
      h: 0.08,
      line: { color: C.aqua, transparency: 100 },
      fill: { color: C.aqua },
    });
    slide.addText(text, {
      x: A.textSummaryBullets.bodyX + 0.18,
      y,
      w: A.textSummaryBullets.bodyW,
      h: 0.26,
      fontFace: F.body,
      fontSize: 13,
      bold: true,
      color: C.black,
      margin: 0,
    });
  });
}

function addTextImageSlide() {
  const slide = pptx.addSlide();
  addStandardFrame(slide, 3);
  slide.addText("テキスト + 右画像", {
    x: A.standardContent.title.x,
    y: A.standardContent.title.y,
    w: 6.0,
    h: A.standardContent.title.h,
    fontFace: F.title,
    fontSize: A.standardContent.title.fontSize,
    bold: true,
    color: C.black,
    margin: 0,
  });

  slide.addShape(ShapeType.rect, {
    x: A.textImageAside.summaryBand.x,
    y: A.textImageAside.summaryBand.y,
    w: A.textImageAside.summaryBand.w,
    h: A.textImageAside.summaryBand.h,
    line: { color: C.aquaTint, transparency: 100 },
    fill: { color: "#ECEBE8" },
  });
  slide.addText("右カラム画像もロゴと同じく imageSource() で path / base64 を切り替える", {
    x: 1.0,
    y: 1.12,
    w: 10.2,
    h: 0.28,
    fontFace: F.title,
    fontSize: 16,
    bold: true,
    color: C.darkGray,
    margin: 0,
  });

  const bullets = [
    {
      title: "画像パスで動くなら、assets/ を一緒に持ち込むだけで済む",
      sub: "・ローカル Node 実行ではこの運用が最も軽い",
    },
    {
      title: "base64 に切り替えると、画像ファイル参照なしで同じ deck を出せる",
      sub: "・ただしコードサイズは増えるので、必要時だけ使う",
    },
    {
      title: "灰色パネルは shape のまま維持し、画像にしない",
      sub: "・テンプレの再現性と編集性が落ちない",
    },
  ];
  bullets.forEach((item, index) => {
    const y = A.textImageAside.bodyY + index * 0.82;
    slide.addShape(ShapeType.rect, {
      x: 0.95,
      y: y + 0.08,
      w: 0.08,
      h: 0.08,
      line: { color: C.aqua, transparency: 100 },
      fill: { color: C.aqua },
    });
    slide.addText(item.title, {
      x: 1.12,
      y,
      w: 5.2,
      h: 0.26,
      fontFace: F.body,
      fontSize: 12.6,
      bold: true,
      color: C.black,
      margin: 0,
    });
    slide.addText(item.sub, {
      x: 1.18,
      y: y + 0.29,
      w: 5.0,
      h: 0.3,
      fontFace: F.body,
      fontSize: 10.4,
      color: C.darkGray,
      margin: 0,
    });
  });

  slide.addText("右画像サンプル", {
    x: A.textImageAside.imageCaption.x,
    y: A.textImageAside.imageCaption.y,
    w: A.textImageAside.imageCaption.w,
    h: A.textImageAside.imageCaption.h,
    fontFace: F.body,
    fontSize: A.textImageAside.imageCaption.fontSize,
    color: C.darkGray,
    align: "center",
    margin: 0,
  });
  slide.addImage({
    ...imageSource(path.join("assets", "extracted", "page31-human-capital-aside.png")),
    x: A.textImageAside.image.x,
    y: A.textImageAside.image.y,
    w: A.textImageAside.image.w,
    h: A.textImageAside.image.h,
  });
}

async function main() {
  const outputDir = resolveRunOutputDir(OUTPUT_ROOT, DECK_BASENAME);
  addCoverSlide();
  addSummaryBulletSlide();
  addTextImageSlide();

  const outputFile = path.join(outputDir, `${DECK_BASENAME}.pptx`);
  await pptx.writeFile({ fileName: outputFile });
  console.log(`IMAGE_MODE=${IMAGE_MODE}`);
  console.log(outputFile);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
