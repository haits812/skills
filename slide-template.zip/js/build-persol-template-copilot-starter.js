"use strict";

const fs = require("fs");
const path = require("path");
const PptxGenJS = require("pptxgenjs");
const { PERSOL_THEME } = require("../assets/pptx-starter/persol-theme");

const ROOT = path.join(__dirname, "..");
const OUTPUT_ROOT = path.join(ROOT, "output");
const DECK_BASENAME = process.env.DECK_BASENAME || "persol-template-copilot-safe";
const IMAGE_MODE = (process.env.PERSOL_IMAGE_MODE || "base64").toLowerCase();

const pptx = new PptxGenJS();
pptx.layout = PERSOL_THEME.layout;
pptx.author = "Codex";
pptx.company = "OpenAI";
pptx.subject = "PERSOL Copilot-safe starter";
pptx.title = "PERSOL Copilot-safe Starter";
pptx.lang = "ja-JP";
pptx.theme = {
  headFontFace: PERSOL_THEME.fonts.title,
  bodyFontFace: PERSOL_THEME.fonts.body,
  lang: "ja-JP",
};

const ShapeType = pptx.ShapeType;
const C = PERSOL_THEME.colors;
const F = PERSOL_THEME.fonts;
const A = PERSOL_THEME.archetypes;
const S = PERSOL_THEME.structuralPanels;

function timestampToken() {
  const now = new Date();
  const pad = (value) => String(value).padStart(2, "0");
  return [
    now.getFullYear(),
    pad(now.getMonth() + 1),
    pad(now.getDate()),
  ].join("") + "-" + [pad(now.getHours()), pad(now.getMinutes())].join("");
}

function resolveRunOutputDir(outputRoot, requestedBaseName) {
  if (!fs.existsSync(outputRoot)) {
    fs.mkdirSync(outputRoot, { recursive: true });
  }
  const baseFolderName = `${timestampToken()}-${requestedBaseName}`;
  let counter = 1;
  let candidateDir = path.join(outputRoot, baseFolderName);
  while (fs.existsSync(candidateDir)) {
    counter += 1;
    candidateDir = path.join(outputRoot, `${baseFolderName}-${String(counter).padStart(2, "0")}`);
  }
  fs.mkdirSync(candidateDir, { recursive: true });
  return candidateDir;
}

function inferMimeType(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  if (ext === ".jpg" || ext === ".jpeg") return "image/jpeg";
  if (ext === ".svg") return "image/svg+xml";
  return "image/png";
}

function imageSource(relativePath) {
  const absolutePath = path.join(ROOT, relativePath);
  if (IMAGE_MODE === "path") {
    return { path: absolutePath };
  }
  const mimeType = inferMimeType(absolutePath);
  const base64 = fs.readFileSync(absolutePath).toString("base64");
  return { data: `${mimeType};base64,${base64}` };
}

function addFooter(slide, pageNo, showBrand = true) {
  if (showBrand) {
    slide.addImage({
      ...imageSource(path.join("assets", "logo", "persol-logo-small.png")),
      x: PERSOL_THEME.pageFurniture.topRightBrandImage.x,
      y: PERSOL_THEME.pageFurniture.topRightBrandImage.y,
      w: PERSOL_THEME.pageFurniture.topRightBrandImage.w,
      h: PERSOL_THEME.pageFurniture.topRightBrandImage.h,
    });
  }

  slide.addText("Copyright © PERSOL HOLDINGS CO., LTD. All Rights Reserved.", {
    x: PERSOL_THEME.pageFurniture.copyright.x,
    y: PERSOL_THEME.pageFurniture.copyright.y,
    w: PERSOL_THEME.pageFurniture.copyright.w,
    h: 0.15,
    fontFace: F.numeric,
    fontSize: 7.5,
    color: C.footerGray,
    align: "center",
    margin: 0,
  });

  slide.addText(String(pageNo), {
    x: PERSOL_THEME.pageFurniture.pageNo.x,
    y: PERSOL_THEME.pageFurniture.pageNo.y,
    w: PERSOL_THEME.pageFurniture.pageNo.w,
    h: PERSOL_THEME.pageFurniture.pageNo.h,
    fontFace: F.numeric,
    fontSize: 9,
    color: C.footerGray,
    align: "right",
    margin: 0,
  });
}

function addStandardFrame(slide, pageNo) {
  slide.background = { color: C.white };
  slide.addShape(ShapeType.rect, {
    x: 0,
    y: 0,
    w: 0.05,
    h: 7.5,
    line: { color: C.frameGray, transparency: 100 },
    fill: { color: C.frameGray },
  });
  addFooter(slide, pageNo);
}

function addMeasuredRightPanel(slide, fillColor) {
  slide.addShape(ShapeType.custGeom, {
    x: S.rightPanelPolygon.x,
    y: S.rightPanelPolygon.y,
    w: S.rightPanelPolygon.w,
    h: S.rightPanelPolygon.h,
    points: S.rightPanelPolygon.points,
    line: { color: fillColor, transparency: 100 },
    fill: { color: fillColor },
  });
}

function addPolyline(slide, points, color, weight = 1.2) {
  const thickness = Math.max(weight / 72, 0.016);
  for (let i = 1; i < points.length; i++) {
    const from = points[i - 1];
    const to = points[i];
    const dx = to.x - from.x;
    const dy = to.y - from.y;
    const length = Math.hypot(dx, dy);
    const angle = (Math.atan2(dy, dx) * 180) / Math.PI;
    slide.addShape(ShapeType.rect, {
      x: (from.x + to.x) / 2 - length / 2,
      y: (from.y + to.y) / 2 - thickness / 2,
      w: length,
      h: thickness,
      rotate: angle,
      line: { color, transparency: 100 },
      fill: { color },
    });
  }
  points.forEach((point) => {
    slide.addShape(ShapeType.ellipse, {
      x: point.x - 0.035,
      y: point.y - 0.035,
      w: 0.07,
      h: 0.07,
      line: { color, pt: 0.5 },
      fill: { color },
    });
  });
}

function addLegendItem(slide, x, y, color, label) {
  slide.addShape(ShapeType.rect, {
    x,
    y: y + 0.08,
    w: 0.18,
    h: 0.03,
    line: { color, transparency: 100 },
    fill: { color },
  });
  slide.addText(label, {
    x: x + 0.24,
    y,
    w: 1.2,
    h: 0.2,
    fontFace: F.body,
    fontSize: 9.5,
    color: C.darkGray,
    margin: 0,
  });
}

function addCoverSlide() {
  const slide = pptx.addSlide();
  slide.background = { color: C.white };
  addMeasuredRightPanel(slide, C.panelGray);

  slide.addImage({
    ...imageSource(path.join("assets", "logo", "persol-logo-lockup.png")),
    x: A.cover.logoLockup.x,
    y: A.cover.logoLockup.y,
    w: A.cover.logoLockup.w,
    h: A.cover.logoLockup.h,
  });

  slide.addText("Copilot 持込用テンプレ", {
    x: A.cover.title.x,
    y: A.cover.title.y,
    w: A.cover.title.w,
    h: A.cover.title.h,
    fontFace: F.title,
    fontSize: A.cover.title.fontSize,
    bold: true,
    color: C.darkGray,
    margin: 0,
  });
  slide.addText("2026年4月16日", {
    x: A.cover.metaDate.x,
    y: A.cover.metaDate.y,
    w: A.cover.metaDate.w,
    h: A.cover.metaDate.h,
    fontFace: F.body,
    fontSize: A.cover.metaDate.fontSize,
    color: C.darkGray,
    align: "right",
    margin: 0,
  });
  slide.addText("ロゴ維持 / custGeom維持 / native chart 不使用", {
    x: 6.45,
    y: A.cover.metaCompany.y,
    w: 5.48,
    h: A.cover.metaCompany.h,
    fontFace: F.body,
    fontSize: 14.5,
    color: C.darkGray,
    align: "right",
    margin: 0,
  });
  addFooter(slide, 1, false);
}

function addRulesSlide() {
  const slide = pptx.addSlide();
  addStandardFrame(slide, 2);
  slide.addText("Copilot 向けの割り切り", {
    x: A.standardContent.title.x,
    y: A.standardContent.title.y,
    w: 7.0,
    h: A.standardContent.title.h,
    fontFace: F.title,
    fontSize: A.standardContent.title.fontSize,
    bold: true,
    color: C.black,
    margin: 0,
  });

  slide.addShape(ShapeType.rect, {
    x: A.textSummaryBullets.summaryBand.x,
    y: A.textSummaryBullets.summaryBand.y,
    w: A.textSummaryBullets.summaryBand.w,
    h: A.textSummaryBullets.summaryBand.h,
    line: { color: C.aquaTint, transparency: 100 },
    fill: { color: "#ECEBE8" },
  });
  slide.addText("ロゴと custGeom は残す。壊れやすいのは画像の渡し方と native chart 内の日本語なので、そこだけ変える", {
    x: A.textSummaryBullets.summaryText.x,
    y: A.textSummaryBullets.summaryText.y,
    w: 11.1,
    h: A.textSummaryBullets.summaryText.h,
    fontFace: F.title,
    fontSize: A.textSummaryBullets.summaryText.fontSize,
    bold: true,
    color: C.darkGray,
    margin: 0,
  });

  const bullets = [
    "ロゴ画像は既定で base64 埋め込み。画像パスが通る環境だけ path に戻す",
    "表紙の灰色パネルは元の measured custGeom をそのまま使う",
    "グラフは native chart を使わず、線・棒・凡例を shape と text で描く",
    "日本語はタイトル・注記・凡例見出しとして slide.addText で置く",
  ];
  bullets.forEach((text, index) => {
    const y = A.textSummaryBullets.bodyY + index * 0.84;
    slide.addShape(ShapeType.rect, {
      x: 0.98,
      y: y + 0.08,
      w: 0.08,
      h: 0.08,
      line: { color: C.aqua, transparency: 100 },
      fill: { color: C.aqua },
    });
    slide.addText(text, {
      x: 1.16,
      y,
      w: 10.2,
      h: 0.26,
      fontFace: F.body,
      fontSize: 13,
      bold: true,
      color: C.black,
      margin: 0,
    });
  });
}

function addManualTrendSlide() {
  const slide = pptx.addSlide();
  addStandardFrame(slide, 3);

  slide.addText("日別推移", {
    x: 0.9,
    y: 0.9,
    w: 2.0,
    h: 0.35,
    fontFace: F.title,
    fontSize: 24,
    bold: true,
    color: C.black,
    margin: 0,
  });

  slide.addText("東京 2026年3月 天気サマリー", {
    x: 4.45,
    y: 1.34,
    w: 3.3,
    h: 0.2,
    fontFace: F.body,
    fontSize: 10.5,
    color: C.darkGray,
    align: "center",
    margin: 0,
  });

  const chart = { x: 1.35, y: 1.82, w: 9.2, h: 4.2 };
  const plotLeft = chart.x + 0.54;
  const plotRight = chart.x + chart.w - 0.22;
  const plotTop = chart.y + 0.28;
  const plotBottom = chart.y + chart.h - 0.34;
  const plotH = plotBottom - plotTop;
  const xStep = (plotRight - plotLeft) / 6;

  slide.addShape(ShapeType.line, {
    x: plotLeft,
    y: plotBottom,
    w: plotRight - plotLeft,
    h: 0,
    line: { color: C.darkGray, pt: 0.8 },
  });
  slide.addShape(ShapeType.line, {
    x: plotLeft,
    y: plotTop,
    w: 0,
    h: plotBottom - plotTop,
    line: { color: C.darkGray, pt: 0.8 },
  });

  [0, 5, 10, 15, 20].forEach((tick, index) => {
    const y = plotBottom - (index / 4) * plotH;
    slide.addShape(ShapeType.line, {
      x: plotLeft,
      y,
      w: plotRight - plotLeft,
      h: 0,
      line: { color: C.ruleGray, pt: 0.5, transparency: 15 },
    });
    slide.addText(String(tick), {
      x: chart.x - 0.05,
      y: y - 0.08,
      w: 0.3,
      h: 0.16,
      fontFace: F.numeric,
      fontSize: 8.5,
      color: C.darkGray,
      align: "right",
      margin: 0,
    });
  });

  ["1", "5", "10", "15", "20", "25", "31"].forEach((label, index) => {
    const x = plotLeft + index * xStep;
    slide.addText(label, {
      x: x - 0.08,
      y: plotBottom + 0.08,
      w: 0.2,
      h: 0.16,
      fontFace: F.numeric,
      fontSize: 8.5,
      color: C.darkGray,
      align: "center",
      margin: 0,
    });
  });

  const hiTemp = [18, 14, 17, 12, 16, 19, 21];
  const avgTemp = [11, 9, 10, 8, 11, 13, 16];
  const rain = [6, 12, 0, 2, 4, 9, 3];
  const maxY = 22;

  const hiPoints = hiTemp.map((value, index) => ({
    x: plotLeft + index * xStep,
    y: plotBottom - (value / maxY) * plotH,
  }));
  const avgPoints = avgTemp.map((value, index) => ({
    x: plotLeft + index * xStep,
    y: plotBottom - (value / maxY) * plotH,
  }));

  rain.forEach((value, index) => {
    const barW = 0.22;
    const barH = (value / 12) * 1.5;
    slide.addShape(ShapeType.rect, {
      x: plotLeft + index * xStep - barW / 2,
      y: plotBottom - barH,
      w: barW,
      h: barH,
      line: { color: C.aquaSoft, transparency: 100 },
      fill: { color: C.aquaSoft, transparency: 20 },
    });
  });

  addPolyline(slide, hiPoints, "#D99285", 1.4);
  addPolyline(slide, avgPoints, "#808089", 1.4);

  addLegendItem(slide, 2.65, 1.52, "#D99285", "最高気温");
  addLegendItem(slide, 3.95, 1.52, "#808089", "平均気温");
  addLegendItem(slide, 5.25, 1.52, C.aquaSoft, "降水量");

  slide.addText("凡例や見出しは chart 内に入れず、通常テキストとして外に置く", {
    x: 0.92,
    y: 6.46,
    w: 7.4,
    h: 0.2,
    fontFace: F.body,
    fontSize: 8.8,
    color: C.darkGray,
    margin: 0,
  });
}

async function main() {
  const outputDir = resolveRunOutputDir(OUTPUT_ROOT, DECK_BASENAME);
  addCoverSlide();
  addRulesSlide();
  addManualTrendSlide();

  const outputFile = path.join(outputDir, `${DECK_BASENAME}.pptx`);
  await pptx.writeFile({ fileName: outputFile });
  console.log(`IMAGE_MODE=${IMAGE_MODE}`);
  console.log(outputFile);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
