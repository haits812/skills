---
name: persol-slide-template
description: Build or revise Japanese business presentation decks in the visual language of the bundled PERSOL FY2025 Q3 investor-deck PDF. Use when the user wants "このテンプレで", "このPDFっぽく", "PERSOLの決算説明会資料風に", or needs reusable slide archetypes, theme tokens, and layout rules derived from the reference deck.
---

# PERSOL Slide Template

## Overview

Use this skill to reuse the bundled PERSOL FY2025 Q3 deck as a house style for new slides.
Treat this skill as the template layer and pair it with the built-in slides skill at `C:\Users\khsub\.codex\skills\slides\SKILL.md` when editable `.pptx` output is required.
When delivering a deck with this skill, submit a companion HTML preview alongside the `.pptx`; do not deliver the PowerPoint alone unless the user explicitly opts out of HTML.
Place every deck package under `output/yyyyMMdd-HHmm-<basename>/` so the `.pptx`, `.html`, source, and preview assets stay grouped by run.

## Workflow

1. Read `references/template-profile.md` before drafting slides.
2. Scan `assets/reference/reference-sheet.png` to choose the closest layout archetype.
3. If you are building or editing a cover slide, open page 1 of `assets/source/FY2025Q3presentation-template.pdf` and confirm the logo box against the measured token before touching sizing.
4. Open `assets/source/FY2025Q3presentation-template.pdf` for any other page that needs closer visual inspection.
5. Copy `assets/pptx-starter/persol-theme.js` into the deck workspace when authoring with PptxGenJS.
6. Keep the 16:9 canvas, Meiryo-first typography, muted gray framing, aqua highlights, and the footer pattern unless the user explicitly asks to break the template.
7. Create or reuse a run folder under `output/` named `yyyyMMdd-HHmm-<basename>/` before writing deliverables. Treat that folder as the only destination for the deck package.
8. Export a companion HTML preview after the `.pptx` is generated. Use `export-html-preview.ps1` at the template root or an equivalent process that keeps `<basename>.html` plus the sibling `<basename>-assets/` folder inside the same run folder.
9. Render the result and compare it against the reference sheet before delivery. Validate both the `.pptx` and the HTML preview naming/output paths inside the chosen run folder.
10. For cover slides, compare the rendered cover against PDF page 1 and treat any larger-by-eye logo as a regression until the PDF box is rechecked.
11. For cover and section-divider slides, do not fake the right-side gray area with an inset rectangle plus rotated white bars. Reuse the measured polygon from `assets/pptx-starter/persol-theme.js`.
12. When carrying this skill into another environment, start from `js/build-persol-template-starter.js`. It already demonstrates `画像パス` mode and can switch to `base64` via `PERSOL_IMAGE_MODE=base64`.

## Layout Selection

- Use the cover archetype for title pages, external reports, and opening slides.
- Use the section divider archetype for chapter boundaries and major transitions.
- Use the standard content archetype for summary slides, KPI tables, and commentary pages.
- Use the waterfall archetype for increase/decrease analysis.
- Use the two-panel archetype for side-by-side business unit comparisons or commentary blocks.
- Use the SBU comparison archetype for horizontal bar rows with a right-side commentary column.
- Use the outlook matrix archetype for environment assessment, next-year outlook, and action grids.
- Use the growth mix chart archetype for stacked bars plus trend lines and share callouts.
- Use the text-image aside archetype when bullets dominate the left side and a report cover or visual sits on the right.
- Use the topic list archetype when many key points must be stacked in a single page with small category pills.
- Use the dual-statement table archetype for two side-by-side financial tables.
- Use the multi-series trend archetype for line-heavy labor-market or KPI trend charts.
- Use the text-only notice archetype for disclaimer or closing pages.

## Output Rules

- Prefer editable PowerPoint-native text, tables, and charts over rasterized slide screenshots.
- Deliver both the editable `.pptx` and a companion `.html` preview for every completed deck unless the user explicitly asks for a different package.
- Put every deliverable for a run inside `output/yyyyMMdd-HHmm-<basename>/`. Do not scatter the `.pptx`, `.html`, assets, or source across multiple directories.
- Keep the HTML preview file beside the deck using the same basename, with preview images in a sibling `<basename>-assets/` directory.
- If you generate deck source code, keep delivering that source as well; HTML is additive, not a replacement for `.pptx` or authoring source.
- Use Meiryo Bold for Japanese headings, Meiryo for body copy, and Verdana only for compact numeric labels outside tables such as axes, footers, and tiny English tags.
- Inside tables and matrix cells, keep both Japanese text and numerals in Meiryo / Meiryo Bold. Do not switch table figures to Verdana.
- When exporting multiple decks or HTML previews, namespace outputs by deck basename. Keep HTML preview assets in a sibling folder like `<basename>-assets/` instead of a shared `assets/`.
- Use the extracted logo assets under `assets/logo/`. Do not redraw or approximate the PERSOL mark when the PDF-derived assets are available.
- For cover slides, keep the large lockup in the measured `cover.logoLockup` box from `assets/pptx-starter/persol-theme.js`. Do not enlarge it by eye to "fill" the white panel.
- For cover and section-divider slides, preserve the slight top-right and bottom-left bevels of the gray panel. They are part of the PDF's fill path, not decorative afterthoughts.
- Keep colors flat. Do not add gradients, glassmorphism, shadows, or rounded-card UI patterns.
- Keep the footer structure: centered copyright, page number at bottom-right, and restrained branding at top-right.
- Preserve the airy whitespace. Do not overfill the template with dense cards or excessive annotation.

## Resources

- `references/template-profile.md`: Theme tokens, layout rules, and slide archetypes extracted from the source PDF.
- `assets/reference/reference-sheet.png`: Six representative slides for quick visual matching.
- `assets/reference/archetype-sheet-expanded.png`: Additional reference pages covering P9, P25, P28, P31, P33, P36, P42, and P53.
- `assets/source/FY2025Q3presentation-template.pdf`: Ground-truth source deck.
- `assets/logo/persol-logo-lockup.png` and `assets/logo/persol-logo-small.png`: PDF-derived logo assets for cover pages and body-slide branding.
- `assets/extracted/page31-human-capital-aside.png`: Sample right-column image cut from the PDF for the text-plus-image archetype.
- `assets/pptx-starter/persol-theme.js`: Reusable theme tokens and geometry constants for PptxGenJS decks.
- `js/build-persol-template-starter.js`: Portable PptxGenJS starter that shows both the `画像パス` default and the `base64` fallback switch for logos and right-column images.
- `js/package.json`: Minimal Node package manifest for the starter script.
- `export-html-preview.ps1`: Stable wrapper for the HTML preview exporter. It resolves the bundled reference exporter and keeps the generated HTML package inside the active run folder.
