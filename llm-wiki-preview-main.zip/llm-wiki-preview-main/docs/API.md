# llm-wiki-preview API 契約 (v1 — backend/frontend 両担当はこれに従う)

原則: 読み取り専用 (GET のみ、他 method は 405)。導出物を保存しない — 全 API はリクエスト毎に WIKI_ROOT (env、既定は隣の ../llm-wiki か ../llm-wiki-demo) の markdown を読み直して導出する。キャッシュ禁止。依存パッケージ禁止 (vanilla node、http/fs/path/child_process のみ)。

- GET /            → public/index.html
- GET /api/notes   → { "<id>": { fm: [[key, value|value[]],...], body: "<逐語>" } } — entities/ records/ の全ファイル。追加: 各エントリに "mtime": "<ISO8601>" を足してよい (tree の 更新日時 ソート用)
- GET /api/graph   → { nodes: [...], edges: [...] }
- GET /api/search?q=<str> → { hits: [{ file: "<repo相対パス>", line: <n>, text: "<行逐語>" }] }
  実装: execFile("rg", ["-F","-n","-i","--max-count","3","-g","*.md", q, "entities/","records/"], {cwd: WIKI_ROOT, timeout: 3000})。-F = リテラル固定 ("[" 等をパターン解釈しない)。q は string 引数として渡す (shell 経由禁止)。長さ 200 超は 400。rg exit 1 (0件) は hits: [] で 200、timeout は 500、rg 不在 (ENOENT) は 500
- bind: HOST/PORT env。ローカル既定は 127.0.0.1:6789
