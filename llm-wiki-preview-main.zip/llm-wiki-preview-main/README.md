# llm-wiki-preview

[llm-wiki](https://github.com/AI-Driven-R-D-Dept/llm-wiki) を人間がブラウズするための読み取り専用ビューア。
wiki 本体はエージェント専用 (人間は repo を直接読まない) — 中を覗きたくなった時だけこれを立てる。

wiki の思想をそのまま守る: **導出物を保存しない**。ノート一覧・リンクグラフ・検索は
全てリクエスト毎に WIKI_ROOT の markdown から読み時導出する。キャッシュ無し・DB 無し・
依存パッケージ 0 (vanilla node)。書き込み系 API は無い (GET のみ)。

## 起動

```bash
node server.js                          # 既定: 隣の ../llm-wiki (無ければ ../llm-wiki-demo)、127.0.0.1:6789
WIKI_ROOT=<wiki の path> node server.js # 任意の llm-wiki repo を指す
HOST=0.0.0.0 PORT=8080 node server.js   # bind の変更
```

必要なもの: node と rg (ripgrep — 検索 API が使う)。WIKI_ROOT が wiki repo でなければ起動時に即死する。

## 画面と API

1 画面 (public/index.html) — ノートツリー・本文表示・リンクグラフ・検索。
API 契約は [docs/API.md](docs/API.md):

- `GET /api/notes` — 全エンティティ・記録の frontmatter + 本文 (逐語)
- `GET /api/graph` — リンクグラフ (nodes / edges を毎回導出)
- `GET /api/search?q=` — rg によるリテラル検索 (上位 3 行/ファイル)

## クレジット

- アイコン: [Feather Icons](https://feathericons.com) (MIT) を元に一部調整 — ライセンス全文は [docs/CREDITS.md](docs/CREDITS.md)
- フォント: IBM Plex Sans JP / IBM Plex Mono (SIL OFL 1.1、Google Fonts 経由)

## 利用条件

本 repo にオープンソースライセンスは付与していない (All rights reserved)。
閲覧・評価を超える複製・改変・再配布・商用利用はできない。
(上記クレジット節のサードパーティ素材は各自のライセンスに従う)
