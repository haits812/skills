"use strict";
/* server.js — llm-wiki-preview (docs/API.md v1)。vanilla node http、GET のみ。
   導出物を保存しない: 全 API はリクエスト毎に WIKI_ROOT の markdown を読み直す (lib/derive.js)。
   bind: HOST/PORT env。ローカル既定は 127.0.0.1:6789 */
const http = require("http");
const fs = require("fs");
const path = require("path");
const derive = require("./lib/derive");

const HOST = process.env.HOST || "127.0.0.1";
const PORT = Number(process.env.PORT || 6789);

/* WIKI_ROOT の指し先が wiki repo でなければ即死する (黙って空を返さない) */
if (!fs.existsSync(path.join(derive.WIKI_ROOT, "entities"))) {
  console.error("WIKI_ROOT が wiki repo を指していません: " + derive.WIKI_ROOT);
  console.error("例: WIKI_ROOT=../llm-wiki node server.js");
  process.exit(1);
}
const INDEX_HTML = path.join(__dirname, "public", "index.html");

function sendJson(res, status, obj) {
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
  res.end(JSON.stringify(obj));
}

/* エラーメッセージにホスト絶対パスを出さない — WIKI_ROOT 相対に丸める */
function scrub(msg) {
  return String(msg).split(derive.WIKI_ROOT + path.sep).join("").split(derive.WIKI_ROOT).join("WIKI_ROOT");
}

const server = http.createServer((req, res) => {
  try {
    if (req.method !== "GET") return sendJson(res, 405, { error: "GET only" });
    const url = new URL(req.url, "http://" + (req.headers.host || "localhost"));

    if (url.pathname === "/" || url.pathname === "/index.html") {
      fs.readFile(INDEX_HTML, (err, buf) => {
        if (err) return sendJson(res, 404, { error: "public/index.html not found" });
        res.writeHead(200, { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" });
        res.end(buf);
      });
      return;
    }

    if (url.pathname === "/api/notes") return sendJson(res, 200, derive.deriveNotes());

    if (url.pathname === "/api/graph") return sendJson(res, 200, derive.deriveGraph());

    if (url.pathname === "/api/search") {
      const q = url.searchParams.get("q");
      if (q === null) return sendJson(res, 400, { error: "q required" });
      if (q.length > 200) return sendJson(res, 400, { error: "q too long (max 200)" });
      derive.search(q)
        .then(result => sendJson(res, 200, result))
        .catch(e => sendJson(res, 500, { error: scrub(e.message || e) }));
      return;
    }

    return sendJson(res, 404, { error: "not found: " + url.pathname });
  } catch (e) {
    return sendJson(res, 500, { error: scrub(e.message || e) });
  }
});

server.listen(PORT, HOST, () => {
  console.log("llm-wiki-preview http://" + HOST + ":" + PORT + " (WIKI_ROOT=" + derive.WIKI_ROOT + ")");
});
