# claude skills (動画系)

自作 Claude Code Skill の開発モノレポ。各 Skill は `skills/<skill-name>/` に置き、
インストール時は `~/.claude/skills/<skill-name>/` へ同期する。

## Skills

| Skill | 概要 |
|-------|------|
| [short-movie-maker](skills/short-movie-maker/) | 長尺トーク動画 (ローカル/YouTube URL) から YouTube Shorts 用の縦型完成ショート (9:16・60秒以内) を複数本全自動生成。翻訳字幕・ずんだもん吹き替え・話者分離・盛り上がり検出ほか M1〜M17 のオプション |
| [video-production](skills/video-production/) | テーマ・ブランド文脈・口調コンテキストから台本→VOICEVOX 音声→テロップ→Remotion レンダで解説動画・非属人動画を新規制作 (day01-bonus-package 由来) |
| [sns-video-ops](skills/sns-video-ops/) | 競合 SNS 動画 (Instagram リール等) を分析し、自社 UGC 風動画の企画・台本・字コンテ・画像生成指示・レビュー板まで作る運用ハーネス (day02-sns-video-ops-bonus 由来) |

## 構成

```
skills/
  <skill-name>/
    SKILL.md        Skill 本体 (Claude が読むオーケストレーション手順書)
    scripts/        決定論的処理のスクリプト群
    templates/      素材テンプレ
    contexts/       ユーザー編集可能な設定・辞書
    eval/           eval-loop の合格基準 (goal.json 等)
    README.md       Skill ごとの説明
output/             実行時の成果物置き場 (gitignore 済み)
  <素材名>/         work (作業用) と out (完成品) を素材ごとにまとめる
```

> 作業ディレクトリとレンダ出力 (`output/`) は巨大なため gitignore 済み。
> リポジトリには Skill 本体と設計ドキュメントのみを含む。
