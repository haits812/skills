# recipes — 動画編集の「型」レシピ集

流行りの編集スタイル (まとめ反応集など) を **Skill にせず、レシピ (作り方 + 小道具) として**
置く場所。型ごとに Skill を作ると乱立するし、旬が過ぎたら不要になる。レシピなら
**流行ったら .md を足す / 廃れたら消す**だけで済む。

**使い方**: 「`recipes/<name>` でやって」+ 素材動画 → Claude が該当レシピの手順に沿って作る。

## レシピ一覧

| レシピ | 概要 |
|--------|------|
| [matome-reaction](matome-reaction/RECIPE.md) | 「〜が話題にｗ」スレタイ + ゆっくり音声のレス連打。集中線背景・色付きコメントボックス・冒頭カットイン |

## 構成

```
recipes/
  README.md                この索引
  bgm/                     BGM 置き場 (フリー音源)
  lib/                     レシピ共通の小道具スクリプト
    yukkuri.py             ゆっくり(AquesTalk)音声合成。32bit python を自動用意
    _yukkuri_dll.py        (内部) 32bit 下で走る ctypes ブリッジ
    burst_bg.py            集中線サンバースト背景
    comment_box.py         角丸コメントボックス / スレタイ帯 / 矢印
    py32/                  自動展開される 32bit 組み込み python (gitignore)
  <recipe-name>/
    RECIPE.md              作り方 (「これでやって」の本体)
    build.py               組み立てスクリプト
```

## 小道具 (lib) は共用

`lib/` のスクリプトは複数レシピで使い回す前提。新しい型を足すときは、まず lib の
小道具で組めないか見て、足りなければ小道具を増やす (レシピ固有の組み立ては各レシピの
build.py に置く)。重い合成 (ASS 字幕・NVENC 等) は
`skills/short-movie-maker/scripts/` の資産も流用してよい。

## ゆっくり音声のライセンス (重要)

`lib/yukkuri.py` が使う AquesTalk のフリー版は **「個人が非営利で使う場合のみ無償」**。
個人であっても個人事業・会社・大学での使用や、収益化した動画は範囲外で、商用ライセンス
(使用ライセンス・商用コンテンツ向け) の購入が必要。詳細は AquesTalk 同梱 readme /
<https://www.a-quest.com/licence_free.html>。

## BGM (bgm/)

フリーで使える音源のみを置く。使用時は各音源の配布元ライセンスに従う。

| ファイル | 出典 | 用途 |
|----------|------|------|
| kakekko-kyoso.mp3 | YouTube「かけっこ競争」(フリー利用可) | まとめ反応集など明るい型の BGM |
