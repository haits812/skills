"""32bit Python 下で走る AquesTalk DLL ブリッジ (直接呼ばない。yukkuri.py 経由)。

漢字仮名交じり文 → 音声記号列 (AqKanji2Koe) → WAV (AquesTalk1) を 8kHz で書き出す。
AquesTalk のフリー版ライセンスは「個人が非営利で使う場合のみ無償」。商用利用は
使用ライセンス購入が必要 (recipes/README.md 参照)。

Usage (32bit python):
  python _yukkuri_dll.py "<text>" <voice> <out.wav> <speed> <aques_base>
    voice : f1(れいむ) / f2(まりさ) / m1 / m2 ... (aqtk1 のフォルダ名)
    speed : 50..200 (標準 100)
"""
import ctypes, os, sys

text, voice, out, speed, base = (
    sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4]), sys.argv[5])
os.add_dll_directory(base)

# 1) 漢字仮名交じり -> 音声記号列
k2k = ctypes.CDLL(os.path.join(base, "AqKanji2Koe.dll"))
k2k.AqKanji2Koe_Create.restype = ctypes.c_void_p
k2k.AqKanji2Koe_Create.argtypes = [ctypes.c_char_p, ctypes.POINTER(ctypes.c_int)]
k2k.AqKanji2Koe_Convert_utf8.argtypes = [
    ctypes.c_void_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_int]
err = ctypes.c_int(0)
h = k2k.AqKanji2Koe_Create(os.path.join(base, "aq_dic").encode("mbcs"),
                           ctypes.byref(err))
if not h:
    print("K2K create failed", err.value); sys.exit(1)
buf = ctypes.create_string_buffer(8192)
if k2k.AqKanji2Koe_Convert_utf8(h, text.encode("utf-8"), buf, 8192) != 0:
    print("K2K convert failed"); sys.exit(1)
koe = buf.value

# 2) 音声記号列 -> WAV (声ごとに別 DLL)
dll = ctypes.CDLL(os.path.join(base, "aqtk1", voice, "AquesTalk.dll"))
dll.AquesTalk_Synthe_Utf8.restype = ctypes.POINTER(ctypes.c_ubyte)
dll.AquesTalk_Synthe_Utf8.argtypes = [
    ctypes.c_char_p, ctypes.c_int, ctypes.POINTER(ctypes.c_int)]
dll.AquesTalk_FreeWave.argtypes = [ctypes.POINTER(ctypes.c_ubyte)]
size = ctypes.c_int(0)
wav = dll.AquesTalk_Synthe_Utf8(koe, speed, ctypes.byref(size))
if not wav:
    print("Synthe failed code", size.value); sys.exit(1)
data = bytes(ctypes.cast(wav, ctypes.POINTER(ctypes.c_ubyte * size.value)).contents)
dll.AquesTalk_FreeWave(wav)
with open(out, "wb") as f:
    f.write(data)
print("OK", size.value)
