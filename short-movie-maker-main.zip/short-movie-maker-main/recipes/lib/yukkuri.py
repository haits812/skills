"""ゆっくり(AquesTalk)音声合成ヘルパー (64bit 側の入口)。

AquesTalk の DLL は 32bit なので、64bit Python からは直接呼べない。この
モジュールは 32bit の組み込み Python を lib/py32 に自動展開し、その下で
_yukkuri_dll.py を走らせて WAV を作り、ffmpeg で 44.1kHz にアップサンプルする。

前提:
  - AquesTalkPlayer 一式 (DLL + aq_dic)。既定パス D:\ドキュメント\aquestalkplayer。
    環境変数 AQUES_BASE で上書き可。
  - ライセンス: フリー版は「個人・非営利のみ無償」(recipes/README.md 参照)。

使い方:
  from yukkuri import synth
  wav, dur = synth("こんにちは", voice="f1", out="out.wav", speed=100)
"""
from __future__ import annotations

import os
import subprocess
import sys
import urllib.request
import wave
import zipfile

LIB = os.path.dirname(os.path.abspath(__file__))
PY32_DIR = os.path.join(LIB, "py32")
PY32 = os.path.join(PY32_DIR, "python.exe")
DLL_BRIDGE = os.path.join(LIB, "_yukkuri_dll.py")
EMBED_URL = "https://www.python.org/ftp/python/3.12.0/python-3.12.0-embed-win32.zip"
AQUES_BASE = os.environ.get("AQUES_BASE", r"D:\ドキュメント\aquestalkplayer")

VOICES = {"reimu": "f1", "marisa": "f2", "male1": "m1", "male2": "m2"}


def ensure_py32() -> str:
    """32bit 組み込み Python を用意する (無ければダウンロード展開)。"""
    if os.path.exists(PY32):
        return PY32
    os.makedirs(PY32_DIR, exist_ok=True)
    zp = os.path.join(PY32_DIR, "embed.zip")
    sys.stderr.write("[yukkuri] fetching 32-bit embeddable python (one-time)...\n")
    urllib.request.urlretrieve(EMBED_URL, zp)
    with zipfile.ZipFile(zp) as z:
        z.extractall(PY32_DIR)
    os.remove(zp)
    if not os.path.exists(PY32):
        raise RuntimeError("failed to set up 32-bit python at " + PY32_DIR)
    return PY32


def _wav_dur(path: str) -> float:
    with wave.open(path) as w:
        return w.getnframes() / w.getframerate()


def synth(text: str, voice: str = "f1", out: str = "out.wav",
          speed: int = 100, upsample: int = 44100,
          aques_base: str | None = None) -> tuple[str, float]:
    """text をゆっくり音声で合成し WAV を書き出す。(out, 秒) を返す。

    voice: aqtk1 のフォルダ名 (f1=れいむ f2=まりさ m1 m2) or エイリアス
           (reimu/marisa/male1/male2)。
    """
    voice = VOICES.get(voice, voice)
    base = aques_base or AQUES_BASE
    py32 = ensure_py32()
    raw = out + ".8k.wav"
    r = subprocess.run([py32, DLL_BRIDGE, text, voice, raw, str(speed), base],
                       capture_output=True, text=True, encoding="utf-8",
                       errors="replace")
    if not os.path.exists(raw):
        raise RuntimeError(f"yukkuri synth failed: {r.stdout}\n{r.stderr}")
    if upsample:
        subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", raw,
                        "-ar", str(upsample), "-ac", "2", out], check=True)
        os.remove(raw)
    else:
        os.replace(raw, out)
    return out, _wav_dur(out)


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("text")
    ap.add_argument("--voice", default="f1")
    ap.add_argument("--out", default="out.wav")
    ap.add_argument("--speed", type=int, default=100)
    a = ap.parse_args()
    p, d = synth(a.text, a.voice, a.out, a.speed)
    print(f"{p} ({d:.2f}s)")
