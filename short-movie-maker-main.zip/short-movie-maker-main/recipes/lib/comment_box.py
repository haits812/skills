"""角丸コメントボックス / スレタイ帯の PNG を描く (まとめ反応集などの型で使う)。

白地 + 色枠 + 角丸の吹き出しボックス。中央寄せ複数行。位置プリセットに応じた
配置座標も返す。

Usage:
  from comment_box import make_box, POSITIONS
  png, (x, y) = make_box("入社1ヶ月で\n有能すぎやろ", "top",
                         box_color=(255,90,160), out="box.png")
"""
from __future__ import annotations

from PIL import Image, ImageDraw, ImageFont

FONT_BOLD = r"C:\Windows\Fonts\BIZ-UDGothicB.ttc"
W, H = 1080, 1920

# 位置プリセット: (x基準, y基準, align) — align "C"=中央そろえ, "L"=左寄せ
POSITIONS = {
    "top":  (0.5, 300, "C"),
    "topL": (70, 330, "L"),
    "bot":  (0.5, 1560, "C"),
    "botL": (70, 1560, "L"),
}


def _font(path: str, sz: int) -> ImageFont.FreeTypeFont:
    try:
        return ImageFont.truetype(path, sz)
    except OSError:
        return ImageFont.load_default()


def make_box(text: str, pos: str = "top", box_color=(255, 90, 160),
             out: str = "box.png", fontsize: int = 58,
             font_path: str = FONT_BOLD, canvas=(W, H)) -> tuple[str, tuple[int, int]]:
    """コメントボックス PNG を作り (path, (x, y)) を返す。x/y は canvas 上の配置座標。"""
    cw, ch = canvas
    lines = text.split("\n")
    f = _font(font_path, fontsize)
    tw = max(f.getbbox(ln)[2] for ln in lines)
    th = len(lines) * (fontsize + 14)
    padx, pady = 46, 30
    bw, bh = tw + padx * 2, th + pady * 2
    img = Image.new("RGBA", (bw + 20, bh + 20), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((10, 10, 10 + bw, 10 + bh), radius=28,
                        fill=(255, 255, 255, 255),
                        outline=box_color + (255,), width=8)
    for j, ln in enumerate(lines):
        lw = f.getbbox(ln)[2]
        d.text(((bw - lw) // 2 + 10, 10 + pady + j * (fontsize + 14)), ln,
               font=f, fill=(30, 30, 30, 255))
    img.save(out)
    px, py, align = POSITIONS.get(pos, POSITIONS["top"])
    x = int((cw - img.width) // 2) if align == "C" else int(px)
    y = int(py) - 10
    return out, (x, y)


def make_title_bar(text: str, out: str = "titlebar.png",
                   box_color=(255, 90, 160), fontsize: int = 66,
                   font_path: str = FONT_BOLD) -> str:
    """スレタイ帯 (ヒーロー用・改行は / 区切り) の PNG を作る。"""
    lines = text.split("/")
    f = _font(font_path, fontsize)
    tw = max(f.getbbox(l)[2] for l in lines)
    th = len(lines) * (fontsize + 14)
    img = Image.new("RGBA", (tw + 120, th + 60), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((10, 10, tw + 110, th + 50), radius=34,
                        fill=(255, 255, 255, 255),
                        outline=box_color + (255,), width=9)
    for j, l in enumerate(lines):
        lw = f.getbbox(l)[2]
        d.text(((tw + 120 - lw) // 2, 25 + j * (fontsize + 14)), l,
               font=f, fill=(40, 40, 40, 255))
    img.save(out)
    return out


def make_arrow(out: str = "arrow.png", color=(230, 30, 30)) -> str:
    img = Image.new("RGBA", (220, 180), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.polygon([(15, 55), (140, 55), (140, 20), (210, 90),
               (140, 160), (140, 125), (15, 125)], fill=color + (255,))
    img.save(out)
    return out
