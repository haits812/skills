"""集中線サンバースト背景を生成する (まとめ反応集などの型で使う)。

Usage:
  from burst_bg import make_burst
  make_burst("bg.png")                         # 既定の水色
  make_burst("bg.png", base=(150,216,240), rays=((120,200,232),(172,226,246)))
"""
from __future__ import annotations

import math

from PIL import Image, ImageDraw


def make_burst(out: str, w: int = 1080, h: int = 1920,
               base=(150, 216, 240), rays=((120, 200, 232), (172, 226, 246)),
               center=(0.5, 0.42), n: int = 72) -> str:
    cx, cy = int(w * center[0]), int(h * center[1])
    img = Image.new("RGB", (w, h), base)
    d = ImageDraw.Draw(img)
    R = int(math.hypot(w, h) * 1.3)
    for i in range(n):
        a0 = (i / n) * 2 * math.pi
        a1 = ((i + 0.5) / n) * 2 * math.pi
        col = rays[i % len(rays)]
        d.polygon([(cx, cy),
                   (cx + R * math.cos(a0), cy + R * math.sin(a0)),
                   (cx + R * math.cos(a1), cy + R * math.sin(a1))], fill=col)
    img.save(out)
    return out


if __name__ == "__main__":
    import sys
    make_burst(sys.argv[1] if len(sys.argv) > 1 else "bg_burst.png")
    print("wrote burst background")
