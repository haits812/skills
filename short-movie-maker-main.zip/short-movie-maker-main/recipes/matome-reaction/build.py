"""まとめ反応集メーカー — script.json から 1 本組み立てる。

script.json (Claude が書く):
{
  "footage": "素材動画のパス",
  "bgm": "recipes/bgm/kakekko-kyoso.mp3",
  "title": {"text": "職場の新人ちゃんが/優秀すぎると話題にｗ", "voice": "f1"},
  "hero_ss": 52,          # ヒーローに使う素材の開始秒
  "band_ss": 6,           # 本体バンドに使う素材の開始秒
  "lines": [
    {"voice": "f2", "say": "入社1ヶ月で即戦力とか有能すぎやろ",
     "telop": "入社1ヶ月で即戦力とか/有能すぎやろ", "pos": "top",  "color": [255,90,160]},
    {"voice": "f1", "say": "ワイの後輩にこそ欲しいわ",
     "telop": "ワイの後輩にこそ/欲しいわ",           "pos": "botL", "color": [90,170,255]}
  ]
}
  - text/telop の改行は "/" 区切り。
  - pos: top / topL / bot / botL (comment_box.POSITIONS)。連続で同じにしない。
  - voice: f1(れいむ) / f2(まりさ) / m1 / m2。

Usage:
  python build.py --script script.json --out out.mp4
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys

LIB = os.path.normpath(os.path.join(os.path.dirname(__file__), "..", "lib"))
sys.path.insert(0, LIB)
import burst_bg          # noqa: E402
import comment_box       # noqa: E402
import yukkuri           # noqa: E402

W, H = 1080, 1920
BAND_H, BAND_Y = 1200, 430


def main() -> None:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser()
    ap.add_argument("--script", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--workdir", default=None)
    ap.add_argument("--bgm-volume", type=float, default=0.13)
    args = ap.parse_args()

    with open(args.script, encoding="utf-8") as f:
        spec = json.load(f)
    work = args.workdir or os.path.join(os.path.dirname(args.out) or ".", "work")
    os.makedirs(work, exist_ok=True)
    footage = spec["footage"]
    bgm = spec["bgm"]

    # --- 1) 音声合成 + タイムライン ---
    timeline = []
    t = 0.4
    for i, ln in enumerate(spec["lines"]):
        wav = os.path.join(work, f"v{i}.wav")
        _, dur = yukkuri.synth(ln["say"], voice=ln.get("voice", "f1"), out=wav)
        timeline.append((t, dur, wav, i))
        t += dur + 0.4
    hero_wav = os.path.join(work, "vtitle.wav")
    _, hero_dur = yukkuri.synth(spec["title"]["text"].replace("/", "、"),
                                voice=spec["title"].get("voice", "f1"), out=hero_wav)
    total = t + 0.5
    HERO = max(hero_dur + 0.3, timeline[0][0] if timeline else 3.0)

    # --- 2) ボイストラック (タイトル + 各レスを adelay で配置) ---
    inp, fl, lb = [], [], []
    allv = [(0.2, hero_wav)] + [(st, w) for (st, d, w, i) in timeline]
    for k, (st, w) in enumerate(allv):
        inp += ["-i", w]
        fl.append(f"[{k}:a]adelay={int(st*1000)}|{int(st*1000)}[a{k}]")
        lb.append(f"[a{k}]")
    voicetrk = os.path.join(work, "voice.wav")
    subprocess.run(["ffmpeg", "-y", "-v", "error", *inp, "-filter_complex",
                    ";".join(fl) + ";" + "".join(lb) +
                    f"amix=inputs={len(allv)}:normalize=0[v]",
                    "-t", f"{total}", "-map", "[v]", voicetrk], check=True)

    # --- 3) 背景・ボックス・タイトル帯・矢印 ---
    bg = os.path.join(work, "bg.png")
    burst_bg.make_burst(bg)
    boxes = []  # (png, x, y) index対応
    for i, ln in enumerate(spec["lines"]):
        p = os.path.join(work, f"box{i}.png")
        _, (x, y) = comment_box.make_box(
            ln["telop"].replace("/", "\n"), ln.get("pos", "top"),
            tuple(ln.get("color", [255, 90, 160])), out=p)
        boxes.append((p, x, y))
    titlebar = comment_box.make_title_bar(spec["title"]["text"],
                                          out=os.path.join(work, "titlebar.png"))
    arrow = comment_box.make_arrow(out=os.path.join(work, "arrow.png"))

    # --- 4) 映像 (ヒーロー全画面 + 本体バンド) ---
    hero = os.path.join(work, "hero.mp4")
    band = os.path.join(work, "band.mp4")
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-ss", str(spec.get("hero_ss", 0)),
                    "-t", f"{HERO:.2f}", "-i", footage, "-an", "-vf",
                    f"scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H}",
                    "-r", "30", hero], check=True)
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-ss", str(spec.get("band_ss", 0)),
                    "-t", f"{total-HERO+0.5:.2f}", "-i", footage, "-an", "-vf",
                    f"scale={W}:{BAND_H}:force_original_aspect_ratio=increase,crop={W}:{BAND_H}",
                    "-r", "30", band], check=True)

    # --- 5) 合成 ---
    inputs = ["-loop", "1", "-i", bg, "-i", hero, "-i", band,
              "-loop", "1", "-i", titlebar, "-loop", "1", "-i", arrow]
    box_idx = []
    idx = 5
    for (p, x, y) in boxes:
        inputs += ["-loop", "1", "-i", p]
        box_idx.append(idx)
        idx += 1
    voice_i = idx
    inputs += ["-i", voicetrk]
    bgm_i = idx + 1
    inputs += ["-i", bgm]

    f = [f"[0:v]scale={W}:{H}[bg]",
         f"[1:v]setsar=1,format=rgba,fade=t=out:st={HERO-0.2}:d=0.2:alpha=1[hero]",
         f"[2:v]setsar=1[band]",
         f"[bg][band]overlay=x=0:y={BAND_Y}:enable='gte(t,{HERO})'[m1]",
         f"[m1][hero]overlay=x=0:y=0:enable='lt(t,{HERO})'[m2]",
         f"[m2][3:v]overlay=x=(W-w)/2:y=140:enable='lt(t,{HERO})'[m3]",
         f"[m3][4:v]overlay=x=40:y=1150:enable='lt(t,{HERO})'[cur]"]
    cur = "cur"
    for k, (st, d, w, i) in enumerate(timeline):
        en = st + d + 0.35
        _, x, y = boxes[i]
        nn = f"c{k}"
        # ポップ出現は overlay では不可なので pad + scale で近似せず、素直に enable 表示
        f.append(f"[{cur}][{box_idx[i]}:v]overlay=x={x}:y={y}:"
                 f"enable='between(t,{st-0.12},{en})'[{nn}]")
        cur = nn
    f.append(f"[{cur}]null[vout]")
    f.append(f"[{voice_i}:a]volume=1.0[vo]")
    f.append(f"[{bgm_i}:a]volume={args.bgm_volume},aloop=loop=-1:size=2e9[bgm]")
    f.append(f"[bgm][vo]amix=inputs=2:duration=first:normalize=0[aout]")

    cmd = ["ffmpeg", "-y", "-v", "error", *inputs, "-filter_complex", ";".join(f),
           "-map", "[vout]", "-map", "[aout]", "-t", f"{total:.2f}",
           "-c:v", "h264_nvenc", "-preset", "p5", "-cq", "23", "-pix_fmt", "yuv420p",
           "-c:a", "aac", "-b:a", "192k", "-r", "30", "-movflags", "+faststart",
           args.out]
    r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8",
                       errors="replace")
    if r.returncode:
        sys.stderr.write("RENDER FAIL\n" + (r.stderr or "")[-2500:] + "\n")
        sys.exit(1)
    print(json.dumps({"out": args.out, "duration": round(total, 1),
                      "clips": len(spec["lines"])}, ensure_ascii=False))


if __name__ == "__main__":
    main()
