# まとめ反応集レシピ (ゆっくり2ch まとめ風ショート)

「〜が話題にｗ」系のスレタイ + ゆっくり音声のレス連打で構成する、縦型ショートの型。
**発動**: 「recipes/matome-reaction でやって」「まとめ反応集レシピで作って」+ 素材動画。

## 完成イメージ (この型の要件)

- **9:16 / 15〜30 秒 / BGM + ゆっくり音声**
- **冒頭カットイン**: スレタイをヒーロー映像 (全画面) に乗せ、ピンク角丸帯 + 赤矢印で掴む
- **本体**: 集中線サンバースト背景 + 素材映像を大きめバンド表示。その上に
  **色付き角丸コメントボックスが位置を変えて (上/上左/下/下左) ポンポン出る**
- **音声**: ゆっくり (れいむ f1 / まりさ f2) を交互に。レスを掛け合いにする
- 参考にした実例の型: YouTube Shorts の「〇〇が話題にｗ」まとめ反応集

## 作り方 (Claude の手順)

1. **素材を受け取る** (ローカル動画 or YouTube URL)。URL なら
   `skills/short-movie-maker/scripts/fetch.py` で mp4 化する。
2. **ネタと台本を作る** — スレタイ (煽り気味の一文) と、レス 5〜7 本を **なんJ語/2ch語の
   短い掛け合い**で書く。1 レス = 1 ボックス。オチのレスで締める。内容は素材に合わせる。
   - 実在人物・誹謗中傷・センシティブな断定は避ける (ネタとして成立する範囲で)。
3. **script.json を書く** (下記スキーマ)。`pos` は連続で同じにしない (上→下左→上左…と散らす)。
   `color` はレスごとに変えて賑やかに。改行は `/`。
4. **合成する**:
   ```bash
   python recipes/matome-reaction/build.py --script <script.json> --out output/<名前>/out.mp4
   ```
   - 出力先は `output/<素材名>/` 配下にする (ルートを散らかさない)。
   - BGM は `recipes/bgm/` から選ぶ (既定候補: `kakekko-kyoso.mp3`)。
5. **フレームを目視で確認**して、見切れ・かぶり・誤字がないかチェックする。

## script.json スキーマ

```json
{
  "footage": "素材動画の絶対パス",
  "bgm": "recipes/bgm/kakekko-kyoso.mp3",
  "title": {"text": "スレタイ/2行目", "voice": "f1"},
  "hero_ss": 52,
  "band_ss": 6,
  "lines": [
    {"voice": "f2", "say": "読み上げる台詞", "telop": "画面の文字/2行目",
     "pos": "top", "color": [255, 90, 160]}
  ]
}
```

- `voice`: `f1`(れいむ) / `f2`(まりさ) / `m1` / `m2`。エイリアス reimu/marisa も可。
- `say`: ゆっくりが読む文 (漢字仮名交じりでよい。音声記号は自動変換)。
- `telop`: 画面に出す文 (`say` の要約 or そのまま)。`/` で改行。
- `pos`: `top` / `topL` / `bot` / `botL`。
- `color`: ボックス枠色 [R,G,B]。
- `hero_ss` / `band_ss`: 素材動画のどこをヒーロー / 本体バンドに使うか (秒)。
  素材の良い表情・構図の箇所を選ぶ。

## 前提・セットアップ

- **ゆっくり音声**: AquesTalkPlayer 一式 (DLL + aq_dic)。既定パス
  `D:\ドキュメント\aquestalkplayer` (環境変数 `AQUES_BASE` で上書き可)。
  32bit の組み込み Python は `recipes/lib/yukkuri.py` が初回に自動展開する。
  **ライセンス: フリー版は個人・非営利のみ無償** ([../README.md](../README.md))。
- **依存**: `ffmpeg` (NVENC)、`Pillow`、`yt-dlp` (URL 素材時)。
- 使う小道具: [../lib/yukkuri.py](../lib/yukkuri.py) /
  [../lib/burst_bg.py](../lib/burst_bg.py) / [../lib/comment_box.py](../lib/comment_box.py)。

## 既知の粗さ (改善余地・必要になったら)

- コメントボックスの**出現ポップ**アニメ未実装 (今は enable で瞬間表示)。
- レスは**1個ずつ表示**で消える (積み上げ型にするオプション余地)。
- ヒーローの**ズームパンチ**未実装 (静止)。
- 横位置ずれ: landscape 素材を縦クロップするため。縦素材ならそのまま綺麗。
