# Hermes Cron Prompt

Task:

1. Check `inputs/inbox/` for unprocessed SNS video URL files.
2. If one exists, run `python3 tools/daily_runner.py --mode preimage --max-images 6`.
3. Check latest `runs/*/harness_log.json`.
4. Summarize whether there are failed runs, review-pending runs, or learning-update-pending runs.
5. Do not modify brand rules directly.
6. If a human has approved learning updates, run `python3 tools/apply_learning_to_vault.py --run-dir <latest-run-dir> --vault sample-cosme`.
7. Report the generated review files under `runs/<run_id>/review/`.

The goal is not to chat. The goal is to keep the SNS video operations workflow moving. Image rendering is a separate approved step; do not run it unless the operator explicitly switches to `--mode render` or `--mode full --execute-images`.

