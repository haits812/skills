#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
HARNESS_DIR="${HARNESS_DIR:-$(cd "$SCRIPT_DIR/.." && pwd)}"
if [[ ! -f "$HARNESS_DIR/tools/daily_runner.py" ]]; then
  cat >&2 <<'EOF'
Could not find tools/daily_runner.py.

If this script was copied under ~/.hermes/scripts, set HARNESS_DIR to the
absolute path of the package's harness directory, or use the wrapper described
in hermes/install_cron.md.
EOF
  exit 1
fi
cd "$HARNESS_DIR"

MAX_IMAGES="${MAX_IMAGES:-6}"
MODE="${MODE:-preimage}"

if [[ "${EXECUTE_IMAGES:-0}" == "1" ]]; then
  python3 tools/daily_runner.py --mode "$MODE" --execute-images --max-images "$MAX_IMAGES"
else
  python3 tools/daily_runner.py --mode "$MODE" --max-images "$MAX_IMAGES"
fi
