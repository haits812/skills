# Hermes Cron Setup

Hermes Agentを導入済みの環境で、SNS動画運用ハーネスを定期実行するためのメモです。

## 重要な前提

この配布版の安定経路は、Hermes AgentのLLM実行ではなく、Hermesの `script-only cron` です。

- `--no-agent`: LLMを使わず、bashを実行する
- `--script`: `~/.hermes/scripts/` 配下のscriptを実行する
- 自動発火には `hermes gateway` が起動している必要がある
- Hermes AgentでCodexモデルを使うには、Hermes側のOpenAI Codex認証が別途必要

## 1. まず手動起動する

```bash
cd harness
printf '%s\n' "https://www.instagram.com/reels/XXXX/" > inputs/inbox/sample-cosme.md
MODE=preimage MAX_IMAGES=6 bash hermes/day02_sns_video_ops_daily.sh
```

## 2. Hermes script-only cron用wrapperを作る

Hermesの `--script` は `~/.hermes/scripts/` 配下のscriptを実行するため、配布パッケージ内のscriptをそのままコピーすると相対パスが崩れます。必ず `HARNESS_DIR` を固定したwrapperを作ります。

```bash
cd harness
mkdir -p ~/.hermes/scripts
cat > ~/.hermes/scripts/sns_video_ops_daily.sh <<EOF
#!/usr/bin/env bash
set -euo pipefail
export HARNESS_DIR="$(pwd)"
export MODE="\${MODE:-preimage}"
export MAX_IMAGES="\${MAX_IMAGES:-6}"
bash "\$HARNESS_DIR/hermes/day02_sns_video_ops_daily.sh"
EOF
chmod +x ~/.hermes/scripts/sns_video_ops_daily.sh
```

## 3. script-only cronを作る

```bash
hermes cron create "every 1d" \
  --no-agent \
  --script sns_video_ops_daily.sh \
  --deliver local \
  --name "sns-video-ops-daily"
```

## 4. 手動で1回起動する

```bash
hermes cron list
hermes cron run <job_id>
hermes cron tick
```

## 5. 自動実行させる

`hermes cron status` が `Gateway is not running` の場合、登録済みcronは自動発火しません。

```bash
hermes gateway
```

またはユーザーサービスとして入れる場合:

```bash
hermes gateway install
```

## 6. Agent cronへ広げる場合

script-onlyで安定した後、必要なら `cron_prompt.md` を使ってagent sessionへ広げます。ただし、この経路はHermes側のモデルプロバイダと認証に依存します。

```bash
hermes status
hermes auth status openai-codex
```

OpenAI Codexが未ログインの場合、Hermes AgentはCodexサブスク経路では動きません。

Vaultを直接上書きさせるのではなく、改善提案を作り、人間が承認したものだけ反映する運用を推奨します。

