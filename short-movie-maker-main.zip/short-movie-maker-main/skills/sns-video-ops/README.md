# SNS Video Ops Harness

競合SNS動画を分析し、自社商品のUGC風SNS動画の企画、台本、字コンテ、絵コンテ確認まで進めるハーネスです。

## What This Builds

入力はInstagramリールURLまたはローカル動画です。出力は最終動画ではなく、制作判断に使う中間成果物です。

1. 動画取得
2. フレーム抽出
3. サブ秒ショット検出
4. Claude Codeによるフレーム/ショット分析
5. Vaultによる自社文脈、UGC文法、禁止線の注入
6. 自社UGC動画企画
7. 台本
8. 字コンテ
9. image 2プロンプト
10. image 2絵コンテ画像
11. HTMLレビュー板
12. レビューと学習更新

## Canonical Files

```text
harness/
├── README.md
├── AGENTS.md
├── CLAUDE.md
├── docs/
├── vaults/
│   ├── sample-cosme/
│   └── template-cosme/
├── tools/
├── schemas/
├── prompts/
├── hermes/
├── inputs/
└── runs/                 # 実行時に生成。配布zipには含めない
```

## Run

画像生成前の改善ループ:

```bash
python3 tools/run_harness.py \
  --mode preimage \
  --run-id sample-cosme-test-001 \
  --url "https://www.instagram.com/reels/XXXX/" \
  --analysis-concurrency 6 \
  --max-frames 25 \
  --max-shots 60 \
  --max-images 6
```

画像生成だけ後から実行:

```bash
python3 tools/run_harness.py \
  --mode render \
  --run-dir runs/sample-cosme-test-001 \
  --max-images 6 \
  --execute-images
```

Hermes/bash入口:

```bash
printf '%s\n' "https://www.instagram.com/reels/XXXX/" > inputs/inbox/sample-cosme.md
MODE=preimage MAX_IMAGES=6 bash hermes/day02_sns_video_ops_daily.sh
```

## Review Entry Points

```text
runs/<run_id>/storyboard/14_operator_board.html
runs/<run_id>/storyboard/13_analysis_review_board.html
runs/<run_id>/storyboard/08_storyboard_board.html
runs/<run_id>/stages/04b_ad_video_plan.md
runs/<run_id>/stages/05a_video_script.md
runs/<run_id>/stages/05b_shot_script.md
runs/<run_id>/stages/06_image_prompts.yaml
runs/<run_id>/stages/context_reads/
```

## Known Scope

この配布版は、架空コスメブランド `sample-cosme` をデフォルトにしたスターターです。完全な汎用SaaSではありません。自社導入時はVaultを書き換え、必要に応じて `tools/build_brief.py` や `tools/build_shot_script.py` のサンプル商品名も調整してください。

