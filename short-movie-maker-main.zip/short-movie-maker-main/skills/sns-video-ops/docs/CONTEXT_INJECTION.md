# Context Injection

## Principle

AIに全部渡さない。stageごとに必要なVaultファイルだけを渡す。

デフォルトVaultは `vaults/sample-cosme/`。自社導入時はこのVaultを編集するか、`vaults/template-cosme/` をコピーして使う。

## Canonical Vault Files

| File | Role | Typical Stages |
|---|---|---|
| `brand_context.md` | 商品、ターゲット、利用シーン、CTA | brief, UGC plan, script, review |
| `ugc_style_grammar.md` | UGC風SNS動画の見た目、語り口、禁止トーン | analysis, plan, script, shot script, image prompts |
| `shot_grammar.md` | 画角、フレーミング、被写体、動き、編集意図の見方 | shot analysis, shot script, image prompts |
| `claim_guardrails.md` | コスメ表現の禁止線、薬機法・景表法リスク | plan, script, prompts, review |
| `learnings.md` | 過去runの学習 | analysis, plan, script, review, update memory |

## Routing

`vaults/sample-cosme/context_manifest.json` がstageごとのrequired/optional contextを定義する。

```text
analyze_shots
  -> ugc_style_grammar, shot_grammar, learnings

analyze_frames
  -> ugc_style_grammar, shot_grammar, learnings

build_brief
  -> brand_context, ugc_style_grammar, claim_guardrails, learnings

build_ugc_plan
  -> brand_context, ugc_style_grammar, claim_guardrails, learnings

build_video_script
  -> brand_context, ugc_style_grammar, claim_guardrails, learnings

build_shot_script
  -> brand_context, ugc_style_grammar, shot_grammar, claim_guardrails, learnings

build_image_prompts
  -> ugc_style_grammar, shot_grammar, claim_guardrails

review_outputs
  -> brand_context, ugc_style_grammar, shot_grammar, claim_guardrails, learnings
```

## Audit

各stageは実行時に `stages/context_reads/<stage>.json` を出す。

保存する情報:

- stage name
- purpose
- required/optional files
- actual file path
- sha256
- missing required files
- input artifacts
- output artifacts

これにより「その出力は何の文脈を読んで作られたのか」を後から説明できる。

## Explanation

Obsidian/Vaultの価値は、単に情報を置くことではない。

- 競合動画のファクト
- 自社の商品/ターゲット/禁止線
- UGC風の見た目と言葉
- ショット単位の作り方
- 過去runの学び

これらを工程ごとに必要な量だけ渡すことで、出力が自然に自社らしくなり、同時に監査可能になる。
