# Operation Runbook

## 通常実行

preimageで分析、企画、台本、字コンテ、画像プロンプトまで作る。

```bash
python3 tools/run_harness.py \
  --mode preimage \
  --run-id sample-cosme-test-001 \
  --url "https://www.instagram.com/reels/XXXX/" \
  --analysis-concurrency 6 \
  --max-frames 25 \
  --max-shots 60 \
  --max-images 6
```

## 画像生成

`stages/06b_preimage_review.json` が `accept` のrunだけrenderへ進める。

```bash
python3 tools/run_harness.py \
  --mode render \
  --run-dir runs/sample-cosme-test-001 \
  --max-images 6 \
  --execute-images
```

## Inbox経由の起動

```bash
printf '%s\n' "https://www.instagram.com/reels/XXXX/" > inputs/inbox/sample-cosme.md
MODE=preimage MAX_IMAGES=6 bash hermes/day02_sns_video_ops_daily.sh
```

## 確認するHTML

```text
runs/<run_id>/storyboard/14_operator_board.html
runs/<run_id>/storyboard/13_analysis_review_board.html
runs/<run_id>/storyboard/08_storyboard_board.html
```

## 学習更新

人間レビュー後、承認した項目だけをVaultへ戻す。

```bash
python3 tools/build_review_learning_pack.py --run-dir runs/<run_id>
python3 tools/apply_learning_to_vault.py --run-dir runs/<run_id>
python3 tools/verify_vault_context_read.py --run-id vault-read-after-human-review-001
```

## Run ID運用

- 分析、企画、字コンテを作り直すときは毎回新しいrun idを作る。
- 同じrun idにpreimageを再実行して育て直さない。
- renderはaccept済みpreimage runに対してだけ実行する。

