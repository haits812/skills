# UGC Canonical Architecture

## Goal

競合SNS動画から、コピーではなく再利用可能な構造を抽出し、自社商品のUGC風SNS動画の企画、台本、字コンテ、絵コンテ確認へ変換する。

## Core Flow

```text
URL or local video
  -> download_video
  -> extract_frames
  -> detect_shots
  -> analyze_shots_with_claude
  -> analyze_frames_with_claude
  -> build_shot_structure_map
  -> build_temporal_window_analysis
  -> build_competitive_pattern_map
  -> build_brief
  -> build_ad_video_plan
  -> build_continuity_contract
  -> build_storyboard_plan
  -> build_video_script
  -> build_shot_script
  -> build_image_prompts
  -> review_preimage_outputs
  -> render images when accepted
```

## Vault

Vaultは最初から細かく分けすぎない。最小単位は以下です。

- `brand_context.md`: ブランド、商品、ターゲット、提供価値
- `ugc_style_grammar.md`: UGC風に見える条件、避ける表現
- `shot_grammar.md`: 画角、被写体、動き、編集意図
- `claim_guardrails.md`: 薬機法、景表法、レビュー捏造の禁止線
- `learnings.md`: 人間レビュー後に承認した学び

各stageは `context_manifest.json` を読み、実際に読んだVaultファイルを `runs/<run_id>/stages/context_reads/<stage>.json` に残す。

## Claude Code Role

- フレーム/ショット画像を読んで構造化分析を行う。
- Vaultを踏まえて、自社UGC動画向けの企画、台本、字コンテへ変換する。
- 競合の表面表現ではなく、視聴者理解の順番、カット尺、画角、編集テンポを抽出する。

## Codex/image 2 Role

- 字コンテをもとに、絵コンテ確認用の画像を生成する。
- 画像は最終クリエイティブではなく、制作チームが方向性を確認する補助成果物。
- テロップやCTAは画像に焼き込まず、編集レイヤーで後載せする。

## Hermes Role

- 本来の役割は、定期的にinboxを見て処理を起動すること。
- 初回は `hermes/day02_sns_video_ops_daily.sh` を手動実行する。
- Vault更新は人間承認後に行う。自動でVaultを上書きしない。

