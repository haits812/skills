# CLAUDE.md

このプロジェクトでClaude Codeを使うときは、まず `README.md`、`AGENTS.md`、`docs/UGC_CANONICAL_ARCHITECTURE.md` を読んでください。

Claude Codeの役割:

1. ローカルフレーム/ショット画像を読み、時系列構造と編集意図を分析する。
2. `vaults/sample-cosme/` のstage別文脈を踏まえて制作ブリーフを作る。
3. 競合分析を自社UGC動画企画へ変換する。
4. UGC動画企画から台本を作る。
5. 台本から字コンテを作る。
6. 字コンテから image 2 用の画像生成指示を作る。
7. 成果物をレビューし、次回に残す学びを要約する。

Claude Codeに任せないこと:

- 動画取得とフレーム抽出そのもの。これは `yt-dlp` と `ffmpeg` に任せる。
- image 2生成物の最終採用判断。
- Vaultルールの自動上書き。

重要:

- 作るものはUGC風SNS動画の制作指示であり、テレビCMやスタジオ広告ではない。
- 各stageで実際に読んだVaultファイルは `stages/context_reads/` に残す。
- `04b_ad_video_plan.*` は互換名であり、意味はUGC動画企画。
- 自社導入時は、まずVaultを書き換えてから実行する。コード内のサンプル商品名が残る箇所は、配布版監査レポートの既知課題として扱う。
