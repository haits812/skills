# AGENTS.md

このディレクトリは、競合SNS動画を分析し、自社商品のUGC風SNS動画企画、台本、字コンテ、絵コンテ確認まで進める運用ハーネスです。

## Canonical Design

最初に `README.md` と `docs/UGC_CANONICAL_ARCHITECTURE.md` を読む。

デフォルトVaultは `vaults/sample-cosme/`。自社用に使う場合は、このVaultをコピーしてブランド、商品、表現禁止線、学習ログを書き換える。

## Execution Principles

- 一つの巨大プロンプトで全工程を済ませない。
- stageごとに必要なVaultファイルだけを `context_manifest.json` から読む。
- 実際に読んだVaultファイルは `runs/<run_id>/stages/context_reads/<stage>.json` に残す。
- 画像生成は字コンテの補助工程。正本は `05b_shot_script.*`。
- UGC風SNS動画として自然なスマホ縦動画を作る。テレビCM、スタジオ広告、海外ラグジュアリー広告へ寄せない。

## Prohibited

- `meta-spy` をこのワークフローに組み込まない。
- 旧 `memory/` や旧Vault v1を新しいstageに再接続しない。
- image 2の生成結果を人間レビューなしで最終採用しない。
- 実在顧客情報、秘匿情報、未公開アカウント情報を外部APIに送らない。
- 競合のUI、コピー、パッケージ、レビュー文を模写しない。

## Recommended Review Flow

- `storyboard/14_operator_board.html` で全体を確認する。
- `storyboard/13_analysis_review_board.html` で分析、企画、字コンテ、Vault読込ログを確認する。
- `storyboard/08_storyboard_board.html` で絵コンテ画像と字コンテを横に見て確認する。
- 人間レビュー後、承認した学習だけをVaultへ戻す。
