---
name: sns-video-ops
description: 競合の SNS 動画 (Instagram リール URL or ローカル動画) を分析し、自社商品の UGC 風 SNS 動画の企画・台本・字コンテ・画像生成指示・絵コンテレビュー板まで作る運用ハーネス。フレーム/ショット分析 → Vault (自社文脈・UGC文法・禁止線) 注入 → 企画変換 → 台本 → 字コンテ → image プロンプト → HTML レビュー板 → 学習更新、のパイプライン。「このリールを分析して自社版の企画作って」「競合動画から UGC 台本起こして」等で使う。最終動画は作らない (制作判断に使う中間成果物まで)。
---

# sns-video-ops

競合 SNS 動画の分析から自社 UGC 風動画の制作指示までを作る運用ハーネス。
day02-sns-video-ops-bonus (Hermes ハーネス) をスキルとして取り込んだもので、
**中身の正典はこのディレクトリ直下の `README.md` / `AGENTS.md` / `CLAUDE.md` /
`docs/UGC_CANONICAL_ARCHITECTURE.md`。実行前に必ずこの 4 つを読むこと。**

## 使いどころ

- 入力: Instagram リール URL または ローカル動画
- 出力: 最終動画ではなく制作判断用の中間成果物 —
  フレーム/ショット分析 → UGC 企画 → 台本 → 字コンテ → image 2 プロンプト →
  HTML レビュー板 → 学習更新
- 切り抜き量産は `short-movie-maker`、テーマからの新規動画制作は `video-production` を使う。
  このスキルは「競合分析 → 自社 UGC 制作指示」専用。

## 実行の要点 (詳細は README.md)

```bash
python3 tools/run_harness.py --mode preimage --run-id <run-id> --url "<リールURL>"
```

- 実行成果物 `runs/` は生成物なので git に入れない (リポジトリの .gitignore で除外済み)。
- 自社導入時はまず `vaults/` を自社文脈に書き換えてから実行する
  (`vaults/template-cosme/` がテンプレ、`vaults/sample-cosme/` がサンプル)。
- Claude の役割・任せない領域は `CLAUDE.md` の定義に従う。
