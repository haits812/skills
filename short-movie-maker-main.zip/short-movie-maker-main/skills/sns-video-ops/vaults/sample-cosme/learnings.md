# 学習ログ

完了したrunから得た学びを保存する。

## サンプル初期メモ

- 競合事実、LUMIA前提、生成案を分ける。
- きれいな広告画像より、シーン意図が伝わる絵コンテを優先する。
- 競合リール分析では、各ショットの「採用する構造」と「コピー禁止」を同時に記録してから字コンテへ渡す。
- 自社UGC動画では、広告らしい作り込みよりも、日本の生活者が自宅で撮ったような自然な距離感を優先する。
- 画像生成前に字コンテを確認し、人物、場所、商品、光、撮影トーンの一貫性が崩れていないかを見る。
- 競合の良いカットは、画角、尺、視聴者理解の順番として採用してよい。ただし固有のブランド、容器、コピー、SNS UIは持ち込まない。
- Per-frame image analysis is more stable than large contact-sheet analysis for this Claude Code workflow.
- Fast Reels require shot-boundary analysis in addition to 1fps frame sampling; otherwise sub-second cuts disappear from the planning context.
- Japanese cosmetic ad generation needs an explicit visual continuity contract for person, room, product shape, and negative drift conditions.
- Long-form brief/storyboard generation should use compacted analysis or deterministic assembly to avoid prompt bloat.
- image 2 storyboard prompts should explicitly block competitor packaging, fake social UI, long text, and medical claims.
- 絵コンテ画像では、人物の顔立ちがシーンごとに変わるとUGCシリーズとしての信頼感が落ちる。画像生成プロンプトでは同一人物の参照イメージ、髪型、年齢感、服装方向を毎回固定する。
- 絵コンテ全体が人物の顔中心に寄りすぎると、商品理解が弱くなる。商品理解、質感、CTAでは顔を主役にせず、商品単体、手元、洗面台置き、スプレー口、ラベル印象のカットを明示的に混ぜる。
