#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

from lib.harness_common import append_log, load_json, resolve_run_dir, stage_path, write_context_read_log, write_json, write_text, write_yaml_like


ROLE_KEYWORDS = [
    ("cta", ["cta", "チェック", "保存", "詳細", "プロフィール", "買える", "締め"]),
    ("finish", ["仕上", "サラ艶", "ツヤ", "艶", "天才", "なりたい", "結果", "印象"]),
    ("routine", ["使用", "手順", "ルーティン", "使う", "塗", "すくう", "スプレー", "メイク前", "支度"]),
    ("texture", ["質感", "クリーム", "泡", "ミスト", "中身", "テクスチャ", "接写"]),
    ("trust", ["レビュー", "proof", "証明", "X", "Twitter", "購入", "実績", "バズ", "在庫", "相乗効果"]),
    ("product", ["商品", "ラベル", "容器", "ジャー", "ボトル", "product", "ヘアケア"]),
    ("hook", ["冒頭", "フック", "話題", "スクロール"]),
]


CAMERA_KEYWORDS = [
    ("mirror_selfie", ["鏡", "ミラー", "mirror"]),
    ("handheld_close", ["手持ち", "近接", "接写", "クローズ", "スマホ"]),
    ("top_down_vanity", ["斜め上", "真上", "俯瞰", "天面"]),
    ("product_on_vanity", ["洗面台", "ドレッサー", "テーブルトップ", "置かれた", "据え置き"]),
    ("hand_and_product", ["手で", "片手", "両手", "持つ", "掲げ", "指"]),
    ("partial_face", ["半顔", "パーシャル", "頬", "口元", "顔の一部", "partial_face"]),
    ("overlay_collage", ["スクショ", "コラージュ", "重ね", "PinP", "ピクチャーインピクチャー", "合成"]),
]


COMPETITOR_TERMS = [
    "ADVANCED CLINICALS",
    "Advanced Clinicals",
    "BIOTIN",
    "KERATIN",
    "ヘアマスク",
    "ヘアケア",
    "ジャー",
    "Xでバズりまくり",
    "SNS投稿スクショ",
    "通販レビュー",
    "星評価",
    "閲覧数",
    "購入実績",
]


ROLE_HINTS = {
    "hook": {
        "viewer_question": "何の商品で、なぜ見続けるべきかを冒頭で理解する",
        "reuse": "冒頭で商品カテゴリ、生活者の悩み、見る理由を短い画と後載せテロップで同時に理解させる",
        "conversion": "LUMIAでは、商品1本と朝の支度シーンを短く見せ、話題性ではなく使用タイミングの自分ごと化で止める",
    },
    "trust": {
        "viewer_question": "なぜ信じてよいのか、どの生活文脈で使われているのかを理解する",
        "reuse": "社会的証明や使用メモで納得感を作る。ただし偽レビューやSNS UIではなく、実在情報と生活導線で補強する",
        "conversion": "LUMIAでは、実在するレビューや使用タイミングの短いメモだけを後載せし、架空数値や競合UIは使わない",
    },
    "product": {
        "viewer_question": "どんな商品か、どの場面で使うものかを理解する",
        "reuse": "商品を生活導線の中で短く見せ、ラベル説明ではなく使う場所と手元動作で商品理解を作る",
        "conversion": "LUMIAでは、洗面台やメイク道具の横に商品1本を置き、スプレー口や手に取る動きでミスト商品だと分かるようにする",
    },
    "texture": {
        "viewer_question": "中身や使用感がどう見えるかを視覚で理解する",
        "reuse": "手元接写や質感カットで、言葉ではなく素材感と使う直前の動きを見せる",
        "conversion": "LUMIAでは、スプレー口、軽いミスト感、手元の近接カットを使い、過度な水滴や効果演出は避ける",
    },
    "routine": {
        "viewer_question": "日常のどのタイミングでどう使うのかを理解する",
        "reuse": "生活者の手順、手元動作、鏡前の流れで使用シーンを具体化する",
        "conversion": "LUMIAでは、朝のメイク前に商品へ手を伸ばす、顔から少し離して構える、洗面台へ戻す流れを見せる",
    },
    "finish": {
        "viewer_question": "使った後にどんな印象や気分につながるのかを理解する",
        "reuse": "仕上がりを断定せず、自然な表情や支度の続きで余韻を作る",
        "conversion": "LUMIAでは、ビフォーアフターではなく、同じ洗面台で支度を続ける自然な印象を見せる",
    },
    "cta": {
        "viewer_question": "次に何をすればよいかを理解する",
        "reuse": "最後に商品を再提示し、保存や詳細確認へ軽くつなげる",
        "conversion": "LUMIAでは、商品1本と余白を残した置きカットに、保存/プロフィール確認の短い後載せCTAを入れる",
    },
}


def compact_shot_analysis(shot_manifest: dict, shot_analysis: dict) -> list[dict]:
    manifest_by_ref = {item.get("source_ref"): item for item in shot_manifest.get("shots", [])}
    rows = []
    for item in shot_analysis.get("frames", []):
        refs = item.get("source_refs", [])
        ref = refs[0] if refs else ""
        manifest_item = manifest_by_ref.get(ref, {})
        rows.append({
            "source_shot_ref": ref,
            "start_sec": manifest_item.get("start_sec"),
            "end_sec": manifest_item.get("end_sec"),
            "duration_sec": manifest_item.get("duration_sec"),
            "is_micro_shot": manifest_item.get("is_micro_shot"),
            "visible_elements": item.get("visible_elements", [])[:8],
            "on_screen_text": item.get("on_screen_text", []),
            "motion_or_edit": item.get("motion_or_edit", ""),
            "business_signal": item.get("business_signal", ""),
            "role": item.get("role", ""),
            "camera_pattern": item.get("camera_pattern", ""),
            "framing": item.get("framing", ""),
            "camera_distance": item.get("camera_distance", ""),
            "angle": item.get("angle", ""),
            "viewer_question_answered": item.get("viewer_question_answered", ""),
            "reuse_principle": item.get("reuse_principle", ""),
            "do_not_copy": item.get("do_not_copy", []),
            "conversion_hint_for_own_brand": item.get("conversion_hint_for_own_brand", ""),
        })
    return rows


def joined_text(row: dict) -> str:
    parts = []
    parts.extend(row.get("visible_elements", []))
    parts.extend(row.get("on_screen_text", []))
    parts.append(row.get("motion_or_edit", ""))
    parts.append(row.get("business_signal", ""))
    return "\n".join(str(part) for part in parts if part)


def contains_any(text: str, keywords: list[str]) -> bool:
    lowered = text.lower()
    return any(keyword.lower() in lowered for keyword in keywords)


def classify_role(row: dict, index: int, total: int) -> str:
    text = joined_text(row)
    if index <= 3 and contains_any(text, ["冒頭", "フック", "話題", "バズ", "スクロール", "ヘアケア"]):
        return "hook"
    if index >= max(1, total - 2) and contains_any(text, ["チェック", "保存", "買える", "cta", "締め"]):
        return "cta"
    scores: dict[str, int] = {}
    for role, keywords in ROLE_KEYWORDS:
        scores[role] = sum(1 for keyword in keywords if keyword.lower() in text.lower())
    role = max(scores, key=scores.get)
    if scores.get(role, 0) == 0:
        if index <= 5:
            return "hook"
        if index >= total - 3:
            return "finish"
        return "product"
    if 6 <= index <= 10:
        return "product"
    if 11 <= index <= 18 and role in {"product", "texture", "trust"}:
        return "routine"
    if 19 <= index <= 22 and role == "product":
        return "finish"
    if index >= total - 2:
        return "cta"
    if role == "texture":
        return "routine"
    return role


def classify_camera(row: dict) -> str:
    text = joined_text(row)
    patterns = [label for label, keywords in CAMERA_KEYWORDS if contains_any(text, keywords)]
    if not patterns:
        return "vertical smartphone handheld"
    return " + ".join(dict.fromkeys(patterns[:3]))


def camera_distance(row: dict) -> str:
    text = joined_text(row)
    if contains_any(text, ["接写", "近接", "クローズ", "アップ", "マクロ"]):
        return "close"
    if contains_any(text, ["上半身", "バスト", "中距離", "テーブル"]):
        return "medium"
    return "smartphone-near"


def camera_angle(row: dict) -> str:
    text = joined_text(row)
    if contains_any(text, ["俯瞰", "斜め上", "真上", "天面"]):
        return "top-down or high angle"
    if contains_any(text, ["鏡", "正面", "目線"]):
        return "eye-level front or mirror angle"
    return "casual handheld angle"


def human_presence(row: dict) -> str:
    text = joined_text(row)
    if contains_any(text, ["女性", "顔", "半顔", "頬", "口元", "人物"]):
        if contains_any(text, ["手", "指"]):
            return "partial face and hands"
        return "partial face"
    if contains_any(text, ["手", "指", "片手", "両手"]):
        return "hands only"
    return "none"


def product_presence(row: dict) -> str:
    text = joined_text(row)
    if contains_any(text, ["ジャー", "容器", "ラベル", "商品", "ボトル"]):
        if contains_any(text, ["2個", "両", "複数", "ラインナップ"]):
            return "competitor products are visible as multiple containers"
        return "competitor product is visible"
    return "product not visible or unclear"


def visible_subject(row: dict) -> list[str]:
    items = list(row.get("visible_elements", [])[:5])
    if not items:
        return ["visible subject requires review"]
    return items


def framing(row: dict) -> str:
    text = joined_text(row)
    if contains_any(text, ["スクショ", "コラージュ", "PinP", "ピクチャーインピクチャー", "合成"]):
        return "layered overlay composition with product or person in background"
    if contains_any(text, ["洗面台", "ドレッサー", "テーブル"]):
        return "vanity or tabletop lifestyle framing"
    if contains_any(text, ["半顔", "顔の一部", "パーシャル", "頬", "口元"]):
        return "partial-face close framing"
    if contains_any(text, ["手元", "指", "片手", "両手"]):
        return "hand-action close framing"
    return "vertical smartphone framing"


def do_not_copy(row: dict, role: str) -> list[str]:
    text = joined_text(row)
    items = []
    for term in COMPETITOR_TERMS:
        if term.lower() in text.lower():
            items.append(f"{term}をコピーしない")
    if contains_any(text, ["スクショ", "レビュー", "星評価", "購入", "閲覧", "投稿"]):
        items.append("実在しないSNS UI、レビュー数、購入実績を作らない")
    if contains_any(text, ["髪", "ヘア", "ケラチン", "ビオチン"]):
        items.append("ヘアケア文脈を自社ミスト商品の文脈へ持ち込まない")
    if role in {"hook", "cta"}:
        items.append("商品を掲げる広告的ポーズに寄せすぎない")
    items.append("競合の容器、ラベル、商品カテゴリ、文言をそのまま使わない")
    return list(dict.fromkeys(items))[:8]


def role_hint(role: str) -> dict:
    return ROLE_HINTS.get(role, ROLE_HINTS["product"])


def normalize_shot(row: dict, index: int, total: int) -> dict:
    role = row.get("role") or classify_role(row, index, total)
    hint = role_hint(role)
    return {
        "source_shot_ref": row.get("source_shot_ref", ""),
        "duration_sec": float(row.get("duration_sec") or 0),
        "is_micro_shot": bool(row.get("is_micro_shot")),
        "role": role,
        "visible_subject": visible_subject(row),
        "product_presence": product_presence(row),
        "human_presence": human_presence(row),
        "camera_pattern": row.get("camera_pattern") or classify_camera(row),
        "framing": row.get("framing") or framing(row),
        "camera_distance": row.get("camera_distance") or camera_distance(row),
        "angle": row.get("angle") or camera_angle(row),
        "motion": row.get("motion_or_edit", ""),
        "edit_function": row.get("motion_or_edit", ""),
        "on_screen_text": row.get("on_screen_text", []),
        "viewer_question_answered": row.get("viewer_question_answered") or hint["viewer_question"],
        "reuse_principle": row.get("reuse_principle") or hint["reuse"],
        "do_not_copy": list(dict.fromkeys((row.get("do_not_copy") or []) + do_not_copy(row, role)))[:10],
        "conversion_hint_for_own_brand": row.get("conversion_hint_for_own_brand") or hint["conversion"],
        "business_signal": row.get("business_signal", ""),
        "normalization_basis": "03b_structural_fields" if row.get("reuse_principle") else "deterministic_from_03b_shot_analysis",
    }


def aggregate_patterns(shots: list[dict]) -> list[str]:
    patterns = []
    roles = [shot.get("role", "") for shot in shots]
    if roles:
        patterns.append(" → ".join(dict.fromkeys(roles)))
    if any(shot.get("is_micro_shot") for shot in shots):
        patterns.append("冒頭やつなぎにmicro shotを混ぜてテンポを作る")
    if any("overlay_collage" in shot.get("camera_pattern", "") for shot in shots):
        patterns.append("証拠や説明は画面レイヤーで補足する。ただし自社では偽UIを避ける")
    if any("hand" in shot.get("camera_pattern", "") for shot in shots):
        patterns.append("商品理解は手元動作と生活導線で作る")
    return list(dict.fromkeys(patterns))


def aggregate_risks(shots: list[dict]) -> list[str]:
    risks = [
        "03cはLLM一括再解釈ではなく、03bショット分析を決定論的に正規化したもの。",
        "微妙なrole分類は後段の字コンテ生成で補正される前提。必要なら03bの各ショット分析を確認する。",
    ]
    if any("実在しないSNS UI" in " / ".join(shot.get("do_not_copy", [])) for shot in shots):
        risks.append("競合のSNS UIやレビュー数は構造参考に留め、自社動画では実在しない証拠として生成しない。")
    return risks


def markdown(data: dict) -> str:
    lines = [
        f"# {data.get('title', 'Shot Structure Map')}",
        "",
        f"- source_run: {data.get('source_run', '')}",
        "",
        "## Context Refs",
        "",
        *[f"- {item}" for item in data.get("context_refs", [])],
        "",
        "## Shots",
        "",
    ]
    for shot in data.get("shots", []):
        lines.extend([
            f"### {shot.get('source_shot_ref')} / {shot.get('role')}",
            "",
            f"- duration_sec: {shot.get('duration_sec')}",
            f"- is_micro_shot: {shot.get('is_micro_shot')}",
            f"- camera_pattern: {shot.get('camera_pattern')}",
            f"- framing: {shot.get('framing')}",
            f"- edit_function: {shot.get('edit_function')}",
            f"- viewer_question_answered: {shot.get('viewer_question_answered')}",
            f"- reuse_principle: {shot.get('reuse_principle')}",
            f"- conversion_hint_for_own_brand: {shot.get('conversion_hint_for_own_brand')}",
            f"- do_not_copy: {' / '.join(shot.get('do_not_copy', []))}",
            "",
        ])
    lines.extend(["## Patterns", "", *[f"- {item}" for item in data.get("patterns", [])], ""])
    lines.extend(["## Risks", "", *[f"- {item}" for item in data.get("risks", [])], ""])
    return "\n".join(lines).strip() + "\n"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", type=Path)
    parser.add_argument("--run-id")
    parser.add_argument("--max-budget-usd", type=float, default=6.0)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    run_dir = resolve_run_dir(args)
    append_log(run_dir, "build_shot_structure_map", "start")
    output_json = stage_path(run_dir, "03c_shot_structure_map.json")
    context_report = write_context_read_log(
        run_dir,
        "build_shot_structure_map",
        input_artifacts=["stages/02b_shot_manifest.json", "stages/03b_shot_analysis.json"],
        output_artifacts=["stages/03c_shot_structure_map.json", "stages/03c_shot_structure_map.md"],
    )
    if output_json.exists() and not args.force:
        cached = load_json(output_json)
        if isinstance(cached.get("shots"), list) and cached["shots"]:
            append_log(run_dir, "build_shot_structure_map", "skip_existing", shot_count=len(cached.get("shots", [])))
            return 0
    shot_manifest = load_json(stage_path(run_dir, "02b_shot_manifest.json"))
    shot_analysis = load_json(stage_path(run_dir, "03b_shot_analysis.json"))
    rows = compact_shot_analysis(shot_manifest, shot_analysis)
    shots = [
        normalize_shot(row, index, len(rows))
        for index, row in enumerate(rows, start=1)
    ]
    parsed = {
        "title": "Shot Structure Map",
        "source_run": run_dir.name,
        "context_refs": [item["relative_path"] for item in context_report.get("files", []) if item.get("exists")],
        "mode": "deterministic_from_03b_shot_analysis",
        "shots": shots,
        "patterns": aggregate_patterns(shots),
        "risks": aggregate_risks(shots),
    }
    write_json(stage_path(run_dir, "03c_shot_structure_map.json"), parsed)
    write_yaml_like(stage_path(run_dir, "03c_shot_structure_map.yaml"), parsed)
    write_text(stage_path(run_dir, "03c_shot_structure_map.md"), markdown(parsed))
    write_json(run_dir / "logs" / "build_shot_structure_map.json", {
        "mode": "deterministic_from_03b_shot_analysis",
        "shot_count": len(parsed.get("shots", [])),
        "llm_call": False,
    })
    append_log(run_dir, "build_shot_structure_map", "success", shot_count=len(parsed.get("shots", [])), mode="deterministic")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
