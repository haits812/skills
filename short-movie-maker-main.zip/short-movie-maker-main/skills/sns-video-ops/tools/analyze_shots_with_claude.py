#!/usr/bin/env python3
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from lib.harness_common import HARNESS_ROOT, append_log, load_json, prompt_text, render_context_bundle, resolve_run_dir, run_claude_structured, stage_path, write_context_read_log, write_json


def resolve_shot_frame_path(item: dict) -> Path:
    frame_path = Path(item["representative_frame_path"])
    if frame_path.is_absolute():
        return frame_path
    return (HARNESS_ROOT / frame_path).resolve()


def analyze_single_shot(run_dir: Path, item: dict, max_budget_usd: float, force: bool = False) -> dict:
    index = int(item["index"])
    output_path = run_dir / "batches" / f"03b_shot_analysis_{index:03d}.json"
    if output_path.exists() and not force:
        cached = load_json(output_path)
        if isinstance(cached.get("frames"), list) and cached["frames"]:
            return cached

    frame_path = resolve_shot_frame_path(item)
    prompt = f"""{prompt_text("01_analyze_frames.md")}

{render_context_bundle("analyze_shots")}

# Task

Read this one representative frame for a detected video shot with the Read tool.
Analyze it as a SHOT, not as a one-second sample.

Focus on:
- visible subject/product/background/text
- shot role in the reel
- likely edit function: hook, proof, product close-up, usage, transition, finish, CTA
- whether this is a micro-shot and why it matters for pacing
- production structure fields needed for storyboard planning:
  - role
  - camera_pattern
  - framing
  - camera_distance
  - angle
  - viewer_question_answered
  - reuse_principle
  - do_not_copy
  - conversion_hint_for_own_brand

Do not use outside knowledge. Do not infer invisible product claims.

# Shot

- source_ref: {item["source_ref"]}
- start_sec: {item["start_sec"]}
- end_sec: {item["end_sec"]}
- duration_sec: {item["duration_sec"]}
- representative_time_sec: {item["representative_time_sec"]}
- is_micro_shot: {item["is_micro_shot"]}
- frame_path: {frame_path}

# Required output discipline

- Return strict JSON only. Do not use trailing commas.
- Return exactly one item in `frames[]`.
- `frames[0].source_refs` must be exactly `["{item["source_ref"]}"]`.
- If text is too small or blurry, state that it is unreadable instead of inventing it.
- `motion_or_edit` should describe the shot's edit role and pacing, not just the still image.
- `role` must be one of: hook, product, trust, routine, texture, finish, cta, transition.
- `reuse_principle` must describe the structural pattern to keep, not the competitor expression to copy.
- `do_not_copy` must explicitly block competitor brand, container, label, UI, claims, and exact composition when visible.
- `conversion_hint_for_own_brand` must describe how the own brand should translate the structure into a Japanese UGC-style cosmetics video.
- Keep `patterns`, `reuse_notes`, and `risks` short and tied to this shot.
"""

    parsed, wrapper = run_claude_structured(
        prompt,
        schema_name="shot_analysis.schema.json",
        allowed_tools="Read",
        max_budget_usd=max_budget_usd,
        timeout=420,
    )
    if "raw_text" in parsed or not isinstance(parsed.get("frames"), list) or len(parsed["frames"]) != 1:
        write_json(run_dir / "logs" / f"claude_analyze_shot_{index:03d}_failed.json", {"parsed": parsed, "wrapper": wrapper})
        raise RuntimeError(f"Claude shot {index:03d} did not return one parseable shot item")
    shot_result = parsed["frames"][0]
    if item["source_ref"] not in shot_result.get("source_refs", []):
        shot_result["source_refs"] = [item["source_ref"]]
        parsed["frames"][0] = shot_result
        parsed.setdefault("risks", []).append(f"source_refs normalized to {item['source_ref']}")
    write_json(output_path, parsed)
    write_json(run_dir / "logs" / f"claude_analyze_shot_{index:03d}.json", wrapper)
    return parsed


def merge_results(results: list[dict]) -> dict:
    frames: list[dict] = []
    patterns: list[str] = []
    reuse_notes: list[str] = []
    risks: list[str] = []
    summaries: list[str] = []
    for result in results:
        summaries.append(result.get("batch_summary", ""))
        frames.extend(result.get("frames", []))
        patterns.extend(result.get("patterns", []))
        reuse_notes.extend(result.get("reuse_notes", []))
        risks.extend(result.get("risks", []))
    frames.sort(key=lambda item: float(str(item.get("source_refs", ["shot_000@0-0s"])[0]).split("@", 1)[1].split("-", 1)[0]))
    return {
        "batch_summary": "\n".join(s for s in summaries if s),
        "frames": frames,
        "patterns": patterns,
        "reuse_notes": reuse_notes,
        "risks": risks,
        "traceability": {
            "analysis_mode": "per_shot_representative_read_tool",
            "shot_result_files": [
                f"batches/03b_shot_analysis_{int(item.get('source_refs', ['shot_000'])[0].split('@')[0].split('_')[-1]):03d}.json"
                for item in frames
                if item.get("source_refs")
            ],
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", type=Path)
    parser.add_argument("--run-id")
    parser.add_argument("--max-shots", type=int, default=60)
    parser.add_argument("--max-budget-usd", type=float, default=5.0)
    parser.add_argument("--concurrency", type=int, default=6)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    run_dir = resolve_run_dir(args)
    append_log(run_dir, "analyze_shots_with_claude", "start", max_shots=args.max_shots)
    write_context_read_log(
        run_dir,
        "analyze_shots",
        input_artifacts=["stages/02b_shot_manifest.json", "shots/shot_###.jpg"],
        output_artifacts=["stages/03b_shot_analysis.json", "batches/03b_shot_analysis_###.json"],
    )
    manifest = load_json(stage_path(run_dir, "02b_shot_manifest.json"))
    shots = manifest.get("shots", [])[: args.max_shots]
    if not shots:
        raise RuntimeError("No shots found in 02b_shot_manifest.json")
    if args.concurrency <= 0:
        raise RuntimeError("--concurrency must be positive")

    results: list[dict] = []
    per_shot_budget = max(args.max_budget_usd, 0.25)
    with ThreadPoolExecutor(max_workers=args.concurrency) as executor:
        futures = {
            executor.submit(analyze_single_shot, run_dir, item, per_shot_budget, args.force): item
            for item in shots
        }
        for future in as_completed(futures):
            item = futures[future]
            append_log(run_dir, "analyze_shots_with_claude", "shot_start", shot_index=item["index"], source_ref=item["source_ref"])
            parsed = future.result()
            results.append(parsed)
            append_log(run_dir, "analyze_shots_with_claude", "shot_success", shot_index=item["index"], source_ref=item["source_ref"])

    merged = merge_results(results)
    expected_refs = {item["source_ref"] for item in shots}
    actual_refs = {ref for item in merged.get("frames", []) for ref in item.get("source_refs", [])}
    missing_refs = sorted(expected_refs - actual_refs)
    if missing_refs:
        merged.setdefault("risks", []).append(f"Missing analyzed shot source_refs: {', '.join(missing_refs)}")
        raise RuntimeError(f"Missing analyzed shot source_refs: {', '.join(missing_refs)}")

    write_json(stage_path(run_dir, "03b_shot_analysis.json"), merged)
    write_json(run_dir / "logs" / "claude_analyze_shots.json", {
        "mode": "per_shot_representative_read_tool",
        "result_count": len(merged.get("frames", [])),
        "source_ref_count": len(actual_refs),
        "missing_source_refs": missing_refs,
    })
    append_log(run_dir, "analyze_shots_with_claude", "success", shot_count=len(merged.get("frames", [])))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
