#!/usr/bin/env python3
from __future__ import annotations

import argparse
import html
from collections import defaultdict
from pathlib import Path

from lib.harness_common import append_log, ensure_dir, load_json, relative_or_abs, resolve_run_dir, stage_path, write_json, write_text


def rel(run_dir: Path, path: Path) -> str:
    try:
        return str(path.relative_to(run_dir))
    except ValueError:
        return relative_or_abs(path)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", type=Path)
    parser.add_argument("--run-id")
    args = parser.parse_args()

    run_dir = resolve_run_dir(args)
    append_log(run_dir, "build_preimage_board", "start")
    storyboard_dir = ensure_dir(run_dir / "storyboard")

    shot_manifest = load_json(stage_path(run_dir, "02b_shot_manifest.json"))
    shot_structure = load_json(stage_path(run_dir, "03c_shot_structure_map.json"))
    temporal = load_json(stage_path(run_dir, "03d_temporal_window_analysis.json"))
    pattern_map = load_json(stage_path(run_dir, "03e_competitive_pattern_map.json"))
    ugc_plan = load_json(stage_path(run_dir, "04b_ad_video_plan.json"))
    continuity = load_json(stage_path(run_dir, "04c_continuity_contract.json"))
    storyboard = load_json(stage_path(run_dir, "05_storyboard_plan.json"))
    video_script = load_json(stage_path(run_dir, "05a_video_script.json"))
    shot_script = load_json(stage_path(run_dir, "05b_shot_script.json"))
    image_prompts = load_json(stage_path(run_dir, "06_image_prompts.json"))
    review = load_json(stage_path(run_dir, "06b_preimage_review.json"))

    prompt_by_scene = {item.get("scene_id"): item for item in image_prompts.get("prompts", [])}
    shots_by_scene: dict[str, list[dict]] = defaultdict(list)
    for shot in shot_script.get("planned_shots", []):
        scene_ref = shot.get("scene_id", "")
        if scene_ref:
            shots_by_scene[scene_ref].append(shot)
    script_by_scene = {item.get("scene_id"): item for item in video_script.get("scenes", [])}

    cards = []
    json_scenes = []
    for scene in storyboard.get("scenes", []):
        scene_id = scene["scene_id"]
        script_scene = script_by_scene.get(scene_id, {})
        prompt = prompt_by_scene.get(scene_id, {})
        planned_shots = shots_by_scene.get(scene_id, [])
        shot_rows = []
        for shot in planned_shots:
            shot_rows.append(f"""
<tr>
  <td>{html.escape(shot.get('shot_id', ''))}</td>
  <td>{html.escape(shot.get('camera_pattern') or shot.get('camera_angle', ''))}</td>
  <td>{html.escape(shot.get('subject', ''))}<br>{html.escape(shot.get('action', ''))}<br><span class="muted">{html.escape(shot.get('background', ''))}</span></td>
  <td>{html.escape(shot.get('overlay_text', ''))}</td>
  <td>{html.escape(shot.get('source_learning', ''))}<br><span class="muted">{html.escape(shot.get('edit_layer_notes', ''))}</span></td>
</tr>
""")
        cards.append(f"""
<article class="scene">
  <div class="scene-head">
    <div class="eyebrow">{html.escape(scene_id)} / {html.escape(scene.get('role', ''))}</div>
    <h2>{html.escape(scene.get('viewer_takeaway', ''))}</h2>
    <p>{html.escape(scene.get('visual_direction', ''))}</p>
  </div>
  <div class="meta">
    <div><b>source_refs</b><br>{html.escape(', '.join(scene.get('source_refs', [])))}</div>
    <div><b>shot_refs</b><br>{html.escape(', '.join(scene.get('source_shot_refs', [])))}</div>
    <div><b>assumptions</b><br>{html.escape(', '.join(scene.get('assumption_ids', [])))}</div>
  </div>
  <div class="script">
    <b>Script</b>
    <p>{html.escape(script_scene.get('narration', ''))}</p>
    <p class="caption">{html.escape(' / '.join(script_scene.get('on_screen_text', [])))}</p>
  </div>
  <table>
	    <thead><tr><th>Shot</th><th>Camera</th><th>Subject / Action</th><th>Overlay</th><th>Learning / Edit</th></tr></thead>
    <tbody>{''.join(shot_rows)}</tbody>
  </table>
  <div class="prompt">
    <b>Image prompt handoff</b>
    <p>{html.escape(prompt.get('image_id', ''))} / {html.escape(', '.join(prompt.get('planned_shot_ids', [])))}</p>
  </div>
</article>
""")
        json_scenes.append({
            "scene_id": scene_id,
            "role": scene.get("role", ""),
            "viewer_takeaway": scene.get("viewer_takeaway", ""),
            "planned_shots": [shot.get("shot_id") for shot in planned_shots],
            "image_id": prompt.get("image_id", ""),
        })

    board = {
        "run_id": run_dir.name,
        "title": "Day02 Pre-Image Workflow Board",
        "review_decision": review.get("decision"),
        "review_score": review.get("score"),
        "shot_count": shot_manifest.get("shot_count"),
        "micro_shot_count": shot_manifest.get("micro_shot_count"),
        "shot_structure_count": len(shot_structure.get("shots", [])),
        "temporal_window_count": len(temporal.get("windows", [])),
        "usable_principle_count": len(pattern_map.get("usable_principles", [])),
        "single_message": ugc_plan.get("own_ad_strategy", {}).get("single_message", ""),
        "continuity_contract": {
            "person": continuity.get("person", ""),
            "location": continuity.get("location", ""),
            "product": continuity.get("product", ""),
            "capture_style": continuity.get("capture_style", ""),
        },
        "scenes": json_scenes,
        "files": {
            "html": rel(run_dir, storyboard_dir / "12_preimage_workflow_board.html"),
            "json": rel(run_dir, storyboard_dir / "12_preimage_workflow_board.json"),
            "markdown": rel(run_dir, storyboard_dir / "12_preimage_workflow_board.md"),
        },
    }

    html_text = f"""<!doctype html>
<html lang="ja">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Day02 Pre-Image Workflow Board</title>
  <style>
    body {{ margin: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; background: #f6f7f7; color: #1b1f24; }}
    header {{ background: #fff; padding: 26px 32px; border-bottom: 1px solid #d8dddd; }}
    main {{ max-width: 1180px; margin: 0 auto; padding: 24px; display: grid; gap: 18px; }}
    .metrics {{ display: grid; grid-template-columns: repeat(5, 1fr); gap: 12px; }}
	    .metric, .scene {{ background: #fff; border: 1px solid #d8dddd; border-radius: 8px; padding: 16px; }}
	    .metric b {{ display: block; font-size: 22px; margin-top: 4px; }}
	    .scene-head h2 {{ margin: 4px 0 8px; }}
	    .eyebrow, .caption, .muted {{ color: #59666f; font-size: 13px; }}
	    .meta {{ display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin: 12px 0; }}
	    .meta div, .script, .prompt {{ background: #f7faf9; border-left: 4px solid #0b705f; padding: 10px; }}
	    .grid2 {{ display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }}
	    .pill {{ display: inline-block; margin: 3px 4px 3px 0; padding: 3px 7px; background: #edf4f2; border: 1px solid #cadbd7; border-radius: 999px; font-size: 12px; }}
	    table {{ width: 100%; border-collapse: collapse; margin-top: 12px; font-size: 13px; }}
    th, td {{ border: 1px solid #d8dddd; padding: 8px; vertical-align: top; }}
    th {{ background: #eef3f2; text-align: left; }}
    @media (max-width: 880px) {{ .metrics, .meta {{ grid-template-columns: 1fr; }} }}
  </style>
</head>
<body>
<header>
  <h1>Day02 Pre-Image Workflow Board</h1>
  <p>画像生成前に、競合分析、自社UGC動画企画、台本、字コンテ、プロンプト引き継ぎまでを確認する。</p>
</header>
<main>
  <section class="metrics">
    <div class="metric">review<b>{html.escape(str(review.get('decision')))} / {html.escape(str(review.get('score')))}</b></div>
	    <div class="metric">source shots<b>{html.escape(str(shot_manifest.get('shot_count')))}</b></div>
	    <div class="metric">micro shots<b>{html.escape(str(shot_manifest.get('micro_shot_count')))}</b></div>
	    <div class="metric">windows<b>{len(temporal.get('windows', []))}</b></div>
	    <div class="metric">planned shots<b>{len(shot_script.get('planned_shots', []))}</b></div>
	  </section>
	  <section class="scene">
	    <div class="eyebrow">single message</div>
	    <h2>{html.escape(ugc_plan.get('own_ad_strategy', {}).get('single_message', ''))}</h2>
	    <p>このボードでは画像の出来ではなく、画像生成前の設計品質だけを見る。</p>
	    <p><a href="../stages/03c_shot_structure_map.md">ショット構造</a> / <a href="../stages/03d_temporal_window_analysis.md">時系列窓分析</a> / <a href="../stages/03e_competitive_pattern_map.md">競合型</a> / <a href="../stages/04c_continuity_contract.md">Continuity</a> / <a href="../stages/05b_shot_script.md">字コンテ</a> / <a href="../stages/06_image_prompts.yaml">画像プロンプト</a> / <a href="../stages/06b_preimage_review.md">Pre-image review</a></p>
	  </section>
	  <section class="scene">
	    <div class="eyebrow">competitive pattern map</div>
	    <h2>競合から表現ではなく型を抽出する</h2>
	    <div class="grid2">
	      <div><b>Opening</b><p>{html.escape(pattern_map.get('opening_hook_pattern', ''))}</p></div>
	      <div><b>Product</b><p>{html.escape(pattern_map.get('product_understanding_pattern', ''))}</p></div>
	      <div><b>Trust</b><p>{html.escape(pattern_map.get('proof_or_trust_pattern', ''))}</p></div>
	      <div><b>Pacing</b><p>{html.escape(pattern_map.get('pacing_pattern', ''))}</p></div>
	    </div>
	    <p>{''.join(f'<span class="pill">{html.escape(item)}</span>' for item in pattern_map.get('usable_principles', [])[:8])}</p>
	  </section>
	  <section class="scene">
	    <div class="eyebrow">continuity contract</div>
	    <h2>画像生成前に一貫性を固定する</h2>
	    <div class="meta">
	      <div><b>person</b><br>{html.escape(continuity.get('person', ''))}</div>
	      <div><b>location</b><br>{html.escape(continuity.get('location', ''))}</div>
	      <div><b>product</b><br>{html.escape(continuity.get('product', ''))}</div>
	    </div>
	    <p>{html.escape(continuity.get('prompt_anchor_text', ''))}</p>
	  </section>
	  {''.join(cards)}
</main>
</body>
</html>
"""

    md = [
        "# Day02 Pre-Image Workflow Board",
        "",
        f"- review: {review.get('decision')} / {review.get('score')}",
        f"- source_shots: {shot_manifest.get('shot_count')}",
        f"- micro_shots: {shot_manifest.get('micro_shot_count')}",
        f"- shot_structure_count: {len(shot_structure.get('shots', []))}",
        f"- temporal_windows: {len(temporal.get('windows', []))}",
        f"- usable_principles: {len(pattern_map.get('usable_principles', []))}",
        f"- planned_shots: {len(shot_script.get('planned_shots', []))}",
        f"- image_prompts: {len(image_prompts.get('prompts', []))}",
        "",
        f"Single message: {ugc_plan.get('own_ad_strategy', {}).get('single_message', '')}",
        "",
    ]
    for scene in json_scenes:
        md.append(f"## {scene['scene_id']} / {scene['role']}")
        md.append(f"- takeaway: {scene['viewer_takeaway']}")
        md.append(f"- planned_shots: {', '.join(scene['planned_shots'])}")
        md.append(f"- image_id: {scene['image_id']}")
        md.append("")

    write_json(storyboard_dir / "12_preimage_workflow_board.json", board)
    write_text(storyboard_dir / "12_preimage_workflow_board.html", html_text)
    write_text(storyboard_dir / "12_preimage_workflow_board.md", "\n".join(md))
    append_log(run_dir, "build_preimage_board", "success", scene_count=len(json_scenes))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
