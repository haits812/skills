#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

from lib.harness_common import append_log, load_json, resolve_run_dir, stage_path, write_context_read_log, write_json, write_text, write_yaml_like


def as_text_list(value: object) -> list[str]:
    if isinstance(value, list):
        return [str(item) for item in value if str(item).strip()]
    if value is None:
        return []
    text = str(value).strip()
    return [text] if text else []


def message_ladder_for_scene(ladder: list[dict], index: int, section: str) -> list[dict]:
    matched = [item for item in ladder if item.get("level") == index]
    if matched:
        return matched[:2]
    if section.lower() in {"hook", "opening", "冒頭フック"}:
        return ladder[:2]
    if section.lower() in {"cta", "closing"}:
        return ladder[-2:]
    return ladder[max(0, index - 2) : index]


def build_script(run_dir: Path, context_refs: list[str]) -> dict:
    ugc_plan = load_json(stage_path(run_dir, "04b_ad_video_plan.json"))
    scene_plan = load_json(stage_path(run_dir, "05_storyboard_plan.json"))
    continuity = load_json(stage_path(run_dir, "04c_continuity_contract.json"))
    own = ugc_plan.get("own_ad_strategy", {})
    ladder = ugc_plan.get("message_ladder", [])
    scenes = []
    for index, scene in enumerate(scene_plan.get("scenes", []), start=1):
        role = scene.get("role", "")
        on_screen = as_text_list(scene.get("on_screen_text"))
        narration = scene.get("narration", "")
        viewer_takeaway = scene.get("viewer_takeaway", "")
        scenes.append({
            "scene_index": index,
            "scene_id": scene.get("scene_id", f"scene_{index:02d}"),
            "section": role,
            "duration_sec": scene.get("duration_sec"),
            "viewer_takeaway": viewer_takeaway,
            "viewer_question": f"この場面で視聴者は何を理解するか: {viewer_takeaway}",
            "answer_in_this_scene": viewer_takeaway,
            "spoken_intent": f"{role}として、{viewer_takeaway}",
            "narration": narration,
            "on_screen_text": on_screen,
            "visual_summary": scene.get("visual_direction", ""),
            "why_this_scene_exists": "message_ladderと競合構造から、自社UGC動画で視聴者理解を一段進めるため。",
            "source_refs": scene.get("source_refs", []),
            "source_shot_refs": scene.get("source_shot_refs", []),
            "assumption_ids": scene.get("assumption_ids", []),
            "generated_from": scene.get("generated_from", []),
            "message_ladder_refs": message_ladder_for_scene(ladder, index, role),
            "claim_check": own.get("claim_boundary", []),
            "continuity_refs": {
                "person": continuity.get("person"),
                "location": continuity.get("location"),
                "product": continuity.get("product"),
            },
        })
    return {
        "title": f"{own.get('product', 'UGC動画')} 台本",
        "purpose": "UGC動画企画を、自然なナレーション、短い画面テロップ、視聴者理解、参照根拠へ落とす。字コンテと画像生成の前提になる。",
        "context_refs": context_refs,
        "input_artifacts": {
            "ugc_video_plan": "stages/04b_ad_video_plan.json",
            "scene_plan": "stages/05_storyboard_plan.json",
            "continuity_contract": "stages/04c_continuity_contract.json",
        },
        "runtime_sec": sum(float(scene.get("duration_sec") or 0) for scene in scenes),
        "single_message": own.get("single_message"),
        "creative_concept": ugc_plan.get("creative_concept", {}).get("concept_name"),
        "scenes": scenes,
        "script_rules": [
            "テロップは短く、画像内に焼き込まず編集レイヤーで置く",
            "ナレーションは広告コピーではなく、生活者が友人に説明するような自然な言い方にする",
            "効能断定よりも使用場面・生活導線を説明する",
            "各シーンはsource_refs/source_shot_refsとassumption_idsを残す",
            "CTAは保存/プロフィール確認など、次行動を明確にする",
        ],
    }


def markdown(data: dict) -> str:
    lines = [
        f"# {data['title']}",
        "",
        f"目的: {data['purpose']}",
        "",
        f"- runtime_sec: {data['runtime_sec']}",
        f"- single_message: {data['single_message']}",
        f"- creative_concept: {data['creative_concept']}",
        "",
        "## Context Refs",
        "",
        *[f"- {item}" for item in data.get("context_refs", [])],
        "",
        "## Scenes",
        "",
    ]
    for scene in data["scenes"]:
        lines.extend([
            f"### {scene['scene_index']}. {scene['scene_id']} / {scene['section']}",
            "",
            f"- duration_sec: {scene['duration_sec']}",
            f"- viewer_question: {scene['viewer_question']}",
            f"- answer_in_this_scene: {scene['answer_in_this_scene']}",
            f"- narration: {scene['narration']}",
            f"- on_screen_text: {' / '.join(scene['on_screen_text'])}",
            f"- visual_summary: {scene['visual_summary']}",
            f"- source_shot_refs: {', '.join(scene['source_shot_refs'])}",
            f"- assumption_ids: {', '.join(scene['assumption_ids'])}",
            "",
        ])
    return "\n".join(lines).strip() + "\n"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", type=Path)
    parser.add_argument("--run-id")
    args = parser.parse_args()

    run_dir = resolve_run_dir(args)
    append_log(run_dir, "build_video_script", "start")
    context_report = write_context_read_log(
        run_dir,
        "build_video_script",
        input_artifacts=["stages/04b_ad_video_plan.json", "stages/05_storyboard_plan.json", "stages/04c_continuity_contract.json"],
        output_artifacts=["stages/05a_video_script.json", "stages/05a_video_script.md"],
    )
    context_refs = [item["relative_path"] for item in context_report.get("files", []) if item.get("exists")]
    data = build_script(run_dir, context_refs)
    write_json(stage_path(run_dir, "05a_video_script.json"), data)
    write_yaml_like(stage_path(run_dir, "05a_video_script.yaml"), data)
    write_text(stage_path(run_dir, "05a_video_script.md"), markdown(data))
    write_json(run_dir / "logs" / "build_video_script.json", {
        "mode": "derived_from_storyboard_plan",
        "scene_count": len(data.get("scenes", [])),
        "runtime_sec": data.get("runtime_sec"),
    })
    append_log(run_dir, "build_video_script", "success", scene_count=len(data.get("scenes", [])))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
