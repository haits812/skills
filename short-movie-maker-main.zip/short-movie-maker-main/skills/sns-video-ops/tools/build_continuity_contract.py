#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

from lib.harness_common import append_log, load_json, resolve_run_dir, stage_path, write_context_read_log, write_json, write_text, write_yaml_like


def markdown(data: dict) -> str:
    lines = [
        f"# {data.get('title', 'Continuity Contract')}",
        "",
        f"- source_run: {data.get('source_run', '')}",
        "",
        f"- person: {data.get('person', '')}",
        f"- location: {data.get('location', '')}",
        f"- product: {data.get('product', '')}",
        f"- lighting: {data.get('lighting', '')}",
        f"- capture_style: {data.get('capture_style', '')}",
        f"- wardrobe: {data.get('wardrobe', '')}",
        "",
        "## Props",
        "",
        *[f"- {item}" for item in data.get("props", [])],
        "",
        "## Forbidden Visual Drift",
        "",
        *[f"- {item}" for item in data.get("forbidden_visual_drift", [])],
        "",
        "## Prompt Anchor Text",
        "",
        data.get("prompt_anchor_text", ""),
        "",
    ]
    return "\n".join(lines).strip() + "\n"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", type=Path)
    parser.add_argument("--run-id")
    args = parser.parse_args()

    run_dir = resolve_run_dir(args)
    append_log(run_dir, "build_continuity_contract", "start")
    context_report = write_context_read_log(
        run_dir,
        "build_continuity_contract",
        input_artifacts=["stages/04b_ad_video_plan.json", "stages/03e_competitive_pattern_map.json"],
        output_artifacts=["stages/04c_continuity_contract.json", "stages/04c_continuity_contract.md"],
    )
    ugc_plan = load_json(stage_path(run_dir, "04b_ad_video_plan.json"))
    own = ugc_plan.get("own_ad_strategy", {})
    product = own.get("product", "自社コスメ商品")
    usage = own.get("job_to_be_done", "日常の美容ルーティン")
    data = {
        "title": "Continuity Contract",
        "source_run": run_dir.name,
        "context_refs": [item["relative_path"] for item in context_report.get("files", []) if item.get("exists")],
        "person": "同じ日本人女性。30代前半に見える生活者。黒から暗めブラウンの自然なストレート寄りの髪、ナチュラルメイク、落ち着いた顔立ち、淡色の部屋着またはメイク前の自然な服装。過度なモデル感や海外広告風のポージングを避ける。",
        "person_identity_lock": {
            "reference_rule": "人物が出る全画像で同一人物の参照イメージを保つ。顔立ち、髪型、髪色、年齢感、肌質、服装方向を変えない。",
            "visible_when": "人物が必要なhook, routine, finishの一部だけ。商品理解、質感、CTAでは顔を主役にしない。",
            "fixed_traits": [
                "30代前半に見える日本人女性",
                "黒から暗めブラウンの自然なストレート寄りの髪",
                "ナチュラルメイク",
                "淡色の部屋着またはメイク前の自然な服装",
                "生活者らしい自然な表情",
            ],
        },
        "location": "同じ日本の住まいの洗面台またはメイク前の生活導線。清潔だが作り込みすぎない。",
        "product": f"同じ商品として見える {product}。形状、色味、ラベル印象を全ショットで固定する。",
        "product_focus_policy": {
            "minimum_product_led_images": 2,
            "product_led_roles": ["product", "texture", "cta"],
            "rule": "絵コンテ全体を人物の顔中心にしない。商品理解、質感、CTAでは商品、手元、洗面台置き、スプレー口、ラベル印象を主役にする。",
        },
        "props": ["洗面台", "メイク道具", "タオル", "自然な生活小物", product],
        "lighting": "朝または日中の柔らかい自然光。スタジオ照明や海外ラグジュアリー広告の光に寄せない。",
        "capture_style": "縦型9:16のスマホUGC。少し手持ち感があり、生活者が撮ったような自然な画角。",
        "wardrobe": "白、淡色、ベーシックな部屋着またはメイク前の自然な服装。衣装感を出しすぎない。",
        "forbidden_visual_drift": [
            "外国人モデル風に変わる",
            "ホテルや海外高級スタジオのような場所に変わる",
            "商品が別カテゴリ、別容器、ドロッパー、ジャー、香水瓶に変わる",
            "人物の年齢、髪型、肌質、部屋の雰囲気がショットごとに変わる",
            "テレビCMや商品ヒーローカットのように作り込みすぎる",
            "長文日本語や効果断定を画像内に焼き込む",
        ],
        "prompt_anchor_text": (
            f"All frames belong to the same Japanese UGC-style vertical cosmetics reel for {product}. "
            "Use the same Japanese woman identity across frames: early-30s Japanese woman, natural straight dark hair, natural makeup, light neutral homewear, same facial structure and skin tone. "
            "Use the same everyday Japanese bathroom or makeup-prep location, same product, same soft natural light, "
            "casual smartphone video feel, clean but not studio-like. "
            f"The product is used in the context of {usage}. "
            "Do not make every frame a face portrait; include product-led B-roll where the bottle, spray nozzle, hand action, label impression, or vanity placement is the main subject. "
            "No overseas luxury advertising, no TV commercial look, no fake review UI, no long text baked into the image."
        ),
    }
    write_json(stage_path(run_dir, "04c_continuity_contract.json"), data)
    write_yaml_like(stage_path(run_dir, "04c_continuity_contract.yaml"), data)
    write_text(stage_path(run_dir, "04c_continuity_contract.md"), markdown(data))
    write_json(run_dir / "logs" / "build_continuity_contract.json", {"mode": "deterministic_from_ugc_plan"})
    append_log(run_dir, "build_continuity_contract", "success")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
