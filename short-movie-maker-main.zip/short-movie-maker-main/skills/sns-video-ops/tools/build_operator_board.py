#!/usr/bin/env python3
from __future__ import annotations

import argparse
import html
import os
from collections import defaultdict
from pathlib import Path

from lib.harness_common import append_log, ensure_dir, load_json, resolve_run_dir, stage_path, write_json, write_text


def esc(value: object) -> str:
    return html.escape(str(value or ""))


def rel_from(base: Path, target: Path) -> str:
    return os.path.relpath(target, base).replace(os.sep, "/")


def chips(items: list[str], limit: int = 8) -> str:
    return "".join(f'<span class="chip">{esc(item)}</span>' for item in (items or [])[:limit])


def load_optional_json(path: Path) -> dict:
    if not path.exists():
        return {}
    return load_json(path)


def image_cards(run_dir: Path, storyboard_dir: Path, prompts: dict, prompts_path: Path) -> tuple[str, list[dict], str]:
    normalized_dir = run_dir / "images" / "normalized"
    cards = []
    manifest_items = []
    prompt_by_scene = {item.get("scene_id"): item for item in prompts.get("prompts", [])}
    prompt_mtime = prompts_path.stat().st_mtime if prompts_path.exists() else 0
    prompt_cards = []
    for prompt in prompts.get("prompts", []):
        prompt_cards.append(f"""
<article class="empty-card">
  <div class="eyebrow">{esc(prompt.get("image_id"))}</div>
  <h3>{esc(prompt.get("purpose"))}</h3>
  <p>{esc(prompt.get("scene_id"))}</p>
  <p class="muted">画像未生成、または最新プロンプトとは別世代です。字コンテとプロンプトを正本にしてください。</p>
</article>
""")
    if normalized_dir.exists():
        stale_count = 0
        for path in sorted(normalized_dir.glob("*.png")):
            stale = path.stat().st_mtime < prompt_mtime
            if stale:
                stale_count += 1
            manifest_items.append({"image": str(path), "exists": True, "stale_against_prompts": stale})
            badge = '<span class="badge warn">プロンプト更新前</span>' if stale else '<span class="badge">最新プロンプト後</span>'
            cards.append(f"""
<article class="image-card">
  <img src="{esc(rel_from(storyboard_dir, path))}" alt="{esc(path.stem)}">
  <div class="caption">{esc(path.stem)} {badge}</div>
</article>
""")
        if cards:
            status = "stale" if stale_count else "current"
            if status == "stale":
                return "\n".join(prompt_cards), manifest_items, status
            return "\n".join(cards), manifest_items, status
    return "\n".join(prompt_cards), [{"image_id": item.get("image_id"), "exists": False} for item in prompt_by_scene.values()], "prompt_only"


def shot_rows(planned_shots: list[dict]) -> str:
    rows = []
    for shot in planned_shots:
        rows.append(f"""
<tr>
  <td><b>{esc(shot.get("shot_id"))}</b><br><span class="muted">{esc(shot.get("scene_id"))}</span></td>
  <td>{esc(shot.get("adopted_cut_pattern"))}<br><span class="muted">{esc(", ".join(shot.get("source_shot_refs", [])))}</span></td>
  <td>{esc(shot.get("subject"))}<br><span class="muted">{esc(shot.get("action"))}</span></td>
  <td>{esc(shot.get("camera_pattern"))}<br><span class="muted">{esc(shot.get("motion_or_edit"))}</span></td>
  <td>{esc(shot.get("overlay_text"))}</td>
</tr>
""")
    return "".join(rows)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", type=Path)
    parser.add_argument("--run-id")
    args = parser.parse_args()

    run_dir = resolve_run_dir(args)
    append_log(run_dir, "build_operator_board", "start")
    storyboard_dir = ensure_dir(run_dir / "storyboard")

    shot_manifest = load_json(stage_path(run_dir, "02b_shot_manifest.json"))
    pattern_map = load_json(stage_path(run_dir, "03e_competitive_pattern_map.json"))
    ugc_plan = load_json(stage_path(run_dir, "04b_ad_video_plan.json"))
    continuity = load_json(stage_path(run_dir, "04c_continuity_contract.json"))
    storyboard = load_json(stage_path(run_dir, "05_storyboard_plan.json"))
    video_script = load_json(stage_path(run_dir, "05a_video_script.json"))
    shot_script = load_json(stage_path(run_dir, "05b_shot_script.json"))
    prompts_path = stage_path(run_dir, "06_image_prompts.json")
    prompts = load_json(prompts_path)
    preimage_review = load_json(stage_path(run_dir, "06b_preimage_review.json"))
    final_review = load_optional_json(stage_path(run_dir, "09_review.json"))

    shots_by_scene: dict[str, list[dict]] = defaultdict(list)
    for shot in shot_script.get("planned_shots", []):
        shots_by_scene[shot.get("scene_id", "")].append(shot)
    script_by_scene = {scene.get("scene_id"): scene for scene in video_script.get("scenes", [])}
    own = ugc_plan.get("own_ad_strategy", {})
    image_html, image_manifest, image_status = image_cards(run_dir, storyboard_dir, prompts, prompts_path)
    if image_status == "stale":
        storyboard_notice = "既存の絵コンテ画像はありますが、最新の字コンテ/プロンプト更新前のため非表示にしています。本番判断では字コンテを正本にします。"
    elif image_status == "current":
        storyboard_notice = "最新プロンプト後に生成された絵コンテ画像を表示しています。"
    else:
        storyboard_notice = "画像は未生成です。字コンテとimage 2プロンプトまでは生成済みです。"

    scene_cards = []
    for scene in storyboard.get("scenes", []):
        scene_id = scene.get("scene_id", "")
        script = script_by_scene.get(scene_id, {})
        shots = shots_by_scene.get(scene_id, [])
        scene_cards.append(f"""
<article class="scene-card">
  <div class="scene-head">
    <div>
      <div class="eyebrow">{esc(scene_id)} / {esc(scene.get("role"))}</div>
      <h3>{esc(scene.get("viewer_takeaway"))}</h3>
    </div>
    <span class="badge">{esc(scene.get("duration_sec"))} sec</span>
  </div>
  <div class="two">
    <div>
      <h4>現場で撮る/生成するもの</h4>
      <ul>
        {''.join(f'<li>{esc(shot.get("subject"))} / {esc(shot.get("action"))}</li>' for shot in shots[:3])}
      </ul>
    </div>
    <div>
      <h4>後載せテロップ/ナレーション</h4>
      <p><b>{esc(scene.get("on_screen_text"))}</b></p>
      <p class="muted">{esc(script.get("narration"))}</p>
    </div>
  </div>
</article>
""")

    review_path = run_dir / "review" / "human_review.md"
    learning_path = run_dir / "review" / "learning_candidates.md"
    review_exists = review_path.exists()
    learning_exists = learning_path.exists()

    board = {
        "run_id": run_dir.name,
        "operator_board": str(storyboard_dir / "14_operator_board.html"),
        "review": preimage_review.get("decision"),
        "score": preimage_review.get("score"),
        "shot_count": shot_manifest.get("shot_count"),
        "micro_shot_count": shot_manifest.get("micro_shot_count"),
        "scene_count": len(storyboard.get("scenes", [])),
        "planned_shot_count": len(shot_script.get("planned_shots", [])),
        "image_count": len(image_manifest),
        "image_status": image_status,
        "review_files": {
            "human_review": str(review_path),
            "learning_candidates": str(learning_path),
            "human_review_exists": review_exists,
            "learning_candidates_exists": learning_exists,
        },
    }

    html_text = f"""<!doctype html>
<html lang="ja">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>現場向けSNS動画運用ボード</title>
  <style>
    :root {{
      --bg: #f5f7f7;
      --surface: #ffffff;
      --line: #d9e0df;
      --text: #152022;
      --muted: #5d6a70;
      --accent: #0b6f61;
      --accent-soft: #e9f3f1;
      --warn: #8a5b00;
    }}
    * {{ box-sizing: border-box; }}
    body {{ margin: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; color: var(--text); background: var(--bg); line-height: 1.55; }}
    header {{ background: var(--surface); border-bottom: 1px solid var(--line); padding: 24px 32px 18px; position: sticky; top: 0; z-index: 10; }}
    h1 {{ margin: 0 0 6px; font-size: 26px; letter-spacing: 0; }}
    h2 {{ margin: 0 0 12px; font-size: 21px; }}
    h3 {{ margin: 0 0 8px; font-size: 17px; }}
    h4 {{ margin: 0 0 6px; font-size: 13px; color: var(--muted); }}
    main {{ max-width: 1240px; margin: 0 auto; padding: 22px; }}
    .tabs {{ display: flex; gap: 8px; flex-wrap: wrap; margin-top: 14px; }}
    .tab {{ border: 1px solid var(--line); background: #fbfcfc; color: var(--text); border-radius: 6px; padding: 7px 11px; cursor: pointer; font-size: 14px; }}
    .tab.active {{ background: var(--accent); border-color: var(--accent); color: #fff; }}
    .panel {{ display: none; }}
    .panel.active {{ display: block; }}
    .grid {{ display: grid; gap: 14px; }}
    .metrics {{ grid-template-columns: repeat(5, minmax(0, 1fr)); }}
    .two {{ display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }}
    .card, .metric, .scene-card, .image-card, .empty-card {{ background: var(--surface); border: 1px solid var(--line); border-radius: 8px; padding: 14px; }}
    .metric span {{ color: var(--muted); font-size: 12px; }}
    .metric b {{ display: block; font-size: 24px; margin-top: 2px; }}
    .eyebrow, .muted {{ color: var(--muted); font-size: 13px; }}
    .badge {{ display: inline-flex; align-items: center; min-height: 24px; padding: 2px 8px; background: var(--accent-soft); border: 1px solid #c8ded9; border-radius: 999px; color: var(--accent); font-size: 12px; white-space: nowrap; }}
    .badge.warn {{ background: #fff4d7; border-color: #e6c56b; color: #7b5400; }}
    .chip {{ display: inline-block; margin: 3px 4px 3px 0; padding: 3px 7px; background: var(--accent-soft); border: 1px solid #c8ded9; border-radius: 999px; font-size: 12px; }}
    .scene-head {{ display: flex; justify-content: space-between; gap: 12px; align-items: flex-start; margin-bottom: 10px; }}
    .flow {{ display: grid; grid-template-columns: repeat(6, 1fr); gap: 8px; }}
    .flow div {{ background: var(--surface); border: 1px solid var(--line); border-left: 4px solid var(--accent); border-radius: 6px; padding: 10px; min-height: 86px; }}
    table {{ width: 100%; border-collapse: collapse; background: var(--surface); font-size: 13px; }}
    th, td {{ border: 1px solid var(--line); padding: 8px; vertical-align: top; }}
    th {{ background: #edf3f2; text-align: left; }}
    .images {{ grid-template-columns: repeat(3, minmax(0, 1fr)); }}
    .image-card img {{ width: 100%; border-radius: 6px; border: 1px solid var(--line); background: #eef1f1; display: block; }}
    .empty-card {{ min-height: 170px; display: flex; flex-direction: column; justify-content: center; }}
    .notice {{ border-left: 4px solid var(--warn); background: #fff9ec; padding: 10px; border-radius: 6px; }}
    code {{ background: #eef2f2; border: 1px solid var(--line); border-radius: 4px; padding: 1px 4px; }}
    pre {{ overflow: auto; background: #182225; color: #e9f2ef; border-radius: 8px; padding: 14px; }}
    @media (max-width: 960px) {{ .metrics, .two, .flow, .images {{ grid-template-columns: 1fr; }} header {{ position: static; }} }}
  </style>
</head>
<body>
<header>
  <div class="eyebrow">Day02 / SNS動画運用エージェント / operator view</div>
  <h1>競合リールから自社UGC動画の制作指示を作る</h1>
  <div class="tabs">
    <button class="tab active" data-tab="overview">概要</button>
    <button class="tab" data-tab="competitive">競合分析</button>
    <button class="tab" data-tab="script">字コンテ</button>
    <button class="tab" data-tab="storyboard">絵コンテ</button>
    <button class="tab" data-tab="review">レビュー/学習</button>
  </div>
</header>
<main>
  <section class="panel active" id="overview">
    <div class="grid metrics">
      <div class="metric"><span>preimage review</span><b>{esc(preimage_review.get("decision"))} / {esc(preimage_review.get("score"))}</b></div>
      <div class="metric"><span>source shots</span><b>{esc(shot_manifest.get("shot_count"))}</b></div>
      <div class="metric"><span>micro shots</span><b>{esc(shot_manifest.get("micro_shot_count"))}</b></div>
      <div class="metric"><span>scenes</span><b>{len(storyboard.get("scenes", []))}</b></div>
      <div class="metric"><span>planned shots</span><b>{len(shot_script.get("planned_shots", []))}</b></div>
    </div>
    <div class="card" style="margin-top:14px">
      <h2>{esc(own.get("single_message"))}</h2>
      <p>{esc(own.get("target_viewer"))}</p>
      <p class="muted">この画面は完成動画ではなく、現場担当者が「何を分析し、何を作るのか」を確認するための業務ビューです。字コンテが正本で、絵コンテ画像は補助です。</p>
    </div>
    <div class="flow" style="margin-top:14px">
      <div><b>1. 競合URL</b><br><span class="muted">inboxまたは手動入力</span></div>
      <div><b>2. ショット分析</b><br><span class="muted">25 shots / 5 micro</span></div>
      <div><b>3. 型の抽出</b><br><span class="muted">採用する型とコピー禁止</span></div>
      <div><b>4. 自社企画</b><br><span class="muted">自社文脈へ変換</span></div>
      <div><b>5. 字コンテ</b><br><span class="muted">撮影/生成/編集の指示</span></div>
      <div><b>6. レビュー</b><br><span class="muted">学びをVaultへ戻す</span></div>
    </div>
    <div class="card" style="margin-top:14px">
      <h2>手動起動と定期起動</h2>
      <p>通常はHermes cronから定期起動します。確認時は同じbashを手動で起動します。</p>
      <pre>printf '%s\\n' "https://www.instagram.com/reels/XXXX/" > inputs/inbox/sample-cosme.md
MODE=preimage MAX_IMAGES=6 bash hermes/day02_sns_video_ops_daily.sh</pre>
    </div>
  </section>

  <section class="panel" id="competitive">
    <div class="grid two">
      <div class="card"><h2>採用する型</h2>{chips(pattern_map.get("usable_principles", []), 16)}</div>
      <div class="card"><h2>コピーしないもの</h2>{chips(pattern_map.get("do_not_copy", []), 12)}</div>
    </div>
    <div class="grid two" style="margin-top:14px">
      <div class="card"><h3>Opening</h3><p>{esc(pattern_map.get("opening_hook_pattern"))}</p></div>
      <div class="card"><h3>Product</h3><p>{esc(pattern_map.get("product_understanding_pattern"))}</p></div>
      <div class="card"><h3>Usage</h3><p>{esc(pattern_map.get("usage_scene_pattern"))}</p></div>
      <div class="card"><h3>CTA</h3><p>{esc(pattern_map.get("cta_pattern"))}</p></div>
    </div>
  </section>

  <section class="panel" id="script">
    <div class="card">
      <h2>字コンテ</h2>
      <p class="muted">現場ではこの表を見れば、何を撮る/生成するか、どの競合カットの型を採用したかが分かります。</p>
    </div>
    <div style="overflow:auto; margin-top:14px">
      <table>
        <thead><tr><th>Shot</th><th>採用する型</th><th>被写体/動き</th><th>画角/編集</th><th>後載せテロップ</th></tr></thead>
        <tbody>{shot_rows(shot_script.get("planned_shots", []))}</tbody>
      </table>
    </div>
    <div class="grid" style="margin-top:14px">{''.join(scene_cards)}</div>
  </section>

  <section class="panel" id="storyboard">
    <div class="notice">
      {esc(storyboard_notice)}
    </div>
    <div class="grid images" style="margin-top:14px">{image_html}</div>
  </section>

  <section class="panel" id="review">
    <div class="grid two">
      <div class="card">
        <h2>人間レビュー</h2>
        <p>{'作成済み' if review_exists else '未作成'}: <code>{esc(rel_from(run_dir, review_path))}</code></p>
        <p class="muted">現場担当者は、良かった点、修正点、次回に残す学びを書きます。</p>
      </div>
      <div class="card">
        <h2>学習候補</h2>
        <p>{'作成済み' if learning_exists else '未作成'}: <code>{esc(rel_from(run_dir, learning_path))}</code></p>
        <p class="muted">Vaultへ直接反映せず、まず候補として整理します。</p>
      </div>
    </div>
    <div class="card" style="margin-top:14px">
      <h2>Continuity Contract</h2>
      <p><b>person:</b> {esc(continuity.get("person"))}</p>
      <p><b>location:</b> {esc(continuity.get("location"))}</p>
      <p><b>product:</b> {esc(continuity.get("product"))}</p>
      <p><b>style:</b> {esc(continuity.get("capture_style"))}</p>
    </div>
    <div class="card" style="margin-top:14px">
      <h2>Preimage Review</h2>
      <p><b>{esc(preimage_review.get("decision"))} / {esc(preimage_review.get("score"))}</b></p>
      <p>{chips(preimage_review.get("passed", []), 18)}</p>
      <p class="muted">{esc(" / ".join(preimage_review.get("issues", [])) or "issuesなし")}</p>
      <p class="muted">Final review: {esc(final_review.get("decision", "未実行"))}</p>
    </div>
  </section>
</main>
<script>
  const tabs = [...document.querySelectorAll('.tab')];
  const panels = [...document.querySelectorAll('.panel')];
  tabs.forEach(tab => {{
    tab.addEventListener('click', () => {{
      tabs.forEach(t => t.classList.remove('active'));
      panels.forEach(p => p.classList.remove('active'));
      tab.classList.add('active');
      document.getElementById(tab.dataset.tab).classList.add('active');
    }});
  }});
</script>
</body>
</html>
"""

    write_text(storyboard_dir / "14_operator_board.html", html_text)
    write_json(storyboard_dir / "14_operator_board.json", board)
    append_log(run_dir, "build_operator_board", "success", image_count=len(image_manifest))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
