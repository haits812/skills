#!/usr/bin/env python3
from __future__ import annotations

import argparse
import math
from pathlib import Path

from lib.harness_common import HARNESS_ROOT, append_log, ensure_dir, load_json, relative_or_abs, require_cli, resolve_run_dir, run_cmd, stage_path, write_json, write_text


def duration_from_download(download: dict) -> float | None:
    try:
        return float(download.get("ffprobe", {}).get("format", {}).get("duration"))
    except (TypeError, ValueError):
        return None


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", type=Path)
    parser.add_argument("--run-id")
    parser.add_argument("--fps", type=float, default=1.0)
    parser.add_argument("--max-frames", type=int)
    args = parser.parse_args()

    require_cli("ffmpeg")
    run_dir = resolve_run_dir(args)
    frames_dir = ensure_dir(run_dir / "frames")
    append_log(run_dir, "extract_frames", "start", fps=args.fps)

    download = load_json(stage_path(run_dir, "01_download.json"))
    video_path = Path(download["video_path"])
    if not video_path.is_absolute():
        video_path = (HARNESS_ROOT / video_path).resolve()
    if not video_path.exists():
        raise FileNotFoundError(video_path)

    for old in frames_dir.glob("frame_*.jpg"):
        old.unlink()

    vf = f"fps={args.fps}"
    if args.max_frames:
        vf = f"{vf},select='lte(n\\,{args.max_frames - 1})'"
    cmd = ["ffmpeg", "-y", "-i", str(video_path), "-vf", vf, str(frames_dir / "frame_%03d.jpg")]
    completed = run_cmd(cmd, timeout=900)
    write_text(run_dir / "logs" / "ffmpeg_extract_frames_stdout.txt", completed.stdout)
    write_text(run_dir / "logs" / "ffmpeg_extract_frames_stderr.txt", completed.stderr)
    if completed.returncode != 0:
        append_log(run_dir, "extract_frames", "failed", returncode=completed.returncode)
        return completed.returncode

    frame_paths = sorted(frames_dir.glob("frame_*.jpg"))
    duration = duration_from_download(download)
    frame_items = []
    for index, path in enumerate(frame_paths, start=1):
        time_sec = (index - 1) / args.fps if args.fps else index - 1
        if duration is not None:
            time_sec = min(time_sec, max(duration - 0.001, 0))
        frame_items.append({
            "index": index,
            "frame_path": relative_or_abs(path),
            "time_sec": round(time_sec, 3),
            "source_ref": f"frame_{index:03d}@{round(time_sec, 3)}s",
        })

    manifest = {
        "run_id": run_dir.name,
        "video_path": relative_or_abs(video_path),
        "fps": args.fps,
        "duration_sec": duration,
        "frame_count": len(frame_items),
        "frames": frame_items,
        "command": cmd,
    }
    write_json(stage_path(run_dir, "02_frame_manifest.json"), manifest)
    append_log(run_dir, "extract_frames", "success", frame_count=len(frame_items))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
