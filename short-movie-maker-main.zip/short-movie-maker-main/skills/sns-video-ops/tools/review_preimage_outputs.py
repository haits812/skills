#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

from lib.harness_common import append_log, load_json, read_text, resolve_run_dir, stage_path, write_context_read_log, write_json, write_text


FORBIDDEN_PRODUCTION_TERMS = [
    "Advanced Clinicals",
    "BIOTIN",
    "KERATIN",
    "ヘアケア",
    "髪",
    "ジャー",
    "成分バッジ",
    "泡",
    "商品2点",
    "2点",
    "2商品",
    "複数商品",
    "背面ラベル",
    "星評価",
    "表示数",
    "SNS投稿スクショ",
    "Xロゴ",
]


PRODUCTION_FIELDS = [
    "camera_pattern",
    "camera_angle",
    "framing",
    "subject",
    "action",
    "background",
    "motion_or_edit",
    "image_generation_bridge",
    "visual_content",
]


def markdown(review: dict) -> str:
    lines = [
        "# Pre-Image Review",
        "",
        f"- decision: {review.get('decision')}",
        f"- score: {review.get('score')}",
        "",
        "## What Passed",
        *[f"- {item}" for item in review.get("passed", [])],
        "",
        "## Issues",
        *[f"- {item}" for item in review.get("issues", [])],
        "",
        "## Next Actions",
        *[f"- {item}" for item in review.get("next_actions", [])],
        "",
        "## Artifacts Checked",
        "",
    ]
    for key, value in review.get("artifacts_checked", {}).items():
        lines.append(f"- {key}: {value}")
    return "\n".join(lines).strip() + "\n"


def refs_from_analysis(analysis: dict) -> set[str]:
    return {ref for frame in analysis.get("frames", []) for ref in frame.get("source_refs", [])}


def refs_from_shots(shot_manifest: dict, shot_analysis: dict, shot_structure: dict) -> set[str]:
    refs = {shot.get("source_ref") for shot in shot_manifest.get("shots", []) if shot.get("source_ref")}
    refs |= {ref for item in shot_analysis.get("frames", []) for ref in item.get("source_refs", [])}
    refs |= {item.get("source_shot_ref") for item in shot_structure.get("shots", []) if item.get("source_shot_ref")}
    return {ref for ref in refs if ref}


def forbidden_hits(text: str) -> list[str]:
    return [term for term in FORBIDDEN_PRODUCTION_TERMS if term and term in text]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", type=Path)
    parser.add_argument("--run-id")
    args = parser.parse_args()

    run_dir = resolve_run_dir(args)
    append_log(run_dir, "review_preimage_outputs", "start")
    write_context_read_log(
        run_dir,
        "review_preimage_outputs",
        input_artifacts=[
            "stages/03_timeseries_analysis.json",
            "stages/03b_shot_analysis.json",
            "stages/03c_shot_structure_map.json",
            "stages/03d_temporal_window_analysis.json",
            "stages/03e_competitive_pattern_map.json",
            "stages/04b_ad_video_plan.json",
            "stages/04c_continuity_contract.json",
            "stages/05a_video_script.json",
            "stages/05b_shot_script.json",
            "stages/06_image_prompts.json",
        ],
        output_artifacts=["stages/06b_preimage_review.json", "stages/06b_preimage_review.md"],
    )

    analysis = load_json(stage_path(run_dir, "03_timeseries_analysis.json"))
    shot_manifest = load_json(stage_path(run_dir, "02b_shot_manifest.json"))
    shot_analysis = load_json(stage_path(run_dir, "03b_shot_analysis.json"))
    shot_structure = load_json(stage_path(run_dir, "03c_shot_structure_map.json"))
    temporal = load_json(stage_path(run_dir, "03d_temporal_window_analysis.json"))
    pattern_map = load_json(stage_path(run_dir, "03e_competitive_pattern_map.json"))
    ugc_plan = load_json(stage_path(run_dir, "04b_ad_video_plan.json"))
    continuity = load_json(stage_path(run_dir, "04c_continuity_contract.json"))
    storyboard = load_json(stage_path(run_dir, "05_storyboard_plan.json"))
    video_script = load_json(stage_path(run_dir, "05a_video_script.json"))
    shot_script = load_json(stage_path(run_dir, "05b_shot_script.json"))
    image_prompts = load_json(stage_path(run_dir, "06_image_prompts.json"))
    brief = read_text(stage_path(run_dir, "04_production_brief.md"))

    issues: list[str] = []
    passed: list[str] = []
    analysis_refs = refs_from_analysis(analysis)
    shot_refs = refs_from_shots(shot_manifest, shot_analysis, shot_structure)
    scene_count = len(storyboard.get("scenes", []))
    script_scene_count = len(video_script.get("scenes", []))
    planned_shot_count = len(shot_script.get("planned_shots", []))
    prompt_count = len(image_prompts.get("prompts", []))

    if len(analysis.get("frames", [])) >= 20 and not any(not f.get("source_refs") for f in analysis.get("frames", [])):
        passed.append("フレーム分析は20件以上あり、source_refsが維持されている。")
    else:
        issues.append("フレーム分析の件数またはsource_refsが不足している。")

    if shot_manifest.get("shot_count", 0) >= 20 and shot_manifest.get("micro_shot_count", 0) > 0:
        passed.append(f"ショット検出は{shot_manifest.get('shot_count')}ショット、micro shot {shot_manifest.get('micro_shot_count')}件を保持している。")
    else:
        issues.append("高速リールのショット構造を説明するには、shot_countまたはmicro_shot_countが弱い。")

    if len(shot_structure.get("shots", [])) == shot_manifest.get("shot_count"):
        passed.append("shot_structure_mapが検出ショット数と一致している。")
    else:
        issues.append(f"shot_structure_mapの件数がショット検出と不一致。structure={len(shot_structure.get('shots', []))}, detected={shot_manifest.get('shot_count')}")

    required_shot_fields = ["role", "camera_pattern", "framing", "edit_function", "reuse_principle", "conversion_hint_for_own_brand"]
    for shot in shot_structure.get("shots", []):
        missing = [key for key in required_shot_fields if not shot.get(key)]
        if missing:
            issues.append(f"{shot.get('source_shot_ref')}: shot_structure_map項目が不足: {', '.join(missing)}")
            break
    else:
        passed.append("shot_structure_mapは画角、編集意図、自社転用ヒントを持つ。")

    if len(temporal.get("windows", [])) >= 4 and temporal.get("overall_flow"):
        passed.append("temporal_window_analysisが複数窓とoverall_flowを持つ。")
    else:
        issues.append("temporal_window_analysisの窓数またはoverall_flowが不足している。")

    if pattern_map.get("usable_principles") and pattern_map.get("do_not_copy"):
        passed.append("competitive_pattern_mapが使う型とコピー禁止表現を分離している。")
    else:
        issues.append("competitive_pattern_mapのusable_principlesまたはdo_not_copyが不足している。")

    own = ugc_plan.get("own_ad_strategy", {})
    if ugc_plan.get("context_refs") and own.get("single_message") and own.get("source_learning_to_keep"):
        passed.append("自社UGC動画企画にcontext_refs, single_message, source_learning_to_keepがある。")
    else:
        issues.append("自社UGC動画企画のcontext_refs, single_message, source_learning_to_keepが不足している。")

    for key in ["person", "location", "product", "lighting", "capture_style", "prompt_anchor_text"]:
        if not continuity.get(key):
            issues.append(f"continuity_contract.{key} が不足している。")
            break
    else:
        passed.append("continuity_contractが人物、場所、商品、光、撮影トーンを固定している。")

    if scene_count == script_scene_count and scene_count >= 5:
        passed.append("シーン設計と台本のシーン数が一致している。")
    else:
        issues.append(f"シーン設計と台本の数がずれている。storyboard={scene_count}, script={script_scene_count}")

    for scene in storyboard.get("scenes", []):
        missing_frame_refs = sorted(set(scene.get("source_refs", [])) - analysis_refs)
        missing_shot_refs = sorted(set(scene.get("source_shot_refs", [])) - shot_refs)
        if missing_frame_refs:
            issues.append(f"{scene.get('scene_id')}: source_refsが分析結果に存在しない: {', '.join(missing_frame_refs)}")
        if missing_shot_refs:
            issues.append(f"{scene.get('scene_id')}: source_shot_refsがショット分析に存在しない: {', '.join(missing_shot_refs)}")
        if not scene.get("generated_from") or not scene.get("assumption_ids"):
            issues.append(f"{scene.get('scene_id')}: generated_fromまたはassumption_idsが不足している。")

    if planned_shot_count >= scene_count * 2:
        passed.append(f"字コンテは{planned_shot_count}ショットあり、各シーンを複数ショットに分解している。")
    else:
        issues.append("字コンテのショット数が薄い。各シーン2ショット以上を目安にする。")

    required_planned_fields = ["source_learning", "camera_pattern", "subject", "action", "background", "motion_or_edit", "overlay_text", "narration", "edit_layer_notes"]
    for shot in shot_script.get("planned_shots", []):
        missing = [key for key in required_planned_fields if not shot.get(key)]
        if missing:
            issues.append(f"{shot.get('shot_id')}: 字コンテ項目が不足: {', '.join(missing)}")
            break
    else:
        passed.append("字コンテはsource_learning, subject, action, edit_layer_notesを持つ。")

    production_term_issues = []
    for shot in shot_script.get("planned_shots", []):
        for field in PRODUCTION_FIELDS:
            text = str(shot.get(field, ""))
            hits = forbidden_hits(text)
            if hits:
                production_term_issues.append(f"{shot.get('shot_id')}.{field}: {', '.join(hits)}")
    if production_term_issues:
        issues.append("自社制作指示に競合固有の視覚語が混入している: " + " / ".join(production_term_issues[:8]))
    else:
        passed.append("字コンテの制作指示は競合固有物を混ぜず、自社UGC向けに変換されている。")

    for shot in shot_script.get("planned_shots", []):
        if not shot.get("source_cut_recipe") or not shot.get("adopted_cut_pattern") or not shot.get("source_expression_to_avoid"):
            issues.append(f"{shot.get('shot_id')}: source_cut_recipe, adopted_cut_pattern, source_expression_to_avoid のいずれかが不足している。")
            break
    else:
        passed.append("字コンテは競合から採用するカット型と、自社で避ける表現を分離している。")

    if 0 < prompt_count <= scene_count:
        passed.append("image 2プロンプトはシーン数以内で生成されている。")
    else:
        issues.append(f"image 2プロンプト数が不正。prompts={prompt_count}, scenes={scene_count}")

    for prompt in image_prompts.get("prompts", []):
        contract = prompt.get("visual_continuity_contract") or {}
        if not contract.get("person") or not contract.get("location") or not contract.get("product"):
            issues.append(f"{prompt.get('image_id')}: visual_continuity_contractが弱い。")
        if len("".join(prompt.get("overlay_text_later", []))) > 60:
            issues.append(f"{prompt.get('image_id')}: 後載せテロップが長い。")
        hits = forbidden_hits(str(prompt.get("prompt", "")))
        if hits:
            issues.append(f"{prompt.get('image_id')}: image prompt本文に競合固有語が混入している: {', '.join(hits)}")

    if "UGC" in brief or "テレビCM" in brief:
        passed.append("制作ブリーフはUGC風と広告過多回避の前提を含んでいる。")
    else:
        issues.append("制作ブリーフにUGC風/広告過多回避の前提が弱い。")

    decision = "accept" if not issues else "revise"
    score = 94 if not issues else max(55, 94 - min(len(issues) * 4, 40))
    review = {
        "decision": decision,
        "score": score,
        "passed": passed,
        "issues": issues,
        "next_actions": [
            "画像生成前の改善では、03c/03d/03e/04c/05bを主対象にレビューする。",
            "画像生成は06b_preimage_reviewがacceptになってから実行する。",
            "プロンプトだけ直したい場合でも、まずcontinuity_contractと字コンテの不足を確認する。",
        ],
        "artifacts_checked": {
            "frame_count": len(analysis.get("frames", [])),
            "shot_count": shot_manifest.get("shot_count", 0),
            "micro_shot_count": shot_manifest.get("micro_shot_count", 0),
            "shot_structure_count": len(shot_structure.get("shots", [])),
            "temporal_window_count": len(temporal.get("windows", [])),
            "usable_principle_count": len(pattern_map.get("usable_principles", [])),
            "scene_count": scene_count,
            "video_script_scene_count": script_scene_count,
            "planned_shot_count": planned_shot_count,
            "prompt_count": prompt_count,
        },
    }
    write_json(stage_path(run_dir, "06b_preimage_review.json"), review)
    write_text(stage_path(run_dir, "06b_preimage_review.md"), markdown(review))
    write_json(run_dir / "logs" / "review_preimage_outputs.json", {"mode": "deterministic_traceability_review", "decision": decision, "score": score})
    append_log(run_dir, "review_preimage_outputs", "success", decision=decision, score=score)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
