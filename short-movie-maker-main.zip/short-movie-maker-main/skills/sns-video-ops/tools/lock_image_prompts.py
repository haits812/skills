#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
from pathlib import Path

from lib.harness_common import append_log, load_json, resolve_run_dir, stage_path, utc_now, write_json


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", type=Path)
    parser.add_argument("--run-id")
    parser.add_argument("--reason", default="render")
    args = parser.parse_args()

    run_dir = resolve_run_dir(args)
    append_log(run_dir, "lock_image_prompts", "start", reason=args.reason)
    prompt_path = stage_path(run_dir, "06_image_prompts.json")
    if not prompt_path.exists():
        raise FileNotFoundError(prompt_path)
    text = prompt_path.read_text(encoding="utf-8")
    data = load_json(prompt_path)
    lock = {
        "locked_at": utc_now(),
        "reason": args.reason,
        "source_path": "stages/06_image_prompts.json",
        "source_sha256": sha256_text(text),
        "prompt_count": len(data.get("prompts", [])),
        "image_ids": [item.get("image_id") for item in data.get("prompts", [])],
        "prompt_contract": data.get("prompt_contract", {}),
        "prompts": data.get("prompts", []),
    }
    write_json(stage_path(run_dir, "06_image_prompts.lock.json"), lock)
    append_log(run_dir, "lock_image_prompts", "success", prompt_count=lock["prompt_count"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
