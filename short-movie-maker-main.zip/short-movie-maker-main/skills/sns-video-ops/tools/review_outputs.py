#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

from lib.harness_common import append_log, load_json, read_text, resolve_run_dir, stage_path, write_context_read_log, write_json, write_text


def review_markdown(review: dict) -> str:
    lines = [
        "# Review",
        "",
        f"- decision: {review.get('decision')}",
        f"- score: {review.get('score')}",
        f"- copy_risk: {review.get('copy_risk')}",
        f"- cosme_ad_claim_risk: {review.get('cosme_ad_claim_risk')}",
        "",
        "## Strengths",
        *[f"- {x}" for x in review.get("strengths", [])],
        "",
        "## Issues",
        *[f"- {x}" for x in review.get("issues", [])],
        "",
        "## Revision Instructions",
        *[f"- {x}" for x in review.get("revision_instructions", [])],
        "",
        "## Fact Traceability Issues",
        *[f"- {x}" for x in review.get("fact_traceability_issues", [])],
        "",
        "## Memory Updates",
        *[f"- {x}" for x in review.get("memory_updates", [])],
        "",
    ]
    return "\n".join(lines)


def all_source_refs(analysis: dict) -> set[str]:
    return {ref for item in analysis.get("frames", []) for ref in item.get("source_refs", [])}


def all_shot_refs(shot_manifest: dict, shot_analysis: dict) -> set[str]:
    manifest_refs = {shot.get("source_ref") for shot in shot_manifest.get("shots", []) if shot.get("source_ref")}
    analysis_refs = {ref for item in shot_analysis.get("frames", []) for ref in item.get("source_refs", [])}
    return manifest_refs | analysis_refs


def deterministic_review(payload: dict, run_dir: Path) -> dict:
    analysis_refs = all_source_refs(payload["analysis"])
    shot_manifest = payload.get("shot_manifest", {})
    shot_analysis = payload.get("shot_analysis", {})
    shot_refs = all_shot_refs(shot_manifest, shot_analysis)
    issues: list[str] = []
    traceability_issues: list[str] = []

    plan = payload["storyboard_plan"]
    ad_video_plan = payload.get("ad_video_plan", {})
    video_script = payload.get("video_script", {})
    shot_script = payload.get("shot_script", {})
    prompts = payload["image_prompts"].get("prompts", [])
    image_manifest = payload["image_manifest"].get("images", [])
    board = payload["storyboard_board"]

    for scene in plan.get("scenes", []):
        missing_refs = sorted(set(scene.get("source_refs", [])) - analysis_refs)
        if missing_refs:
            traceability_issues.append(f"{scene.get('scene_id')}: source_refs not found in analysis: {', '.join(missing_refs)}")
        if not scene.get("assumption_ids"):
            traceability_issues.append(f"{scene.get('scene_id')}: assumption_ids missing")
        if not scene.get("generated_from"):
            traceability_issues.append(f"{scene.get('scene_id')}: generated_from missing")
        missing_shot_refs = sorted(set(scene.get("source_shot_refs", [])) - shot_refs)
        if missing_shot_refs:
            traceability_issues.append(f"{scene.get('scene_id')}: source_shot_refs not found in shot analysis: {', '.join(missing_shot_refs)}")

    if not ad_video_plan:
        issues.append("UGC video plan missing; analysis is jumping into storyboard without first defining own UGC strategy")
    elif not ad_video_plan.get("own_ad_strategy", {}).get("single_message"):
        issues.append("UGC video plan missing single_message")
    elif not ad_video_plan.get("context_refs"):
        issues.append("UGC video plan missing context_refs")

    if not video_script:
        issues.append("video script missing; shot script lacks a script-level source of truth")
    elif len(video_script.get("scenes", [])) != len(plan.get("scenes", [])):
        issues.append("video script scene count does not match scene plan count")
    elif not video_script.get("context_refs"):
        issues.append("video script missing context_refs")

    if not shot_script:
        issues.append("shot script missing; image generation is not grounded in shot-level production directions")
    elif len(shot_script.get("planned_shots", [])) < len(plan.get("scenes", [])) * 2:
        issues.append("shot script is too thin; expected multiple planned shots per scene")
    elif not shot_script.get("context_refs"):
        issues.append("shot script missing context_refs")

    if shot_manifest:
        if shot_manifest.get("shot_count", 0) < 10:
            issues.append("shot manifest is too coarse for a fast Instagram Reel; expected double-digit shots")
        if shot_manifest.get("micro_shot_count", 0) == 0:
            issues.append("micro shots were not detected; high-speed cut structure may still be under-modeled")
        if len(shot_analysis.get("frames", [])) != shot_manifest.get("shot_count"):
            issues.append("shot analysis count does not match shot manifest count")
    else:
        issues.append("shot manifest missing; sub-second edit structure was not reviewed")

    for prompt in prompts:
        text = " ".join([
            prompt.get("prompt", ""),
            prompt.get("negative_prompt", ""),
            " ".join(prompt.get("overlay_text_later", [])),
        ])
        continuity = prompt.get("visual_continuity_contract") or prompt.get("continuity_lock") or {}
        if "ADVANCED CLINICALS" in prompt.get("prompt", ""):
            issues.append(f"{prompt.get('image_id')}: competitor brand leaked into positive prompt")
        if len("".join(prompt.get("overlay_text_later", []))) > 40:
            issues.append(f"{prompt.get('image_id')}: overlay text is long; keep text in editor layer")
        if "medical claim" not in prompt.get("negative_prompt", ""):
            issues.append(f"{prompt.get('image_id')}: negative prompt does not explicitly block medical claims")
        if "before-after" not in prompt.get("negative_prompt", ""):
            issues.append(f"{prompt.get('image_id')}: negative prompt does not explicitly block before-after framing")
        if "Japanese woman" not in text and "Japanese woman" not in " ".join(str(v) for v in continuity.values()):
            issues.append(f"{prompt.get('image_id')}: Japanese market model continuity is not explicit")
        if "Western-looking model" not in prompt.get("negative_prompt", ""):
            issues.append(f"{prompt.get('image_id')}: negative prompt does not explicitly block Western-looking model drift")
        if "slim cylindrical" not in text and "slim cylindrical" not in " ".join(str(v) for v in continuity.values()):
            issues.append(f"{prompt.get('image_id')}: product shape continuity is not explicit")

    image_ids = {p.get("image_id") for p in prompts}
    manifest_ids = {item.get("image_id") for item in image_manifest}
    missing_manifest = sorted(image_ids - manifest_ids)
    if missing_manifest:
        issues.append(f"image manifest missing ids: {', '.join(missing_manifest)}")

    for item in image_manifest:
        image_path = Path(item["image_path"])
        generation_manifest_path = Path(item.get("generation_manifest_path", ""))
        if not image_path.exists() or image_path.stat().st_size == 0:
            issues.append(f"{item.get('image_id')}: generated PNG missing or empty")
        if not generation_manifest_path.exists():
            issues.append(f"{item.get('image_id')}: generation manifest missing")

    board_html = run_dir / "storyboard" / "08_storyboard_board.html"
    contact_sheet = run_dir / "storyboard" / "08_storyboard_contact_sheet.png"
    if not board_html.exists():
        issues.append("storyboard HTML missing")
    if not contact_sheet.exists():
        issues.append("storyboard contact sheet missing")

    visual_issue = "Generated storyboard images are suitable for lecture storyboard review, but final production still needs a fixed product reference and real brand assets to eliminate residual visual drift."
    issues.append(visual_issue)

    score = 88 if not traceability_issues else 72
    decision = "accept" if not traceability_issues and len([i for i in issues if "missing" in i or "leaked" in i]) == 0 else "revise"
    return {
        "decision": decision,
        "score": score,
        "strengths": [
            "Instagram Reel was downloaded, sampled, and analyzed frame-by-frame with source_refs preserved.",
            f"Shot detection found {shot_manifest.get('shot_count', 0)} shots and {shot_manifest.get('micro_shot_count', 0)} micro shots, then carried source_shot_refs into storyboard scenes.",
            "UGC video plan, video script, and shot script separate strategy, copy, camera direction, and image generation.",
            "Storyboard scenes separate competitor structure from own-brand assumptions and generated direction.",
            "All six gpt-image-2 storyboard PNGs exist with generation manifests and non-zero file sizes.",
            "Copy risk is structurally controlled by replacing competitor product, UI, copy, and category context.",
        ],
        "issues": issues,
        "revision_instructions": [
            "For final production, replace generated generic bottles with actual product photography or a fixed product reference image.",
            "Keep all Japanese captions in the editing layer, not inside generated images.",
            "If using review-like copy, avoid fake testimonials; frame it as usage-scene guidance or clearly sourced real reviews.",
            "Use this storyboard as a lecture demo and UGC creative planning artifact, not as final creative without legal/brand review.",
        ],
        "memory_updates": [
            "Per-frame image analysis is more stable than large contact-sheet analysis for this Claude Code workflow.",
            "Fast Reels require shot-boundary analysis in addition to 1fps frame sampling; otherwise sub-second cuts disappear from the planning context.",
            "Japanese cosmetic ad generation needs an explicit visual continuity contract for person, room, product shape, and negative drift conditions.",
            "Long-form brief/storyboard generation should use compacted analysis or deterministic assembly to avoid prompt bloat.",
            "image 2 storyboard prompts should explicitly block competitor packaging, fake social UI, long text, and medical claims.",
        ],
        "fact_traceability_issues": traceability_issues,
        "copy_risk": "low: competitor structure is reused, but product, category, UI, copy, and CTA are replaced.",
        "cosme_ad_claim_risk": "low-to-medium: prompts avoid medical claims and before/after, but final captions still require legal/brand review.",
        "artifacts_checked": {
            "storyboard_board": str(board_html),
            "contact_sheet": str(contact_sheet),
            "board_scene_count": len(board.get("scenes", [])),
            "image_count": len(image_manifest),
            "shot_count": shot_manifest.get("shot_count", 0),
            "micro_shot_count": shot_manifest.get("micro_shot_count", 0),
            "planned_shot_count": len(shot_script.get("planned_shots", [])) if shot_script else 0,
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", type=Path)
    parser.add_argument("--run-id")
    parser.add_argument("--max-budget-usd", type=float, default=2.5)
    args = parser.parse_args()

    run_dir = resolve_run_dir(args)
    append_log(run_dir, "review_outputs", "start")
    write_context_read_log(
        run_dir,
        "review_outputs",
        input_artifacts=[
            "stages/03_timeseries_analysis.json",
            "stages/03b_shot_analysis.json",
            "stages/04b_ad_video_plan.json",
            "stages/05a_video_script.json",
            "stages/05b_shot_script.json",
            "stages/06_image_prompts.json",
            "stages/07_storyboard_images_manifest.json"
        ],
        output_artifacts=["stages/09_review.json", "stages/09_review.md"],
    )
    payload = {
        "analysis": load_json(stage_path(run_dir, "03_timeseries_analysis.json")),
        "shot_manifest": load_json(stage_path(run_dir, "02b_shot_manifest.json")) if stage_path(run_dir, "02b_shot_manifest.json").exists() else {},
        "shot_analysis": load_json(stage_path(run_dir, "03b_shot_analysis.json")) if stage_path(run_dir, "03b_shot_analysis.json").exists() else {},
        "brief": read_text(stage_path(run_dir, "04_production_brief.md")),
        "ad_video_plan": load_json(stage_path(run_dir, "04b_ad_video_plan.json")) if stage_path(run_dir, "04b_ad_video_plan.json").exists() else {},
        "storyboard_plan": load_json(stage_path(run_dir, "05_storyboard_plan.json")),
        "video_script": load_json(stage_path(run_dir, "05a_video_script.json")) if stage_path(run_dir, "05a_video_script.json").exists() else {},
        "shot_script": load_json(stage_path(run_dir, "05b_shot_script.json")) if stage_path(run_dir, "05b_shot_script.json").exists() else {},
        "image_prompts": load_json(stage_path(run_dir, "06_image_prompts.json")),
        "image_manifest": load_json(stage_path(run_dir, "07_storyboard_images_manifest.json")),
        "storyboard_board": load_json(run_dir / "storyboard" / "08_storyboard_board.json"),
    }
    parsed = deterministic_review(payload, run_dir)
    write_json(stage_path(run_dir, "09_review.json"), parsed)
    write_text(stage_path(run_dir, "09_review.md"), review_markdown(parsed))
    write_json(run_dir / "logs" / "review_outputs.json", {"mode": "deterministic", "decision": parsed.get("decision"), "score": parsed.get("score")})
    append_log(run_dir, "review_outputs", "success", decision=parsed.get("decision"), score=parsed.get("score"), mode="deterministic")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
