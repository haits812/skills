#!/usr/bin/env python3
from __future__ import annotations

import shutil
import subprocess
import sys
import argparse
from pathlib import Path


HARNESS_ROOT = Path(__file__).resolve().parents[1]


def ok(message: str) -> None:
    print(f"[OK] {message}")


def warn(message: str) -> None:
    print(f"[WARN] {message}")


def fail(message: str) -> None:
    print(f"[FAIL] {message}")


def check_cli(name: str, *, required: bool = True) -> bool:
    found = shutil.which(name)
    if found:
        ok(f"{name}: {found}")
        return True
    if required:
        fail(f"{name}: not found")
    else:
        warn(f"{name}: not found")
    return False


def probe_command(cmd: list[str], label: str, *, required: bool = True) -> bool:
    try:
        completed = subprocess.run(
            cmd,
            cwd=str(HARNESS_ROOT),
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=30,
        )
    except Exception as exc:
        if required:
            fail(f"{label}: probe failed: {exc}")
        else:
            warn(f"{label}: probe failed: {exc}")
        return False
    if completed.returncode == 0:
        ok(f"{label}: responds")
        return True
    message = (completed.stderr or completed.stdout).strip().splitlines()
    detail = message[0] if message else f"exit code {completed.returncode}"
    if required:
        fail(f"{label}: probe failed: {detail}")
    else:
        warn(f"{label}: probe failed: {detail}")
    return False


def check_python() -> bool:
    version = sys.version_info
    if version >= (3, 10):
        ok(f"python: {version.major}.{version.minor}.{version.micro}")
        return True
    fail(f"python: {version.major}.{version.minor}.{version.micro}; Python 3.10+ required")
    return False


def check_paths() -> bool:
    required = [
        HARNESS_ROOT / "tools" / "run_harness.py",
        HARNESS_ROOT / "tools" / "daily_runner.py",
        HARNESS_ROOT / "schemas",
        HARNESS_ROOT / "prompts",
        HARNESS_ROOT / "vaults" / "sample-cosme" / "context_manifest.json",
        HARNESS_ROOT / "vaults" / "sample-cosme" / "brand_context.md",
        HARNESS_ROOT / "hermes" / "day02_sns_video_ops_daily.sh",
        HARNESS_ROOT / "inputs" / "inbox",
    ]
    passed = True
    for path in required:
        if path.exists():
            ok(f"path: {path.relative_to(HARNESS_ROOT)}")
        else:
            fail(f"missing: {path.relative_to(HARNESS_ROOT)}")
            passed = False
    return passed


def check_hermes_hint() -> None:
    if not shutil.which("hermes"):
        warn("hermes: not found; script-only daily runner can still be run manually with bash")
        return
    probe_command(["hermes", "cron", "--help"], "hermes cron", required=False)
    completed = subprocess.run(
        ["hermes", "cron", "status"],
        cwd=str(HARNESS_ROOT),
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=30,
    )
    output = completed.stdout + completed.stderr
    if "Gateway is not running" in output:
        warn("hermes cron gateway is not running; scheduled jobs will not fire automatically until hermes gateway is installed or running")
    else:
        ok("hermes cron status checked")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--require-render", action="store_true", help="Fail if Codex CLI is not executable for image rendering.")
    args = parser.parse_args()

    print(f"HARNESS_ROOT={HARNESS_ROOT}")
    passed = True
    passed = check_python() and passed
    for cli in ["yt-dlp", "ffmpeg", "ffprobe", "claude"]:
        passed = check_cli(cli) and passed
    if shutil.which("yt-dlp"):
        passed = probe_command(["yt-dlp", "--version"], "yt-dlp") and passed
    if shutil.which("ffmpeg"):
        passed = probe_command(["ffmpeg", "-version"], "ffmpeg") and passed
    if shutil.which("ffprobe"):
        passed = probe_command(["ffprobe", "-version"], "ffprobe") and passed
    if shutil.which("claude"):
        passed = probe_command(["claude", "--version"], "claude") and passed
    codex_exists = check_cli("codex", required=False)
    if codex_exists:
        codex_ok = probe_command(["codex", "--version"], "codex", required=args.require_render)
        if args.require_render:
            passed = codex_ok and passed
    elif args.require_render:
        passed = False
    check_hermes_hint()
    passed = check_paths() and passed
    if passed:
        ok("preflight passed")
        return 0
    fail("preflight failed")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
