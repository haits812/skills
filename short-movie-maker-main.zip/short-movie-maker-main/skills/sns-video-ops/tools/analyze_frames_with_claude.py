#!/usr/bin/env python3
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import json
import math
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

from lib.harness_common import HARNESS_ROOT, append_log, ensure_dir, load_json, prompt_text, render_context_bundle, resolve_run_dir, run_claude_structured, stage_path, write_context_read_log, write_json


def resolve_frame_path(item: dict) -> Path:
    frame_path = Path(item["frame_path"])
    if frame_path.is_absolute():
        return frame_path
    return (HARNESS_ROOT / frame_path).resolve()


def chunked(items: list[dict], size: int) -> list[list[dict]]:
    return [items[i : i + size] for i in range(0, len(items), size)]


def make_contact_sheet(run_dir: Path, frames: list[dict], name: str, cols: int = 5, thumb_width: int = 260) -> Path:
    sheet_path = ensure_dir(run_dir / "batches") / f"{name}.jpg"
    thumbs = []
    font = ImageFont.load_default()
    label_h = 24
    for item in frames:
        frame_path = resolve_frame_path(item)
        with Image.open(frame_path) as img:
            img = img.convert("RGB")
            ratio = thumb_width / img.width
            thumb_h = int(img.height * ratio)
            img = img.resize((thumb_width, thumb_h))
            canvas = Image.new("RGB", (thumb_width, thumb_h + label_h), "white")
            canvas.paste(img, (0, label_h))
            draw = ImageDraw.Draw(canvas)
            label = f"{item['source_ref']}"
            draw.rectangle((0, 0, thumb_width, label_h), fill=(20, 20, 20))
            draw.text((6, 6), label, fill=(255, 255, 255), font=font)
            thumbs.append(canvas)
    rows = math.ceil(len(thumbs) / cols)
    cell_w = max(t.width for t in thumbs)
    cell_h = max(t.height for t in thumbs)
    sheet = Image.new("RGB", (cell_w * cols, cell_h * rows), (245, 245, 245))
    for i, thumb in enumerate(thumbs):
        x = (i % cols) * cell_w
        y = (i // cols) * cell_h
        sheet.paste(thumb, (x, y))
    sheet.save(sheet_path, quality=92)
    return sheet_path


def analyze_batch(run_dir: Path, batch: list[dict], batch_index: int, max_budget_usd: float) -> tuple[dict, dict]:
    contact_sheet = make_contact_sheet(run_dir, batch, f"contact_sheet_batch_{batch_index:03d}")
    frame_lines = []
    for item in batch:
        frame_lines.append({
            "index": item["index"],
            "time_sec": item["time_sec"],
            "frame_path": str(resolve_frame_path(item)),
            "source_ref": item["source_ref"],
        })

    prompt = f"""{prompt_text("01_analyze_frames.md")}

{render_context_bundle("analyze_frames")}

# Task

Read the contact sheet image with the Read tool. It contains only this batch of frames with source_ref labels burned into each tile.
Produce a factual time-series analysis of this batch of the competitor Reel.

Do not infer product claims that are not visible. Separate visual facts from reuse ideas.

# Contact Sheet

{contact_sheet.resolve()}

# Frames In This Batch

{json.dumps(frame_lines, ensure_ascii=False, indent=2)}

# Required traceability

- Return one `frames[]` item per listed frame.
- Every frame item must include source_refs such as `frame_001@0.0s`.
- If a tile is too small to read exact text, state that the exact text is unreadable instead of inventing it.
- Patterns and reuse_notes should reference the relevant source_refs in natural language.
"""

    parsed, wrapper = run_claude_structured(
        prompt,
        schema_name="timeseries_analysis.schema.json",
        allowed_tools="Read",
        max_budget_usd=max_budget_usd,
        timeout=900,
    )
    if "raw_text" in parsed or not isinstance(parsed.get("frames"), list):
        raise RuntimeError(f"Claude batch {batch_index} did not return parseable frame analysis")
    write_json(run_dir / "batches" / f"03_timeseries_analysis_batch_{batch_index:03d}.json", parsed)
    write_json(run_dir / "logs" / f"claude_analyze_frames_batch_{batch_index:03d}.json", wrapper)
    return parsed, wrapper


def analyze_single_frame(run_dir: Path, item: dict, max_budget_usd: float, force: bool = False) -> dict:
    index = int(item["index"])
    output_path = run_dir / "batches" / f"03_frame_analysis_{index:03d}.json"
    if output_path.exists() and not force:
        cached = load_json(output_path)
        if isinstance(cached.get("frames"), list) and cached["frames"]:
            return cached

    frame_path = resolve_frame_path(item)
    prompt = f"""{prompt_text("01_analyze_frames.md")}

# Task

Read this one local frame image with the Read tool and return factual analysis for this frame only.
Do not use outside knowledge. Do not infer invisible product claims.

# Frame

- source_ref: {item["source_ref"]}
- time_sec: {item["time_sec"]}
- frame_path: {frame_path}

# Required output discipline

- Return exactly one item in `frames[]`.
- `frames[0].source_refs` must be exactly `["{item["source_ref"]}"]`.
- If text is too small or blurry, say it is unreadable instead of inventing it.
- `motion_or_edit` may describe only what can be inferred from this still frame.
- Keep `patterns`, `reuse_notes`, and `risks` short and tied to this frame.
"""

    parsed, wrapper = run_claude_structured(
        prompt,
        schema_name="timeseries_analysis.schema.json",
        allowed_tools="Read",
        max_budget_usd=max_budget_usd,
        timeout=420,
    )
    if "raw_text" in parsed or not isinstance(parsed.get("frames"), list) or len(parsed["frames"]) != 1:
        write_json(run_dir / "logs" / f"claude_analyze_frame_{index:03d}_failed.json", {"parsed": parsed, "wrapper": wrapper})
        raise RuntimeError(f"Claude frame {index:03d} did not return one parseable frame item")
    frame_result = parsed["frames"][0]
    refs = frame_result.get("source_refs", [])
    if item["source_ref"] not in refs:
        frame_result["source_refs"] = [item["source_ref"]]
        parsed["frames"][0] = frame_result
        parsed.setdefault("risks", []).append(f"source_refs normalized to {item['source_ref']}")
    write_json(output_path, parsed)
    write_json(run_dir / "logs" / f"claude_analyze_frame_{index:03d}.json", wrapper)
    return parsed


def merge_batches(run_dir: Path, batches: list[dict]) -> dict:
    frames: list[dict] = []
    patterns: list[str] = []
    reuse_notes: list[str] = []
    risks: list[str] = []
    summaries: list[str] = []
    for i, batch in enumerate(batches, start=1):
        summaries.append(f"batch_{i:03d}: {batch.get('batch_summary', '')}")
        frames.extend(batch.get("frames", []))
        patterns.extend(batch.get("patterns", []))
        reuse_notes.extend(batch.get("reuse_notes", []))
        risks.extend(batch.get("risks", []))
    frames.sort(key=lambda item: float(item.get("time_sec", 0)))
    return {
        "batch_summary": "\n".join(summaries),
        "frames": frames,
        "patterns": patterns,
        "reuse_notes": reuse_notes,
        "risks": risks,
        "traceability": {
            "analysis_mode": "batched_contact_sheets",
            "batch_count": len(batches),
            "batch_files": [f"batches/03_timeseries_analysis_batch_{i:03d}.json" for i in range(1, len(batches) + 1)],
        },
    }


def merge_frame_results(results: list[dict]) -> dict:
    frames: list[dict] = []
    patterns: list[str] = []
    reuse_notes: list[str] = []
    risks: list[str] = []
    summaries: list[str] = []
    for result in results:
        summaries.append(result.get("batch_summary", ""))
        frames.extend(result.get("frames", []))
        patterns.extend(result.get("patterns", []))
        reuse_notes.extend(result.get("reuse_notes", []))
        risks.extend(result.get("risks", []))
    frames.sort(key=lambda item: float(item.get("time_sec", 0)))
    return {
        "batch_summary": "\n".join(s for s in summaries if s),
        "frames": frames,
        "patterns": patterns,
        "reuse_notes": reuse_notes,
        "risks": risks,
        "traceability": {
            "analysis_mode": "per_frame_read_tool",
            "frame_result_files": [f"batches/03_frame_analysis_{int(item.get('source_refs', ['frame_000'])[0].split('@')[0].split('_')[-1]):03d}.json" for item in frames if item.get("source_refs")],
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", type=Path)
    parser.add_argument("--run-id")
    parser.add_argument("--max-frames", type=int, default=25)
    parser.add_argument("--max-budget-usd", type=float, default=4.0)
    parser.add_argument("--batch-size", type=int, default=5)
    parser.add_argument("--mode", choices=["batch", "per-frame"], default="per-frame")
    parser.add_argument("--concurrency", type=int, default=6)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    run_dir = resolve_run_dir(args)
    append_log(run_dir, "analyze_frames_with_claude", "start", max_frames=args.max_frames, batch_size=args.batch_size, mode=args.mode)
    write_context_read_log(
        run_dir,
        "analyze_frames",
        input_artifacts=["stages/02_frame_manifest.json", "frames/frame_###.jpg"],
        output_artifacts=["stages/03_timeseries_analysis.json", "batches/03_frame_analysis_###.json"],
    )
    frame_manifest = load_json(stage_path(run_dir, "02_frame_manifest.json"))
    frames = frame_manifest.get("frames", [])[: args.max_frames]
    if not frames:
        raise RuntimeError("No frames found in 02_frame_manifest.json")
    if args.batch_size <= 0:
        raise RuntimeError("--batch-size must be positive")

    if args.mode == "batch":
        batch_results: list[dict] = []
        batches = chunked(frames, args.batch_size)
        per_batch_budget = max(args.max_budget_usd, 0.5)
        for batch_index, batch in enumerate(batches, start=1):
            append_log(run_dir, "analyze_frames_with_claude", "batch_start", batch_index=batch_index, frame_count=len(batch))
            parsed, _wrapper = analyze_batch(run_dir, batch, batch_index, per_batch_budget)
            batch_results.append(parsed)
            append_log(run_dir, "analyze_frames_with_claude", "batch_success", batch_index=batch_index, frame_count=len(parsed.get("frames", [])))
        merged = merge_batches(run_dir, batch_results)
    else:
        if args.concurrency <= 0:
            raise RuntimeError("--concurrency must be positive")
        per_frame_budget = max(args.max_budget_usd, 0.25)
        frame_results: list[dict] = []
        with ThreadPoolExecutor(max_workers=args.concurrency) as executor:
            futures = {
                executor.submit(analyze_single_frame, run_dir, item, per_frame_budget, args.force): item
                for item in frames
            }
            for future in as_completed(futures):
                item = futures[future]
                append_log(run_dir, "analyze_frames_with_claude", "frame_start", frame_index=item["index"], source_ref=item["source_ref"])
                parsed = future.result()
                frame_results.append(parsed)
                append_log(run_dir, "analyze_frames_with_claude", "frame_success", frame_index=item["index"], source_ref=item["source_ref"])
        merged = merge_frame_results(frame_results)

    expected_refs = {item["source_ref"] for item in frames}
    actual_refs = {ref for item in merged.get("frames", []) for ref in item.get("source_refs", [])}
    missing_refs = sorted(expected_refs - actual_refs)
    if missing_refs:
        merged.setdefault("risks", []).append(f"Missing analyzed source_refs: {', '.join(missing_refs)}")
        raise RuntimeError(f"Missing analyzed source_refs: {', '.join(missing_refs)}")

    write_json(stage_path(run_dir, "03_timeseries_analysis.json"), merged)
    traceability = merged.get("traceability", {})
    write_json(run_dir / "logs" / "claude_analyze_frames.json", {
        "mode": traceability.get("analysis_mode", args.mode),
        "result_count": len(merged.get("frames", [])),
        "source_ref_count": len(actual_refs),
        "missing_source_refs": missing_refs,
    })
    append_log(
        run_dir,
        "analyze_frames_with_claude",
        "success",
        frame_count=len(merged.get("frames", [])),
        mode=traceability.get("analysis_mode", args.mode),
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
