#!/usr/bin/env python3
from __future__ import annotations

import argparse
import re
import subprocess
import sys
from pathlib import Path

from lib.harness_common import HARNESS_ROOT, append_log, ensure_dir, ensure_run_dir, read_text, utc_now, write_json


def extract_url(text: str) -> str | None:
    for token in text.replace("\n", " ").split():
        if token.startswith("http://") or token.startswith("https://"):
            return token.strip()
    return None


def safe_stem(value: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9_.-]+", "-", value).strip("-")
    return cleaned or "item"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--inbox", type=Path, default=HARNESS_ROOT / "inputs" / "inbox")
    parser.add_argument("--mode", choices=["preimage", "render", "full"])
    parser.add_argument("--execute-images", action="store_true")
    parser.add_argument("--max-images", type=int, default=6)
    args = parser.parse_args()
    mode = args.mode or ("full" if args.execute_images else "preimage")

    ensure_dir(args.inbox)
    processed_dir = ensure_dir(args.inbox / "processed")
    failed_dir = ensure_dir(args.inbox / "failed")
    inbox_items = sorted([
        p
        for p in args.inbox.glob("*")
        if p.is_file() and p.suffix.lower() in {".md", ".txt"} and p.name.upper() != "README.MD"
    ])
    report = {"started_at": utc_now(), "items": []}
    exit_code = 0
    for item in inbox_items:
        text = read_text(item)
        url = extract_url(text)
        if not url:
            report["items"].append({"file": str(item), "status": "skipped", "reason": "no url"})
            continue
        stamp = utc_now().replace("-", "").replace(":", "").replace("T", "-").replace("Z", "")
        run_id = f"daily-{safe_stem(item.stem)}-{stamp}"
        cmd = [
            sys.executable,
            str(HARNESS_ROOT / "tools" / "run_harness.py"),
            "--mode",
            mode,
            "--run-id",
            run_id,
            "--url",
            url,
            "--max-images",
            str(args.max_images),
            "--improve-vault",
        ]
        if args.execute_images:
            cmd.append("--execute-images")
        completed = subprocess.run(cmd, cwd=str(HARNESS_ROOT), text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        report["items"].append({
            "file": str(item),
            "url": url,
            "run_id": run_id,
            "mode": mode,
            "returncode": completed.returncode,
            "stdout": completed.stdout[-2000:],
            "stderr": completed.stderr[-2000:],
        })
        if completed.returncode == 0:
            moved_to = processed_dir / item.name
            item.rename(moved_to)
            report["items"][-1]["moved_to"] = str(moved_to)
        else:
            moved_to = failed_dir / item.name
            item.rename(moved_to)
            report["items"][-1]["moved_to"] = str(moved_to)
            exit_code = completed.returncode
            break
    write_json(HARNESS_ROOT / "runs" / "daily_runner_report.json", report)
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
