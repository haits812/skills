# Tools

## 実行順

通常は `run_harness.py --mode preimage` で画像生成前までを先に改善し、合格後に `run_harness.py --mode render` で画像生成する。

### Preimage

1. `download_video.py`
2. `extract_frames.py`
3. `detect_shots.py`
4. `analyze_shots_with_claude.py`
5. `analyze_frames_with_claude.py`
6. `build_brief.py`
7. `build_ad_video_plan.py`
8. `build_storyboard_plan.py`
9. `build_video_script.py`
10. `build_shot_script.py`
11. `build_image_prompts.py`
12. `review_preimage_outputs.py`
13. `build_preimage_board.py`
14. `build_review_learning_pack.py`
15. `build_analysis_review_board.py`
16. `build_operator_board.py`

### Render

1. `lock_image_prompts.py`
2. `generate_images_with_codex_exec.py`
3. `normalize_storyboard_images.py`
4. `build_storyboard_board.py`
5. `review_outputs.py`
6. `build_review_learning_pack.py`
7. `build_analysis_review_board.py`
8. `build_operator_board.py`
9. `update_memory.py`
10. `improve_vault.py`

通常は `run_harness.py` を使う。

## 外部依存

- `yt-dlp`
- `ffmpeg`
- `ffprobe`
- `claude`
- Codex exec image generation runtime
