#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

from lib.harness_common import append_log, load_json, read_text, resolve_run_dir, stage_path, utc_now, vault_dir, write_context_read_log, write_json, write_text


def checked_items(text: str, heading: str = "Candidates To Consider") -> list[str]:
    marker = f"## {heading}"
    if marker not in text:
        return []
    body = text.split(marker, 1)[1]
    next_pos = body.find("\n## ")
    if next_pos >= 0:
        body = body[:next_pos]
    items: list[str] = []
    for line in body.splitlines():
        stripped = line.strip()
        lower = stripped.lower()
        if lower.startswith("- [x] "):
            items.append(stripped[6:].strip())
        elif lower.startswith("- [✓] "):
            items.append(stripped[6:].strip())
    return [item for item in items if item]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", type=Path)
    parser.add_argument("--run-id")
    parser.add_argument("--vault", default="sample-cosme")
    parser.add_argument("--allow-empty", action="store_true")
    args = parser.parse_args()

    run_dir = resolve_run_dir(args)
    append_log(run_dir, "apply_learning_to_vault", "start", vault=args.vault)
    write_context_read_log(
        run_dir,
        "apply_learning_to_vault",
        args.vault,
        input_artifacts=[
            "review/human_review.md",
            "review/learning_candidates.md",
            "review/learning_update_decision.md",
        ],
        output_artifacts=[
            "stages/10b_vault_learning_apply.json",
            "stages/10b_vault_learning_apply.md",
            "vaults/sample-cosme/learnings.md",
        ],
    )

    decision_path = run_dir / "review" / "learning_update_decision.md"
    learning_path = run_dir / "review" / "learning_candidates.md"
    human_path = run_dir / "review" / "human_review.md"
    if not decision_path.exists():
        raise FileNotFoundError(decision_path)

    approved = checked_items(read_text(decision_path))
    if not approved and not args.allow_empty:
        raise SystemExit(
            "No approved learning candidates found. Mark items with '- [x]' in review/learning_update_decision.md, "
            "or pass --allow-empty for dry verification."
        )

    learnings_path = vault_dir(args.vault) / "learnings.md"
    existing = read_text(learnings_path).rstrip()
    marker = f"## Human Review Run {run_dir.name}"
    appended = 0
    if approved and marker not in existing:
        lines = [existing, "", f"{marker} ({utc_now()})"]
        lines.extend(f"- {item}" for item in approved)
        lines.append("")
        write_text(learnings_path, "\n".join(lines))
        appended = len(approved)

    result = {
        "run_id": run_dir.name,
        "vault": args.vault,
        "decision_file": str(decision_path),
        "learning_candidates": str(learning_path),
        "human_review": str(human_path),
        "approved_count": len(approved),
        "appended_count": appended,
        "skipped_duplicate": bool(approved and appended == 0),
        "approved_items": approved,
        "vault_learnings": str(learnings_path),
        "applied_at": utc_now(),
    }
    write_json(stage_path(run_dir, "10b_vault_learning_apply.json"), result)
    md = [
        "# Vault Learning Apply",
        "",
        f"- run_id: {run_dir.name}",
        f"- vault: {args.vault}",
        f"- approved_count: {len(approved)}",
        f"- appended_count: {appended}",
        f"- skipped_duplicate: {result['skipped_duplicate']}",
        "",
        "## Approved Items",
        "",
        *[f"- {item}" for item in approved],
        "",
    ]
    write_text(stage_path(run_dir, "10b_vault_learning_apply.md"), "\n".join(md))
    append_log(run_dir, "apply_learning_to_vault", "success", approved=len(approved), appended=appended)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
