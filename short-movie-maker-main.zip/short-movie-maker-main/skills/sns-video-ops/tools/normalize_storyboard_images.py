#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

from PIL import Image, ImageOps

from lib.harness_common import append_log, ensure_dir, load_json, resolve_run_dir, stage_path, write_json


def normalize_image(source: Path, target: Path, width: int, height: int) -> dict:
    with Image.open(source) as img:
        img = ImageOps.exif_transpose(img).convert("RGB")
        original_size = img.size
        target_ratio = width / height
        original_ratio = img.width / img.height

        canvas = ImageOps.fit(
            img,
            (width, height),
            method=Image.Resampling.LANCZOS,
            centering=(0.5, 0.5),
        )

        ensure_dir(target.parent)
        canvas.save(target, quality=95)
        return {
            "source_size": list(original_size),
            "source_ratio": round(original_ratio, 6),
            "target_size": [width, height],
            "target_ratio": round(target_ratio, 6),
            "fit_mode": "center_crop",
        }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", type=Path)
    parser.add_argument("--run-id")
    parser.add_argument("--width", type=int, default=1080)
    parser.add_argument("--height", type=int, default=1920)
    args = parser.parse_args()

    run_dir = resolve_run_dir(args)
    append_log(run_dir, "normalize_storyboard_images", "start", width=args.width, height=args.height)
    manifest_path = stage_path(run_dir, "07_storyboard_images_manifest.json")
    manifest = load_json(manifest_path)
    normalized_dir = ensure_dir(run_dir / "images" / "normalized")
    normalized_items = []

    for item in manifest.get("images", []):
        source_path = Path(item["image_path"])
        if not source_path.is_absolute():
            source_path = (run_dir / source_path).resolve()
        if not source_path.exists():
            raise FileNotFoundError(source_path)

        target_path = normalized_dir / f"{item['image_id']}.png"
        metrics = normalize_image(source_path, target_path, args.width, args.height)
        next_item = dict(item)
        next_item["source_generated_image_path"] = str(source_path)
        next_item["image_path"] = str(target_path)
        next_item["normalized"] = True
        next_item["normalization"] = metrics
        normalized_items.append(next_item)

    normalized_manifest = {**manifest, "images": normalized_items, "normalized_size": [args.width, args.height]}
    write_json(stage_path(run_dir, "07b_normalized_storyboard_images_manifest.json"), normalized_manifest)
    write_json(manifest_path, normalized_manifest)
    append_log(run_dir, "normalize_storyboard_images", "success", image_count=len(normalized_items))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
