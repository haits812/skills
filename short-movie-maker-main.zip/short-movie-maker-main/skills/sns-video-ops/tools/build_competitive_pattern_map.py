#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

from lib.harness_common import append_log, load_json, resolve_run_dir, stage_path, write_context_read_log, write_json, write_text, write_yaml_like


CANONICAL_PATTERNS = {
    "opening_hook_pattern": {
        "label": "opening hook",
        "shot_range": (1, 5),
        "summary": "冒頭は、商品カテゴリ・生活者の悩み・主役商品を0.5-3秒で同時に理解させる。作り込んだ広告ではなく、スマホで一瞬見せる日常語の入りにする。",
        "own_conversion": "自社ミスト商品を1本だけ顔横または洗面台に置き、朝のメイク前に使うものだと即理解できる画にする。複数商品、競合容器、SNS投稿UIは使わない。",
    },
    "product_understanding_pattern": {
        "label": "product understanding",
        "shot_range": (6, 10),
        "summary": "商品理解は、接写、手元、使用直前の動きで積み上げる。ラベルを読むためではなく、どの生活導線に入る商品かを短く見せる。",
        "own_conversion": "ボトル1本、スプレー口、手に持つ動作、洗面台に置いた状態を組み合わせ、メイク前のミスト商品として分かるようにする。裏面ラベルや成分訴求に寄せすぎない。",
    },
    "usage_scene_pattern": {
        "label": "usage scene",
        "shot_range": (11, 17),
        "summary": "使用シーンは、説明よりも生活者の手順で見せる。商品を手に取る、顔から少し離して使う、メイク道具の横に戻すなど、実際の行動が分かる粒度にする。",
        "own_conversion": "日本の住まいの洗面台/メイク前導線で、自社ミスト商品を手に取り、顔まわりにミストを使う前後の自然な動きを見せる。髪・ヘアケア・ジャー商品の文脈は持ち込まない。",
    },
    "proof_or_trust_pattern": {
        "label": "proof or trust",
        "shot_range": (2, 18),
        "summary": "信頼感は、派手なレビュー画面ではなく、使うタイミング、生活導線、短い使用メモ、商品質感で補強する。実在しない数値やSNS UIは使わない。",
        "own_conversion": "朝の支度に追加しやすいこと、軽いミスト感、メイク前に使う意図を、手元メモや短い後載せテロップで説明する。効果断定や捏造レビューは避ける。",
    },
    "finish_or_memory_pattern": {
        "label": "finish or memory",
        "shot_range": (18, 22),
        "summary": "終盤は、仕上がりの断定ではなく、商品名と使った後の自然な印象を戻す。視聴者が『朝の支度で使う商品』として記憶できるようにする。",
        "own_conversion": "同じ場所、同じ人物、同じボトルで、メイク前後の自然な印象と商品記憶を残す。ビフォーアフターや過剰な美容効果演出にしない。",
    },
    "cta_pattern": {
        "label": "cta",
        "shot_range": (23, 25),
        "summary": "CTAは最後に軽く置く。押し売りではなく、保存、プロフィール確認、商品詳細確認に自然につなげる。",
        "own_conversion": "ボトルと洗面台背景に余白を作り、テロップ編集レイヤーで『気になったら保存』『プロフィールから詳細』を載せる。画像内に長文を焼き込まない。",
    },
}


USABLE_PRINCIPLES = [
    "冒頭0.5-3秒で、商品カテゴリ、生活者の悩み、主役商品を同時に理解させる",
    "商品を1本に絞り、視聴者の記憶対象を散らさない",
    "商品理解は、接写、手元、使用直前の動きで短く積み上げる",
    "生活者の自然な所作を挟み、広告ではなく投稿らしい距離感を作る",
    "証拠は捏造レビューではなく、使用タイミング、商品質感、短い使用メモで作る",
    "画角はスマホ縦型の手持ち感を残し、スタジオ広告の完成度に寄せすぎない",
    "短いmicro shotでテンポを作り、長めのカットで商品理解を補う",
    "テロップは後載せ前提にして、画像生成内に長文日本語を焼き込まない",
    "終盤で商品と生活導線を再提示し、保存/詳細確認へ軽くつなぐ",
    "競合の表現ではなく、視聴者理解の順番だけを自社商品へ移植する",
]


DO_NOT_COPY = [
    "競合ブランド名、容器形状、ラベル、商品カテゴリをコピーしない",
    "ヘアケア、髪、ジャー、成分バッジ、泡など競合商品の具体文脈を持ち込まない",
    "SNS投稿UI、レビュー画面、表示数、星評価を実在しない証拠として作らない",
    "複数商品を並べて、自社商品の記憶対象をぼかさない",
    "テレビCM、海外ラグジュアリー広告、モデル撮影のように作り込みすぎない",
    "効果効能の断定、医療/改善表現、極端なビフォーアフターを使わない",
]


def shot_number(shot: dict) -> int:
    ref = str(shot.get("source_shot_ref", ""))
    marker = ref.split("@", 1)[0].replace("shot_", "")
    try:
        return int(marker)
    except ValueError:
        return 0


def select_by_range(shots: list[dict], start: int, end: int) -> list[dict]:
    selected = [shot for shot in shots if start <= shot_number(shot) <= end]
    return selected or shots[max(0, start - 1):end]


def summarize(pattern_key: str, shots: list[dict]) -> str:
    pattern = CANONICAL_PATTERNS[pattern_key]
    refs = [shot.get("source_shot_ref", "") for shot in shots if shot.get("source_shot_ref")]
    return f"{pattern['label']}: {pattern['summary']} 自社変換: {pattern['own_conversion']} 根拠: {', '.join(refs[:5])}"


def markdown(data: dict) -> str:
    keys = [
        "opening_hook_pattern",
        "product_understanding_pattern",
        "proof_or_trust_pattern",
        "usage_scene_pattern",
        "finish_or_memory_pattern",
        "cta_pattern",
        "pacing_pattern",
    ]
    lines = [
        f"# {data.get('title', 'Competitive Pattern Map')}",
        "",
        f"- source_run: {data.get('source_run', '')}",
        "",
    ]
    for key in keys:
        lines.extend([f"## {key}", "", str(data.get(key, "")), ""])
    lines.extend(["## Source Evidence Refs", "", *[f"- {item}" for item in data.get("source_evidence_refs", [])], ""])
    lines.extend(["## Usable Principles", "", *[f"- {item}" for item in data.get("usable_principles", [])], ""])
    lines.extend(["## Do Not Copy", "", *[f"- {item}" for item in data.get("do_not_copy", [])], ""])
    return "\n".join(lines).strip() + "\n"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", type=Path)
    parser.add_argument("--run-id")
    args = parser.parse_args()

    run_dir = resolve_run_dir(args)
    append_log(run_dir, "build_competitive_pattern_map", "start")
    context_report = write_context_read_log(
        run_dir,
        "build_competitive_pattern_map",
        input_artifacts=["stages/03c_shot_structure_map.json", "stages/03d_temporal_window_analysis.json"],
        output_artifacts=["stages/03e_competitive_pattern_map.json", "stages/03e_competitive_pattern_map.md"],
    )
    shot_structure = load_json(stage_path(run_dir, "03c_shot_structure_map.json"))
    temporal = load_json(stage_path(run_dir, "03d_temporal_window_analysis.json"))
    shots = shot_structure.get("shots", [])
    refs = [shot.get("source_shot_ref", "") for shot in shots if shot.get("source_shot_ref")]
    selected_by_pattern = {
        key: select_by_range(shots, *pattern["shot_range"])
        for key, pattern in CANONICAL_PATTERNS.items()
    }
    temporal_principles = []
    for window in temporal.get("windows", []):
        temporal_principles.extend(window.get("structure_to_keep", [])[:1])
    data = {
        "title": "Competitive Pattern Map",
        "source_run": run_dir.name,
        "context_refs": [item["relative_path"] for item in context_report.get("files", []) if item.get("exists")],
        "opening_hook_pattern": summarize("opening_hook_pattern", selected_by_pattern["opening_hook_pattern"]),
        "product_understanding_pattern": summarize("product_understanding_pattern", selected_by_pattern["product_understanding_pattern"]),
        "proof_or_trust_pattern": summarize("proof_or_trust_pattern", selected_by_pattern["proof_or_trust_pattern"]),
        "usage_scene_pattern": summarize("usage_scene_pattern", selected_by_pattern["usage_scene_pattern"]),
        "finish_or_memory_pattern": summarize("finish_or_memory_pattern", selected_by_pattern["finish_or_memory_pattern"]),
        "cta_pattern": summarize("cta_pattern", selected_by_pattern["cta_pattern"]),
        "pacing_pattern": "micro shotと標準尺ショットを混ぜ、冒頭の情報密度、商品理解、使用場面、CTAへ緩急を作る。",
        "source_evidence_refs": refs,
        "pattern_source_refs": {
            key: [shot.get("source_shot_ref", "") for shot in value if shot.get("source_shot_ref")]
            for key, value in selected_by_pattern.items()
        },
        "usable_principles": list(dict.fromkeys(USABLE_PRINCIPLES + temporal_principles))[:18],
        "do_not_copy": DO_NOT_COPY,
    }
    write_json(stage_path(run_dir, "03e_competitive_pattern_map.json"), data)
    write_yaml_like(stage_path(run_dir, "03e_competitive_pattern_map.yaml"), data)
    write_text(stage_path(run_dir, "03e_competitive_pattern_map.md"), markdown(data))
    write_json(run_dir / "logs" / "build_competitive_pattern_map.json", {"mode": "deterministic_from_shot_structure", "principle_count": len(data.get("usable_principles", []))})
    append_log(run_dir, "build_competitive_pattern_map", "success", principle_count=len(data.get("usable_principles", [])))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
