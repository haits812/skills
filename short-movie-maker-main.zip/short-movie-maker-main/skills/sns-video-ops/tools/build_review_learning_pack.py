#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

from lib.harness_common import append_log, ensure_dir, load_json, read_text, resolve_run_dir, stage_path, utc_now, write_json, write_text


TEMPLATE_MARKER = "<!-- human-review-template-v1 -->"


def non_empty_lines(section: str) -> list[str]:
    lines = []
    for line in section.splitlines():
        stripped = line.strip()
        if stripped.startswith("- "):
            value = stripped[2:].strip()
            if value and not value.startswith("未記入") and not value.startswith("例:"):
                lines.append(value)
    return lines


def section(text: str, heading: str) -> str:
    marker = f"## {heading}"
    if marker not in text:
        return ""
    body = text.split(marker, 1)[1]
    next_pos = body.find("\n## ")
    return body if next_pos < 0 else body[:next_pos]


def bullet_lines(items: list[str], fallback: str) -> list[str]:
    lines = [f"- {item}" for item in items if item]
    return lines if lines else [fallback]


def template(run_dir: Path, review: dict, shot_script: dict) -> str:
    return f"""# Human Review

{TEMPLATE_MARKER}

- run_id: {run_dir.name}
- created_at: {utc_now()}
- preimage_review: {review.get("decision")} / {review.get("score")}
- planned_shots: {len(shot_script.get("planned_shots", []))}

## 良かった点

- 未記入

## 修正したい点

- 未記入

## 次回から必ず守りたい学び

- 未記入

## Vaultに追加したい候補

- 未記入

## Vaultには入れない一時メモ

- 未記入

## 確認した成果物

- storyboard/14_operator_board.html
- storyboard/13_analysis_review_board.html
- stages/05b_shot_script.md
- stages/06_image_prompts.yaml
- stages/06b_preimage_review.md
"""


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", type=Path)
    parser.add_argument("--run-id")
    parser.add_argument("--force-template", action="store_true")
    args = parser.parse_args()

    run_dir = resolve_run_dir(args)
    append_log(run_dir, "build_review_learning_pack", "start")
    review_dir = ensure_dir(run_dir / "review")
    human_review_path = review_dir / "human_review.md"
    learning_path = review_dir / "learning_candidates.md"
    decision_path = review_dir / "learning_update_decision.md"

    preimage_review = load_json(stage_path(run_dir, "06b_preimage_review.json"))
    shot_script = load_json(stage_path(run_dir, "05b_shot_script.json"))
    pattern_map = load_json(stage_path(run_dir, "03e_competitive_pattern_map.json"))
    continuity = load_json(stage_path(run_dir, "04c_continuity_contract.json"))

    if args.force_template or not human_review_path.exists():
        write_text(human_review_path, template(run_dir, preimage_review, shot_script))

    human_text = read_text(human_review_path)
    good = non_empty_lines(section(human_text, "良かった点"))
    fixes = non_empty_lines(section(human_text, "修正したい点"))
    learnings = non_empty_lines(section(human_text, "次回から必ず守りたい学び"))
    vault_candidates = non_empty_lines(section(human_text, "Vaultに追加したい候補"))

    auto_candidates = [
        "競合動画からは表現ではなく、視聴者理解の順番、カット尺、画角、編集テンポを抽出する。",
        "自社UGC動画では、競合固有のブランド名、容器、SNS UI、レビュー数、成分訴求を制作指示に持ち込まない。",
        "画像生成前に、人物、場所、商品、光、撮影トーンをcontinuity contractで固定する。",
        "字コンテを正本とし、画像生成は字コンテを確認する補助工程として扱う。",
    ]
    if preimage_review.get("decision") == "accept":
        auto_candidates.append("preimage reviewがacceptになるまで画像生成へ進まない。")
    if continuity.get("forbidden_visual_drift"):
        auto_candidates.append("外国人モデル化、海外スタジオ化、商品カテゴリの変化を画像生成前に禁止条件として明示する。")

    all_candidates = []
    all_candidates.extend(learnings)
    all_candidates.extend(vault_candidates)
    all_candidates.extend(auto_candidates)
    all_candidates = list(dict.fromkeys(item for item in all_candidates if item))

    learning_md = [
        "# Learning Candidates",
        "",
        f"- run_id: {run_dir.name}",
        f"- generated_at: {utc_now()}",
        f"- source: review/human_review.md + preimage artifacts",
        "",
        "## 人間レビューからの候補",
        "",
        *bullet_lines(learnings + vault_candidates, "- 人間レビューはまだ未記入"),
        "",
        "## 自動抽出された候補",
        "",
        *[f"- {item}" for item in auto_candidates],
        "",
        "## 修正したい点",
        "",
        *bullet_lines(fixes, "- 未記入"),
        "",
        "## 良かった点",
        "",
        *bullet_lines(good, "- 未記入"),
        "",
        "## 反映判断",
        "",
        "- `vaults/sample-cosme/learnings.md` へ反映する前に人間が確認する。",
        "- 一時メモ、営業説明、個人情報、未公開顧客情報はVaultへ入れない。",
        "- 商品固有ルールを追加する場合は `brand_context.md`、表現禁止は `claim_guardrails.md`、制作の型は `ugc_style_grammar.md` または `shot_grammar.md` に分ける。",
        "",
    ]
    write_text(learning_path, "\n".join(learning_md))

    decision_md = [
        "# Learning Update Decision",
        "",
        f"- run_id: {run_dir.name}",
        "- status: pending-human-approval",
        "",
        "## Candidates To Consider",
        "",
        *[f"- [ ] {item}" for item in all_candidates],
        "",
        "## Do Not Auto Apply",
        "",
        "- [ ] 実在しないレビュー、SNS数値、顧客発言はVaultに追加しない。",
        "- [ ] 一時的な説明都合や運用メモをブランドルールとして保存しない。",
        "- [ ] 画像生成の一時的な失敗を恒久ルールにしない。",
        "",
    ]
    write_text(decision_path, "\n".join(decision_md))

    write_json(review_dir / "learning_pack_manifest.json", {
        "run_id": run_dir.name,
        "human_review": str(human_review_path),
        "learning_candidates": str(learning_path),
        "learning_update_decision": str(decision_path),
        "human_review_filled": bool(good or fixes or learnings or vault_candidates),
        "candidate_count": len(all_candidates),
        "pattern_principle_count": len(pattern_map.get("usable_principles", [])),
    })
    append_log(run_dir, "build_review_learning_pack", "success", candidate_count=len(all_candidates))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
