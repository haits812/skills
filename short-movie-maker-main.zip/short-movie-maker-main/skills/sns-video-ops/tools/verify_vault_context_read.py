#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

from lib.harness_common import append_log, context_read_report, ensure_run_dir, resolve_run_dir, utc_now, write_context_read_log, write_json, write_text


DEFAULT_STAGES = [
    "analyze_shots",
    "build_ugc_plan",
    "build_shot_script",
    "review_preimage_outputs",
]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", type=Path)
    parser.add_argument("--run-id")
    parser.add_argument("--vault", default="sample-cosme")
    parser.add_argument("--stage", action="append", dest="stages")
    args = parser.parse_args()

    if not args.run_dir and not args.run_id:
        args.run_id = f"vault-context-read-verification-{utc_now().replace(':', '').replace('-', '').replace('Z', '').replace('T', '-')}"
    run_dir = resolve_run_dir(args)
    stages = args.stages or DEFAULT_STAGES

    append_log(run_dir, "verify_vault_context_read", "start", stages=stages, vault=args.vault)
    reports = []
    for stage in stages:
        report = write_context_read_log(
            run_dir,
            stage,
            args.vault,
            input_artifacts=["vaults/sample-cosme/context_manifest.json"],
            output_artifacts=[f"stages/context_reads/{stage}.json"],
        )
        reports.append(report)

    missing = sorted({item for report in reports for item in report.get("missing_required", [])})
    files_by_stage = {
        report["stage"]: [
            {
                "relative_path": file_info["relative_path"],
                "exists": file_info["exists"],
                "bytes": file_info["bytes"],
                "sha256": file_info["sha256"],
            }
            for file_info in report.get("files", [])
        ]
        for report in reports
    }
    result = {
        "run_id": run_dir.name,
        "vault": args.vault,
        "verified_at": utc_now(),
        "stage_count": len(stages),
        "stages": stages,
        "missing_required": missing,
        "files_by_stage": files_by_stage,
    }
    write_json(run_dir / "stages" / "00_vault_context_verification.json", result)

    lines = [
        "# Vault Context Read Verification",
        "",
        f"- run_id: {run_dir.name}",
        f"- vault: {args.vault}",
        f"- stage_count: {len(stages)}",
        f"- missing_required: {', '.join(missing) if missing else 'none'}",
        "",
    ]
    for stage, files in files_by_stage.items():
        lines.append(f"## {stage}")
        lines.append("")
        for file_info in files:
            sha = file_info.get("sha256") or ""
            lines.append(
                f"- {file_info['relative_path']} | exists={file_info['exists']} | "
                f"bytes={file_info['bytes']} | sha256={sha[:16]}"
            )
        lines.append("")
    write_text(run_dir / "stages" / "00_vault_context_verification.md", "\n".join(lines))
    append_log(run_dir, "verify_vault_context_read", "success", stages=len(stages), missing_required=len(missing))
    print(run_dir)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
