#!/usr/bin/env python3
from __future__ import annotations

import argparse
import re
from pathlib import Path

from lib.harness_common import append_log, load_json, read_text, resolve_run_dir, stage_path, write_context_read_log, write_json, write_text, write_yaml_like


def extract_value(text: str, label: str, fallback: str = "") -> str:
    pattern = rf"-\s*{re.escape(label)}:\s*(.+)"
    match = re.search(pattern, text)
    return match.group(1).strip() if match else fallback


def extract_section_bullets(text: str, heading: str) -> list[str]:
    marker = f"## {heading}"
    if marker not in text:
        return []
    section = text.split(marker, 1)[1]
    next_heading = re.search(r"\n##\s+", section)
    if next_heading:
        section = section[: next_heading.start()]
    return [line[2:].strip() for line in section.splitlines() if line.strip().startswith("- ")]


def build_plan(run_dir: Path, context_refs: list[str]) -> dict:
    brand_context = read_text(Path("vaults/sample-cosme/brand_context.md"))
    pattern_map = load_json(stage_path(run_dir, "03e_competitive_pattern_map.json"))
    temporal = load_json(stage_path(run_dir, "03d_temporal_window_analysis.json"))
    brief = read_text(stage_path(run_dir, "04_production_brief.md"))
    product = extract_value(brand_context, "商品名", "自社コスメ商品")
    brand = extract_value(brand_context, "会社名", "自社ブランド")
    category = extract_value(brand_context, "カテゴリ", "コスメ")
    price = extract_value(brand_context, "価格", "")
    volume = extract_value(brand_context, "内容量", "")
    usage = extract_value(brand_context, "使用シーン", "")
    value = extract_value(brand_context, "提供価値", "")
    target_bullets = extract_section_bullets(brand_context, "Target")
    value_props = extract_section_bullets(brand_context, "Value Propositions")
    ctas = extract_section_bullets(brand_context, "CTA Candidates")
    target = " / ".join(target_bullets[:3])
    core_message_match = re.search(r"## Core Message\s+(.+?)(?:\n##|\Z)", brand_context, re.S)
    core_message = core_message_match.group(1).strip() if core_message_match else f"{usage}に使える{category}"
    source_learning = list(dict.fromkeys(pattern_map.get("usable_principles", [])))[:8]
    source_avoid = list(dict.fromkeys(pattern_map.get("do_not_copy", [])))[:8]
    story_arc = [
        {"arc": "hook", "role": pattern_map.get("opening_hook_pattern", "冒頭で何の商品/悩みかを理解させる")},
        {"arc": "product", "role": pattern_map.get("product_understanding_pattern", "商品理解を作る")},
        {"arc": "routine", "role": pattern_map.get("usage_scene_pattern", "使う場面を見せる")},
        {"arc": "proof", "role": pattern_map.get("proof_or_trust_pattern", "信頼感を補助する")},
        {"arc": "finish", "role": pattern_map.get("finish_or_memory_pattern", "仕上がり印象と商品記憶を戻す")},
        {"arc": "cta", "role": pattern_map.get("cta_pattern", "次行動へつなげる")},
    ]
    return {
        "title": f"{brand} {product} UGC動画企画",
        "purpose": "競合リールの構造を、自社ブランドのUGC風SNS動画企画へ変換する。画像生成ではなく、誰に何をどの順番で自然に理解させるかを決める正本。",
        "context_refs": context_refs,
        "input_artifacts": {
            "temporal_window_analysis": "stages/03d_temporal_window_analysis.json",
            "competitive_pattern_map": "stages/03e_competitive_pattern_map.json",
            "production_brief": "stages/04_production_brief.md",
        },
        "competitive_learning": {
            "source_evidence_refs": pattern_map.get("source_evidence_refs", []),
            "source_learning_to_keep": source_learning,
            "source_expression_to_avoid": source_avoid,
            "overall_flow": temporal.get("overall_flow", []),
        },
        "own_ad_strategy": {
            "brand": brand,
            "product": product,
            "category": category,
            "price": price,
            "volume": volume,
            "scenario": f"{brand}が、{product}をInstagram/TikTokでUGC風に訴求する。",
            "target_viewer": target,
            "job_to_be_done": f"{usage}に、{value}。",
            "core_offer": " / ".join(value_props[:3]),
            "single_message": core_message,
            "reason_to_believe": value_props[:5],
            "source_learning_to_keep": source_learning,
            "source_expression_to_avoid": source_avoid,
            "own_brand_angle": f"競合の構造だけを使い、{product}の使用シーン、質感、生活導線に置き換える。",
            "proof_strategy": "捏造レビューやSNS UIではなく、使うタイミング、生活導線、商品質感、使用メモで納得感を作る。",
            "cta_strategy": ctas[:3],
            "claim_boundary": [
                "効果効能の断定、治療/改善表現、極端なビフォーアフターを避ける",
                "ツヤ感や整った印象は視覚印象として扱い、効能保証にしない",
                "レビュー風表現は、実レビューがない限り使用シーン説明に置き換える",
            ],
            "creative_non_goals": [
                "テレビCM風に作り込まない",
                "海外ラグジュアリー広告に寄せない",
                "競合の容器、ラベル、SNS UIをコピーしない",
            ],
        },
        "creative_concept": {
            "concept_name": core_message,
            "tone": "日本の生活者向け、清潔、実用的、UGC感。企業広告ではなく日常の投稿に見える。",
            "visual_anchor": f"{product}を、{usage}の生活導線に自然に置く。",
            "story_arc": story_arc,
        },
        "message_ladder": [
            {"level": 1, "viewer_question": "これは何の話?", "answer": f"{usage}に使う{category}"},
            {"level": 2, "viewer_question": "自分に関係ある?", "answer": target},
            {"level": 3, "viewer_question": "どう使う?", "answer": usage},
            {"level": 4, "viewer_question": "なぜ良さそう?", "answer": " / ".join(value_props[:3])},
            {"level": 5, "viewer_question": "次に何をする?", "answer": " / ".join(ctas[:2])},
        ],
        "production_requirements": {
            "runtime_sec": 25,
            "format": "vertical 9:16 Instagram Reel",
            "required_layers": [
                "競合ファクト分析",
                "自社UGC動画企画",
                "continuity contract",
                "台本",
                "字コンテ",
                "画像生成プロンプト",
                "レビュー/学習",
            ],
            "asset_requirements": [
                "実商品画像または固定商品参照",
                "同一人物または固定人物参照",
                "スマホ縦動画らしい生活導線背景",
                "後載せテロップ",
                "CTA文言",
            ],
        },
        "review_criteria": [
            "競合動画の構造を活かしているが、表現をコピーしていない",
            "UGC風SNS動画企画として、誰に何を自然に見せるかが一文で説明できる",
            "台本と字コンテがmessage_ladderに沿っている",
            "画像生成は字コンテを可視化する補助であり、企画の代替になっていない",
            "人物・場所・商品が一貫するコンテキストが後続工程へ渡っている",
        ],
        "brief_excerpt": brief[:1200],
    }


def markdown(data: dict) -> str:
    own = data.get("own_ad_strategy", {})
    creative = data.get("creative_concept", {})
    lines = [
        f"# {data.get('title', 'UGC Video Plan')}",
        "",
        f"目的: {data.get('purpose', '')}",
        "",
        "## Single Message",
        "",
        str(own.get("single_message", "")),
        "",
        "## Own UGC Strategy",
        "",
        f"- brand: {own.get('brand', '')}",
        f"- product: {own.get('product', '')}",
        f"- target_viewer: {own.get('target_viewer', '')}",
        f"- job_to_be_done: {own.get('job_to_be_done', '')}",
        f"- own_brand_angle: {own.get('own_brand_angle', '')}",
        "",
        "## Source Learning To Keep",
        "",
        *[f"- {item}" for item in own.get("source_learning_to_keep", [])],
        "",
        "## Source Expression To Avoid",
        "",
        *[f"- {item}" for item in own.get("source_expression_to_avoid", [])],
        "",
        "## Creative Concept",
        "",
        f"- concept_name: {creative.get('concept_name', '')}",
        f"- tone: {creative.get('tone', '')}",
        f"- visual_anchor: {creative.get('visual_anchor', '')}",
        "",
        "## Message Ladder",
        "",
    ]
    for item in data.get("message_ladder", []):
        lines.append(f"- L{item.get('level')}: {item.get('viewer_question', '')} -> {item.get('answer', '')}")
    return "\n".join(lines).strip() + "\n"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", type=Path)
    parser.add_argument("--run-id")
    args = parser.parse_args()

    run_dir = resolve_run_dir(args)
    append_log(run_dir, "build_ad_video_plan", "start")
    context_report = write_context_read_log(
        run_dir,
        "build_ugc_plan",
        input_artifacts=[
            "stages/03d_temporal_window_analysis.json",
            "stages/03e_competitive_pattern_map.json",
            "stages/04_production_brief.md",
        ],
        output_artifacts=["stages/04b_ad_video_plan.json", "stages/04b_ad_video_plan.md"],
    )
    context_refs = [item["relative_path"] for item in context_report.get("files", []) if item.get("exists")]
    data = build_plan(run_dir, context_refs)
    write_json(stage_path(run_dir, "04b_ad_video_plan.json"), data)
    write_yaml_like(stage_path(run_dir, "04b_ad_video_plan.yaml"), data)
    write_text(stage_path(run_dir, "04b_ad_video_plan.md"), markdown(data))
    write_json(run_dir / "logs" / "build_ad_video_plan.json", {
        "mode": "deterministic_from_vault_and_pattern_map",
        "single_message": data.get("own_ad_strategy", {}).get("single_message"),
    })
    append_log(run_dir, "build_ad_video_plan", "success", mode="deterministic")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
