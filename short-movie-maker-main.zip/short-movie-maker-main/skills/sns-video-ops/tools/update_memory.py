#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

from lib.harness_common import append_log, load_json, read_text, resolve_run_dir, stage_path, utc_now, vault_dir, write_context_read_log, write_json, write_text


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", type=Path)
    parser.add_argument("--run-id")
    parser.add_argument("--vault", default="sample-cosme")
    parser.add_argument("--max-budget-usd", type=float, default=1.5)
    args = parser.parse_args()

    run_dir = resolve_run_dir(args)
    append_log(run_dir, "update_memory", "start", vault=args.vault)
    write_context_read_log(
        run_dir,
        "update_memory",
        args.vault,
        input_artifacts=["stages/09_review.json"],
        output_artifacts=["stages/10_memory_update.json", "stages/10_memory_update.md", "vaults/sample-cosme/learnings.md"],
    )
    review = load_json(stage_path(run_dir, "09_review.json"))
    learnings_path = vault_dir(args.vault) / "learnings.md"
    parsed = {
        "summary": "Run results updated business memory for the competitor-UGC-to-shot-script workflow.",
        "append_to_learnings": review.get("memory_updates", []),
        "suggested_rule_changes": [
            "Prefer per-frame visual analysis over large contact sheets when Claude Code image analysis becomes slow or unstable.",
            "Keep full analysis artifacts, but pass compacted summaries to downstream brief/storyboard generation.",
            "For final UGC creative production, use fixed product reference assets to avoid bottle-form drift in generated storyboard images.",
        ],
        "do_not_apply_without_human": [
            "Do not turn generated storyboard images into final UGC creatives without legal/brand review.",
            "Do not add fake review UI or unsourced testimonial claims to the business vault.",
        ],
    }
    write_json(stage_path(run_dir, "10_memory_update.json"), parsed)
    lines = [
        "# Memory Update",
        "",
        f"summary: {parsed.get('summary', '')}",
        "",
        "## Append To Learnings",
        *[f"- {x}" for x in parsed.get("append_to_learnings", [])],
        "",
        "## Suggested Rule Changes",
        *[f"- {x}" for x in parsed.get("suggested_rule_changes", [])],
        "",
        "## Do Not Apply Without Human",
        *[f"- {x}" for x in parsed.get("do_not_apply_without_human", [])],
        "",
    ]
    write_text(stage_path(run_dir, "10_memory_update.md"), "\n".join(lines))
    existing = read_text(learnings_path).rstrip()
    marker = f"## Run {run_dir.name} "
    appended = 0
    if marker not in existing:
        append_lines = [existing, "", f"## Run {run_dir.name} ({utc_now()})"]
        append_lines.extend(f"- {x}" for x in parsed.get("append_to_learnings", []))
        append_lines.append("")
        write_text(learnings_path, "\n".join(append_lines))
        appended = len(parsed.get("append_to_learnings", []))
    write_json(run_dir / "logs" / "update_memory.json", {"mode": "deterministic", "appended": appended, "skipped_duplicate": appended == 0})
    append_log(run_dir, "update_memory", "success", appended=appended, skipped_duplicate=appended == 0, mode="deterministic")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
