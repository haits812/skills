#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

from lib.harness_common import append_log, load_json, read_text, resolve_run_dir, stage_path, write_context_read_log, write_json, write_text, write_yaml_like


ROLE_DIRECTIONS = {
    "hook": [
        {
            "adopted_cut_pattern": "冒頭のフラッシュ的な商品提示",
            "camera_pattern": "vertical smartphone handheld, chest-up or vanity quick reveal",
            "framing": "日本の洗面台またはメイク前の場所で、LUMIAミスト1本を顔横か手元に短く見せる",
            "subject": "LUMIA Dew Mist Serum 1本と、同じ日本人女性の顔の一部または手元",
            "action": "朝の支度中に商品をさっと持ち上げ、何の商品かを一瞬で理解させる",
            "motion_or_edit": "0.5秒前後の短い導入カット。後載せテロップで悩みと使用タイミングだけを載せる。",
        },
        {
            "adopted_cut_pattern": "人物の気配を入れるテンポカット",
            "camera_pattern": "handheld partial face or hand movement",
            "framing": "顔全体を作り込まず、手元、頬まわり、メイク道具の近くに寄る",
            "subject": "同じ日本人女性の手元または頬まわりと、近くに置いたLUMIAミスト",
            "action": "メイク前に鏡を見る、商品へ手を伸ばす、軽く準備する所作を見せる",
            "motion_or_edit": "人の気配を作る短い差し込み。商品説明ではなく視聴維持のリズムを作る。",
        },
    ],
    "product": [
        {
            "adopted_cut_pattern": "商品理解のための手持ち正面提示",
            "camera_pattern": "handheld product close-up",
            "framing": "LUMIAミスト1本を片手で持ち、ラベル印象とスプレー口が分かる距離に寄る",
            "subject": "LUMIA Dew Mist Serum 1本",
            "action": "ボトルを軽く回す、スプレー口を見せる、洗面台の上に戻す",
            "motion_or_edit": "商品カテゴリと使い方を短く理解させるB-roll。比較構図にはしない。",
        },
        {
            "adopted_cut_pattern": "生活導線の中の商品B-roll",
            "camera_pattern": "vanity tabletop close-up with hand action",
            "framing": "洗面台のメイク道具横に置いたLUMIAミストを斜め上から撮る",
            "subject": "洗面台に置かれたLUMIAミストと自然なメイク道具",
            "action": "手が商品を取る、キャップやスプレー部分へ自然に触れる",
            "motion_or_edit": "日常の中に入る商品だと見せる。説明過多にせず短いテロップで補足する。",
        },
    ],
    "routine": [
        {
            "adopted_cut_pattern": "使用直前の準備カット",
            "camera_pattern": "mirror-side smartphone angle",
            "framing": "鏡の前で顔から少し離してLUMIAミストを構える",
            "subject": "同じ日本人女性とLUMIAミスト",
            "action": "メイク前に顔まわりへ使う準備をする。噴霧そのものは自然で控えめに見せる",
            "motion_or_edit": "実際の使い方が分かる中心カット。美容効果の断定には寄せない。",
        },
        {
            "adopted_cut_pattern": "手元の質感/動作インサート",
            "camera_pattern": "close-up hand insert",
            "framing": "手元、スプレー口、軽いミスト感が分かる近距離",
            "subject": "LUMIAミストのスプレー口と手元",
            "action": "ワンプッシュする直前またはミストが軽く出る様子を見せる",
            "motion_or_edit": "商品の質感を伝える短いB-roll。水滴や過剰な演出は控える。",
        },
        {
            "adopted_cut_pattern": "日常のルーティン接続",
            "camera_pattern": "handheld everyday routine shot",
            "framing": "メイク道具、タオル、洗面台が同じ場所に見える中距離",
            "subject": "LUMIAミストと朝のメイク前の小物",
            "action": "商品を置き、次のメイク動作へ自然につなげる",
            "motion_or_edit": "商品単体ではなく、支度の流れに入ることを見せる。",
        },
    ],
    "trust": [
        {
            "adopted_cut_pattern": "証拠を前倒しするが、捏造UIは使わない",
            "camera_pattern": "overhead note and product shot",
            "framing": "LUMIAミストの横に短い手書きメモや使用タイミングのメモを置く",
            "subject": "LUMIAミストと短い使用メモ",
            "action": "『メイク前』『外出前』のような使用タイミングを後載せテロップで補足する",
            "motion_or_edit": "信頼感を作る補助カット。レビュー数やSNS画面は使わない。",
        },
        {
            "adopted_cut_pattern": "生活者の本音感を出す顔/手元カット",
            "camera_pattern": "partial face handheld close shot",
            "framing": "顔の一部、鏡、商品が自然に入る距離",
            "subject": "同じ日本人女性の自然な表情とLUMIAミスト",
            "action": "使うタイミングについて短く話しているような間を作る",
            "motion_or_edit": "宣伝感を薄め、生活者視点の納得感を作る。",
        },
    ],
    "finish": [
        {
            "adopted_cut_pattern": "使った後の自然な印象カット",
            "camera_pattern": "soft handheld mirror angle",
            "framing": "同じ洗面台で、メイク前後の自然な支度感が分かる中距離",
            "subject": "同じ日本人女性とLUMIAミスト",
            "action": "鏡を見て支度を続ける。過剰なビフォーアフターではなく自然な印象に留める",
            "motion_or_edit": "効果断定ではなく、生活導線の終盤として見せる。",
        },
        {
            "adopted_cut_pattern": "商品記憶を戻す置きカット",
            "camera_pattern": "product on vanity memory shot",
            "framing": "洗面台に置いたLUMIAミストを商品名が連想できる距離で見せる",
            "subject": "LUMIA Dew Mist Serum 1本",
            "action": "商品を洗面台に置き、メイク道具と一緒に自然に残す",
            "motion_or_edit": "終盤で商品を再提示し、保存/詳細確認へつなぐ。",
        },
        {
            "adopted_cut_pattern": "余韻を作る生活導線カット",
            "camera_pattern": "casual handheld exit shot",
            "framing": "商品、鏡、メイク道具が同じ場所に収まる",
            "subject": "LUMIAミストと朝の支度の余韻",
            "action": "商品を画面内に残しながら次の行動へ移る雰囲気を作る",
            "motion_or_edit": "視聴者が自分の朝に置き換えやすい余韻を作る。",
        },
    ],
    "cta": [
        {
            "adopted_cut_pattern": "最後の商品再提示",
            "camera_pattern": "clean product memory shot",
            "framing": "LUMIAミスト1本と洗面台背景に、後載せテロップ用の余白を作る",
            "subject": "LUMIA Dew Mist Serum 1本",
            "action": "商品を中央または少し右に置き、保存CTAを後載せできる余白を残す",
            "motion_or_edit": "押し売りではなく保存/プロフィール確認へ自然につなぐ。",
        },
        {
            "adopted_cut_pattern": "軽い締めの生活者カット",
            "camera_pattern": "handheld partial person and product",
            "framing": "人物の手元と商品が同じ生活導線に入る",
            "subject": "同じ日本人女性の手元とLUMIAミスト",
            "action": "商品を手に取る、棚に戻す、保存を促す余白を残す",
            "motion_or_edit": "CTAは編集レイヤーで短く。画像内に長文は入れない。",
        },
    ],
}


def by_ref(shot_structure: dict) -> dict[str, dict]:
    return {
        item.get("source_shot_ref", ""): item
        for item in shot_structure.get("shots", [])
        if item.get("source_shot_ref")
    }


def chunk_refs(refs: list[str], count: int) -> list[list[str]]:
    if count <= 0:
        return []
    if not refs:
        return [[] for _ in range(count)]
    chunks = [[] for _ in range(count)]
    for index, ref in enumerate(refs):
        chunks[min(count - 1, int(index * count / max(1, len(refs))))].append(ref)
    return chunks


def shot_count_for_scene(scene: dict) -> int:
    duration = float(scene.get("duration_sec") or 4)
    if duration >= 5:
        return 3
    return 2


def source_learning(refs: list[str], structure_by_ref: dict[str, dict]) -> str:
    notes = []
    for ref in refs:
        item = structure_by_ref.get(ref, {})
        if item.get("reuse_principle"):
            notes.append(item["reuse_principle"])
        elif item.get("conversion_hint_for_own_brand"):
            notes.append(item["conversion_hint_for_own_brand"])
    return " / ".join(notes[:2])


def role_key(scene: dict) -> str:
    scene_id = str(scene.get("scene_id", "")).lower()
    role = str(scene.get("role", "")).lower()
    text = f"{scene_id} {role}"
    if "hook" in text or "冒頭" in text:
        return "hook"
    if "product" in text or "商品" in text:
        return "product"
    if "routine" in text or "usage" in text or "使用" in text:
        return "routine"
    if "trust" in text or "proof" in text or "信頼" in text:
        return "trust"
    if "finish" in text or "仕上" in text:
        return "finish"
    if "cta" in text:
        return "cta"
    return "product"


def own_direction(scene: dict, shot_index: int) -> dict:
    directions = ROLE_DIRECTIONS.get(role_key(scene), ROLE_DIRECTIONS["product"])
    return directions[min(shot_index - 1, len(directions) - 1)]


def product_label(continuity: dict) -> str:
    product = str(continuity.get("product") or "自社ミスト商品")
    if "同じ商品として見える " in product:
        product = product.split("同じ商品として見える ", 1)[1]
    if "。" in product:
        product = product.split("。", 1)[0]
    return product.strip() or "自社ミスト商品"


def materialize_direction(direction: dict, continuity: dict) -> dict:
    product = product_label(continuity)
    replacements = {
        "LUMIA Dew Mist Serum": product,
        "LUMIAミスト": product,
    }
    materialized = {}
    for key, value in direction.items():
        text = str(value)
        for before, after in replacements.items():
            text = text.replace(before, after)
        materialized[key] = text
    return materialized


def source_cut_recipe(source: dict) -> dict:
    return {
        "source_camera_pattern": source.get("camera_pattern", ""),
        "source_framing": source.get("framing", ""),
        "source_edit_function": source.get("edit_function", ""),
        "source_motion": source.get("motion", ""),
        "source_reuse_principle": source.get("reuse_principle", ""),
    }


def expression_to_avoid(source: dict) -> list[str]:
    avoid = list(source.get("do_not_copy", []) or [])
    avoid.extend([
        "競合商品の髪/ヘアケア/ジャー/成分訴求をLUMIAの制作指示へ持ち込まない",
        "競合の複数商品提示やSNS UIをそのまま使わない",
    ])
    return list(dict.fromkeys(item for item in avoid if item))[:8]


def first_structure(refs: list[str], structure_by_ref: dict[str, dict]) -> dict:
    for ref in refs:
        if ref in structure_by_ref:
            return structure_by_ref[ref]
    return {}


def make_shot(scene: dict, scene_index: int, shot_index: int, refs: list[str], structure_by_ref: dict[str, dict], script_scene: dict, continuity: dict) -> dict:
    source = first_structure(refs, structure_by_ref)
    shot_id = f"S{scene_index:02d}-{shot_index:02d}"
    role = scene.get("role", "")
    direction = materialize_direction(own_direction(scene, shot_index), continuity)
    camera_pattern = direction["camera_pattern"]
    framing = direction["framing"]
    subject = direction["subject"]
    action = direction["action"]
    background = continuity.get("location", "同じ生活導線の背景")
    source_learning_text = source_learning(refs, structure_by_ref) or scene.get("visual_direction", "")
    return {
        "shot_id": shot_id,
        "scene_id": scene.get("scene_id", ""),
        "duration_sec": round(float(scene.get("duration_sec") or 4) / max(1, shot_count_for_scene(scene)), 2),
        "role": role,
        "viewer_takeaway": scene.get("viewer_takeaway", ""),
        "source_learning": source_learning_text,
        "source_shot_refs": refs,
        "source_cut_recipe": source_cut_recipe(source),
        "adopted_cut_pattern": direction["adopted_cut_pattern"],
        "source_expression_to_avoid": expression_to_avoid(source),
        "camera_pattern": camera_pattern,
        "camera_angle": camera_pattern,
        "framing": framing,
        "subject": subject,
        "action": action,
        "background": background,
        "props": continuity.get("props", [])[:4],
        "motion_or_edit": direction["motion_or_edit"],
        "overlay_text": scene.get("on_screen_text", ""),
        "narration": script_scene.get("narration") or scene.get("narration", ""),
        "continuity_refs": ["04c_continuity_contract.person", "04c_continuity_contract.location", "04c_continuity_contract.product"],
        "continuity_context": {
            "person": continuity.get("person"),
            "location": continuity.get("location"),
            "product": continuity.get("product"),
            "capture_style": continuity.get("capture_style"),
        },
        "image_generation_bridge": f"{direction['adopted_cut_pattern']} / {subject} / {action} / {framing}",
        "edit_layer_notes": "テロップ、CTA、説明文は画像に焼き込まず編集レイヤーで後載せする。長文や効果断定は避ける。",
        "visual_content": f"{subject}。{action}。背景は{background}。",
        "asset_requirements": continuity.get("props", [])[:4],
        "claim_guardrails": [
            "薬機法・景表法上の効果断定を避ける",
            "競合商品の容器・ブランド・SNS UIをコピーしない",
            "日本語テキストは原則として動画編集レイヤーで後載せする",
        ],
        "review_checkpoints": [
            "source_learningが競合構造から来ているか",
            "人物・場所・商品がcontinuity contractからズレていないか",
            "撮影/生成/編集指示として実行可能か",
        ],
    }


def markdown(data: dict) -> str:
    lines = [
        f"# {data.get('title', 'Shot Script')}",
        "",
        f"目的: {data.get('purpose', '')}",
        "",
        "## Context Refs",
        "",
        *[f"- {item}" for item in data.get("context_refs", [])],
        "",
        "## Planned Shots",
        "",
    ]
    for shot in data.get("planned_shots", []):
        lines.extend([
            f"### {shot.get('shot_id')} / {shot.get('role')}",
            "",
            f"- scene_id: {shot.get('scene_id')}",
            f"- duration_sec: {shot.get('duration_sec')}",
            f"- viewer_takeaway: {shot.get('viewer_takeaway')}",
            f"- source_shot_refs: {', '.join(shot.get('source_shot_refs', []))}",
            f"- source_learning: {shot.get('source_learning')}",
            f"- source_cut_recipe: {shot.get('source_cut_recipe')}",
            f"- adopted_cut_pattern: {shot.get('adopted_cut_pattern')}",
            f"- source_expression_to_avoid: {' / '.join(shot.get('source_expression_to_avoid', []))}",
            f"- camera_pattern: {shot.get('camera_pattern')}",
            f"- framing: {shot.get('framing')}",
            f"- subject: {shot.get('subject')}",
            f"- action: {shot.get('action')}",
            f"- background: {shot.get('background')}",
            f"- props: {' / '.join(shot.get('props', []))}",
            f"- motion_or_edit: {shot.get('motion_or_edit')}",
            f"- overlay_text: {shot.get('overlay_text')}",
            f"- narration: {shot.get('narration')}",
            f"- continuity_refs: {' / '.join(shot.get('continuity_refs', []))}",
            f"- edit_layer_notes: {shot.get('edit_layer_notes')}",
            f"- image_generation_bridge: {shot.get('image_generation_bridge')}",
            "",
        ])
    lines.extend(["## Quality Bar", "", *[f"- {item}" for item in data.get("quality_bar", [])], ""])
    return "\n".join(lines).strip() + "\n"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", type=Path)
    parser.add_argument("--run-id")
    args = parser.parse_args()

    run_dir = resolve_run_dir(args)
    append_log(run_dir, "build_shot_script", "start")
    context_report = write_context_read_log(
        run_dir,
        "build_shot_script",
        input_artifacts=[
            "stages/03c_shot_structure_map.json",
            "stages/04b_ad_video_plan.json",
            "stages/04c_continuity_contract.json",
            "stages/05a_video_script.json",
            "stages/05_storyboard_plan.json",
        ],
        output_artifacts=["stages/05b_shot_script.json", "stages/05b_shot_script.md"],
    )
    shot_structure = load_json(stage_path(run_dir, "03c_shot_structure_map.json"))
    ugc_plan = load_json(stage_path(run_dir, "04b_ad_video_plan.json"))
    continuity = load_json(stage_path(run_dir, "04c_continuity_contract.json"))
    storyboard = load_json(stage_path(run_dir, "05_storyboard_plan.json"))
    video_script = load_json(stage_path(run_dir, "05a_video_script.json"))
    shot_manifest = load_json(stage_path(run_dir, "02b_shot_manifest.json"))
    brief = read_text(stage_path(run_dir, "04_production_brief.md"))
    structure_by_ref = by_ref(shot_structure)
    script_by_scene = {scene.get("scene_id"): scene for scene in video_script.get("scenes", [])}
    scenes = []
    planned_shots = []
    for scene_index, scene in enumerate(storyboard.get("scenes", []), start=1):
        count = shot_count_for_scene(scene)
        grouped_refs = chunk_refs(scene.get("source_shot_refs", []), count)
        scene_shots = [
            make_shot(scene, scene_index, shot_index + 1, grouped_refs[shot_index] if shot_index < len(grouped_refs) else [], structure_by_ref, script_by_scene.get(scene.get("scene_id"), {}), continuity)
            for shot_index in range(count)
        ]
        scenes.append({
            "scene_id": scene.get("scene_id", ""),
            "role": scene.get("role", ""),
            "source_refs": scene.get("source_refs", []),
            "source_shot_refs": scene.get("source_shot_refs", []),
            "assumption_ids": scene.get("assumption_ids", []),
            "planned_shot_ids": [shot["shot_id"] for shot in scene_shots],
            "scene_takeaway": scene.get("viewer_takeaway", ""),
        })
        planned_shots.extend(scene_shots)
    data = {
        "title": f"{ugc_plan.get('own_ad_strategy', {}).get('product', 'UGC動画')} 字コンテ",
        "purpose": "画像生成ではなく、競合ショット構造を自社UGC風SNS動画の制作指示へ変換するための中間成果物。",
        "context_refs": [item["relative_path"] for item in context_report.get("files", []) if item.get("exists")],
        "source_run": run_dir.name,
        "input_artifacts": {
            "shot_manifest": "stages/02b_shot_manifest.json",
            "shot_structure_map": "stages/03c_shot_structure_map.json",
            "ugc_video_plan": "stages/04b_ad_video_plan.json",
            "continuity_contract": "stages/04c_continuity_contract.json",
            "video_script": "stages/05a_video_script.json",
            "storyboard_plan": "stages/05_storyboard_plan.json",
        },
        "source_video_structure": {
            "duration_sec": shot_manifest.get("duration_sec"),
            "source_shot_count": shot_manifest.get("shot_count"),
            "micro_shot_count": shot_manifest.get("micro_shot_count"),
            "interpretation": "ショット境界と03cの構造分析を字コンテの主根拠にする。",
        },
        "continuity_context": {
            "person": continuity.get("person"),
            "location": continuity.get("location"),
            "product": continuity.get("product"),
            "capture_style": continuity.get("capture_style"),
        },
        "brief_excerpt": brief[:1200],
        "scenes": scenes,
        "planned_shots": planned_shots,
        "quality_bar": [
            "各planned_shotはsource_shot_refsとsource_learningを持つ",
            "被写体、動き、背景、テロップ、ナレーションが分離されている",
            "人物・場所・商品一貫性はcontinuity contractに集約されている",
            "画像生成はplanned_shotの可視化であり、完成物の主役は字コンテである",
            "テレビCM/スタジオ広告風ではなく、スマホで撮ったようなUGC風ショットである",
        ],
    }
    write_json(stage_path(run_dir, "05b_shot_script.json"), data)
    write_yaml_like(stage_path(run_dir, "05b_shot_script.yaml"), data)
    write_text(stage_path(run_dir, "05b_shot_script.md"), markdown(data))
    write_json(run_dir / "logs" / "build_shot_script.json", {"mode": "deterministic_from_shot_structure", "planned_shot_count": len(planned_shots)})
    append_log(run_dir, "build_shot_script", "success", planned_shot_count=len(planned_shots), mode="deterministic")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
