#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

from lib.harness_common import append_log, load_json, resolve_run_dir, stage_path, write_context_read_log, write_json, write_yaml_like


ROLE_DEFAULTS = {
    "hook": {
        "scene_id": "scene_01_hook",
        "role": "冒頭フック",
        "duration_sec": 3,
        "viewer_takeaway": "何の商品で、自分のどの悩みに関係するかをすぐ理解する。",
        "on_screen_text": "朝のメイク前に気になる日に",
    },
    "product": {
        "scene_id": "scene_02_product",
        "role": "商品理解",
        "duration_sec": 4,
        "viewer_takeaway": "商品の質感、使い方、生活導線での使いやすさを理解する。",
        "on_screen_text": "メイク前に使いやすい軽さ",
    },
    "routine": {
        "scene_id": "scene_03_routine",
        "role": "使用シーン",
        "duration_sec": 5,
        "viewer_takeaway": "自分の朝の流れにどう入るかを想像できる。",
        "on_screen_text": "いつもの支度にそのまま追加",
    },
    "proof": {
        "scene_id": "scene_04_trust",
        "role": "信頼感の補助",
        "duration_sec": 4,
        "viewer_takeaway": "押し売りではなく、使うタイミングや使用メモで納得する。",
        "on_screen_text": "使う場面を決めるだけ",
    },
    "finish": {
        "scene_id": "scene_05_finish",
        "role": "仕上がり印象",
        "duration_sec": 5,
        "viewer_takeaway": "効果断定ではなく、自然な仕上がり印象を想像する。",
        "on_screen_text": "自然な仕上がり印象へ",
    },
    "cta": {
        "scene_id": "scene_06_cta",
        "role": "CTA",
        "duration_sec": 4,
        "viewer_takeaway": "保存またはプロフィール確認という次の行動が明確になる。",
        "on_screen_text": "気になったら保存",
    },
}


def chunk_refs(refs: list[str], count: int) -> list[list[str]]:
    if count <= 0:
        return []
    if not refs:
        return [[] for _ in range(count)]
    chunks = [[] for _ in range(count)]
    for index, ref in enumerate(refs):
        chunks[min(count - 1, int(index * count / max(1, len(refs))))].append(ref)
    return chunks


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", type=Path)
    parser.add_argument("--run-id")
    args = parser.parse_args()

    run_dir = resolve_run_dir(args)
    append_log(run_dir, "build_storyboard_plan", "start")
    context_report = write_context_read_log(
        run_dir,
        "build_storyboard_plan",
        input_artifacts=[
            "stages/04b_ad_video_plan.json",
            "stages/04c_continuity_contract.json",
            "stages/03e_competitive_pattern_map.json",
        ],
        output_artifacts=["stages/05_storyboard_plan.json", "stages/05_storyboard_plan.yaml"],
    )
    ugc_plan = load_json(stage_path(run_dir, "04b_ad_video_plan.json"))
    continuity = load_json(stage_path(run_dir, "04c_continuity_contract.json"))
    pattern_map = load_json(stage_path(run_dir, "03e_competitive_pattern_map.json"))
    own = ugc_plan.get("own_ad_strategy", {})
    story_arc = ugc_plan.get("creative_concept", {}).get("story_arc", [])
    refs = pattern_map.get("source_evidence_refs", [])
    ref_chunks = chunk_refs(refs, len(story_arc) or 6)
    scenes = []
    for index, arc in enumerate(story_arc or [{"arc": key, "role": ""} for key in ROLE_DEFAULTS], start=1):
        arc_key = str(arc.get("arc", "")).lower()
        defaults = ROLE_DEFAULTS.get(arc_key, {
            "scene_id": f"scene_{index:02d}_{arc_key or 'section'}",
            "role": arc.get("arc", "section"),
            "duration_sec": 4,
            "viewer_takeaway": "視聴者理解を一段進める。",
            "on_screen_text": own.get("single_message", ""),
        })
        source_shot_refs = ref_chunks[index - 1] if index - 1 < len(ref_chunks) else []
        role_text = arc.get("role", "")
        scenes.append({
            "scene_id": defaults["scene_id"],
            "role": defaults["role"],
            "duration_sec": defaults["duration_sec"],
            "viewer_takeaway": defaults["viewer_takeaway"],
            "visual_direction": f"{role_text} / {continuity.get('capture_style', '')} / {continuity.get('product', '')}",
            "on_screen_text": defaults["on_screen_text"],
            "narration": defaults["viewer_takeaway"],
            "asset_needs": continuity.get("props", [])[:5],
            "production_notes": "競合の表現はコピーせず、構造だけを自社UGC文脈に変換する。テロップは後載せ。",
            "source_refs": [],
            "source_shot_refs": source_shot_refs,
            "assumption_ids": ["LUMIA_PRODUCT_001", "LUMIA_TARGET_001", "LUMIA_UGC_001"],
            "generated_from": [
                f"competitive_pattern:{arc_key}",
                "ugc_video_plan:message_ladder",
                "continuity_contract",
            ],
        })
    data = {
        "title": f"{own.get('product', 'UGC動画')} シーン設計",
        "concept": ugc_plan.get("creative_concept", {}).get("concept_name") or own.get("single_message", ""),
        "context_refs": [item["relative_path"] for item in context_report.get("files", []) if item.get("exists")],
        "ad_strategy": {
            "source": "stages/04b_ad_video_plan.json",
            "single_message": own.get("single_message"),
            "target_viewer": own.get("target_viewer"),
            "creative_concept": ugc_plan.get("creative_concept", {}).get("concept_name"),
        },
        "shot_structure": {
            "source": "stages/03e_competitive_pattern_map.json",
            "source_ref_count": len(refs),
            "note": "競合の表現ではなく、pattern mapの構造を根拠としてシーン化する。",
        },
        "scenes": scenes,
        "asset_plan": [
            "実商品画像または固定商品参照",
            "同一人物または固定人物参照",
            "生活導線背景",
            "後載せテロップ",
            "CTA導線",
        ],
        "review_notes": ugc_plan.get("review_criteria", []),
        "source_artifacts": {
            "ugc_video_plan": "stages/04b_ad_video_plan.json",
            "competitive_pattern_map": "stages/03e_competitive_pattern_map.json",
            "continuity_contract": "stages/04c_continuity_contract.json",
        },
    }
    write_json(stage_path(run_dir, "05_storyboard_plan.json"), data)
    write_yaml_like(stage_path(run_dir, "05_storyboard_plan.yaml"), data)
    write_json(run_dir / "logs" / "build_storyboard_plan.json", {"mode": "deterministic_from_ugc_plan", "scene_count": len(scenes)})
    append_log(run_dir, "build_storyboard_plan", "success", scene_count=len(scenes), mode="deterministic")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
