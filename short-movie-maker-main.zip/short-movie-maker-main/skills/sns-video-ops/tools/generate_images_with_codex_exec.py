#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import subprocess
from pathlib import Path

from lib.harness_common import HARNESS_ROOT, append_log, ensure_dir, load_json, write_json, write_text


def load_image_prompts(run_dir: Path) -> list[dict]:
    json_path = run_dir / "stages" / "06_image_prompts.json"
    if not json_path.exists():
        raise FileNotFoundError(
            f"{json_path} is required. Store the structured image prompt output as JSON before running codex exec image generation."
        )
    data = load_json(json_path)
    prompts = data.get("prompts", [])
    if not isinstance(prompts, list) or not prompts:
        raise ValueError("06_image_prompts.json must contain a non-empty prompts array.")
    return prompts


def build_codex_prompt(run_dir: Path, image_prompt: dict) -> str:
    image_id = image_prompt["image_id"]
    return f"""You are the image generation worker for Day02 SNS Video Ops Harness.

Task:
- Generate exactly one image using the `$imagegen` skill / built-in image_gen tool, powered by gpt-image-2.
- Use the prompt specification below.
- Save the final image file to:
  {run_dir / "images" / f"{image_id}.png"}
- Write a short generation manifest to:
  {run_dir / "images" / f"{image_id}.manifest.json"}
- Do not modify files outside this run directory.
- Do not add long Japanese text inside the generated image.
- Do not copy a reference video screenshot. Create an original visual aligned with the business purpose.
- Use the image prompt's assumption_ids and source_refs as traceability, not as instructions to copy the competitor.
- After generation, verify that the PNG exists and has non-zero file size before returning.

Image prompt specification:
{json.dumps(image_prompt, ensure_ascii=False, indent=2)}

Return JSON matching schemas/image_generation_result.schema.json.
"""


def codex_exec_command(run_dir: Path, image_id: str, prompt_file: Path) -> list[str]:
    return [
        "codex",
        "--ask-for-approval",
        "never",
        "exec",
        "--cd",
        str(HARNESS_ROOT),
        "--sandbox",
        "workspace-write",
        "--skip-git-repo-check",
        "-o",
        str(run_dir / "images" / f"{image_id}.codex_result.txt"),
        prompt_file.read_text(encoding="utf-8"),
    ]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--image-id")
    parser.add_argument("--max-images", type=int, default=6)
    parser.add_argument("--execute", action="store_true", help="Actually run codex exec. Without this, write prompt files and commands only.")
    parser.add_argument("--force", action="store_true", help="Regenerate even when the target PNG already exists.")
    parser.add_argument("--per-image-timeout-sec", type=int, default=600, help="Fail a single image generation instead of waiting forever.")
    args = parser.parse_args()

    run_dir = args.run_dir.resolve()
    ensure_dir(run_dir / "images")
    append_log(run_dir, "generate_images_with_codex_exec", "start", execute=args.execute)

    prompts = load_image_prompts(run_dir)
    if args.image_id:
        prompts = [p for p in prompts if p.get("image_id") == args.image_id]
    prompts = prompts[: args.max_images]

    commands_manifest = []
    for image_prompt in prompts:
        image_id = image_prompt["image_id"]
        prompt_text = build_codex_prompt(run_dir, image_prompt)
        prompt_file = run_dir / "images" / f"{image_id}.codex_prompt.md"
        write_text(prompt_file, prompt_text)
        cmd = codex_exec_command(run_dir, image_id, prompt_file)
        image_path = run_dir / "images" / f"{image_id}.png"
        manifest_path = run_dir / "images" / f"{image_id}.manifest.json"
        already_generated = image_path.exists() and image_path.stat().st_size > 0 and manifest_path.exists()
        commands_manifest.append({
            "image_id": image_id,
            "prompt_file": str(prompt_file),
            "result_file": str(run_dir / "images" / f"{image_id}.codex_result.txt"),
            "image_path": str(image_path),
            "generation_manifest_path": str(manifest_path),
            "command_preview": cmd[:-1] + ["<prompt text>"],
            "executed": bool(args.execute),
            "skipped_existing": bool(args.execute and already_generated and not args.force),
        })
        if args.execute and already_generated and not args.force:
            append_log(run_dir, "generate_images_with_codex_exec", "skip_existing", image_id=image_id)
            continue
        if args.execute:
            try:
                completed = subprocess.run(
                    cmd,
                    cwd=str(HARNESS_ROOT),
                    text=True,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    timeout=args.per_image_timeout_sec,
                )
            except subprocess.TimeoutExpired as exc:
                write_text(run_dir / "images" / f"{image_id}.codex_stdout.txt", exc.stdout or "")
                write_text(run_dir / "images" / f"{image_id}.codex_stderr.txt", exc.stderr or "")
                append_log(
                    run_dir,
                    "generate_images_with_codex_exec",
                    "failed",
                    image_id=image_id,
                    reason="timeout",
                    timeout_sec=args.per_image_timeout_sec,
                )
                return 124
            write_text(run_dir / "images" / f"{image_id}.codex_stdout.txt", completed.stdout)
            write_text(run_dir / "images" / f"{image_id}.codex_stderr.txt", completed.stderr)
            if completed.returncode != 0:
                append_log(run_dir, "generate_images_with_codex_exec", "failed", image_id=image_id, returncode=completed.returncode)
                return completed.returncode
            if not image_path.exists() or image_path.stat().st_size == 0:
                append_log(run_dir, "generate_images_with_codex_exec", "failed", image_id=image_id, reason="image_file_missing")
                return 2
            if not manifest_path.exists():
                append_log(run_dir, "generate_images_with_codex_exec", "failed", image_id=image_id, reason="generation_manifest_missing")
                return 3

    write_json(run_dir / "stages" / "07_storyboard_images_manifest.json", {"images": commands_manifest})
    append_log(run_dir, "generate_images_with_codex_exec", "success", image_count=len(commands_manifest), executed=args.execute)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
