#!/usr/bin/env python3
from __future__ import annotations

import argparse
import html
import os
from pathlib import Path

from lib.harness_common import append_log, ensure_dir, load_json, resolve_run_dir, stage_path, write_json, write_text


def esc(value: object) -> str:
    return html.escape(str(value or ""))


def rel_from(base: Path, target: Path) -> str:
    return os.path.relpath(target, base).replace(os.sep, "/")


def load_optional(path: Path) -> dict:
    if not path.exists():
        return {}
    return load_json(path)


def shot_sort_key(item: dict) -> float:
    ref = str(item.get("source_refs", item.get("source_shot_ref", "")))
    if isinstance(item.get("source_refs"), list) and item["source_refs"]:
        ref = item["source_refs"][0]
    try:
        return float(ref.split("@", 1)[1].split("-", 1)[0])
    except Exception:
        return 0.0


def shot_cards(run_dir: Path, board_dir: Path, shot_analysis: dict, shot_structure: dict) -> str:
    structure_by_ref = {item.get("source_shot_ref"): item for item in shot_structure.get("shots", [])}
    cards = []
    for item in sorted(shot_analysis.get("frames", []), key=shot_sort_key):
        refs = item.get("source_refs", [])
        ref = refs[0] if refs else ""
        structure = structure_by_ref.get(ref, {})
        frame_path = Path(item.get("frame_path", ""))
        img = ""
        if frame_path.exists():
            img = f'<img src="{esc(rel_from(board_dir, frame_path))}" alt="{esc(ref)}">'
        role = structure.get("role") or item.get("role")
        cards.append(f"""
<article class="shot-card">
  {img}
  <div class="shot-body">
    <div class="eyebrow">{esc(ref)} / {esc(role)}</div>
    <h3>{esc(structure.get("camera_pattern") or item.get("camera_pattern"))}</h3>
    <p><b>見えているもの:</b> {esc(" / ".join(item.get("visible_elements", [])[:3]))}</p>
    <p><b>編集意図:</b> {esc(item.get("motion_or_edit"))}</p>
    <p><b>転用する型:</b> {esc(structure.get("reuse_principle") or item.get("reuse_principle"))}</p>
    <p><b>コピー禁止:</b> {esc(" / ".join((structure.get("do_not_copy") or item.get("do_not_copy") or [])[:4]))}</p>
    <p><b>自社変換:</b> {esc(structure.get("conversion_hint_for_own_brand") or item.get("conversion_hint_for_own_brand"))}</p>
  </div>
</article>
""")
    return "\n".join(cards)


def context_rows(run_dir: Path) -> str:
    context_dir = run_dir / "stages" / "context_reads"
    rows = []
    if not context_dir.exists():
        return '<tr><td colspan="4">context_readsなし</td></tr>'
    for path in sorted(context_dir.glob("*.json")):
        data = load_json(path)
        files = data.get("files", [])
        rows.append(f"""
<tr>
  <td>{esc(path.stem)}</td>
  <td>{esc(data.get("purpose"))}</td>
  <td>{esc(", ".join(item.get("relative_path", "") for item in files if item.get("exists")))}</td>
  <td>{esc(", ".join(data.get("missing_required", [])) or "なし")}</td>
</tr>
""")
    return "\n".join(rows)


def planned_rows(shot_script: dict) -> str:
    rows = []
    for shot in shot_script.get("planned_shots", []):
        rows.append(f"""
<tr>
  <td>{esc(shot.get("shot_id"))}<br><span>{esc(shot.get("scene_id"))}</span></td>
  <td>{esc(", ".join(shot.get("source_shot_refs", [])))}</td>
  <td>{esc(shot.get("adopted_cut_pattern"))}</td>
  <td>{esc(shot.get("subject"))}<br><span>{esc(shot.get("action"))}</span></td>
  <td>{esc(shot.get("overlay_text"))}</td>
</tr>
""")
    return "\n".join(rows)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", type=Path)
    parser.add_argument("--run-id")
    args = parser.parse_args()

    run_dir = resolve_run_dir(args)
    append_log(run_dir, "build_analysis_review_board", "start")
    board_dir = ensure_dir(run_dir / "storyboard")

    shot_manifest = load_json(stage_path(run_dir, "02b_shot_manifest.json"))
    shot_analysis = load_json(stage_path(run_dir, "03b_shot_analysis.json"))
    shot_structure = load_json(stage_path(run_dir, "03c_shot_structure_map.json"))
    temporal = load_json(stage_path(run_dir, "03d_temporal_window_analysis.json"))
    pattern_map = load_json(stage_path(run_dir, "03e_competitive_pattern_map.json"))
    shot_script = load_json(stage_path(run_dir, "05b_shot_script.json"))
    preimage_review = load_json(stage_path(run_dir, "06b_preimage_review.json"))
    learning_manifest = load_optional(run_dir / "review" / "learning_pack_manifest.json")

    board_json = {
        "run_id": run_dir.name,
        "shot_count": shot_manifest.get("shot_count"),
        "micro_shot_count": shot_manifest.get("micro_shot_count"),
        "analysis_count": len(shot_analysis.get("frames", [])),
        "structure_count": len(shot_structure.get("shots", [])),
        "window_count": len(temporal.get("windows", [])),
        "planned_shot_count": len(shot_script.get("planned_shots", [])),
        "preimage_review": {
            "decision": preimage_review.get("decision"),
            "score": preimage_review.get("score"),
            "issues": preimage_review.get("issues", []),
        },
        "learning_manifest": learning_manifest,
    }

    html_text = f"""<!doctype html>
<html lang="ja">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Analysis Review Board</title>
  <style>
    body {{ margin:0; font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; background:#f6f7f7; color:#152022; line-height:1.55; }}
    header {{ position:sticky; top:0; z-index:5; background:#fff; border-bottom:1px solid #d9e0df; padding:22px 28px; }}
    main {{ max-width:1320px; margin:0 auto; padding:22px; }}
    h1 {{ margin:0 0 4px; font-size:26px; }}
    h2 {{ margin:0 0 12px; font-size:21px; }}
    h3 {{ margin:0 0 8px; font-size:16px; }}
    .eyebrow, span {{ color:#647174; font-size:12px; }}
    .grid {{ display:grid; gap:14px; }}
    .metrics {{ grid-template-columns:repeat(6,minmax(0,1fr)); }}
    .metric,.card,.shot-card {{ background:#fff; border:1px solid #d9e0df; border-radius:8px; padding:14px; }}
    .metric b {{ display:block; font-size:24px; }}
    .shot-card {{ display:grid; grid-template-columns:190px 1fr; gap:14px; margin-bottom:12px; }}
    .shot-card img {{ width:190px; aspect-ratio:9/16; object-fit:cover; border-radius:6px; border:1px solid #d9e0df; background:#eef1f1; }}
    table {{ width:100%; border-collapse:collapse; background:#fff; font-size:13px; }}
    th,td {{ border:1px solid #d9e0df; padding:8px; vertical-align:top; }}
    th {{ background:#edf3f2; text-align:left; }}
    .two {{ display:grid; grid-template-columns:1fr 1fr; gap:14px; }}
    @media(max-width:960px) {{ .metrics,.two,.shot-card {{ grid-template-columns:1fr; }} header {{ position:static; }} .shot-card img {{ width:100%; max-height:420px; }} }}
  </style>
</head>
<body>
<header>
  <div class="eyebrow">Day02 / internal analysis review</div>
  <h1>ショット分析から字コンテまでの監査ビュー</h1>
</header>
<main>
  <section class="grid metrics">
    <div class="metric"><span>source shots</span><b>{esc(shot_manifest.get("shot_count"))}</b></div>
    <div class="metric"><span>micro shots</span><b>{esc(shot_manifest.get("micro_shot_count"))}</b></div>
    <div class="metric"><span>03b analyses</span><b>{len(shot_analysis.get("frames", []))}</b></div>
    <div class="metric"><span>03c structures</span><b>{len(shot_structure.get("shots", []))}</b></div>
    <div class="metric"><span>windows</span><b>{len(temporal.get("windows", []))}</b></div>
    <div class="metric"><span>review</span><b>{esc(preimage_review.get("decision"))}/{esc(preimage_review.get("score"))}</b></div>
  </section>

  <section class="two" style="margin-top:14px">
    <div class="card">
      <h2>採用する構造</h2>
      <ul>{''.join(f'<li>{esc(item)}</li>' for item in pattern_map.get('usable_principles', [])[:10])}</ul>
    </div>
    <div class="card">
      <h2>コピー禁止</h2>
      <ul>{''.join(f'<li>{esc(item)}</li>' for item in pattern_map.get('do_not_copy', [])[:10])}</ul>
    </div>
  </section>

  <section style="margin-top:18px">
    <h2>03b/03c ショット分析</h2>
    {shot_cards(run_dir, board_dir, shot_analysis, shot_structure)}
  </section>

  <section style="margin-top:18px">
    <h2>字コンテへの変換</h2>
    <table>
      <thead><tr><th>shot</th><th>source</th><th>採用型</th><th>自社で作るもの</th><th>テロップ</th></tr></thead>
      <tbody>{planned_rows(shot_script)}</tbody>
    </table>
  </section>

  <section style="margin-top:18px">
    <h2>Vault参照ログ</h2>
    <table>
      <thead><tr><th>stage</th><th>purpose</th><th>read files</th><th>missing</th></tr></thead>
      <tbody>{context_rows(run_dir)}</tbody>
    </table>
  </section>
</main>
</body>
</html>
"""
    write_text(board_dir / "13_analysis_review_board.html", html_text)
    write_json(board_dir / "13_analysis_review_board.json", board_json)
    append_log(run_dir, "build_analysis_review_board", "success", analysis_count=board_json["analysis_count"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
