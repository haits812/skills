#!/usr/bin/env python3
from __future__ import annotations

import argparse
import re
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

from lib.harness_common import HARNESS_ROOT, append_log, ensure_dir, load_json, relative_or_abs, require_cli, resolve_run_dir, run_cmd, stage_path, write_json, write_text


PTS_RE = re.compile(r"pts_time:(?P<time>[0-9.]+)")


def duration_from_download(download: dict) -> float:
    value = download.get("ffprobe", {}).get("format", {}).get("duration")
    if value is None:
        value = download.get("metadata", {}).get("duration")
    return float(value)


def parse_cut_times(stderr: str) -> list[float]:
    times: list[float] = []
    for match in PTS_RE.finditer(stderr):
        t = round(float(match.group("time")), 3)
        if not times or abs(t - times[-1]) > 0.001:
            times.append(t)
    return times


def make_shots(cut_times: list[float], duration: float) -> list[dict]:
    boundaries = [0.0] + [t for t in cut_times if 0 < t < duration] + [duration]
    shots: list[dict] = []
    for index, (start, end) in enumerate(zip(boundaries, boundaries[1:]), start=1):
        mid = max(start, min((start + end) / 2, duration - 0.001))
        duration_sec = max(end - start, 0)
        shots.append({
            "index": index,
            "start_sec": round(start, 3),
            "end_sec": round(end, 3),
            "duration_sec": round(duration_sec, 3),
            "representative_time_sec": round(mid, 3),
            "source_ref": f"shot_{index:03d}@{round(start, 3)}-{round(end, 3)}s",
            "is_micro_shot": duration_sec < 0.35,
        })
    return shots


def extract_shot_frame(video_path: Path, output_path: Path, time_sec: float) -> None:
    cmd = [
        "ffmpeg",
        "-y",
        "-ss",
        f"{time_sec:.3f}",
        "-i",
        str(video_path),
        "-frames:v",
        "1",
        "-q:v",
        "2",
        str(output_path),
    ]
    completed = run_cmd(cmd, timeout=120)
    if completed.returncode != 0:
        raise RuntimeError(f"ffmpeg shot frame extraction failed for {output_path}\n{completed.stderr}")


def make_contact_sheet(run_dir: Path, shots: list[dict], cols: int = 5, thumb_width: int = 220) -> Path:
    sheet_path = ensure_dir(run_dir / "storyboard") / "02b_shot_contact_sheet.jpg"
    thumbs = []
    font = ImageFont.load_default()
    label_h = 34
    for shot in shots:
        frame_path = Path(shot["representative_frame_path"])
        if not frame_path.is_absolute():
            frame_path = (HARNESS_ROOT / frame_path).resolve()
        with Image.open(frame_path) as img:
            img = img.convert("RGB")
            ratio = thumb_width / img.width
            thumb_h = int(img.height * ratio)
            img = img.resize((thumb_width, thumb_h))
            canvas = Image.new("RGB", (thumb_width, thumb_h + label_h), "white")
            canvas.paste(img, (0, label_h))
            draw = ImageDraw.Draw(canvas)
            label = f"{shot['index']:02d} {shot['start_sec']:.2f}-{shot['end_sec']:.2f}s"
            draw.rectangle((0, 0, thumb_width, label_h), fill=(20, 20, 20))
            draw.text((6, 5), label, fill=(255, 255, 255), font=font)
            if shot.get("is_micro_shot"):
                draw.text((6, 18), "micro", fill=(255, 220, 120), font=font)
            thumbs.append(canvas)
    rows = (len(thumbs) + cols - 1) // cols
    cell_w = max(t.width for t in thumbs)
    cell_h = max(t.height for t in thumbs)
    sheet = Image.new("RGB", (cell_w * cols, cell_h * rows), (245, 245, 245))
    for i, thumb in enumerate(thumbs):
        x = (i % cols) * cell_w
        y = (i // cols) * cell_h
        sheet.paste(thumb, (x, y))
    sheet.save(sheet_path, quality=92)
    return sheet_path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", type=Path)
    parser.add_argument("--run-id")
    parser.add_argument("--scene-threshold", type=float, default=0.12)
    parser.add_argument("--max-shots", type=int, default=60)
    args = parser.parse_args()

    require_cli("ffmpeg")
    run_dir = resolve_run_dir(args)
    shots_dir = ensure_dir(run_dir / "shots")
    append_log(run_dir, "detect_shots", "start", scene_threshold=args.scene_threshold)

    download = load_json(stage_path(run_dir, "01_download.json"))
    video_path = Path(download["video_path"])
    if not video_path.is_absolute():
        video_path = (HARNESS_ROOT / video_path).resolve()
    duration = duration_from_download(download)

    cmd = [
        "ffmpeg",
        "-hide_banner",
        "-i",
        str(video_path),
        "-vf",
        f"select='gt(scene,{args.scene_threshold})',showinfo",
        "-f",
        "null",
        "-",
    ]
    completed = run_cmd(cmd, timeout=300)
    write_text(run_dir / "logs" / "ffmpeg_detect_shots_stdout.txt", completed.stdout)
    write_text(run_dir / "logs" / "ffmpeg_detect_shots_stderr.txt", completed.stderr)
    if completed.returncode != 0:
        append_log(run_dir, "detect_shots", "failed", returncode=completed.returncode)
        return completed.returncode

    raw_cut_times = parse_cut_times(completed.stderr)
    shots = make_shots(raw_cut_times, duration)[: args.max_shots]
    for old in shots_dir.glob("shot_*.jpg"):
        old.unlink()
    for shot in shots:
        frame_path = shots_dir / f"shot_{shot['index']:03d}.jpg"
        extract_shot_frame(video_path, frame_path, float(shot["representative_time_sec"]))
        shot["representative_frame_path"] = relative_or_abs(frame_path)

    contact_sheet = make_contact_sheet(run_dir, shots)
    manifest = {
        "run_id": run_dir.name,
        "video_path": relative_or_abs(video_path),
        "scene_threshold": args.scene_threshold,
        "duration_sec": duration,
        "raw_cut_times": raw_cut_times,
        "shot_count": len(shots),
        "micro_shot_count": sum(1 for shot in shots if shot.get("is_micro_shot")),
        "shots": shots,
        "contact_sheet": relative_or_abs(contact_sheet),
        "command": cmd,
    }
    write_json(stage_path(run_dir, "02b_shot_manifest.json"), manifest)
    append_log(run_dir, "detect_shots", "success", shot_count=len(shots), micro_shot_count=manifest["micro_shot_count"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
