#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

from lib.harness_common import append_log, resolve_run_dir, stage_path, utc_now, vault_dir, write_context_read_log, write_json, write_text


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", type=Path)
    parser.add_argument("--run-id")
    parser.add_argument("--vault", default="sample-cosme")
    parser.add_argument("--max-budget-usd", type=float, default=1.5)
    args = parser.parse_args()

    run_dir = resolve_run_dir(args)
    append_log(run_dir, "improve_vault", "start", vault=args.vault)
    write_context_read_log(
        run_dir,
        "improve_vault",
        vault_name=args.vault,
        input_artifacts=["stages/09_review.json", "stages/10_memory_update.md"],
        output_artifacts=["vaults/sample-cosme/vault_review.md"],
    )
    review = stage_path(run_dir, "09_review.json")
    review_path = vault_dir(args.vault) / "vault_review.md"
    result = f"""# Vault Review

Generated at: {utc_now()}

## Scope

Reviewed only the selected business vault and the completed run review.
Operations notes, sales materials, personal data, and unpublished customer information remain out of scope.

## Recommended Changes

- Add a production rule that real product reference assets should be injected before final UGC storyboard image generation.
- Keep `source_refs`, `assumption_ids`, and `generated_from` mandatory for every storyboard scene and image prompt.
- Keep captions and CTA text outside generated images whenever possible.
- Record that per-frame image analysis was more reliable than large contact sheets in this run.
- Preserve the UGC premise: smartphone vertical video, everyday Japanese routine, natural wording, no TV commercial or studio campaign look.

## Do Not Auto-Apply

- Do not add fake reviews or fabricated testimonial examples to the vault.
- Do not expand the vault with lecture or sales-program notes.
- Do not claim cosmetic efficacy beyond the approved product context.

## Evidence

- Run review: `{review}`
- Storyboard board: `{run_dir / "storyboard" / "08_storyboard_board.html"}`
- Contact sheet: `{run_dir / "storyboard" / "08_storyboard_contact_sheet.png"}`
"""
    write_text(review_path, result)
    write_json(run_dir / "logs" / "improve_vault.json", {"mode": "deterministic", "review_path": str(review_path)})
    append_log(run_dir, "improve_vault", "success", review_path=str(review_path), mode="deterministic")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
