#!/usr/bin/env python3
from __future__ import annotations

import argparse
import html
from pathlib import Path

from lib.harness_common import HARNESS_ROOT, ensure_dir, load_json, relative_or_abs, resolve_run_dir, write_json, write_text


SKIP_NAMES = {".DS_Store", "__pycache__"}
SKIP_DIRS = {"__pycache__"}
COMPACT_DIRS = {"frames", "shots", "logs", "batches"}


def file_label(path: Path) -> str:
    if path.is_dir():
        count = len([p for p in path.iterdir() if p.name not in SKIP_NAMES])
        return f"{path.name}/ ({count} items)"
    size = path.stat().st_size
    return f"{path.name} ({size:,} bytes)"


def tree_lines(root: Path, *, max_depth: int, prefix: str = "", depth: int = 0) -> list[str]:
    if depth > max_depth:
        return []
    try:
        children = sorted(
            [p for p in root.iterdir() if p.name not in SKIP_NAMES and p.name not in SKIP_DIRS],
            key=lambda p: (not p.is_dir(), p.name.lower()),
        )
    except FileNotFoundError:
        return []

    lines: list[str] = []
    for index, path in enumerate(children):
        connector = "└── " if index == len(children) - 1 else "├── "
        next_prefix = prefix + ("    " if index == len(children) - 1 else "│   ")
        lines.append(f"{prefix}{connector}{file_label(path)}")
        if path.is_dir():
            if path.name in COMPACT_DIRS:
                files = [p for p in path.iterdir() if p.is_file() and p.name not in SKIP_NAMES]
                lines.append(f"{next_prefix}└── ... {len(files)} files compacted")
            elif depth < max_depth:
                lines.extend(tree_lines(path, max_depth=max_depth, prefix=next_prefix, depth=depth + 1))
    return lines


def read_file(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        return "[binary or non-UTF-8 file]"


def link_from_html(html_path: Path, target: Path, label: str | None = None) -> str:
    try:
        href = target.relative_to(html_path.parent)
    except ValueError:
        href = target
    return f'<a href="{html.escape(str(href))}">{html.escape(label or target.name)}</a>'


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--output")
    args = parser.parse_args()

    run_dir = resolve_run_dir(args)
    storyboard_dir = ensure_dir(run_dir / "storyboard")
    output_path = Path(args.output) if args.output else storyboard_dir / "15_harness_vault_browser.html"
    if not output_path.is_absolute():
        output_path = (HARNESS_ROOT / output_path).resolve()

    download = load_json(run_dir / "stages" / "01_download.json")
    review = load_json(run_dir / "stages" / "06b_preimage_review.json")
    operator = load_json(run_dir / "storyboard" / "14_operator_board.json")

    vault_dir = HARNESS_ROOT / "vaults" / "sample-cosme"
    vault_files = [
        vault_dir / "brand_context.md",
        vault_dir / "ugc_style_grammar.md",
        vault_dir / "shot_grammar.md",
        vault_dir / "claim_guardrails.md",
        vault_dir / "learnings.md",
        vault_dir / "context_manifest.yaml",
        vault_dir / "context_manifest.json",
        vault_dir / "vault_review.md",
    ]

    key_links = [
        ("絵コンテビューアー", run_dir / "storyboard" / "08_storyboard_board.html"),
        ("contact sheet", run_dir / "storyboard" / "08_storyboard_contact_sheet.png"),
        ("operator board", run_dir / "storyboard" / "14_operator_board.html"),
        ("analysis board", run_dir / "storyboard" / "13_analysis_review_board.html"),
        ("字コンテ", run_dir / "stages" / "05b_shot_script.md"),
        ("画像プロンプト", run_dir / "stages" / "06_image_prompts.yaml"),
        ("Vault反映結果", run_dir / "stages" / "10b_vault_learning_apply.md"),
        ("次回Vault参照確認", HARNESS_ROOT / "runs" / "vault-read-after-human-review-v1" / "stages" / "00_vault_context_verification.md"),
    ]

    vault_cards = []
    for path in vault_files:
        exists = path.exists()
        content = read_file(path) if exists else "[missing]"
        vault_cards.append(f"""
<details class="file" {'open' if path.name in {'brand_context.md', 'learnings.md'} else ''}>
  <summary>{html.escape(path.name)} <span>{path.stat().st_size if exists else 0:,} bytes</span></summary>
  <pre>{html.escape(content)}</pre>
</details>
""")

    harness_tree = "\n".join(["sns-video-ops-harness/"] + tree_lines(HARNESS_ROOT, max_depth=2))
    run_tree = "\n".join([f"{run_dir.name}/"] + tree_lines(run_dir, max_depth=2))

    html_text = f"""<!doctype html>
<html lang="ja">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Harness Structure & Vault</title>
  <style>
    body {{ margin: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; background: #f5f5f2; color: #1f1f1c; }}
    header {{ padding: 22px 28px 14px; background: #fff; border-bottom: 1px solid #ddd; position: sticky; top: 0; z-index: 2; }}
    h1 {{ margin: 0 0 6px; font-size: 22px; }}
    header p {{ margin: 0; color: #666; font-size: 13px; }}
    main {{ max-width: 1220px; margin: 0 auto; padding: 16px; display: grid; gap: 14px; }}
    section {{ background: #fff; border: 1px solid #ddd; border-radius: 8px; padding: 14px; }}
    h2 {{ margin: 0 0 10px; font-size: 18px; }}
    .grid {{ display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 10px; }}
    .metric {{ border: 1px solid #e4e4dd; border-radius: 7px; padding: 10px; background: #fafaf8; }}
    .metric b {{ display: block; font-size: 12px; color: #666; margin-bottom: 5px; }}
    .metric span {{ font-size: 14px; overflow-wrap: anywhere; }}
    .links {{ display: flex; flex-wrap: wrap; gap: 8px; }}
    a {{ color: #245a42; text-decoration: none; border-bottom: 1px solid rgba(36,90,66,.25); }}
    .links a {{ border: 1px solid #cfd8ce; border-radius: 999px; padding: 5px 9px; background: #fbfdf9; }}
    pre {{ margin: 0; padding: 12px; background: #20231f; color: #f1f3ed; border-radius: 7px; overflow: auto; font-size: 12px; line-height: 1.55; }}
    .trees {{ display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }}
    details.file {{ border: 1px solid #e2e2dc; border-radius: 8px; margin-top: 8px; overflow: hidden; }}
    details.file summary {{ cursor: pointer; padding: 10px 12px; font-weight: 700; background: #fbfbf8; display: flex; justify-content: space-between; gap: 12px; }}
    details.file summary span {{ color: #777; font-weight: 500; }}
    details.file pre {{ border-radius: 0; max-height: 520px; }}
    @media (max-width: 900px) {{ .grid {{ grid-template-columns: 1fr 1fr; }} .trees {{ grid-template-columns: 1fr; }} }}
    @media (max-width: 560px) {{ .grid {{ grid-template-columns: 1fr; }} header {{ position: static; }} }}
  </style>
</head>
<body>
<header>
  <h1>Harness Structure & Vault</h1>
  <p>run: {html.escape(run_dir.name)}</p>
</header>
<main>
  <section>
    <h2>実行情報</h2>
    <div class="grid">
      <div class="metric"><b>実行URL</b><span>{html.escape(download.get('source', {}).get('url', ''))}</span></div>
      <div class="metric"><b>動画</b><span>{html.escape(download.get('metadata', {}).get('title', ''))}</span></div>
      <div class="metric"><b>尺</b><span>{html.escape(str(download.get('metadata', {}).get('duration', '')))} sec</span></div>
      <div class="metric"><b>review</b><span>{html.escape(str(review.get('decision')))} / {html.escape(str(review.get('score')))}</span></div>
      <div class="metric"><b>images</b><span>{html.escape(str(operator.get('image_count')))} / {html.escape(str(operator.get('image_status')))}</span></div>
      <div class="metric"><b>shots</b><span>{html.escape(str(operator.get('shot_count')))} shots</span></div>
      <div class="metric"><b>planned shots</b><span>{html.escape(str(operator.get('planned_shot_count')))}</span></div>
      <div class="metric"><b>source file</b><span>{html.escape(download.get('video_path', ''))}</span></div>
    </div>
  </section>
  <section>
    <h2>主要リンク</h2>
    <div class="links">
      {''.join(link_from_html(output_path, target, label) for label, target in key_links if target.exists())}
    </div>
  </section>
  <section>
    <h2>ディレクトリ構造</h2>
    <div class="trees">
      <div>
        <h3>Harness root</h3>
        <pre>{html.escape(harness_tree)}</pre>
      </div>
      <div>
        <h3>Current run</h3>
        <pre>{html.escape(run_tree)}</pre>
      </div>
    </div>
  </section>
  <section>
    <h2>Vault: sample-cosme</h2>
    {''.join(vault_cards)}
  </section>
</main>
</body>
</html>
"""
    write_text(output_path, html_text)
    write_json(output_path.with_suffix(".json"), {
        "run_id": run_dir.name,
        "source_url": download.get("source", {}).get("url", ""),
        "output": relative_or_abs(output_path),
        "vault_files": [relative_or_abs(path) for path in vault_files],
        "key_links": [{"label": label, "path": relative_or_abs(target)} for label, target in key_links if target.exists()],
    })
    print(output_path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
