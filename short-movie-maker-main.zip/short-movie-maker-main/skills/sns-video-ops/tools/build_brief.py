#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

from lib.harness_common import append_log, load_json, resolve_run_dir, stage_path, write_context_read_log, write_json, write_text


def compact_unique(items: list[str], limit: int) -> list[str]:
    compacted: list[str] = []
    seen: set[str] = set()
    for item in items:
        text = str(item).strip()
        if not text or text in seen:
            continue
        compacted.append(text)
        seen.add(text)
        if len(compacted) >= limit:
            break
    return compacted


def compact_analysis(analysis: dict) -> dict:
    frames = []
    for item in analysis.get("frames", []):
        frames.append({
            "time_sec": item.get("time_sec"),
            "source_refs": item.get("source_refs", []),
            "visible_elements": item.get("visible_elements", [])[:3],
            "on_screen_text": item.get("on_screen_text", [])[:3],
            "motion_or_edit": item.get("motion_or_edit", ""),
            "business_signal": item.get("business_signal", ""),
        })
    return {
        "batch_summary": analysis.get("batch_summary", ""),
        "frames": frames,
        "patterns": compact_unique(analysis.get("patterns", []), 18),
        "reuse_notes": compact_unique(analysis.get("reuse_notes", []), 18),
        "risks": compact_unique(analysis.get("risks", []), 18),
        "traceability": analysis.get("traceability", {}),
        "compaction_note": "Full per-frame analysis remains in 03_timeseries_analysis.json and batches/03_frame_analysis_###.json. This compact artifact only limits prompt size.",
    }


def refs_for(frames: list[dict], start: int, end: int) -> list[str]:
    refs: list[str] = []
    for item in frames:
        refs.extend(item.get("source_refs", []))
    return [ref for ref in refs if start <= int(ref.split("@")[0].split("_")[-1]) <= end]


def render_brief(compacted_analysis: dict, download: dict, shot_manifest: dict | None = None, context_refs: list[str] | None = None) -> str:
    frames = compacted_analysis.get("frames", [])
    all_refs = [ref for item in frames for ref in item.get("source_refs", [])]
    opening_refs = refs_for(frames, 1, 3)
    product_refs = refs_for(frames, 3, 8)
    usage_refs = refs_for(frames, 9, 18)
    proof_refs = refs_for(frames, 2, 22)
    closing_refs = refs_for(frames, 23, 25)
    source = download.get("source", {})
    shot_count = (shot_manifest or {}).get("shot_count")
    micro_shot_count = (shot_manifest or {}).get("micro_shot_count")
    raw_cut_times = (shot_manifest or {}).get("raw_cut_times", [])
    shot_note = ""
    if shot_manifest:
        shot_note = f"""
## 2-補足. ショット構造

1fpsのフレーム抽出だけでは、元リールの編集密度を拾い切れない。
ffmpeg scene検出では、25.066667秒の中に `{shot_count}` ショット、うち `{micro_shot_count}` 個の0.35秒未満ショットが検出された。

- cut_times: {", ".join(str(t) for t in raw_cut_times)}
- shot_manifest: `stages/02b_shot_manifest.json`
- shot_analysis: `stages/03b_shot_analysis.json`
- shot_contact_sheet: `storyboard/02b_shot_contact_sheet.jpg`

この講座では、競合を真似るのではなく、ショット密度、役割、切替の意図を抽出して、自社商品の構造へ変換する。
"""

    return f"""# LUMIA COSME 競合リール分析から作るUGC動画制作ブリーフ

## 1. 目的

美容コスメ系の競合Instagramリールを、LUMIA COSMEの自社商品 `LUMIA Dew Mist Serum` 向けのUGC風SNS動画企画、台本、字コンテ、絵コンテへ変換する。
目的は、競合表現のコピーではなく、効いている構造を抽出し、自社の朝メイク前ミストという文脈に置き換えること。

- source_url: {source.get("webpage_url") or source.get("original_url") or source.get("url", "")}
- source_title: {source.get("title", "")}
- analyzed_frames: {len(frames)}
- analysis_mode: {compacted_analysis.get("traceability", {}).get("analysis_mode", "")}
- context_refs: {", ".join(context_refs or [])}

## 2. 参考動画から抽出した構造

1. 冒頭は商品を大きく見せ、SNS投稿風の反応を重ねて視聴者の注意を止めている。
   - source_refs: {", ".join(opening_refs)}
2. 商品アップ、ラベル、テクスチャ、手元、人物の髪/表情を短いカットでつなぎ、商品の使用イメージを積み上げている。
   - source_refs: {", ".join(product_refs + usage_refs)}
3. 「バズ」「口コミ」「良いらしい」といった社会的証明を置き、商品理解より先に興味を作っている。
   - source_refs: {", ".join(proof_refs)}
4. 終盤は人物の仕上がり印象と商品保持カットで締め、実際の使用場面を想像させている。
   - source_refs: {", ".join(closing_refs)}
{shot_note}

## 3. 自社向けに変換する方針

競合はヘアマスク文脈なので、LUMIAでは「朝の乾燥感」「メイク前の整え」「短時間で使いやすいミスト」へ変換する。
競合の容器、ラベル、コピー、SNS投稿画面、構図は使わない。再利用するのは、フック、商品接写、使用感、社会的証明、締めのCTAという構造だけに限定する。

- assumption_ids: `LUMIA_PRODUCT_001`, `LUMIA_TARGET_001`, `LUMIA_VALUE_001`, `LUMIA_CREATIVE_001`, `LUMIA_VISUAL_001`, `LUMIA_CLAIM_001`

## 4. 次回制作ブリーフ

### 企画名

朝のメイク前、ひと吹きで整えるLUMIAミスト

### 動画の流れ

1. 朝の洗面台に置いたLUMIAボトルと短い悩みフック。
2. 手元でミストを使うカット。細かい霧、軽い質感、朝の自然光を見せる。
3. メイク前の準備に足すだけという導入しやすさを見せる。
4. レビュー風の短文を後載せテロップで差し込み、実在しない口コミの捏造に見えないように「使用シーンの感想」へ寄せる。
5. 商品単体とCTAで締める。保存、プロフィールリンク、初回限定セット確認のいずれかに絞る。

### トーン

清潔、実用的、みずみずしい。テレビCMやスタジオ広告ではなく、一般ユーザーがスマホで撮ったような朝のルーティン感を優先する。

## 5. 必要素材

- LUMIA Dew Mist Serumのボトル単体画像。
- 洗面台に置いた商品カット。
- 手元でミストを吹きかけるカット。
- ミストや質感のマクロカット。
- 朝のメイク準備シーン。
- 後載せ用の短文テロップ案。
- CTA用の商品詳細ページURLまたはプロフィールリンク導線。

## 6. 失敗しやすい点

- 競合動画のSNS投稿風UIやコピーをそのまま真似る。
- 「乾燥が治る」「肌荒れが改善する」など医薬品的効能に見える表現を使う。
- image 2生成画像に長い日本語テキストを直接入れて、誤字や崩れを起こす。
- 競合はヘアケア商品なのに、構造変換せずLUMIAのコスメ文脈と混ぜる。

## 7. レビュー観点

- 競合事実、LUMIA前提、生成した企画案が分かれているか。
- 各シーンに `source_refs` と `assumption_ids` があるか。
- 絵コンテ画像が最終クリエイティブではなく、構造理解に使える画像になっているか。
- コスメUGCとして効果断定や誇大表現に見えないか。

## 8. 根拠一覧

### 競合動画の根拠

- 全解析フレーム: {", ".join(all_refs)}
- 完全解析: `stages/03_timeseries_analysis.json`
- 個別解析: `batches/03_frame_analysis_###.json`

### 自社前提

- `LUMIA_PRODUCT_001`: 商品はLUMIA Dew Mist Serum。
- `LUMIA_TARGET_001`: 朝の乾燥感、化粧ノリ、ツヤ不足が気になる25-39歳女性。
- `LUMIA_VALUE_001`: 短時間で肌を整えた印象を作りやすくする。
- `LUMIA_CTA_001`: 保存、プロフィールリンク、初回限定セット確認。
- `LUMIA_CLAIM_001`: 医薬品的効能、効果断定、競合コピー流用は禁止。
- `LUMIA_CREATIVE_001`: 競合構造は使ってよいが表面表現は置き換える。
- `LUMIA_VISUAL_001`: 清潔、実用的、みずみずしい、柔らかい朝光、スマホ縦動画らしい自然な画角。
"""


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", type=Path)
    parser.add_argument("--run-id")
    parser.add_argument("--max-budget-usd", type=float, default=3.0)
    args = parser.parse_args()

    run_dir = resolve_run_dir(args)
    append_log(run_dir, "build_brief", "start")
    context_report = write_context_read_log(
        run_dir,
        "build_brief",
        input_artifacts=["stages/03_timeseries_analysis.json", "stages/03b_shot_analysis.json", "stages/01_download.json"],
        output_artifacts=["stages/03_timeseries_analysis_compact.json", "stages/04_production_brief.md"],
    )
    analysis = load_json(stage_path(run_dir, "03_timeseries_analysis.json"))
    compacted_analysis = compact_analysis(analysis)
    write_json(stage_path(run_dir, "03_timeseries_analysis_compact.json"), compacted_analysis)
    download = load_json(stage_path(run_dir, "01_download.json"))
    shot_path = stage_path(run_dir, "02b_shot_manifest.json")
    shot_manifest = load_json(shot_path) if shot_path.exists() else None

    context_refs = [item["relative_path"] for item in context_report.get("files", []) if item.get("exists")]
    brief = render_brief(compacted_analysis, download, shot_manifest, context_refs)
    write_text(stage_path(run_dir, "04_production_brief.md"), brief)
    write_json(run_dir / "logs" / "build_brief.json", {
        "mode": "deterministic",
        "input_analysis": "stages/03_timeseries_analysis_compact.json",
        "full_analysis": "stages/03_timeseries_analysis.json",
        "frame_count": len(compacted_analysis.get("frames", [])),
    })
    append_log(run_dir, "build_brief", "success", mode="deterministic")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
