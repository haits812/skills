#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

from lib.harness_common import HARNESS_ROOT, append_log, load_json, resolve_run_dir, stage_path, write_json


DIRTY_RUN_PATTERNS = [
    "stages/*.json",
    "stages/*.md",
    "stages/*.yaml",
    "logs/*.txt",
    "images/*.png",
    "images/*.jpg",
    "images/*.jpeg",
    "images/*.webp",
    "images/*.manifest.json",
    "images/normalized/*.png",
    "storyboard/*.html",
    "storyboard/*.json",
    "review/*.md",
    "review/*.json",
]


def intended_run_path(args: argparse.Namespace) -> Path:
    if args.run_dir:
        return Path(args.run_dir).resolve()
    if args.run_id:
        return HARNESS_ROOT / "runs" / args.run_id
    return Path()


def dirty_artifacts(run_dir: Path) -> list[str]:
    artifacts: list[str] = []
    for pattern in DIRTY_RUN_PATTERNS:
        artifacts.extend(str(path.relative_to(run_dir)) for path in run_dir.glob(pattern) if path.is_file())
    return sorted(set(artifacts))


def validate_run_lifecycle(args: argparse.Namespace, run_dir: Path, existed_before: bool) -> None:
    if args.mode in {"preimage", "full"} and existed_before and not args.allow_dirty_run:
        artifacts = dirty_artifacts(run_dir)
        if artifacts:
            sample = "\n".join(f"  - {item}" for item in artifacts[:12])
            extra = "" if len(artifacts) <= 12 else f"\n  ... and {len(artifacts) - 12} more"
            raise SystemExit(
                "Refusing to run preimage/full on an existing non-empty run.\n"
                "Create a new --run-id for every analysis or storyboard rebuild.\n"
                "Use --mode render on an accepted preimage run, or pass --allow-dirty-run only for explicit recovery.\n"
                f"run_dir: {run_dir}\n"
                f"dirty artifacts:\n{sample}{extra}"
            )

    if args.mode == "render":
        review_path = stage_path(run_dir, "06b_preimage_review.json")
        prompts_path = stage_path(run_dir, "06_image_prompts.json")
        if not review_path.exists():
            raise SystemExit(f"Refusing render: missing preimage review: {review_path}")
        if not prompts_path.exists():
            raise SystemExit(f"Refusing render: missing image prompts: {prompts_path}")
        try:
            review = load_json(review_path)
        except json.JSONDecodeError as exc:
            raise SystemExit(f"Refusing render: invalid preimage review JSON: {review_path}: {exc}") from exc
        if review.get("decision") != "accept":
            raise SystemExit(
                "Refusing render: preimage review is not accept.\n"
                f"decision: {review.get('decision')}\n"
                f"review: {review_path}"
            )


def run_step(run_dir: Path, name: str, args: list[str]) -> None:
    cmd = [sys.executable, str(HARNESS_ROOT / "tools" / name), "--run-dir", str(run_dir), *args]
    completed = subprocess.run(cmd, cwd=str(HARNESS_ROOT), text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    (run_dir / "logs" / f"{name}.stdout.txt").write_text(completed.stdout, encoding="utf-8")
    (run_dir / "logs" / f"{name}.stderr.txt").write_text(completed.stderr, encoding="utf-8")
    if completed.returncode != 0:
        append_log(run_dir, "run_harness", "failed", step=name, returncode=completed.returncode)
        raise SystemExit(completed.returncode)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", type=Path)
    parser.add_argument("--run-id")
    parser.add_argument("--mode", choices=["preimage", "render", "full"], default="full")
    parser.add_argument("--url")
    parser.add_argument("--file", type=Path)
    parser.add_argument("--purpose", default="美容コスメ系の競合リールを分析し、サンプルブランドのUGC風SNS動画企画、台本、字コンテ、絵コンテへ変換する")
    parser.add_argument("--fps", type=float, default=1.0)
    parser.add_argument("--max-frames", type=int, default=25)
    parser.add_argument("--scene-threshold", type=float, default=0.12)
    parser.add_argument("--max-shots", type=int, default=60)
    parser.add_argument("--analysis-concurrency", type=int, default=6)
    parser.add_argument("--max-images", type=int, default=6)
    parser.add_argument("--image-timeout-sec", type=int, default=600)
    parser.add_argument("--execute-images", action="store_true")
    parser.add_argument("--review-images", action="store_true")
    parser.add_argument("--improve-vault", action="store_true")
    parser.add_argument("--allow-dirty-run", action="store_true", help="Explicit recovery escape hatch. Normally create a new run id instead of reusing a dirty run.")
    args = parser.parse_args()

    requested_path = intended_run_path(args)
    existed_before = bool(str(requested_path)) and requested_path.exists()
    run_dir = resolve_run_dir(args)
    validate_run_lifecycle(args, run_dir, existed_before)
    append_log(run_dir, "run_harness", "start", mode=args.mode)
    if args.allow_dirty_run:
        append_log(run_dir, "run_harness", "allow_dirty_run", mode=args.mode, reason="explicit CLI flag")

    if args.mode in {"preimage", "full"}:
        download_args = ["--purpose", args.purpose]
        if args.url:
            download_args.extend(["--url", args.url])
        if args.file:
            download_args.extend(["--file", str(args.file)])
        if args.url or args.file or not (run_dir / "stages" / "01_download.json").exists():
            run_step(run_dir, "download_video.py", download_args)
        else:
            append_log(run_dir, "run_harness", "skip_download", reason="existing 01_download.json")
        run_step(run_dir, "extract_frames.py", ["--fps", str(args.fps), "--max-frames", str(args.max_frames)])
        run_step(run_dir, "detect_shots.py", ["--scene-threshold", str(args.scene_threshold), "--max-shots", str(args.max_shots)])
        analysis_concurrency = str(args.analysis_concurrency)
        run_step(run_dir, "analyze_shots_with_claude.py", ["--max-shots", str(args.max_shots), "--concurrency", analysis_concurrency])
        run_step(run_dir, "analyze_frames_with_claude.py", ["--max-frames", str(args.max_frames), "--concurrency", analysis_concurrency])
        run_step(run_dir, "build_shot_structure_map.py", [])
        run_step(run_dir, "build_temporal_window_analysis.py", [])
        run_step(run_dir, "build_competitive_pattern_map.py", [])
        run_step(run_dir, "build_brief.py", [])
        run_step(run_dir, "build_ad_video_plan.py", [])
        run_step(run_dir, "build_continuity_contract.py", [])
        run_step(run_dir, "build_storyboard_plan.py", [])
        run_step(run_dir, "build_video_script.py", [])
        run_step(run_dir, "build_shot_script.py", [])
        run_step(run_dir, "build_image_prompts.py", ["--max-images", str(args.max_images)])
        run_step(run_dir, "review_preimage_outputs.py", [])
        run_step(run_dir, "build_preimage_board.py", [])
        run_step(run_dir, "build_review_learning_pack.py", [])
        run_step(run_dir, "build_analysis_review_board.py", [])
        run_step(run_dir, "build_operator_board.py", [])

    if args.mode in {"render", "full"}:
        run_step(run_dir, "lock_image_prompts.py", ["--reason", args.mode])
        image_args = ["--max-images", str(args.max_images), "--per-image-timeout-sec", str(args.image_timeout_sec)]
        if args.execute_images:
            image_args.append("--execute")
        run_step(run_dir, "generate_images_with_codex_exec.py", image_args)
        if args.execute_images:
            run_step(run_dir, "normalize_storyboard_images.py", [])

        if args.review_images:
            review_image_args = ["--execute"] if args.execute_images else []
            run_step(run_dir, "review_images_with_codex_exec.py", review_image_args)

        board_args = []
        if not args.execute_images:
            board_args.append("--allow-missing-images")
        run_step(run_dir, "build_storyboard_board.py", board_args)
        run_step(run_dir, "review_outputs.py", [])
        run_step(run_dir, "build_review_learning_pack.py", [])
        run_step(run_dir, "build_analysis_review_board.py", [])
        run_step(run_dir, "build_operator_board.py", [])
        run_step(run_dir, "update_memory.py", [])
        if args.improve_vault:
            run_step(run_dir, "improve_vault.py", [])

    write_json(run_dir / "stages" / "99_run_complete.json", {
        "run_id": run_dir.name,
        "status": "preimage_complete" if args.mode == "preimage" else "complete",
        "mode": args.mode,
        "execute_images": args.execute_images,
        "max_images": args.max_images,
    })
    append_log(run_dir, "run_harness", "success", mode=args.mode)
    print(run_dir)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
