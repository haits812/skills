#!/usr/bin/env python3
from __future__ import annotations

import argparse
import subprocess
from pathlib import Path

from lib.harness_common import HARNESS_ROOT, append_log, ensure_dir, load_json, write_text


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--image-id")
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()

    run_dir = args.run_dir.resolve()
    manifest_path = run_dir / "stages" / "07_storyboard_images_manifest.json"
    manifest = load_json(manifest_path)
    images = manifest.get("images", [])
    if args.image_id:
        images = [img for img in images if img.get("image_id") == args.image_id]

    append_log(run_dir, "review_images_with_codex_exec", "start", execute=args.execute)
    for item in images:
        image_id = item["image_id"]
        image_path = Path(item["image_path"])
        prompt = f"""Review generated image {image_id} against:
- vaults/sample-cosme/brand_context.md
- vaults/sample-cosme/ugc_style_grammar.md
- vaults/sample-cosme/shot_grammar.md
- vaults/sample-cosme/claim_guardrails.md
- the source generation prompt at {run_dir / "images" / f"{image_id}.codex_prompt.md"}

Check fact traceability, copy risk, cosmetic claim risk, Japanese UGC style fit, and cross-shot continuity.

Return JSON matching schemas/image_review_result.schema.json.
"""
        prompt_file = run_dir / "images" / f"{image_id}.review_prompt.md"
        write_text(prompt_file, prompt)
        cmd = [
            "codex",
            "--ask-for-approval",
            "never",
            "exec",
            "--cd",
            str(HARNESS_ROOT),
            "--sandbox",
            "workspace-write",
            "--skip-git-repo-check",
            "--image",
            str(image_path),
            "--output-schema",
            str(HARNESS_ROOT / "schemas" / "image_review_result.schema.json"),
            "-o",
            str(run_dir / "images" / f"{image_id}.review.json"),
            prompt,
        ]
        write_text(run_dir / "images" / f"{image_id}.review_command.txt", " ".join(cmd[:-1]) + " <prompt>")
        if args.execute:
            completed = subprocess.run(cmd, cwd=str(HARNESS_ROOT), text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            write_text(run_dir / "images" / f"{image_id}.review_stdout.txt", completed.stdout)
            write_text(run_dir / "images" / f"{image_id}.review_stderr.txt", completed.stderr)
            if completed.returncode != 0:
                append_log(run_dir, "review_images_with_codex_exec", "failed", image_id=image_id, returncode=completed.returncode)
                return completed.returncode

    append_log(run_dir, "review_images_with_codex_exec", "success", image_count=len(images), executed=args.execute)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
