#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

from lib.harness_common import append_log, load_json, resolve_run_dir, stage_path, write_context_read_log, write_json, write_text, write_yaml_like


def time_range_from_refs(refs: list[str]) -> str:
    if not refs:
        return ""
    first = refs[0].split("@", 1)[-1].replace("s", "")
    last = refs[-1].split("@", 1)[-1].replace("s", "")
    return f"{first} -> {last}"


def make_windows(shots: list[dict], size: int = 5, step: int = 4) -> list[dict]:
    windows = []
    if not shots:
        return windows
    index = 1
    for start in range(0, len(shots), step):
        chunk = shots[start : start + size]
        if not chunk:
            continue
        if len(chunk) < 2 and windows:
            break
        refs = [item.get("source_shot_ref", "") for item in chunk if item.get("source_shot_ref")]
        roles = [item.get("role", "") for item in chunk if item.get("role")]
        edit_functions = [item.get("edit_function", "") for item in chunk if item.get("edit_function")]
        reuse = [item.get("reuse_principle", "") for item in chunk if item.get("reuse_principle")]
        avoid: list[str] = []
        for item in chunk:
            avoid.extend(item.get("do_not_copy", [])[:2])
        hints = [item.get("conversion_hint_for_own_brand", "") for item in chunk if item.get("conversion_hint_for_own_brand")]
        windows.append({
            "window_id": f"W{index:02d}",
            "source_shot_refs": refs,
            "time_range_sec": time_range_from_refs(refs),
            "viewer_understanding": " / ".join(dict.fromkeys(roles[:4])) or "ショット群の役割を確認する",
            "flow_role": " → ".join(dict.fromkeys(roles[:5])) or "flow",
            "pacing_notes": " / ".join(edit_functions[:3]),
            "structure_to_keep": list(dict.fromkeys(reuse[:5])),
            "expression_to_avoid": list(dict.fromkeys(avoid[:6])),
            "conversion_hint_for_own_brand": " / ".join(hints[:3]),
        })
        index += 1
        if start + size >= len(shots):
            break
    return windows


def markdown(data: dict) -> str:
    lines = [
        f"# {data.get('title', 'Temporal Window Analysis')}",
        "",
        f"- source_run: {data.get('source_run', '')}",
        "",
        "## Overall Flow",
        "",
        *[f"- {item}" for item in data.get("overall_flow", [])],
        "",
        "## Windows",
        "",
    ]
    for window in data.get("windows", []):
        lines.extend([
            f"### {window.get('window_id')} / {window.get('flow_role')}",
            "",
            f"- source_shot_refs: {', '.join(window.get('source_shot_refs', []))}",
            f"- time_range_sec: {window.get('time_range_sec')}",
            f"- viewer_understanding: {window.get('viewer_understanding')}",
            f"- pacing_notes: {window.get('pacing_notes')}",
            f"- structure_to_keep: {' / '.join(window.get('structure_to_keep', []))}",
            f"- expression_to_avoid: {' / '.join(window.get('expression_to_avoid', []))}",
            f"- conversion_hint_for_own_brand: {window.get('conversion_hint_for_own_brand')}",
            "",
        ])
    lines.extend(["## Risks", "", *[f"- {item}" for item in data.get("risks", [])], ""])
    return "\n".join(lines).strip() + "\n"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", type=Path)
    parser.add_argument("--run-id")
    args = parser.parse_args()

    run_dir = resolve_run_dir(args)
    append_log(run_dir, "build_temporal_window_analysis", "start")
    context_report = write_context_read_log(
        run_dir,
        "build_temporal_window_analysis",
        input_artifacts=["stages/03c_shot_structure_map.json"],
        output_artifacts=["stages/03d_temporal_window_analysis.json", "stages/03d_temporal_window_analysis.md"],
    )
    shot_structure = load_json(stage_path(run_dir, "03c_shot_structure_map.json"))
    windows = make_windows(shot_structure.get("shots", []))
    data = {
        "title": "Temporal Window Analysis",
        "source_run": run_dir.name,
        "context_refs": [item["relative_path"] for item in context_report.get("files", []) if item.get("exists")],
        "windows": windows,
        "overall_flow": [
            window.get("flow_role", "")
            for window in windows
            if window.get("flow_role")
        ],
        "risks": [
            "このstageは03cのショット構造を時系列窓へ圧縮する決定論的ステージ。意味分析の一次情報は03cを参照する。",
        ],
    }
    write_json(stage_path(run_dir, "03d_temporal_window_analysis.json"), data)
    write_yaml_like(stage_path(run_dir, "03d_temporal_window_analysis.yaml"), data)
    write_text(stage_path(run_dir, "03d_temporal_window_analysis.md"), markdown(data))
    write_json(run_dir / "logs" / "build_temporal_window_analysis.json", {"mode": "deterministic_from_shot_structure", "window_count": len(windows)})
    append_log(run_dir, "build_temporal_window_analysis", "success", window_count=len(windows))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
