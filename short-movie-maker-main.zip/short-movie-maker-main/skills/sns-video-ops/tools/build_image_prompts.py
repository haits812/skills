#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

from lib.harness_common import append_log, load_json, resolve_run_dir, stage_path, write_context_read_log, write_json, write_yaml_like


def as_text_list(value: object) -> list[str]:
    if isinstance(value, list):
        return [str(item) for item in value if str(item).strip()]
    if value is None:
        return []
    text = str(value).strip()
    return [text] if text else []


def shot_script_by_scene(shot_script: dict | None) -> dict[str, list[dict]]:
    by_scene: dict[str, list[dict]] = {}
    if not shot_script:
        return by_scene
    for shot in shot_script.get("planned_shots", []):
        by_scene.setdefault(shot.get("scene_id", ""), []).append(shot)
    return by_scene


def summarize_shots(shots: list[dict]) -> str:
    if not shots:
        return "- no shot script available; use scene visual_direction only"
    lines = []
    for shot in shots:
        lines.append(
            f"- {shot.get('shot_id')}: role={shot.get('role')}; "
            f"adopted_cut_pattern={shot.get('adopted_cut_pattern')}; "
            f"camera_pattern={shot.get('camera_pattern')}; framing={shot.get('framing')}; "
            f"subject={shot.get('subject')}; action={shot.get('action')}; background={shot.get('background')}; "
            f"motion_or_edit={shot.get('motion_or_edit')}; "
            f"source_shot_refs={', '.join(shot.get('source_shot_refs', []))}"
        )
    return "\n".join(lines)


def role_text(scene: dict) -> str:
    return f"{scene.get('scene_id', '')} {scene.get('role', '')}".lower()


def product_focus_directive(scene: dict) -> dict[str, object]:
    text = role_text(scene)
    if "product" in text or "商品" in text:
        return {
            "mode": "product-led",
            "directive": (
                "Product-led frame. The LUMIA bottle, spray nozzle, label impression, and hand/vanity placement must be the main subject. "
                "Do not make a full face portrait. If a person appears, show only hand, partial mouth/chin, or cropped cheek as secondary context. "
                "The product should occupy a large, readable part of the frame while still feeling like casual UGC B-roll."
            ),
            "extra_negative": [
                "No full-face beauty portrait for this product scene.",
                "Do not let the product become a small prop.",
            ],
        }
    if "cta" in text:
        return {
            "mode": "product-led",
            "directive": (
                "CTA product memory frame. The product and blank space for later CTA text are more important than the person's face. "
                "Prefer product on vanity, hand placing the bottle, or bottle in lower third with clean empty space. "
                "Avoid turning the scene into a portrait."
            ),
            "extra_negative": [
                "No face-first CTA frame.",
                "Do not obscure the bottle with the person's face or body.",
            ],
        }
    if "trust" in text or "信頼" in text:
        return {
            "mode": "product-support",
            "directive": (
                "Product-support frame. Show the product with a short usage memo, hand action, or vanity context. "
                "The face may be absent; the product and usage cue should carry the scene."
            ),
            "extra_negative": ["Do not make this a face-only reaction shot."],
        }
    return {
        "mode": "person-consistent",
        "directive": (
            "Person may appear, but keep the same identity as the continuity contract. "
            "Even when the person is visible, the product or hand action must remain understandable."
        ),
        "extra_negative": [],
    }


def identity_directive(continuity: dict) -> str:
    identity = continuity.get("person_identity_lock", {})
    fixed_traits = identity.get("fixed_traits", []) if isinstance(identity, dict) else []
    fixed_trait_text = "; ".join(str(item) for item in fixed_traits if str(item).strip())
    reference_rule = identity.get("reference_rule", "") if isinstance(identity, dict) else ""
    if not fixed_trait_text:
        fixed_trait_text = "same early-30s Japanese woman, natural dark hair, natural makeup, light neutral homewear, same face structure and skin tone"
    if not reference_rule:
        reference_rule = "Keep the same person identity across every image where a person appears."
    return (
        f"Person identity lock: {reference_rule} Fixed traits: {fixed_trait_text}. "
        "Do not change her face shape, age, hairstyle, hair color, skin tone, or wardrobe direction between storyboard frames."
    )


def prompt_for_scene(scene: dict, scene_shots: list[dict], continuity: dict) -> dict:
    scene_id = scene["scene_id"]
    prompt_anchor = continuity.get("prompt_anchor_text", "")
    if not prompt_anchor:
        prompt_anchor = "Japanese UGC-style cosmetics reel, vertical smartphone video, same person, same home bathroom, same product, natural everyday routine."
    forbidden = continuity.get("forbidden_visual_drift", [])
    base_negative = [
        "Do not copy competitor reel frames.",
        "No competitor packaging, labels, product shapes, or social media screenshots.",
        "No fake review UI.",
        "No long Japanese text baked into the image.",
        "No medical claim, no effect guarantee, no before-after transformation.",
        "No distorted hands.",
        "Do not change the person, location, product category, bottle shape, or lighting between scenes.",
        "Do not create a different woman from prior storyboard frames.",
        "Do not make every storyboard frame a face portrait.",
        "No studio advertising look, no professional model shoot, no luxury campaign lighting.",
    ]
    base_negative.extend(forbidden)
    focus = product_focus_directive(scene)
    base_negative.extend(focus.get("extra_negative", []))
    overlay = as_text_list(scene.get("on_screen_text"))
    return {
        "image_id": f"img_{scene_id.replace('scene_', '')}",
        "scene_id": scene_id,
        "purpose": scene.get("role", ""),
        "prompt": (
            f"{prompt_anchor}\n\n"
            f"{identity_directive(continuity)}\n\n"
            f"Scene visual priority: {focus['directive']}\n\n"
            "Create one vertical 9:16 photorealistic storyboard frame for this scene. "
            "The image is only a visual aid for the shot script; do not bake long text into the image.\n\n"
            f"Scene role: {scene.get('role', '')}\n"
            f"Viewer takeaway: {scene.get('viewer_takeaway', '')}\n"
            f"Narration intent: {scene.get('narration', '')}\n\n"
            "Shot script context. Treat these as production directions for the new LUMIA UGC storyboard, not as text to draw and not as competitor frames to copy:\n"
            f"{summarize_shots(scene_shots)}"
        ),
        "negative_prompt": " ".join(base_negative),
        "size": "1024x1536",
        "visual_continuity_contract": {
            "person": continuity.get("person", ""),
            "person_identity_lock": continuity.get("person_identity_lock", {}),
            "location": continuity.get("location", ""),
            "product": continuity.get("product", ""),
            "product_focus_policy": continuity.get("product_focus_policy", {}),
            "lighting": continuity.get("lighting", ""),
            "capture_style": continuity.get("capture_style", ""),
        },
        "visual_priority": focus["mode"],
        "overlay_text_later": overlay,
        "review_focus": [
            "9:16 vertical storyboard composition",
            "shot script is visually understandable",
            "same person/location/product continuity",
            "same person identity if a person appears",
            "product-led scenes prioritize bottle, nozzle, hand action, label impression, or vanity placement",
            "UGC look, not studio ad",
            "no long text baked into the image",
            "cosmetics ad claim risk avoided",
        ],
        "source_refs": scene.get("source_refs", []),
        "source_shot_refs": scene.get("source_shot_refs", []),
        "planned_shot_ids": [shot.get("shot_id") for shot in scene_shots],
        "assumption_ids": scene.get("assumption_ids", []),
        "generated_from": scene.get("generated_from", []),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", type=Path)
    parser.add_argument("--run-id")
    parser.add_argument("--max-images", type=int, default=4)
    args = parser.parse_args()

    run_dir = resolve_run_dir(args)
    append_log(run_dir, "build_image_prompts", "start", max_images=args.max_images)
    context_report = write_context_read_log(
        run_dir,
        "build_image_prompts",
        input_artifacts=["stages/05b_shot_script.json", "stages/05_storyboard_plan.json", "stages/04c_continuity_contract.json"],
        output_artifacts=["stages/06_image_prompts.json", "stages/06_image_prompts.yaml"],
    )
    storyboard = load_json(stage_path(run_dir, "05_storyboard_plan.json"))
    continuity = load_json(stage_path(run_dir, "04c_continuity_contract.json"))
    shot_script_path = stage_path(run_dir, "05b_shot_script.json")
    shot_script = load_json(shot_script_path) if shot_script_path.exists() else None
    shots_by_scene = shot_script_by_scene(shot_script)
    parsed = {
        "image_set_name": "lumia-dew-mist-serum-storyboard",
        "prompt_contract": {
            "primary_source": "05b_shot_script.json" if shot_script else "05_storyboard_plan.json",
            "continuity_source": "04c_continuity_contract.json",
            "principle": "画像生成はUGC字コンテを可視化する補助工程。画角、被写体、動き、テロップ、ナレーション、一貫性コンテキストは05bと04cを正本にする。",
            "context_refs": [item["relative_path"] for item in context_report.get("files", []) if item.get("exists")],
        },
        "prompts": [
            prompt_for_scene(scene, shots_by_scene.get(scene.get("scene_id", ""), []), continuity)
            for scene in storyboard.get("scenes", [])[: args.max_images]
        ],
    }
    write_json(stage_path(run_dir, "06_image_prompts.json"), parsed)
    write_yaml_like(stage_path(run_dir, "06_image_prompts.yaml"), parsed)
    write_json(run_dir / "logs" / "build_image_prompts.json", {"mode": "derived_from_shot_script_and_continuity_contract", "image_prompt_count": len(parsed.get("prompts", []))})
    append_log(run_dir, "build_image_prompts", "success", image_prompt_count=len(parsed.get("prompts", [])), mode="derived")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
