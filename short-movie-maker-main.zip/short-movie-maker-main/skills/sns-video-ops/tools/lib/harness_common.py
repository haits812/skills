from __future__ import annotations

import argparse
import base64
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any


HARNESS_ROOT = Path(__file__).resolve().parents[2]
TOOLS_DIR = HARNESS_ROOT / "tools"
PROMPTS_DIR = HARNESS_ROOT / "prompts"
SCHEMAS_DIR = HARNESS_ROOT / "schemas"
MEMORY_DIR = HARNESS_ROOT / "memory"
VAULTS_DIR = HARNESS_ROOT / "vaults"
DEFAULT_VAULT_NAME = "sample-cosme"
RUNS_DIR = HARNESS_ROOT / "runs"


def utc_now() -> str:
    return datetime.utcnow().replace(microsecond=0).isoformat() + "Z"


def make_run_id(prefix: str = "run") -> str:
    return f"{prefix}-{datetime.now().strftime('%Y%m%d-%H%M%S')}"


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def ensure_run_dir(run_id: str | None = None) -> Path:
    run_id = run_id or make_run_id("sns-video")
    run_dir = RUNS_DIR / run_id
    for sub in ["inputs", "frames", "stages", "batches", "images", "logs"]:
        ensure_dir(run_dir / sub)
    return run_dir


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def write_text(path: Path, text: str) -> None:
    ensure_dir(path.parent)
    path.write_text(text, encoding="utf-8")


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, data: Any) -> None:
    ensure_dir(path.parent)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def append_log(run_dir: Path, stage: str, status: str, **extra: Any) -> None:
    log_path = run_dir / "harness_log.json"
    if log_path.exists():
        log = load_json(log_path)
    else:
        log = {"run_id": run_dir.name, "created_at": utc_now(), "stages": []}
    event = {"stage": stage, "status": status, "at": utc_now()}
    event.update(extra)
    log.setdefault("stages", []).append(event)
    write_json(log_path, log)


def run_cmd(cmd: list[str], *, cwd: Path | None = None, timeout: int = 1800) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        cmd,
        cwd=str(cwd or HARNESS_ROOT),
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout,
    )


def require_cli(name: str) -> str:
    found = shutil.which(name)
    if not found:
        raise RuntimeError(f"Required CLI not found: {name}")
    return found


def parse_reference_file(path: Path) -> dict[str, str]:
    text = read_text(path)
    purpose = ""
    url = ""
    for line in text.splitlines():
        lower = line.lower().strip()
        if lower.startswith("purpose:"):
            purpose = line.split(":", 1)[1].strip()
        if lower.startswith("url:"):
            url = line.split(":", 1)[1].strip()
    if not url:
        match = re.search(r"https?://\S+", text)
        if match:
            url = match.group(0).strip().strip("`")
    return {"purpose": purpose, "url": url}


def vault_dir(vault_name: str | None = None) -> Path:
    return VAULTS_DIR / (vault_name or DEFAULT_VAULT_NAME)


def load_context_manifest(vault_name: str | None = None) -> dict[str, Any]:
    path = vault_dir(vault_name) / "context_manifest.json"
    if not path.exists():
        return {"always": [], "stages": {}}
    return load_json(path)


def stage_context_entry(manifest: dict[str, Any], stage: str) -> dict[str, Any]:
    entry = manifest.get("stages", {}).get(stage, [])
    if isinstance(entry, list):
        return {"required": entry, "optional": []}
    if isinstance(entry, dict):
        return {
            "required": list(entry.get("required", [])),
            "optional": list(entry.get("optional", [])),
            "purpose": entry.get("purpose", ""),
        }
    return {"required": [], "optional": []}


def context_rels_for_stage(stage: str, vault_name: str | None = None) -> list[str]:
    manifest = load_context_manifest(vault_name)
    rels: list[str] = []
    rels.extend(manifest.get("always", []))
    entry = stage_context_entry(manifest, stage)
    rels.extend(entry.get("required", []))
    rels.extend(entry.get("optional", []))
    compacted: list[str] = []
    seen: set[str] = set()
    for rel in rels:
        if rel in seen:
            continue
        compacted.append(rel)
        seen.add(rel)
    return compacted


def context_files_for_stage(stage: str, vault_name: str | None = None) -> list[Path]:
    paths: list[Path] = []
    seen: set[Path] = set()
    for rel in context_rels_for_stage(stage, vault_name):
        path = (HARNESS_ROOT / rel).resolve()
        if path in seen:
            continue
        if path.exists() and path.is_file():
            paths.append(path)
            seen.add(path)
    return paths


def file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def context_read_report(
    stage: str,
    vault_name: str | None = None,
    *,
    input_artifacts: list[str] | None = None,
    output_artifacts: list[str] | None = None,
) -> dict[str, Any]:
    manifest = load_context_manifest(vault_name)
    entry = stage_context_entry(manifest, stage)
    files = []
    for rel in context_rels_for_stage(stage, vault_name):
        path = (HARNESS_ROOT / rel).resolve()
        exists = path.exists() and path.is_file()
        files.append({
            "relative_path": rel,
            "absolute_path": str(path),
            "exists": exists,
            "bytes": path.stat().st_size if exists else 0,
            "sha256": file_sha256(path) if exists else None,
        })
    missing_required = []
    for rel in entry.get("required", []):
        path = (HARNESS_ROOT / rel).resolve()
        if not path.exists() or not path.is_file():
            missing_required.append(rel)
    return {
        "stage": stage,
        "vault": vault_name or DEFAULT_VAULT_NAME,
        "manifest": str((vault_dir(vault_name) / "context_manifest.json").resolve()),
        "purpose": entry.get("purpose", ""),
        "required": entry.get("required", []),
        "optional": entry.get("optional", []),
        "files": files,
        "missing_required": missing_required,
        "input_artifacts": input_artifacts or [],
        "output_artifacts": output_artifacts or [],
    }


def write_context_read_log(
    run_dir: Path,
    stage: str,
    vault_name: str | None = None,
    *,
    input_artifacts: list[str] | None = None,
    output_artifacts: list[str] | None = None,
) -> dict[str, Any]:
    report = context_read_report(
        stage,
        vault_name,
        input_artifacts=input_artifacts,
        output_artifacts=output_artifacts,
    )
    write_json(run_dir / "stages" / "context_reads" / f"{stage}.json", report)
    if report.get("missing_required"):
        raise FileNotFoundError(f"Missing required context files for {stage}: {', '.join(report['missing_required'])}")
    return report


def render_context_bundle(stage: str, vault_name: str | None = None) -> str:
    parts = [f"# Context Bundle: {stage}", f"vault: {vault_name or DEFAULT_VAULT_NAME}", ""]
    for path in context_files_for_stage(stage, vault_name):
        try:
            rel = path.relative_to(HARNESS_ROOT)
        except ValueError:
            rel = path
        parts.append(f"## {rel}")
        parts.append(path.read_text(encoding="utf-8"))
        parts.append("")
    return "\n".join(parts)


def prompt_text(name: str) -> str:
    path = PROMPTS_DIR / name
    if not path.exists():
        raise FileNotFoundError(path)
    return read_text(path)


def schema_text(name: str) -> str:
    path = SCHEMAS_DIR / name
    if not path.exists():
        raise FileNotFoundError(path)
    return read_text(path)


def strip_code_fence(text: str) -> str:
    stripped = text.strip()
    if stripped.startswith("```"):
        lines = stripped.splitlines()
        if lines:
            lines = lines[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        stripped = "\n".join(lines).strip()
    return stripped


def parse_json_with_light_repair(raw: str) -> tuple[Any | None, str | None]:
    """Parse strict JSON, then apply only syntax-preserving repairs seen in LLM output."""
    try:
        return json.loads(raw), None
    except json.JSONDecodeError as first_error:
        repaired = re.sub(r",\s*([}\]])", r"\1", raw)
        if repaired != raw:
            try:
                return json.loads(repaired), f"removed_trailing_commas_after_json_error: {first_error.msg}"
            except json.JSONDecodeError:
                pass
        return None, first_error.msg


def parse_claude_json_stdout(stdout: str) -> tuple[Any, dict[str, Any]]:
    wrapper = json.loads(stdout)
    result = wrapper.get("result", "")
    raw = strip_code_fence(result)
    parsed, repair_note = parse_json_with_light_repair(raw)
    if parsed is None:
        parsed = {"raw_text": result}
    elif repair_note:
        wrapper.setdefault("json_repair_notes", []).append(repair_note)
    return parsed, wrapper


def run_claude(
    prompt: str,
    *,
    schema: dict[str, Any] | None = None,
    allowed_tools: str = "Read",
    max_budget_usd: float = 1.0,
    timeout: int = 1800,
    model: str | None = None,
) -> tuple[str, dict[str, Any]]:
    require_cli("claude")
    cmd = [
        "claude",
        "-p",
        "--output-format",
        "json",
        "--allowedTools",
        allowed_tools,
        "--permission-mode",
        "bypassPermissions",
        "--max-budget-usd",
        str(max_budget_usd),
    ]
    if model:
        cmd.extend(["--model", model])
    if schema:
        cmd.extend(["--json-schema", json.dumps(schema, ensure_ascii=False)])
    cmd.append(prompt)
    completed = run_cmd(cmd, cwd=HARNESS_ROOT, timeout=timeout)
    if completed.returncode != 0:
        raise RuntimeError(
            "claude -p failed\n"
            f"cmd: {' '.join(cmd[:12])} ...\n"
            f"stdout:\n{completed.stdout}\n"
            f"stderr:\n{completed.stderr}"
        )
    wrapper = json.loads(completed.stdout)
    return wrapper.get("result", ""), wrapper


def run_claude_structured(
    prompt: str,
    *,
    schema_name: str,
    allowed_tools: str = "Read",
    max_budget_usd: float = 1.0,
    timeout: int = 1800,
    model: str | None = None,
) -> tuple[Any, dict[str, Any]]:
    schema = json.loads(schema_text(schema_name))
    structured_prompt = (
        f"{prompt}\n\n"
        "# JSON Output Contract\n\n"
        "Return only valid JSON. Do not wrap it in markdown fences. "
        "The JSON must match this schema:\n"
        f"{json.dumps(schema, ensure_ascii=False, indent=2)}\n"
    )
    result, wrapper = run_claude(
        structured_prompt,
        schema=None,
        allowed_tools=allowed_tools,
        max_budget_usd=max_budget_usd,
        timeout=timeout,
        model=model,
    )
    raw = strip_code_fence(result)
    parsed, repair_note = parse_json_with_light_repair(raw)
    if parsed is not None:
        if repair_note:
            wrapper.setdefault("json_repair_notes", []).append(repair_note)
        return parsed, wrapper
    else:
        return {"raw_text": result}, wrapper


def json_to_yaml_like(data: Any, indent: int = 0) -> str:
    space = " " * indent
    if isinstance(data, dict):
        lines: list[str] = []
        for key, value in data.items():
            if isinstance(value, (dict, list)):
                lines.append(f"{space}{key}:")
                lines.append(json_to_yaml_like(value, indent + 2))
            else:
                lines.append(f"{space}{key}: {scalar_to_yaml(value)}")
        return "\n".join(lines)
    if isinstance(data, list):
        lines = []
        for item in data:
            if isinstance(item, dict):
                lines.append(f"{space}-")
                lines.append(json_to_yaml_like(item, indent + 2))
            elif isinstance(item, list):
                lines.append(f"{space}-")
                lines.append(json_to_yaml_like(item, indent + 2))
            else:
                lines.append(f"{space}- {scalar_to_yaml(item)}")
        return "\n".join(lines)
    return f"{space}{scalar_to_yaml(data)}"


def scalar_to_yaml(value: Any) -> str:
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        return str(value)
    text = str(value)
    if "\n" in text or len(text) > 80:
        indented = "\n".join("  " + line for line in text.splitlines())
        return "|\n" + indented
    escaped = text.replace('"', '\\"')
    return f'"{escaped}"'


def find_stage_file(run_dir: Path, name: str) -> Path:
    path = run_dir / "stages" / name
    if not path.exists():
        raise FileNotFoundError(path)
    return path


def add_common_run_arg(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--run-dir", type=Path, help="Existing run directory.")
    parser.add_argument("--run-id", help="Run id to create/use.")


def resolve_run_dir(args: argparse.Namespace) -> Path:
    if getattr(args, "run_dir", None):
        run_dir = Path(args.run_dir).resolve()
        for sub in ["inputs", "frames", "stages", "batches", "images", "logs"]:
            ensure_dir(run_dir / sub)
        return run_dir
    return ensure_run_dir(getattr(args, "run_id", None))


def relative_or_abs(path: Path) -> str:
    try:
        return str(path.relative_to(HARNESS_ROOT))
    except ValueError:
        return str(path)


def image_file_to_data_url(path: Path) -> str:
    mime = "image/png" if path.suffix.lower() == ".png" else "image/jpeg"
    encoded = base64.b64encode(path.read_bytes()).decode("ascii")
    return f"data:{mime};base64,{encoded}"


def stage_path(run_dir: Path, filename: str) -> Path:
    return run_dir / "stages" / filename


def write_yaml_like(path: Path, data: Any) -> None:
    write_text(path, json_to_yaml_like(data) + "\n")


def markdown_list(items: list[Any]) -> str:
    return "\n".join(f"- {item}" for item in items)
