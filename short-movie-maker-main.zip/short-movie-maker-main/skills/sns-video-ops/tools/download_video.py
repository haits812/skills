#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from lib.harness_common import (
    append_log,
    ensure_dir,
    load_json,
    parse_reference_file,
    relative_or_abs,
    require_cli,
    resolve_run_dir,
    run_cmd,
    stage_path,
    utc_now,
    write_json,
    write_text,
)


def ffprobe(video_path: Path) -> dict:
    require_cli("ffprobe")
    completed = run_cmd([
        "ffprobe",
        "-v",
        "error",
        "-show_entries",
        "format=duration,size,format_name",
        "-show_entries",
        "stream=index,codec_type,codec_name,width,height,avg_frame_rate",
        "-of",
        "json",
        str(video_path),
    ])
    if completed.returncode != 0:
        raise RuntimeError(completed.stderr)
    return json.loads(completed.stdout)


def find_downloaded_file(inputs_dir: Path, video_id: str | None) -> Path:
    candidates = sorted(inputs_dir.glob("*.mp4")) + sorted(inputs_dir.glob("*.mov")) + sorted(inputs_dir.glob("*.m4v"))
    if video_id:
        exact = [p for p in candidates if p.stem == video_id]
        if exact:
            return exact[0]
    if not candidates:
        raise FileNotFoundError(f"No downloaded video found under {inputs_dir}")
    return max(candidates, key=lambda p: p.stat().st_mtime)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", type=Path)
    parser.add_argument("--run-id")
    parser.add_argument("--url")
    parser.add_argument("--file", type=Path)
    parser.add_argument("--reference-file", type=Path, default=Path("inputs/reference_video.md"))
    parser.add_argument("--purpose")
    args = parser.parse_args()

    run_dir = resolve_run_dir(args)
    inputs_dir = ensure_dir(run_dir / "inputs")
    append_log(run_dir, "download_video", "start")

    source: dict[str, str] = {}
    if args.url:
        source["url"] = args.url
    elif args.file:
        source["file"] = str(args.file)
    elif args.reference_file:
        parsed = parse_reference_file((Path.cwd() / args.reference_file).resolve() if not args.reference_file.is_absolute() else args.reference_file)
        source.update({k: v for k, v in parsed.items() if v})

    purpose = args.purpose or source.get("purpose") or "競合リールを分析し、自社UGC風SNS動画のブリーフ、台本、字コンテ、絵コンテへ変換する"
    metadata: dict = {}
    video_path: Path
    command_logs: dict[str, dict] = {}

    if source.get("file"):
        src = Path(source["file"]).expanduser().resolve()
        if not src.exists():
            raise FileNotFoundError(src)
        video_path = inputs_dir / f"video{src.suffix.lower() or '.mp4'}"
        shutil.copy2(src, video_path)
        source = {"type": "file", "file": str(src)}
    elif source.get("url"):
        require_cli("yt-dlp")
        url = source["url"]
        metadata_path = stage_path(run_dir, "01_download_metadata.json")
        meta_cmd = ["yt-dlp", "--skip-download", "--dump-single-json", url]
        meta_result = run_cmd(meta_cmd, timeout=900)
        command_logs["metadata"] = {
            "command": meta_cmd,
            "returncode": meta_result.returncode,
            "stdout_path": relative_or_abs(run_dir / "logs" / "yt_dlp_metadata_stdout.txt"),
            "stderr_path": relative_or_abs(run_dir / "logs" / "yt_dlp_metadata_stderr.txt"),
        }
        write_text(run_dir / "logs" / "yt_dlp_metadata_stdout.txt", meta_result.stdout)
        write_text(run_dir / "logs" / "yt_dlp_metadata_stderr.txt", meta_result.stderr)
        if meta_result.returncode != 0:
            append_log(run_dir, "download_video", "failed", reason="metadata", stderr=meta_result.stderr)
            return meta_result.returncode
        metadata = json.loads(meta_result.stdout)
        write_json(metadata_path, metadata)

        out_tmpl = str(inputs_dir / "%(id)s.%(ext)s")
        dl_cmd = ["yt-dlp", "-o", out_tmpl, url]
        dl_result = run_cmd(dl_cmd, timeout=1800)
        command_logs["download"] = {
            "command": dl_cmd,
            "returncode": dl_result.returncode,
            "stdout_path": relative_or_abs(run_dir / "logs" / "yt_dlp_download_stdout.txt"),
            "stderr_path": relative_or_abs(run_dir / "logs" / "yt_dlp_download_stderr.txt"),
        }
        write_text(run_dir / "logs" / "yt_dlp_download_stdout.txt", dl_result.stdout)
        write_text(run_dir / "logs" / "yt_dlp_download_stderr.txt", dl_result.stderr)
        if dl_result.returncode != 0:
            append_log(run_dir, "download_video", "failed", reason="download", stderr=dl_result.stderr)
            return dl_result.returncode
        downloaded = find_downloaded_file(inputs_dir, metadata.get("id"))
        video_path = inputs_dir / "video.mp4"
        if downloaded != video_path:
            shutil.copy2(downloaded, video_path)
        source = {"type": "url", "url": url}
    else:
        raise ValueError("Provide --url, --file, or a reference file containing a URL.")

    probe = ffprobe(video_path)
    manifest = {
        "run_id": run_dir.name,
        "created_at": utc_now(),
        "purpose": purpose,
        "source": source,
        "metadata": {
            "id": metadata.get("id"),
            "title": metadata.get("title"),
            "extractor": metadata.get("extractor"),
            "webpage_url": metadata.get("webpage_url"),
            "duration": metadata.get("duration"),
            "width": metadata.get("width"),
            "height": metadata.get("height"),
            "ext": metadata.get("ext"),
        },
        "video_path": relative_or_abs(video_path),
        "ffprobe": probe,
        "commands": command_logs,
    }
    write_json(stage_path(run_dir, "01_download.json"), manifest)
    append_log(run_dir, "download_video", "success", video_path=relative_or_abs(video_path))
    print(run_dir)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
