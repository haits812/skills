#!/usr/bin/env python3
from __future__ import annotations

import argparse
import html
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

from lib.harness_common import append_log, ensure_dir, load_json, relative_or_abs, resolve_run_dir, stage_path, write_json, write_text


def rel_to_run(run_dir: Path, path: Path) -> str:
    try:
        return str(path.relative_to(run_dir))
    except ValueError:
        return str(path)


def image_items(run_dir: Path) -> dict[str, dict]:
    manifest = load_json(stage_path(run_dir, "07_storyboard_images_manifest.json"))
    by_scene: dict[str, dict] = {}
    prompts = load_json(stage_path(run_dir, "06_image_prompts.json")).get("prompts", [])
    prompt_by_image = {p["image_id"]: p for p in prompts}
    for item in manifest.get("images", []):
        image_id = item["image_id"]
        prompt = prompt_by_image.get(image_id, {})
        by_scene[prompt.get("scene_id", image_id)] = {**item, "prompt": prompt}
    return by_scene


def make_contact_sheet(run_dir: Path, scenes: list[dict], output_path: Path, cols: int = 3, thumb_width: int = 260) -> Path | None:
    images: list[tuple[dict, Image.Image]] = []
    for scene in scenes:
        image_path = scene.get("image_path")
        if not image_path:
            continue
        path = Path(image_path)
        if not path.is_absolute():
            path = run_dir / path
        if not path.exists() or not path.is_file():
            continue
        with Image.open(path) as img:
            img = img.convert("RGB")
            ratio = thumb_width / img.width
            thumb = img.resize((thumb_width, int(img.height * ratio)))
            images.append((scene, thumb))

    if not images:
        return None

    label_height = 70
    gap = 18
    rows = (len(images) + cols - 1) // cols
    thumb_height = max(img.height for _, img in images)
    sheet_width = cols * thumb_width + (cols + 1) * gap
    sheet_height = rows * (thumb_height + label_height) + (rows + 1) * gap
    sheet = Image.new("RGB", (sheet_width, sheet_height), "#f7f7f4")
    draw = ImageDraw.Draw(sheet)
    font = ImageFont.load_default()

    for index, (scene, img) in enumerate(images):
        row = index // cols
        col = index % cols
        x = gap + col * (thumb_width + gap)
        y = gap + row * (thumb_height + label_height + gap)
        sheet.paste(img, (x, y))
        text_y = y + thumb_height + 8
        label = f"{scene.get('scene_id', '')} / {scene.get('image_id', '')}"
        takeaway = f"duration {scene.get('duration_sec', '')}s / shots {len(scene.get('source_shot_refs', []))}"
        draw.text((x, text_y), label[:42], fill="#1c1c1c", font=font)
        draw.text((x, text_y + 18), takeaway[:42], fill="#555555", font=font)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    sheet.save(output_path)
    return output_path


def tags(items: list[str], *, empty: str = "none") -> str:
    if not items:
        return f'<span class="muted">{html.escape(empty)}</span>'
    return "".join(f'<span class="tag">{html.escape(str(item))}</span>' for item in items)


def plain(items: list[str], *, empty: str = "none") -> str:
    return html.escape(" / ".join(str(item) for item in items)) if items else f'<span class="muted">{html.escape(empty)}</span>'


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", type=Path)
    parser.add_argument("--run-id")
    parser.add_argument("--allow-missing-images", action="store_true")
    args = parser.parse_args()

    run_dir = resolve_run_dir(args)
    storyboard_dir = ensure_dir(run_dir / "storyboard")
    append_log(run_dir, "build_storyboard_board", "start")

    plan = load_json(stage_path(run_dir, "05_storyboard_plan.json"))
    images = image_items(run_dir)

    scenes = []
    md_parts = [f"# {plan.get('title', 'Storyboard')}", "", plan.get("concept", ""), ""]
    html_cards = []
    for scene in plan.get("scenes", []):
        scene_id = scene["scene_id"]
        image_info = images.get(scene_id, {})
        image_id = image_info.get("image_id") or f"{scene_id}_missing"
        raw_image_path = image_info.get("image_path") or ""
        image_path = Path(raw_image_path) if raw_image_path else Path()
        exists = False
        if raw_image_path:
            if image_path.is_absolute():
                exists = image_path.exists() and image_path.is_file()
            else:
                image_path = (run_dir / image_path).resolve()
                exists = image_path.exists() and image_path.is_file()
        if not exists and not args.allow_missing_images:
            raise FileNotFoundError(f"Storyboard image missing for {scene_id}: {image_info.get('image_path')}")
        display_path = rel_to_run(run_dir, image_path) if exists else ""
        overlay = image_info.get("prompt", {}).get("overlay_text_later", [])
        review_focus = image_info.get("prompt", {}).get("review_focus", [])
        source_refs = scene.get("source_refs", image_info.get("prompt", {}).get("source_refs", []))
        source_shot_refs = scene.get("source_shot_refs", image_info.get("prompt", {}).get("source_shot_refs", []))
        assumption_ids = scene.get("assumption_ids", image_info.get("prompt", {}).get("assumption_ids", []))
        scenes.append({
            "scene_id": scene_id,
            "image_id": image_id,
            "image_path": display_path,
            "role": scene.get("role", ""),
            "duration_sec": scene.get("duration_sec", 0),
            "viewer_takeaway": scene.get("viewer_takeaway", ""),
            "overlay_text_later": overlay,
            "review_focus": review_focus,
            "source_refs": source_refs,
            "source_shot_refs": source_shot_refs,
            "assumption_ids": assumption_ids,
        })
        md_parts.extend([
            f"## {scene_id}: {scene.get('role', '')}",
            f"![{image_id}]({display_path})" if display_path else "_image missing_",
            f"- duration: {scene.get('duration_sec', '')} sec",
            f"- viewer_takeaway: {scene.get('viewer_takeaway', '')}",
            f"- overlay_text_later: {', '.join(overlay)}",
            f"- source_refs: {', '.join(source_refs)}",
            f"- source_shot_refs: {', '.join(source_shot_refs)}",
            f"- assumption_ids: {', '.join(assumption_ids)}",
            "",
        ])
        img_html = f'<img src="../{html.escape(display_path)}" alt="{html.escape(image_id)}">' if display_path else '<div class="missing">image missing</div>'
        html_cards.append(f"""
<article class="scene">
  <div class="media">{img_html}</div>
  <div class="body">
    <div class="scene-head">
      <div>
        <div class="eyebrow">{html.escape(scene_id)}</div>
        <h2>{html.escape(scene.get('role', ''))}</h2>
      </div>
      <div class="duration">{html.escape(str(scene.get('duration_sec', '')))}s</div>
    </div>
    <div class="takeaway">{html.escape(scene.get('viewer_takeaway', ''))}</div>
    <div class="quick">
      <span>Overlay: {plain(overlay)}</span>
      <span>Shots: {len(source_shot_refs)}</span>
    </div>
    <details class="details">
      <summary>詳細を見る</summary>
      <dl class="facts">
        <div>
          <dt>Visual</dt>
          <dd>{html.escape(scene.get('visual_direction', '') or '画像未生成シーンは字コンテを確認')}</dd>
        </div>
        <div>
          <dt>Review Focus</dt>
          <dd class="tag-row">{tags(review_focus)}</dd>
        </div>
        <div>
          <dt>Source Shots</dt>
          <dd class="tag-row">{tags(source_shot_refs)}</dd>
        </div>
        <div>
          <dt>Assumptions</dt>
          <dd class="tag-row">{tags(assumption_ids)}</dd>
        </div>
      </dl>
    </details>
  </div>
</article>
""")

    contact_sheet = make_contact_sheet(run_dir, scenes, storyboard_dir / "08_storyboard_contact_sheet.png")

    board = {
        "run_id": run_dir.name,
        "title": plan.get("title", ""),
        "scenes": scenes,
        "board_files": {
            "html": relative_or_abs(storyboard_dir / "08_storyboard_board.html"),
            "markdown": relative_or_abs(storyboard_dir / "08_storyboard_board.md"),
            "json": relative_or_abs(storyboard_dir / "08_storyboard_board.json"),
            "contact_sheet": relative_or_abs(contact_sheet) if contact_sheet else "",
        },
    }
    html_text = f"""<!doctype html>
<html lang="ja">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{html.escape(board["title"])}</title>
  <style>
    :root {{ color-scheme: light; }}
    body {{ margin: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; background: #f5f5f2; color: #1c1c1c; }}
    header {{ padding: 18px 28px 12px; border-bottom: 1px solid #ddd; background: rgba(255,255,255,.96); position: sticky; top: 0; z-index: 2; }}
    h1 {{ margin: 0 0 6px; font-size: 22px; line-height: 1.25; }}
    header div {{ color: #666; font-size: 13px; }}
    main {{ max-width: 1240px; margin: 0 auto; padding: 12px 16px 20px; display: grid; gap: 8px; }}
    .scene {{ display: grid; grid-template-columns: 136px minmax(0, 1fr); gap: 12px; background: white; border: 1px solid #ddd; border-radius: 8px; padding: 10px; align-items: start; }}
    .media {{ width: 136px; }}
    .media img {{ width: 100%; height: 242px; object-fit: cover; border-radius: 6px; background: #eee; display: block; }}
    .missing {{ width: 100%; height: 242px; display: grid; place-items: center; background: #eee; border-radius: 6px; color: #777; font-size: 13px; }}
    .body {{ min-width: 0; display: grid; gap: 10px; }}
    .scene-head {{ display: flex; justify-content: space-between; gap: 12px; align-items: start; padding-bottom: 6px; border-bottom: 1px solid #eee; }}
    .eyebrow {{ color: #667; font-size: 12px; margin-bottom: 3px; }}
    h2 {{ margin: 0; font-size: 17px; line-height: 1.3; }}
    .duration {{ flex: 0 0 auto; border: 1px solid #d7d7d1; border-radius: 999px; padding: 4px 10px; font-size: 12px; color: #444; background: #fafaf8; }}
    .takeaway {{ font-size: 14px; line-height: 1.5; font-weight: 650; }}
    .quick {{ display: flex; flex-wrap: wrap; gap: 6px; color: #555; font-size: 12px; }}
    .quick span {{ border: 1px solid #e3e3dd; border-radius: 999px; background: #fafaf8; padding: 3px 8px; }}
    .details {{ border-top: 1px solid #eee; padding-top: 6px; }}
    .details > summary {{ cursor: pointer; color: #4f584e; font-size: 13px; font-weight: 700; user-select: none; }}
    .details[open] > summary {{ margin-bottom: 8px; }}
    .facts {{ display: grid; gap: 8px; margin: 0; }}
    .facts > div {{ display: grid; grid-template-columns: 132px minmax(0, 1fr); gap: 12px; padding: 8px 0; border-top: 1px solid #f0f0ec; }}
    .facts > div:first-child {{ border-top: 0; padding-top: 0; }}
    dt {{ font-size: 12px; color: #68685f; font-weight: 700; }}
    dd {{ margin: 0; min-width: 0; font-size: 13px; line-height: 1.55; color: #2a2a27; }}
    .tag-row {{ display: flex; flex-wrap: wrap; gap: 5px; align-items: center; }}
    .tag {{ display: inline-flex; max-width: 100%; border: 1px solid #ddd; background: #fafaf8; border-radius: 999px; padding: 2px 7px; font-size: 11px; line-height: 1.45; color: #484844; overflow-wrap: anywhere; }}
    .muted {{ color: #8b8b82; }}
    @media (max-width: 860px) {{
      header {{ position: static; padding: 16px; }}
      main {{ padding: 12px; }}
      .scene {{ grid-template-columns: 112px minmax(0, 1fr); gap: 10px; }}
      .media {{ width: 112px; }}
      .media img, .missing {{ height: 199px; }}
      .facts > div {{ grid-template-columns: 1fr; gap: 4px; }}
    }}
    @media (max-width: 560px) {{
      .scene {{ grid-template-columns: 1fr; }}
      .media {{ width: min(220px, 100%); }}
      .media img, .missing {{ height: auto; aspect-ratio: 9 / 16; }}
    }}
  </style>
</head>
<body>
<header>
  <h1>{html.escape(board["title"])}</h1>
  <div>run: {html.escape(run_dir.name)} / storyboard</div>
</header>
<main>
{''.join(html_cards)}
</main>
</body>
</html>
"""
    write_json(storyboard_dir / "08_storyboard_board.json", board)
    write_text(storyboard_dir / "08_storyboard_board.md", "\n".join(md_parts))
    write_text(storyboard_dir / "08_storyboard_board.html", html_text)
    append_log(run_dir, "build_storyboard_board", "success", scene_count=len(scenes))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
