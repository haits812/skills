# Codex Entry

このフォルダで動画制作Skillを使う場合は、まず `SKILL.md` を読む。

Codex固有の長い手順をここに増やさない。Claude Codeと同じSkill定義を参照し、必要な文脈だけ `contexts/` と `agent-tools/` から読む。

