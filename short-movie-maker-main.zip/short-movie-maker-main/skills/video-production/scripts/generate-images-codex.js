#!/usr/bin/env node
/**
 * 画像生成スクリプト（Codex imagegen 版・Google API キー不要）
 *
 * generate-images.js の Gemini 依存を外し、Codex CLI の `imagegen` スキルに
 * 画像を作らせる。出力契約は Gemini 版と同一:
 *   - public/runs/{run名}/images/{scene.id}.png を生成
 *   - scenes.json の各シーンに scene.image = {path, width, height} を追記
 *
 * Usage: node scripts/generate-images-codex.js <run名> [--force]
 * 前提: `codex` CLI がインストール済み、imagegen スキル利用可能。
 */

const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const PER_IMAGE_TIMEOUT_MS = 600000; // 10 分/枚

const styleByLayout = {
  'main-insert': 'Clean professional illustration, simple composition suitable as a side image, high contrast for video overlay.',
  'main-board': 'Educational whiteboard/diagram style, simple and clear, light background.',
  'main-fullimage': 'Cinematic full-screen image, high impact, good contrast in the lower area for text overlay.'
};

function buildPrompt(imagePrompt, layout, targetPath) {
  const style = styleByLayout[layout] || 'Clean professional illustration.';
  return [
    'Use the `imagegen` skill to generate exactly ONE image for a YouTube explainer video.',
    `Aspect ratio 16:9. Style: ${style}`,
    'IMPORTANT: do NOT render any text, letters, or logos inside the image.',
    `Content to depict: ${imagePrompt}`,
    `Save the final PNG to exactly this absolute path (overwrite if it exists): ${targetPath}`,
    'Do not create any other files. When done, reply with just the saved path.'
  ].join('\n');
}

function runCodexImage(prompt, cwd, resultFile) {
  execFileSync('codex', [
    'exec',
    '--skip-git-repo-check',
    '--sandbox', 'workspace-write',
    '-C', cwd,
    '-o', resultFile,
    prompt
  ], { stdio: 'inherit', timeout: PER_IMAGE_TIMEOUT_MS });
}

function main() {
  const runName = process.argv[2];
  const force = process.argv.includes('--force');
  if (!runName) {
    console.error('Usage: node scripts/generate-images-codex.js <run名> [--force]');
    process.exit(1);
  }

  const baseDir = path.join(__dirname, '..');
  const scenesPath = path.join(baseDir, 'runs', runName, 'scenes.json');
  const outputDir = path.join(baseDir, 'public', 'runs', runName, 'images');
  if (!fs.existsSync(scenesPath)) {
    console.error(`Error: scenes.json not found at ${scenesPath}`);
    process.exit(1);
  }
  fs.mkdirSync(outputDir, { recursive: true });

  const scenesData = JSON.parse(fs.readFileSync(scenesPath, 'utf-8'));
  const scenesNeedingImages = scenesData.scenes.filter(s => s.needsImage && s.imagePrompt);
  console.log(`Found ${scenesNeedingImages.length} scenes needing images (Codex imagegen)\n`);

  const failures = [];
  let successCount = 0;

  for (const scene of scenesNeedingImages) {
    const imagePath = path.join(outputDir, `${scene.id}.png`);
    if (fs.existsSync(imagePath) && !force) {
      console.log(`[${scene.id}] exists, skip (use --force to regenerate)`);
      scene.image = { path: `runs/${runName}/images/${scene.id}.png`, width: 1920, height: 1080 };
      successCount++;
      continue;
    }
    console.log(`[${scene.id}] Generating via Codex imagegen...`);
    const resultFile = path.join(outputDir, `${scene.id}.codex_result.txt`);
    try {
      runCodexImage(buildPrompt(scene.imagePrompt, scene.layout, imagePath), outputDir, resultFile);
    } catch (e) {
      console.log(`  codex exec error: ${e.message}`);
    }
    if (fs.existsSync(imagePath) && fs.statSync(imagePath).size > 0) {
      console.log(`  ✓ Saved: ${scene.id}.png`);
      scene.image = { path: `runs/${runName}/images/${scene.id}.png`, width: 1920, height: 1080 };
      successCount++;
    } else {
      console.log(`  ✗ No image produced for ${scene.id}`);
      failures.push(scene.id);
    }
  }

  fs.writeFileSync(scenesPath, JSON.stringify(scenesData, null, 2));
  console.log(`\n=== 画像生成完了 (Codex) ===`);
  console.log(`成功: ${successCount}/${scenesNeedingImages.length}`);
  if (failures.length) console.log(`失敗: ${failures.join(', ')}`);
  console.log(`Output: ${outputDir}`);
}

main();
