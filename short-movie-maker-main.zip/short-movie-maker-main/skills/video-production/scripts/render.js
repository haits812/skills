#!/usr/bin/env node
/**
 * 動画レンダリングスクリプト
 *
 * Usage: node scripts/render.js <run名> [--preview]
 * Example:
 *   node scripts/render.js nisa           # 本番品質
 *   node scripts/render.js nisa --preview # プレビュー品質
 *
 * 必須: runs/{run名}/composition.json
 * 出力: runs/{run名}/output/video.mp4
 */

const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

function main() {
  const args = process.argv.slice(2);
  const runName = args.find(a => !a.startsWith('--'));
  const isPreview = args.includes('--preview');

  if (!runName) {
    console.error('Usage: node scripts/render.js <run名> [--preview]');
    process.exit(1);
  }

  const baseDir = path.join(__dirname, '..');
  const compositionPath = path.join(baseDir, 'runs', runName, 'composition.json');

  if (!fs.existsSync(compositionPath)) {
    console.error(`Error: composition.json not found`);
    console.error('Run generate-composition.js first.');
    process.exit(1);
  }

  // Create output directory
  const outputDir = path.join(baseDir, 'runs', runName, 'output');
  fs.mkdirSync(outputDir, { recursive: true });

  const outputPath = path.join(outputDir, 'video.mp4');
  const crf = isPreview ? 28 : 18;
  const scale = isPreview ? 0.5 : 1;

  console.log(`Rendering: ${runName} (${isPreview ? 'preview' : 'production'} quality)`);

  const cmd = [
    'npx remotion render',
    'src/remotion/index.ts',
    'ExplainerVideo',
    `--props=runs/${runName}/composition.json`,
    `--output=runs/${runName}/output/video.mp4`,
    '--codec=h264',
    `--crf=${crf}`,
    `--scale=${scale}`
  ].join(' ');

  try {
    execSync(cmd, { cwd: baseDir, stdio: 'inherit' });
    console.log(`\nOutput: ${outputPath}`);
  } catch (e) {
    console.error('Render failed');
    process.exit(1);
  }
}

main();
