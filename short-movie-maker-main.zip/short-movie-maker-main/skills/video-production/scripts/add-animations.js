#!/usr/bin/env node
/**
 * アニメーション追加スクリプト
 *
 * Usage: node scripts/add-animations.js <run名>
 * Example: node scripts/add-animations.js nisa
 *
 * 更新: runs/{run名}/scenes.json の各シーンに telop.animation を追加
 */

const fs = require('fs');
const path = require('path');

// レイアウト別デフォルトアニメーション
const LAYOUT_ANIMATIONS = {
  'intro': { in: 'scale', out: 'fade' },
  'main-insert': { in: 'slide_left', out: 'fade' },
  'main-lecture': { in: 'fade', out: 'fade' },
  'main-board': { in: 'slide_left', out: 'fade' },
  'main-fullimage': { in: 'fade', out: 'fade' },
  'outro': { in: 'fade', out: 'fade' },
  'cta': { in: 'pop', out: 'fade' }
};

function main() {
  const runName = process.argv[2];
  if (!runName) {
    console.error('Usage: node scripts/add-animations.js <run名>');
    process.exit(1);
  }

  const baseDir = path.join(__dirname, '..');
  const scenesPath = path.join(baseDir, 'runs', runName, 'scenes.json');

  if (!fs.existsSync(scenesPath)) {
    console.error(`Error: scenes.json not found`);
    process.exit(1);
  }

  const scenesData = JSON.parse(fs.readFileSync(scenesPath, 'utf-8'));

  for (const scene of scenesData.scenes) {
    if (scene.telop && !scene.telop.animation) {
      scene.telop.animation = LAYOUT_ANIMATIONS[scene.layout] || { in: 'fade', out: 'fade' };
    }
  }

  fs.writeFileSync(scenesPath, JSON.stringify(scenesData, null, 2));
  console.log(`Updated: ${scenesPath}`);
}

main();
