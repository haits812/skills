#!/usr/bin/env node
/**
 * composition.json 生成スクリプト
 *
 * Usage: node scripts/generate-composition.js <run名>
 * Example: node scripts/generate-composition.js nisa
 *
 * 必須: runs/{run名}/scenes.json, voice-meta.json
 * 出力: runs/{run名}/composition.json (Remotion用)
 */

const fs = require('fs');
const path = require('path');

const FPS = 30;

function main() {
  const runName = process.argv[2];
  if (!runName) {
    console.error('Usage: node scripts/generate-composition.js <run名>');
    process.exit(1);
  }

  const baseDir = path.join(__dirname, '..');

  // Load scenes
  const scenesPath = path.join(baseDir, 'runs', runName, 'scenes.json');
  if (!fs.existsSync(scenesPath)) {
    console.error(`Error: scenes.json not found`);
    process.exit(1);
  }
  const scenesData = JSON.parse(fs.readFileSync(scenesPath, 'utf-8'));

  // Load voice-meta
  const voiceMetaPath = path.join(baseDir, 'runs', runName, 'voice-meta.json');
  if (!fs.existsSync(voiceMetaPath)) {
    console.error(`Error: voice-meta.json not found`);
    process.exit(1);
  }
  const voiceMeta = JSON.parse(fs.readFileSync(voiceMetaPath, 'utf-8'));

  // Load style template
  const stylePath = path.join(baseDir, 'templates', 'default-style.json');
  if (!fs.existsSync(stylePath)) {
    console.error(`Error: default-style.json not found`);
    process.exit(1);
  }
  const style = JSON.parse(fs.readFileSync(stylePath, 'utf-8'));

  // Build composition
  const composition = {
    meta: {
      title: scenesData.title,
      fps: FPS,
      width: 1920,
      height: 1080,
      durationInFrames: scenesData.meta.totalFrames
    },
    scenes: scenesData.scenes.map(scene => ({
      id: scene.id,
      layout: scene.layout,
      startFrame: scene.startFrame,
      endFrame: scene.endFrame,
      telop: {
        ...scene.telop,
        emphasis: scene.telop?.emphasis || [],
        animation: scene.telop?.animation || { in: 'scale', out: 'fade' }
      },
      image: scene.image ? {
        path: scene.image.path,
        width: scene.image.width,
        height: scene.image.height,
        animation: { in: 'scale', out: 'fade' }
      } : undefined,
      subtitle: {
        text: scene.text,
        animation: 'fadeSlide'
      },
      transition: { type: 'fade', durationFrames: 15 },
      bullets: scene.bullets
    })),
    audio: {
      voice: voiceMeta.tracks.map((track, i) => {
        const scene = scenesData.scenes[i];
        return {
          sceneId: track.sceneId,
          path: `runs/${runName}/audio/${track.sceneId}.wav`,
          startFrame: scene.voiceStartFrame,
          durationFrames: scene.voiceDurationFrames
        };
      })
    },
    style
  };

  const outputPath = path.join(baseDir, 'runs', runName, 'composition.json');
  fs.writeFileSync(outputPath, JSON.stringify(composition, null, 2));

  console.log(`Generated: ${outputPath}`);
  console.log(`Duration: ${(composition.meta.durationInFrames / FPS).toFixed(2)}s`);
}

main();
