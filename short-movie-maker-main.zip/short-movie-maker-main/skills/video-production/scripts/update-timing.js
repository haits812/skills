#!/usr/bin/env node
/**
 * タイミング更新スクリプト
 *
 * Usage: node scripts/update-timing.js <run名>
 * Example: node scripts/update-timing.js nisa
 *
 * 必須: runs/{run名}/voice-meta.json が存在すること
 * 更新: runs/{run名}/scenes.json のフレーム情報を音声長に基づいて更新
 *
 * 設定: config.json の timing セクションで上書き可能
 *   - fps: フレームレート（デフォルト: 30）
 *   - voiceStartDelayFrames: 音声開始までの遅延フレーム（デフォルト: 3）
 *   - scenePaddingFrames: シーン終了後の余白フレーム（デフォルト: 6）
 */

const fs = require('fs');
const path = require('path');

// デフォルト設定
const DEFAULT_TIMING = {
  fps: 30,
  voiceStartDelayFrames: 3,
  scenePaddingFrames: 6
};

function main() {
  const runName = process.argv[2];
  if (!runName) {
    console.error('Usage: node scripts/update-timing.js <run名>');
    process.exit(1);
  }

  const baseDir = path.join(__dirname, '..');

  // Load config (optional timing settings)
  const configPath = path.join(baseDir, 'runs', runName, 'config.json');
  let config = {};
  if (fs.existsSync(configPath)) {
    config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
  }

  // Merge timing settings with defaults
  const timing = { ...DEFAULT_TIMING, ...config.timing };
  const FPS = timing.fps;
  const VOICE_START_DELAY_FRAMES = timing.voiceStartDelayFrames;
  const SCENE_PADDING_FRAMES = timing.scenePaddingFrames;

  // Load voice-meta
  const voiceMetaPath = path.join(baseDir, 'runs', runName, 'voice-meta.json');
  if (!fs.existsSync(voiceMetaPath)) {
    console.error(`Error: voice-meta.json not found at ${voiceMetaPath}`);
    console.error('Run generate-voice.js first.');
    process.exit(1);
  }
  const voiceMeta = JSON.parse(fs.readFileSync(voiceMetaPath, 'utf-8'));

  // Load scenes
  const scenesPath = path.join(baseDir, 'runs', runName, 'scenes.json');
  if (!fs.existsSync(scenesPath)) {
    console.error(`Error: scenes.json not found at ${scenesPath}`);
    process.exit(1);
  }
  const scenesData = JSON.parse(fs.readFileSync(scenesPath, 'utf-8'));

  // Create duration map
  const durationMap = {};
  for (const track of voiceMeta.tracks) {
    durationMap[track.sceneId] = track.durationSec;
  }

  let currentFrame = 0;

  for (const scene of scenesData.scenes) {
    const durationSec = durationMap[scene.id] || 3;
    const voiceDurationFrames = Math.ceil(durationSec * FPS);

    scene.startFrame = currentFrame;
    scene.voiceStartFrame = currentFrame + VOICE_START_DELAY_FRAMES;
    scene.voiceDurationFrames = voiceDurationFrames;
    scene.endFrame = currentFrame + VOICE_START_DELAY_FRAMES + voiceDurationFrames + SCENE_PADDING_FRAMES;

    // Update pages with frame timing (relative to voice start)
    if (scene.telop?.pages) {
      const textLength = scene.text.length;
      for (const page of scene.telop.pages) {
        const startRatio = page.startCharIndex / textLength;
        const endRatio = page.endCharIndex / textLength;
        // ページのフレームは音声開始（voiceStartFrame）からの相対位置
        page.startFrame = VOICE_START_DELAY_FRAMES + Math.round(startRatio * voiceDurationFrames);
        page.endFrame = VOICE_START_DELAY_FRAMES + Math.round(endRatio * voiceDurationFrames);
      }
    }

    currentFrame = scene.endFrame;
  }

  scenesData.meta.totalFrames = currentFrame;
  scenesData.meta.totalDuration = currentFrame / FPS;
  scenesData.meta.fps = FPS;

  fs.writeFileSync(scenesPath, JSON.stringify(scenesData, null, 2));

  console.log(`Updated: ${scenesPath}`);
  console.log(`Total frames: ${currentFrame} (${(currentFrame / FPS).toFixed(2)}s)`);
}

main();
