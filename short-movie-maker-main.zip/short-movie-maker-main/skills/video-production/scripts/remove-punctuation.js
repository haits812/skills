#!/usr/bin/env node
/**
 * 句読点削除スクリプト
 *
 * Usage: node scripts/remove-punctuation.js <run名>
 *
 * 必須: runs/{run名}/scenes.json が存在すること（page-splitter実行後）
 * 更新: scenes.json の pages.lines から句読点を削除
 *
 * 削除対象: 。、・：；
 * 保持: ！？(感情を伝えるテロップ表現として残す)、カッコ類、ー〜…、英数字の句読点
 */

const fs = require('fs');
const path = require('path');

const runName = process.argv[2];

if (!runName) {
  console.error('Usage: node scripts/remove-punctuation.js <run名>');
  process.exit(1);
}

const baseDir = path.resolve(__dirname, '..');
const scenesPath = path.join(baseDir, 'runs', runName, 'scenes.json');

if (!fs.existsSync(scenesPath)) {
  console.error(`Error: ${scenesPath} not found`);
  process.exit(1);
}

// 削除対象の句読点
const punctuationToRemove = /[。、・：；]/g;

function removePunctuation(lines) {
  return lines.map(line => line.replace(punctuationToRemove, ''));
}

// scenes.json読み込み
const scenes = JSON.parse(fs.readFileSync(scenesPath, 'utf-8'));

let removedCount = 0;

// 各シーンのpagesから句読点を削除
scenes.scenes.forEach(scene => {
  if (scene.telop && scene.telop.pages) {
    scene.telop.pages.forEach(page => {
      const original = page.lines.join('');
      page.lines = removePunctuation(page.lines);
      const cleaned = page.lines.join('');
      if (original !== cleaned) {
        removedCount++;
      }
    });
  }
});

// 保存
fs.writeFileSync(scenesPath, JSON.stringify(scenes, null, 2) + '\n');
console.log(`Updated: ${scenesPath}`);
console.log(`Removed punctuation from ${removedCount} pages`);
