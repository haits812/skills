#!/usr/bin/env node
/**
 * ElevenLabs STT タイミング抽出スクリプト
 *
 * Usage: node scripts/extract-timing-stt.js <run名>
 * Example: node scripts/extract-timing-stt.js investment-basics
 *
 * 必須:
 *   - .env に ELEVEN_API_KEY を設定
 *   - runs/{run名}/scenes.json に telop.pages が存在（page-splitter実行後）
 *   - public/runs/{run名}/audio/ に音声ファイルが存在
 *
 * 処理:
 *   1. 各シーンの音声を ElevenLabs STT で文字起こし
 *   2. LCS アルゴリズムで元台本とマッチング
 *   3. pages に正確な startFrame/endFrame を追加
 *
 * 参照: services/worker/features/stt/transcribe.py
 */

const fs = require('fs');
const path = require('path');
const FormData = require('form-data');
const axios = require('axios');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });

const ELEVEN_API_KEY = process.env.ELEVEN_API_KEY;
const ELEVEN_API_URL = 'https://api.elevenlabs.io/v1/speech-to-text';

// デフォルトタイミング設定
const DEFAULT_TIMING = {
  fps: 30,
  voiceStartDelayFrames: 3,
  scenePaddingFrames: 6
};

/**
 * ElevenLabs STT API で音声を文字起こし（単語レベルタイムスタンプ付き）
 * 参照: services/worker/features/stt/transcribe.py の _call_elevenlabs_api
 */
async function transcribeWithTimestamps(audioPath) {
  const formData = new FormData();

  // ファイルを追加（Pythonの files={"file": (name, fp, "audio/wav")} と同等）
  formData.append('file', fs.createReadStream(audioPath), {
    filename: path.basename(audioPath),
    contentType: 'audio/wav'
  });

  // データを追加（Pythonの data={...} と同等）
  formData.append('model_id', 'scribe_v1');
  formData.append('timestamps_granularity', 'word');
  formData.append('language_code', 'ja');

  const response = await axios.post(ELEVEN_API_URL, formData, {
    headers: {
      'xi-api-key': ELEVEN_API_KEY,
      'Accept': 'application/json',
      ...formData.getHeaders()
    },
    timeout: 60000
  });

  return response.data;
}

/**
 * テキストをひらがなに正規化（比較用）
 */
function normalizeText(text) {
  // カタカナをひらがなに変換
  let normalized = text.replace(/[\u30A1-\u30F6]/g, (match) => {
    return String.fromCharCode(match.charCodeAt(0) - 0x60);
  });
  // 記号・空白を除去
  normalized = normalized.replace(/[。、！？・：；\s\n]/g, '');
  // 小文字化
  normalized = normalized.toLowerCase();
  return normalized;
}

/**
 * STT結果の単語を文字単位に展開し、タイムスタンプを補間
 */
function expandWordsToChars(words) {
  const chars = [];
  for (const word of words) {
    const text = word.text || word.word || '';
    const start = word.start;
    const end = word.end;
    const charDuration = (end - start) / text.length;

    for (let i = 0; i < text.length; i++) {
      chars.push({
        char: text[i],
        normalizedChar: normalizeText(text[i]),
        start: start + i * charDuration,
        end: start + (i + 1) * charDuration
      });
    }
  }
  return chars;
}

/**
 * LCS (最長共通部分列) でマッチング
 * 元台本の各文字がSTT結果のどの位置に対応するかを計算
 */
function lcsMatch(originalText, sttChars) {
  const normOriginal = normalizeText(originalText);
  const n = normOriginal.length;
  const m = sttChars.length;

  // DP テーブル
  const dp = Array(n + 1).fill(null).map(() => Array(m + 1).fill(0));

  for (let i = 1; i <= n; i++) {
    for (let j = 1; j <= m; j++) {
      if (normOriginal[i - 1] === sttChars[j - 1].normalizedChar) {
        dp[i][j] = dp[i - 1][j - 1] + 1;
      } else {
        dp[i][j] = Math.max(dp[i - 1][j], dp[i][j - 1]);
      }
    }
  }

  // バックトラックでマッチング結果を取得
  const matches = [];
  let i = n, j = m;
  while (i > 0 && j > 0) {
    if (normOriginal[i - 1] === sttChars[j - 1].normalizedChar) {
      matches.unshift({ origIndex: i - 1, sttIndex: j - 1 });
      i--;
      j--;
    } else if (dp[i - 1][j] > dp[i][j - 1]) {
      i--;
    } else {
      j--;
    }
  }

  return matches;
}

/**
 * ページごとのタイムスタンプを計算
 */
function calculatePageTimestamps(pages, originalText, sttResult, voiceStartDelayFrames, fps) {
  if (!sttResult.words || sttResult.words.length === 0) {
    console.warn('  No words in STT result, using fallback');
    return calculateFallbackTimestamps(pages, originalText, sttResult.text?.length || originalText.length, voiceStartDelayFrames, fps);
  }

  const sttChars = expandWordsToChars(sttResult.words);
  const matches = lcsMatch(originalText, sttChars);

  if (matches.length === 0) {
    console.warn('  No LCS matches, using fallback');
    return calculateFallbackTimestamps(pages, originalText, sttResult.text?.length || originalText.length, voiceStartDelayFrames, fps);
  }

  // マッチ率を計算
  const matchRate = matches.length / normalizeText(originalText).length;
  console.log(`  Match rate: ${(matchRate * 100).toFixed(1)}%`);

  // 各文字のタイムスタンプを補間
  const charTimestamps = new Array(originalText.length).fill(null);

  for (const match of matches) {
    charTimestamps[match.origIndex] = {
      start: sttChars[match.sttIndex].start,
      end: sttChars[match.sttIndex].end
    };
  }

  // 前後から補間
  let lastKnown = { start: 0, end: 0 };
  for (let i = 0; i < charTimestamps.length; i++) {
    if (charTimestamps[i]) {
      lastKnown = charTimestamps[i];
    } else {
      // 次のknownを探す
      let nextKnown = null;
      for (let j = i + 1; j < charTimestamps.length; j++) {
        if (charTimestamps[j]) {
          nextKnown = charTimestamps[j];
          break;
        }
      }
      if (nextKnown) {
        // 線形補間
        const ratio = (i - (matches.findIndex(m => charTimestamps[m.origIndex] === lastKnown) || 0)) /
                      ((matches.findIndex(m => charTimestamps[m.origIndex] === nextKnown) || 1) - (matches.findIndex(m => charTimestamps[m.origIndex] === lastKnown) || 0) || 1);
        charTimestamps[i] = {
          start: lastKnown.end + (nextKnown.start - lastKnown.end) * ratio,
          end: lastKnown.end + (nextKnown.start - lastKnown.end) * ratio + 0.05
        };
      } else {
        charTimestamps[i] = { start: lastKnown.end, end: lastKnown.end + 0.05 };
      }
    }
  }

  // ページにタイムスタンプを割り当て
  const updatedPages = pages.map(page => {
    const startChar = page.startCharIndex;
    const endChar = page.endCharIndex - 1;

    const startTime = charTimestamps[startChar]?.start || 0;
    const endTime = charTimestamps[Math.min(endChar, charTimestamps.length - 1)]?.end || startTime + 0.5;

    return {
      ...page,
      startFrame: voiceStartDelayFrames + Math.round(startTime * fps),
      endFrame: voiceStartDelayFrames + Math.round(endTime * fps)
    };
  });

  return updatedPages;
}

/**
 * フォールバック: 比例計算でタイムスタンプを計算
 */
function calculateFallbackTimestamps(pages, originalText, durationSec, voiceStartDelayFrames, fps) {
  const textLength = originalText.length;
  const voiceDurationFrames = Math.round(durationSec * fps);

  return pages.map(page => {
    const startRatio = page.startCharIndex / textLength;
    const endRatio = page.endCharIndex / textLength;

    return {
      ...page,
      startFrame: voiceStartDelayFrames + Math.round(startRatio * voiceDurationFrames),
      endFrame: voiceStartDelayFrames + Math.round(endRatio * voiceDurationFrames)
    };
  });
}

async function main() {
  const runName = process.argv[2];
  if (!runName) {
    console.error('Usage: node scripts/extract-timing-stt.js <run名>');
    process.exit(1);
  }

  if (!ELEVEN_API_KEY) {
    console.error('Error: ELEVEN_API_KEY not set in .env');
    process.exit(1);
  }

  const baseDir = path.join(__dirname, '..');

  // Load config
  const configPath = path.join(baseDir, 'runs', runName, 'config.json');
  let config = {};
  if (fs.existsSync(configPath)) {
    config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
  }
  const timing = { ...DEFAULT_TIMING, ...config.timing };
  const fps = timing.fps;
  const voiceStartDelayFrames = timing.voiceStartDelayFrames;
  const scenePaddingFrames = timing.scenePaddingFrames;

  // Load scenes
  const scenesPath = path.join(baseDir, 'runs', runName, 'scenes.json');
  if (!fs.existsSync(scenesPath)) {
    console.error(`Error: scenes.json not found at ${scenesPath}`);
    process.exit(1);
  }
  const scenesData = JSON.parse(fs.readFileSync(scenesPath, 'utf-8'));

  // Load voice-meta
  const voiceMetaPath = path.join(baseDir, 'runs', runName, 'voice-meta.json');
  if (!fs.existsSync(voiceMetaPath)) {
    console.error(`Error: voice-meta.json not found at ${voiceMetaPath}`);
    process.exit(1);
  }
  const voiceMeta = JSON.parse(fs.readFileSync(voiceMetaPath, 'utf-8'));

  // Create duration map
  const durationMap = {};
  for (const track of voiceMeta.tracks) {
    durationMap[track.sceneId] = track.durationSec;
  }

  const audioDir = path.join(baseDir, 'public', 'runs', runName, 'audio');

  let currentFrame = 0;

  console.log('Extracting timing with ElevenLabs STT...\n');

  for (const scene of scenesData.scenes) {
    console.log(`[${scene.id}] Processing...`);

    const audioPath = path.join(audioDir, `${scene.id}.wav`);
    const durationSec = durationMap[scene.id] || 3;
    const voiceDurationFrames = Math.ceil(durationSec * fps);

    // シーンのフレーム設定
    scene.startFrame = currentFrame;
    scene.voiceStartFrame = currentFrame + voiceStartDelayFrames;
    scene.voiceDurationFrames = voiceDurationFrames;
    scene.endFrame = currentFrame + voiceStartDelayFrames + voiceDurationFrames + scenePaddingFrames;

    // pages がある場合、STT でタイミングを取得
    if (scene.telop?.pages && scene.telop.pages.length > 0) {
      if (fs.existsSync(audioPath)) {
        try {
          const sttResult = await transcribeWithTimestamps(audioPath);
          console.log(`  STT: "${(sttResult.text || '').substring(0, 30)}..."`);

          scene.telop.pages = calculatePageTimestamps(
            scene.telop.pages,
            scene.text,
            sttResult,
            voiceStartDelayFrames,
            fps
          );
        } catch (error) {
          console.error(`  STT Error: ${error.message}`);
          console.log('  Using fallback calculation...');
          scene.telop.pages = calculateFallbackTimestamps(
            scene.telop.pages,
            scene.text,
            durationSec,
            voiceStartDelayFrames,
            fps
          );
        }
      } else {
        console.warn(`  Audio not found: ${audioPath}`);
        scene.telop.pages = calculateFallbackTimestamps(
          scene.telop.pages,
          scene.text,
          durationSec,
          voiceStartDelayFrames,
          fps
        );
      }

      // ページのフレームを検証・修正
      for (let i = 0; i < scene.telop.pages.length; i++) {
        const page = scene.telop.pages[i];
        // 前のページより後に開始するよう調整
        if (i > 0) {
          const prevPage = scene.telop.pages[i - 1];
          if (page.startFrame < prevPage.endFrame) {
            page.startFrame = prevPage.endFrame;
          }
        }
        // シーンの範囲内に収める
        page.startFrame = Math.max(0, page.startFrame);
        page.endFrame = Math.min(scene.endFrame - scene.startFrame, page.endFrame);
        if (page.endFrame <= page.startFrame) {
          page.endFrame = page.startFrame + 10; // 最低10フレーム
        }
      }
    }

    currentFrame = scene.endFrame;

    // Rate limiting
    await new Promise(resolve => setTimeout(resolve, 500));
  }

  // メタ情報更新
  scenesData.meta.totalFrames = currentFrame;
  scenesData.meta.totalDuration = currentFrame / fps;
  scenesData.meta.fps = fps;

  // 保存
  fs.writeFileSync(scenesPath, JSON.stringify(scenesData, null, 2));

  console.log(`\nUpdated: ${scenesPath}`);
  console.log(`Total frames: ${currentFrame} (${(currentFrame / fps).toFixed(2)}s)`);
}

main().catch(e => {
  console.error('Error:', e.message);
  process.exit(1);
});
