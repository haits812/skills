#!/usr/bin/env node
/**
 * 画像を SVG で入れる版（フォールバック・外部依存ゼロ）
 *
 * Codex imagegen も Gemini も使えない環境向け。**画像は Claude が自力で SVG として描き**、
 * `public/runs/{run名}/images/{scene.id}.svg` に置く。本スクリプトはその SVG (無ければ PNG) を
 * scenes.json の scene.image に配線するだけ。Remotion は <Img src={staticFile()}> = Chromium
 * 描画なので SVG をそのままレンダでき、ラスタライズ不要。
 *
 * 手順:
 *   1. 各 needsImage シーンについて Claude が SVG を作成:
 *        public/runs/{run}/images/{scene.id}.svg
 *      - viewBox="0 0 1920 1080" (16:9)、画像内に文字を入れない、
 *        imagePrompt の内容を図形/グラデーションで表現する
 *   2. node scripts/generate-images-svg.js <run名>
 *   3. 以降は通常どおり generate-composition → render
 *
 * Usage: node scripts/generate-images-svg.js <run名>
 */

const fs = require('fs');
const path = require('path');

function main() {
  const runName = process.argv[2];
  if (!runName) {
    console.error('Usage: node scripts/generate-images-svg.js <run名>');
    process.exit(1);
  }
  const baseDir = path.join(__dirname, '..');
  const scenesPath = path.join(baseDir, 'runs', runName, 'scenes.json');
  const imagesDir = path.join(baseDir, 'public', 'runs', runName, 'images');
  if (!fs.existsSync(scenesPath)) {
    console.error(`Error: scenes.json not found at ${scenesPath}`);
    process.exit(1);
  }

  const scenesData = JSON.parse(fs.readFileSync(scenesPath, 'utf-8'));
  const need = scenesData.scenes.filter(s => s.needsImage);
  let wired = 0;
  const missing = [];

  for (const scene of need) {
    const svg = path.join(imagesDir, `${scene.id}.svg`);
    const png = path.join(imagesDir, `${scene.id}.png`);
    let ext = null;
    if (fs.existsSync(svg) && fs.statSync(svg).size > 0) ext = 'svg';
    else if (fs.existsSync(png) && fs.statSync(png).size > 0) ext = 'png';

    if (ext) {
      scene.image = { path: `runs/${runName}/images/${scene.id}.${ext}`, width: 1920, height: 1080 };
      console.log(`[${scene.id}] wired ${scene.id}.${ext}`);
      wired++;
    } else {
      missing.push(scene.id);
      console.log(`[${scene.id}] no SVG/PNG found — Claude must author ${scene.id}.svg`);
    }
  }

  fs.writeFileSync(scenesPath, JSON.stringify(scenesData, null, 2));
  console.log(`\nWired: ${wired}/${need.length}`);
  if (missing.length) {
    console.log(`未作成 (Claude が SVG を描く): ${missing.join(', ')}`);
    console.log(`→ public/runs/${runName}/images/<id>.svg を作成して再実行`);
  }
}

main();
