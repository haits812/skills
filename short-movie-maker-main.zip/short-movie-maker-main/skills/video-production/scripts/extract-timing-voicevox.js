#!/usr/bin/env node
/**
 * タイミング抽出（VOICEVOX 版・外部 API キー不要）
 *
 * extract-timing-stt.js の ElevenLabs 依存を外した版。テロップ pages の
 * startFrame/endFrame は「シーンの WAV 尺をページの文字数比で配分」して算出する
 * (STT の代わりに比例配分)。scene 単位の尺は元から voice-meta.json の実測 WAV 尺を
 * 使っているので、そもそも STT 不要な部分はそのまま。
 *
 * Usage: node scripts/extract-timing-voicevox.js <run名>
 * 前提: generate-voice.js (VOICEVOX) と page-splitter (telop.pages) が完了していること
 */

const fs = require('fs');
const path = require('path');

const DEFAULT_TIMING = {
  fps: 30,
  voiceStartDelayFrames: 3,
  scenePaddingFrames: 6
};

/** ページを文字数比でシーン尺に配分する。 */
function calculatePageTimestamps(pages, originalText, durationSec, voiceStartDelayFrames, fps) {
  const textLength = Math.max(1, originalText.length);
  const voiceDurationFrames = Math.round(durationSec * fps);
  return pages.map(page => ({
    ...page,
    startFrame: voiceStartDelayFrames + Math.round((page.startCharIndex / textLength) * voiceDurationFrames),
    endFrame: voiceStartDelayFrames + Math.round((page.endCharIndex / textLength) * voiceDurationFrames)
  }));
}

function main() {
  const runName = process.argv[2];
  if (!runName) {
    console.error('Usage: node scripts/extract-timing-voicevox.js <run名>');
    process.exit(1);
  }

  const baseDir = path.join(__dirname, '..');
  const configPath = path.join(baseDir, 'runs', runName, 'config.json');
  const config = fs.existsSync(configPath) ? JSON.parse(fs.readFileSync(configPath, 'utf-8')) : {};
  const timing = { ...DEFAULT_TIMING, ...config.timing };
  const { fps, voiceStartDelayFrames, scenePaddingFrames } = timing;

  const scenesPath = path.join(baseDir, 'runs', runName, 'scenes.json');
  if (!fs.existsSync(scenesPath)) {
    console.error(`Error: scenes.json not found at ${scenesPath}`);
    process.exit(1);
  }
  const scenesData = JSON.parse(fs.readFileSync(scenesPath, 'utf-8'));

  const voiceMetaPath = path.join(baseDir, 'runs', runName, 'voice-meta.json');
  if (!fs.existsSync(voiceMetaPath)) {
    console.error(`Error: voice-meta.json not found at ${voiceMetaPath}. Run generate-voice.js first.`);
    process.exit(1);
  }
  const voiceMeta = JSON.parse(fs.readFileSync(voiceMetaPath, 'utf-8'));
  const durationMap = {};
  for (const track of voiceMeta.tracks) durationMap[track.sceneId] = track.durationSec;

  let currentFrame = 0;
  console.log('Extracting timing from VOICEVOX durations (no external API)...\n');

  for (const scene of scenesData.scenes) {
    const durationSec = durationMap[scene.id] || 3;
    const voiceDurationFrames = Math.ceil(durationSec * fps);

    scene.startFrame = currentFrame;
    scene.voiceStartFrame = currentFrame + voiceStartDelayFrames;
    scene.voiceDurationFrames = voiceDurationFrames;
    scene.endFrame = currentFrame + voiceStartDelayFrames + voiceDurationFrames + scenePaddingFrames;

    if (scene.telop?.pages && scene.telop.pages.length > 0) {
      scene.telop.pages = calculatePageTimestamps(
        scene.telop.pages, scene.text, durationSec, voiceStartDelayFrames, fps);

      for (let i = 0; i < scene.telop.pages.length; i++) {
        const page = scene.telop.pages[i];
        if (i > 0) {
          const prev = scene.telop.pages[i - 1];
          if (page.startFrame < prev.endFrame) page.startFrame = prev.endFrame;
        }
        page.startFrame = Math.max(0, page.startFrame);
        page.endFrame = Math.min(scene.endFrame - scene.startFrame, page.endFrame);
        if (page.endFrame <= page.startFrame) page.endFrame = page.startFrame + 10;
      }
    }

    console.log(`[${scene.id}] ${durationSec.toFixed(2)}s -> frames ${scene.startFrame}..${scene.endFrame}`);
    currentFrame = scene.endFrame;
  }

  scenesData.meta.totalFrames = currentFrame;
  scenesData.meta.totalDuration = currentFrame / fps;
  scenesData.meta.fps = fps;

  fs.writeFileSync(scenesPath, JSON.stringify(scenesData, null, 2));
  console.log(`\nUpdated: ${scenesPath}`);
  console.log(`Total frames: ${currentFrame} (${(currentFrame / fps).toFixed(2)}s)`);
}

main();
