#!/usr/bin/env node
/**
 * 画像生成スクリプト
 *
 * Usage: node scripts/generate-images.js <run名>
 * Example: node scripts/generate-images.js video-editing-roadmap
 *
 * モデル: gemini-3-pro-image-preview（固定、フォールバックなし）
 * 必須: .env に GOOGLE_API_KEY を設定
 * 出力: public/runs/{run名}/images/ に PNG ファイルを生成
 */

const fs = require('fs');
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });

const { GoogleGenAI } = require('@google/genai');

const GOOGLE_API_KEY = process.env.GOOGLE_API_KEY;
const MAX_RETRIES = 2;
const RETRY_DELAY_MS = 2000;

const styleByLayout = {
  "main-insert": `
    Style: Clean professional illustration
    - Simple composition, suitable as side image
    - High contrast for video overlay
    - No text in image
    - 16:9 aspect ratio
  `,
  "main-board": `
    Style: Educational diagram/whiteboard style
    - Simple, clear illustration
    - Light background preferred
    - No text in image
    - 16:9 aspect ratio
  `,
  "main-fullimage": `
    Style: Cinematic full-screen image
    - High impact, visually striking
    - Good contrast in lower area for text overlay
    - No text in image
    - 16:9 aspect ratio
  `,
};

async function generateImage(ai, prompt, layout) {
  const styleHint = styleByLayout[layout] || "";
  const fullPrompt = `Generate an image for a YouTube video.
${styleHint}

Content: ${prompt}

Important: Do not include any text in the image.`;

  console.log(`  Prompt: ${prompt.substring(0, 50)}...`);

  let lastError = "Unknown error";

  for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
    try {
      const response = await ai.models.generateContent({
        model: "gemini-3-pro-image-preview",
        contents: fullPrompt,
        config: {
          responseModalities: ["Text", "Image"],
          imageConfig: {
            aspectRatio: "16:9",
            imageSize: "2K",
          },
        },
      });

      const parts = response.candidates?.[0]?.content?.parts || [];
      const imagePart = parts.find(p => p.inlineData?.mimeType?.startsWith("image/"));

      if (imagePart) {
        return {
          success: true,
          data: Buffer.from(imagePart.inlineData.data, "base64"),
        };
      }

      lastError = "No image in response";
      console.log(`  Attempt ${attempt}/${MAX_RETRIES}: ${lastError}`);
    } catch (error) {
      lastError = error.message;
      console.log(`  Attempt ${attempt}/${MAX_RETRIES}: ${lastError}`);
    }

    if (attempt < MAX_RETRIES) {
      await new Promise(resolve => setTimeout(resolve, RETRY_DELAY_MS));
    }
  }

  return {
    success: false,
    error: lastError,
  };
}

async function main() {
  const runName = process.argv[2];
  if (!runName) {
    console.error('Usage: node scripts/generate-images.js <run名>');
    process.exit(1);
  }

  if (!GOOGLE_API_KEY) {
    console.error('Error: GOOGLE_API_KEY not set in .env');
    process.exit(1);
  }

  const baseDir = path.join(__dirname, '..');
  const scenesPath = path.join(baseDir, 'runs', runName, 'scenes.json');
  const outputDir = path.join(baseDir, 'public', 'runs', runName, 'images');

  if (!fs.existsSync(scenesPath)) {
    console.error(`Error: scenes.json not found at ${scenesPath}`);
    process.exit(1);
  }

  fs.mkdirSync(outputDir, { recursive: true });

  const scenesData = JSON.parse(fs.readFileSync(scenesPath, 'utf-8'));
  const ai = new GoogleGenAI({ apiKey: GOOGLE_API_KEY });

  const scenesNeedingImages = scenesData.scenes.filter(s => s.needsImage && s.imagePrompt);
  console.log(`Found ${scenesNeedingImages.length} scenes needing images`);
  console.log(`Model: gemini-3-pro-image-preview (2K, 16:9)\n`);

  const failures = [];
  let successCount = 0;

  for (const scene of scenesNeedingImages) {
    console.log(`[${scene.id}] Generating image...`);

    const result = await generateImage(ai, scene.imagePrompt, scene.layout);

    if (result.success) {
      const imagePath = path.join(outputDir, `${scene.id}.png`);
      fs.writeFileSync(imagePath, result.data);
      console.log(`  ✓ Saved: ${scene.id}.png`);

      scene.image = {
        path: `runs/${runName}/images/${scene.id}.png`,
        width: 1920,
        height: 1080
      };
      successCount++;
    } else {
      console.log(`  ✗ Skipped: ${result.error}`);
      failures.push({ id: scene.id, error: result.error });
    }

    // Rate limiting
    await new Promise(resolve => setTimeout(resolve, 2000));
  }

  // Save updated scenes.json
  fs.writeFileSync(scenesPath, JSON.stringify(scenesData, null, 2));

  // Final report
  console.log(`\n${'='.repeat(40)}`);
  console.log(`=== 画像生成完了 ===`);
  console.log(`成功: ${successCount}/${scenesNeedingImages.length}`);

  if (failures.length > 0) {
    console.log(`失敗: ${failures.length}件`);
    failures.forEach(f => console.log(`  - ${f.id}: ${f.error}`));
    console.log(`\n→ 失敗した画像は手動で再生成してください`);
  }

  console.log(`\nOutput: ${outputDir}`);
}

main().catch(e => {
  console.error('Error:', e.message);
  process.exit(1);
});
