# 解説動画生成スクリプト

パイプラインの各ステップを実行するスクリプト群。

## スクリプト一覧

| スクリプト | スキル | 説明 | 入力 | 出力 |
|-----------|--------|------|------|------|
| `generate-voice.js` | voice-synthesizer | VOICEVOX音声生成 | scenes.json, config.json | public/runs/{run}/audio/*.wav |
| `extract-timing-stt.js` | timing-extractor | **ElevenLabs STTタイミング** | audio/*.wav, scenes.json | scenes.json更新 |
| `remove-punctuation.js` | punctuation-remover | 句読点削除 | scenes.json | scenes.json更新 |
| `add-animations.js` | animation-selector | アニメーション設定追加 | scenes.json | scenes.json更新 |
| `generate-images.js` | image-generator | Gemini画像生成 | scenes.json | public/runs/{run}/images/*.png |
| `generate-composition.js` | - | Remotion props生成 | scenes.json, voice-meta.json | composition.json |
| `validate-schema.js` | - | スキーマバリデーション | scenes.json | 検証結果 |
| `render.js` | remotion-renderer | 動画レンダリング | composition.json | output/video.mp4 |

**注意**: `update-timing.js` は比例計算によるフォールバック用。通常は `extract-timing-stt.js` を使用すること。

## 使用方法

```bash
cd labs/packages/explainer-video

# 音声生成（VOICEVOX起動必須）
node scripts/generate-voice.js {run名}

# ★タイミング抽出（ElevenLabs STT）- 推奨
node scripts/extract-timing-stt.js {run名}

# 句読点削除（page-splitter後に実行）
node scripts/remove-punctuation.js {run名}

# アニメーション追加
node scripts/add-animations.js {run名}

# 画像生成
node scripts/generate-images.js {run名}

# composition.json生成
node scripts/generate-composition.js {run名}

# スキーマバリデーション
node scripts/validate-schema.js {run名}        # 最終チェック
node scripts/validate-schema.js {run名} 7      # Step 7後のチェック

# レンダリング
node scripts/render.js {run名}              # 本番品質
node scripts/render.js {run名} --preview    # プレビュー品質
```

## パイプライン順序（重要）

```
5. voice-synthesizer  → generate-voice.js
6. page-splitter      → (AIエージェントが直接実行)
7. timing-extractor   → extract-timing-stt.js  ★STT使用
8. punctuation-remover→ remove-punctuation.js
9. emphasis-marker    → (AIエージェントが直接実行)
10. animation-selector → add-animations.js
11. image-generator    → generate-images.js
12. generate-composition → generate-composition.js
13. remotion-renderer  → render.js
```

**⚠️ page-splitter (Step 6) の後に timing-extractor (Step 7) を実行すること。**

## 前提条件

- `runs/{run名}/config.json` が存在すること
- `runs/{run名}/scenes.json` が存在すること
- VOICEVOX エンジンが `localhost:50021` で起動中
- `.env` に以下を設定:
  - `ELEVEN_API_KEY` - ElevenLabs STT用（タイミング抽出）
  - `GOOGLE_API_KEY` - Gemini画像生成用

## config.json 設定例

```json
{
  "voice": {
    "speakerId": 47,
    "speedScale": 1.5,
    "speakerName": "青山流星"
  },
  "splitConfig": {
    "maxCharsPerLine": 20,
    "maxLinesPerPage": 1
  },
  "timing": {
    "fps": 30,
    "voiceStartDelayFrames": 3,
    "scenePaddingFrames": 6
  }
}
```

### 設定項目

| カテゴリ | 設定 | デフォルト | 説明 |
|---------|------|-----------|------|
| voice.speakerId | **必須** | - | VOICEVOX話者ID |
| voice.speedScale | 1.0 | - | 読み上げ速度 |
| splitConfig.maxCharsPerLine | 20 | - | 1行の最大文字数 |
| splitConfig.maxLinesPerPage | 1 | - | 1ページの最大行数 |
| timing.fps | 30 | - | フレームレート |
| timing.voiceStartDelayFrames | 3 | - | 音声開始遅延（フレーム） |
| timing.scenePaddingFrames | 6 | - | シーン終了余白（フレーム） |

## extract-timing-stt.js について

ElevenLabs STTを使用して正確なタイミング情報を取得するスクリプト。

### 処理フロー

```
音声ファイル (WAV)
    │
    ▼ ElevenLabs STT API
タイムスタンプ付き文字起こし
    │
    ▼ LCS Matching
元台本とアライメント
    │
    ▼
scenes.json に startFrame/endFrame を追加
```

### 追加されるフィールド

- `scene.startFrame` - シーン開始フレーム
- `scene.endFrame` - シーン終了フレーム
- `scene.voiceStartFrame` - 音声開始フレーム
- `scene.voiceDurationFrames` - 音声長（フレーム）
- `scene.telop.pages[].startFrame` - ページ表示開始フレーム
- `scene.telop.pages[].endFrame` - ページ表示終了フレーム
