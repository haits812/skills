#!/usr/bin/env node
/**
 * 音声生成スクリプト
 *
 * Usage: node scripts/generate-voice.js <run名>
 * Example: node scripts/generate-voice.js nisa
 *
 * 必須: runs/{run名}/config.json に voice.speakerId が設定されていること
 * 出力: public/runs/{run名}/audio/ に WAV ファイルを生成
 */

const fs = require('fs');
const path = require('path');

const VOICEVOX_URL = process.env.VOICEVOX_URL || 'http://localhost:50021';

async function main() {
  const runName = process.argv[2];
  if (!runName) {
    console.error('Usage: node scripts/generate-voice.js <run名>');
    console.error('Example: node scripts/generate-voice.js nisa');
    process.exit(1);
  }

  const baseDir = path.join(__dirname, '..');

  // Load config
  const configPath = path.join(baseDir, 'runs', runName, 'config.json');
  if (!fs.existsSync(configPath)) {
    console.error(`Error: config.json not found at ${configPath}`);
    console.error('Create config.json with voice settings first.');
    process.exit(1);
  }

  const config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
  if (!config.voice?.speakerId) {
    console.error('Error: voice.speakerId is required in config.json');
    process.exit(1);
  }

  const { speakerId, speedScale = 1.0, speakerName = `Speaker ${speakerId}` } = config.voice;

  // Check VOICEVOX
  try {
    const res = await fetch(`${VOICEVOX_URL}/version`);
    if (!res.ok) throw new Error('VOICEVOX not responding');
    console.log(`VOICEVOX: ${await res.text()}`);
  } catch (e) {
    console.error(`Error: VOICEVOX not running at ${VOICEVOX_URL}`);
    console.error('Start VOICEVOX engine first.');
    process.exit(1);
  }

  console.log(`Speaker: ${speakerName} (ID: ${speakerId}), Speed: ${speedScale}x`);

  // Load scenes
  const scenesPath = path.join(baseDir, 'runs', runName, 'scenes.json');
  if (!fs.existsSync(scenesPath)) {
    console.error(`Error: scenes.json not found at ${scenesPath}`);
    process.exit(1);
  }
  const scenesData = JSON.parse(fs.readFileSync(scenesPath, 'utf-8'));

  // Create output directory
  const outputDir = path.join(baseDir, 'public', 'runs', runName, 'audio');
  fs.mkdirSync(outputDir, { recursive: true });

  const tracks = [];

  for (const scene of scenesData.scenes) {
    // 読み上げ用は readingText を優先 (無ければ表示用 text)。表示字幕はアルファベットや
    // ！？ を含めてよいが、TTS は読み間違い防止のため英単語→カタカナ・数字かな化した
    // readingText を使う。
    const text = scene.readingText || scene.text;
    console.log(`[${scene.id}] "${text.substring(0, 30)}..."`);

    // Get audio query
    const queryRes = await fetch(
      `${VOICEVOX_URL}/audio_query?text=${encodeURIComponent(text)}&speaker=${speakerId}`,
      { method: 'POST' }
    );
    const query = await queryRes.json();
    query.speedScale = speedScale;

    // Synthesize
    const synthRes = await fetch(
      `${VOICEVOX_URL}/synthesis?speaker=${speakerId}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(query)
      }
    );

    const audioBuffer = Buffer.from(await synthRes.arrayBuffer());
    const outputPath = path.join(outputDir, `${scene.id}.wav`);
    fs.writeFileSync(outputPath, audioBuffer);

    // Calculate duration from WAV header
    const sampleRate = audioBuffer.readUInt32LE(24);
    const bitsPerSample = audioBuffer.readUInt16LE(34);
    const numChannels = audioBuffer.readUInt16LE(22);
    const dataSize = audioBuffer.readUInt32LE(40);
    const durationSec = dataSize / (sampleRate * numChannels * (bitsPerSample / 8));

    console.log(`  -> ${durationSec.toFixed(2)}s`);

    tracks.push({
      sceneId: scene.id,
      path: `audio/${scene.id}.wav`,
      text,
      durationSec
    });
  }

  // Write voice-meta.json
  const voiceMeta = {
    speaker: speakerName,
    speakerId,
    speedScale,
    tracks,
    totalDurationSec: tracks.reduce((sum, t) => sum + t.durationSec, 0),
    generatedAt: new Date().toISOString()
  };

  const metaPath = path.join(baseDir, 'runs', runName, 'voice-meta.json');
  fs.writeFileSync(metaPath, JSON.stringify(voiceMeta, null, 2));

  console.log(`\nTotal: ${voiceMeta.totalDurationSec.toFixed(2)}s`);
  console.log(`Output: ${outputDir}`);
  console.log(`Metadata: ${metaPath}`);
}

main().catch(e => {
  console.error('Error:', e.message);
  process.exit(1);
});
