#!/usr/bin/env node
/**
 * scenes.json スキーマバリデーションスクリプト
 *
 * Usage: node scripts/validate-schema.js <run名> [step]
 * Example: node scripts/validate-schema.js investment-basics 7
 *
 * step を指定しない場合は全フィールドをチェック（最終状態）
 *
 * Steps:
 *   2: scene-composer 後
 *   3: layout-selector 後
 *   4: telop-formatter 後
 *   5: voice-synthesizer 後
 *   6: page-splitter 後    ★順序重要★
 *   7: timing-extractor 後 ★順序重要★
 *   8: punctuation-remover 後
 *   9: emphasis-marker 後
 *   10: animation-selector 後
 *   11: image-generator 後
 *
 * 重要: Step 6 (page-splitter) → Step 7 (timing-extractor) の順序を守ること
 */

const fs = require('fs');
const path = require('path');

// 各ステップで必須のフィールド
const REQUIRED_FIELDS_BY_STEP = {
  2: {
    scene: ['id', 'type', 'text', 'lineIds'],
    telop: [],
    page: []
  },
  3: {
    scene: ['id', 'type', 'text', 'lineIds', 'layout', 'needsImage'],
    telop: [],
    page: []
  },
  4: {
    scene: ['id', 'type', 'text', 'lineIds', 'layout', 'needsImage'],
    telop: ['lines'],
    page: []
  },
  5: {
    scene: ['id', 'type', 'text', 'lineIds', 'layout', 'needsImage'],
    telop: ['lines'],
    page: []
  },
  6: {
    scene: ['id', 'type', 'text', 'lineIds', 'layout', 'needsImage'],
    telop: ['lines', 'pages'],
    page: ['lines', 'startCharIndex', 'endCharIndex']
  },
  7: {
    scene: ['id', 'type', 'text', 'lineIds', 'layout', 'needsImage', 'startFrame', 'endFrame', 'voiceStartFrame', 'voiceDurationFrames'],
    telop: ['lines', 'pages'],
    page: ['lines', 'startCharIndex', 'endCharIndex', 'startFrame', 'endFrame']
  },
  8: {
    scene: ['id', 'type', 'text', 'lineIds', 'layout', 'needsImage', 'startFrame', 'endFrame', 'voiceStartFrame', 'voiceDurationFrames'],
    telop: ['lines', 'pages'],
    page: ['lines', 'startCharIndex', 'endCharIndex', 'startFrame', 'endFrame']
  },
  9: {
    scene: ['id', 'type', 'text', 'lineIds', 'layout', 'needsImage', 'startFrame', 'endFrame', 'voiceStartFrame', 'voiceDurationFrames'],
    telop: ['lines', 'pages', 'emphasis'],
    page: ['lines', 'startCharIndex', 'endCharIndex', 'startFrame', 'endFrame']
  },
  10: {
    scene: ['id', 'type', 'text', 'lineIds', 'layout', 'needsImage', 'startFrame', 'endFrame', 'voiceStartFrame', 'voiceDurationFrames'],
    telop: ['lines', 'pages', 'emphasis', 'animation'],
    page: ['lines', 'startCharIndex', 'endCharIndex', 'startFrame', 'endFrame']
  },
  11: {
    scene: ['id', 'type', 'text', 'lineIds', 'layout', 'needsImage', 'startFrame', 'endFrame', 'voiceStartFrame', 'voiceDurationFrames'],
    telop: ['lines', 'pages', 'emphasis', 'animation'],
    page: ['lines', 'startCharIndex', 'endCharIndex', 'startFrame', 'endFrame']
  }
};

// バリデーションルール
const VALIDATION_RULES = {
  // telop.lines は1-2行、各行20文字以内
  telopLines: (lines) => {
    if (!Array.isArray(lines)) return 'telop.lines must be an array';
    if (lines.length === 0) return 'telop.lines must have at least 1 line';
    if (lines.length > 2) return `telop.lines has ${lines.length} lines (max 2)`;
    for (let i = 0; i < lines.length; i++) {
      if (lines[i].length > 20) {
        return `telop.lines[${i}] is ${lines[i].length} chars (max 20): "${lines[i]}"`;
      }
    }
    return null;
  },

  // page.lines は1行、20文字以内
  pageLines: (lines) => {
    if (!Array.isArray(lines)) return 'page.lines must be an array';
    if (lines.length === 0) return 'page.lines must have at least 1 line';
    if (lines.length > 2) return `page.lines has ${lines.length} lines (max 2)`;
    for (let i = 0; i < lines.length; i++) {
      if (lines[i].length > 20) {
        return `page.lines[${i}] is ${lines[i].length} chars (max 20): "${lines[i]}"`;
      }
    }
    return null;
  },

  // フレームは正の整数
  frameValue: (value, fieldName) => {
    if (typeof value !== 'number') return `${fieldName} must be a number`;
    if (value < 0) return `${fieldName} must be >= 0 (got ${value})`;
    if (!Number.isInteger(value)) return `${fieldName} must be an integer`;
    return null;
  },

  // endFrame > startFrame
  frameOrder: (startFrame, endFrame, context) => {
    if (endFrame <= startFrame) {
      return `${context}: endFrame (${endFrame}) must be > startFrame (${startFrame})`;
    }
    return null;
  },

  // ページのフレームが連続しているか
  pagesFrameContinuity: (pages, sceneId) => {
    const errors = [];
    for (let i = 1; i < pages.length; i++) {
      const prev = pages[i - 1];
      const curr = pages[i];
      if (curr.startFrame < prev.endFrame) {
        errors.push(`${sceneId} page[${i}].startFrame (${curr.startFrame}) < page[${i-1}].endFrame (${prev.endFrame})`);
      }
    }
    return errors.length > 0 ? errors.join('\n') : null;
  }
};

function validateScene(scene, step, sceneIndex) {
  const errors = [];
  const warnings = [];
  const required = REQUIRED_FIELDS_BY_STEP[step] || REQUIRED_FIELDS_BY_STEP[11];

  // シーンの必須フィールドチェック
  for (const field of required.scene) {
    if (scene[field] === undefined) {
      errors.push(`scene[${sceneIndex}] (${scene.id || 'unknown'}): missing required field '${field}'`);
    }
  }

  // telop チェック
  if (required.telop.length > 0) {
    if (!scene.telop) {
      errors.push(`scene[${sceneIndex}] (${scene.id}): missing 'telop' object`);
    } else {
      for (const field of required.telop) {
        if (scene.telop[field] === undefined) {
          errors.push(`scene[${sceneIndex}] (${scene.id}): missing 'telop.${field}'`);
        }
      }

      // telop.lines のバリデーション
      if (scene.telop.lines) {
        const err = VALIDATION_RULES.telopLines(scene.telop.lines);
        if (err) warnings.push(`scene[${sceneIndex}] (${scene.id}): ${err}`);
      }

      // pages チェック
      if (scene.telop.pages && required.page.length > 0) {
        for (let i = 0; i < scene.telop.pages.length; i++) {
          const page = scene.telop.pages[i];
          for (const field of required.page) {
            if (page[field] === undefined) {
              errors.push(`scene[${sceneIndex}] (${scene.id}) page[${i}]: missing '${field}'`);
            }
          }

          // page.lines のバリデーション
          if (page.lines) {
            const err = VALIDATION_RULES.pageLines(page.lines);
            if (err) warnings.push(`scene[${sceneIndex}] (${scene.id}) page[${i}]: ${err}`);
          }

          // フレームのバリデーション
          if (page.startFrame !== undefined && page.endFrame !== undefined) {
            const err = VALIDATION_RULES.frameOrder(page.startFrame, page.endFrame, `${scene.id} page[${i}]`);
            if (err) errors.push(err);
          }
        }

        // ページのフレーム連続性チェック
        if (scene.telop.pages.length > 1 && scene.telop.pages[0].startFrame !== undefined) {
          const err = VALIDATION_RULES.pagesFrameContinuity(scene.telop.pages, scene.id);
          if (err) warnings.push(err);
        }
      }
    }
  }

  // シーンのフレームチェック
  if (scene.startFrame !== undefined && scene.endFrame !== undefined) {
    const err = VALIDATION_RULES.frameOrder(scene.startFrame, scene.endFrame, scene.id);
    if (err) errors.push(err);
  }

  // needsImage=true の場合、image が必要（Step 11以降）
  if (step >= 11 && scene.needsImage && !scene.image) {
    errors.push(`scene[${sceneIndex}] (${scene.id}): needsImage=true but no 'image' field`);
  }

  return { errors, warnings };
}

function main() {
  const runName = process.argv[2];
  const step = parseInt(process.argv[3]) || 11;

  if (!runName) {
    console.error('Usage: node scripts/validate-schema.js <run名> [step]');
    console.error('Example: node scripts/validate-schema.js investment-basics 7');
    process.exit(1);
  }

  const baseDir = path.join(__dirname, '..');
  const scenesPath = path.join(baseDir, 'runs', runName, 'scenes.json');

  if (!fs.existsSync(scenesPath)) {
    console.error(`Error: scenes.json not found at ${scenesPath}`);
    process.exit(1);
  }

  const scenesData = JSON.parse(fs.readFileSync(scenesPath, 'utf-8'));

  console.log(`Validating: ${scenesPath}`);
  console.log(`Step: ${step} (checking fields required after step ${step})\n`);

  let totalErrors = 0;
  let totalWarnings = 0;

  // メタ情報チェック
  if (!scenesData.title) {
    console.log('WARNING: missing "title" in root');
    totalWarnings++;
  }
  if (!scenesData.scenes || !Array.isArray(scenesData.scenes)) {
    console.error('ERROR: missing or invalid "scenes" array');
    process.exit(1);
  }
  if (!scenesData.meta) {
    console.log('WARNING: missing "meta" object');
    totalWarnings++;
  }

  // 各シーンをチェック
  for (let i = 0; i < scenesData.scenes.length; i++) {
    const scene = scenesData.scenes[i];
    const { errors, warnings } = validateScene(scene, step, i);

    for (const err of errors) {
      console.log(`ERROR: ${err}`);
      totalErrors++;
    }
    for (const warn of warnings) {
      console.log(`WARNING: ${warn}`);
      totalWarnings++;
    }
  }

  // 結果サマリー
  console.log('\n' + '='.repeat(50));
  console.log(`Scenes: ${scenesData.scenes.length}`);
  console.log(`Errors: ${totalErrors}`);
  console.log(`Warnings: ${totalWarnings}`);

  if (totalErrors > 0) {
    console.log('\nValidation FAILED');
    process.exit(1);
  } else if (totalWarnings > 0) {
    console.log('\nValidation PASSED with warnings');
    process.exit(0);
  } else {
    console.log('\nValidation PASSED');
    process.exit(0);
  }
}

main();
