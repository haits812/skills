---
name: video-production
description: テーマ、業務文脈、ブランド文脈、口調コンテキストから、AIエージェントで台本・シーン・画像指示を設計し、音声・テロップ・Remotionレンダリングで非属人動画や解説動画を作るSkill。
---

# Video Production Skill

## 役割

テーマから動画を新規制作する。台本、構成、画像指示、演出方針はAIエージェントが作る。音声生成、タイミング抽出、schema検証、画像生成、composition生成、レンダリングは同梱スクリプトで処理する。

動画編集済み素材を切る用途では使わない。その場合は `video-editing` を使う。

## 基本フロー

1. `runs/{run}/config.json` を作成する。
2. `contexts/` から必要な文脈を選ぶ。
3. `agent-tools/script-planner/TOOL.md` を使って `script.json` を作る。
4. `agent-tools/scene-director/TOOL.md` を使って `scenes.json` を作る。
5. `node scripts/validate-schema.js {run} 4` で初期構造を確認する。
6. VOICEVOXで `node scripts/generate-voice.js {run}` を実行する。
7. `agent-tools/page-splitter/TOOL.md` を使って `telop.pages` を作る。
8. `node scripts/extract-timing-stt.js {run}` で音声同期を取る。
9. `node scripts/remove-punctuation.js {run}` と `node scripts/add-animations.js {run}` を実行する。
10. `node scripts/generate-images.js {run}` で必要画像を作る。
11. `node scripts/generate-composition.js {run}` を実行する。
12. `node scripts/render.js {run} --preview` で確認し、問題なければ本番レンダリングする。

## コンテキスト注入

台本品質はモデル単体ではなく、渡す文脈で変わる。同じテーマでも以下を差し替える。

- `contexts/styles/yukkuri-dialogue.md`: 掛け合い、ツッコミ、テンポを強める。
- `contexts/styles/business-explainer.md`: 経営者・マーケ責任者向けの落ち着いた説明にする。
- `contexts/styles/non-personal-youtube.md`: 非属人YouTube向けに、視聴維持と構成密度を重視する。

講座では「コンテキストなし」と「style contextあり」の差分を見せる。

## キー無しモード (外部 API 不要・推奨)

ElevenLabs / Gemini の API キーが無くても完走できるよう、依存を外した差し替えスクリプトを用意している。VOICEVOX は必要。

- **字幕タイミング**: `scripts/extract-timing-stt.js` (ElevenLabs STT) の代わりに
  `scripts/extract-timing-voicevox.js` を使う。VOICEVOX の実測 WAV 尺をページの文字数比で
  配分してフレームを決める (STT 不要)。手順 8 をこれに置き換える。
- **画像生成 (第1候補: Codex)**: `scripts/generate-images.js` (Gemini) の代わりに
  `scripts/generate-images-codex.js` を使う。Codex CLI の `imagegen` スキルに 16:9・文字なしの
  画像を生成させ、`public/runs/{run}/images/{scene.id}.png` に保存する (Gemini 版と同一契約)。
  1 枚あたり時間がかかるので、外側で短いタイムアウトを掛けないこと (途中で切れる)。手順 10 を置き換える。
- **画像生成 (フォールバック: SVG 自作)**: Codex imagegen も使えない環境では、**画像を
  Claude 自身が SVG として描いて入れる**。各 needsImage シーンについて
  `public/runs/{run}/images/{scene.id}.svg` を作成 (viewBox="0 0 1920 1080"・**画像内に文字を
  入れない**・imagePrompt の内容を図形/グラデーションで表現) し、
  `scripts/generate-images-svg.js <run>` で scenes.json に配線する。**Remotion は
  `<Img src={staticFile()}>` = Chromium 描画なので SVG をそのままレンダでき、ラスタライズ不要**。
  同じ配線スクリプトは既存 PNG も拾うので、PNG があればそちらを優先する。

キー無しの流れ: `generate-voice → (page-splitter) → extract-timing-voicevox → remove-punctuation →
add-animations → generate-images-codex → generate-composition → render`。

## 参照

- schema: `references/scenes-schema.md`
- pipeline: `references/pipeline.md`
- yukkuri構造サンプル: `samples/yukkuri-script.sample.json`, `samples/yukkuri-scenes.sample.json`

