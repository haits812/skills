# scenes.json スキーマ定義

## 概要

このファイルは `runs/{run名}/scenes.json` の完全なスキーマを定義する。
各スキル・スクリプトはこのスキーマに従ってデータを追加・更新すること。

## パイプラインとフィールド追加順序

**⚠️ 重要: Step 6 (page-splitter) → Step 7 (timing-extractor) の順序厳守**

```
Step 1: script-writer
  → script.json を生成

Step 2: scene-composer
  → id, type, text, lineIds

Step 3: layout-selector
  → +layout, +needsImage, +imagePrompt, +bullets

Step 4: telop-formatter
  → +telop.lines

Step 5: voice-synthesizer
  → audio/*.wav, voice-meta.json を出力（scenes.json は変更しない）

Step 6: page-splitter ★順序重要★
  → +telop.pages (startCharIndex, endCharIndex, lines)
  ※ この時点では startFrame/endFrame はまだない

Step 7: timing-extractor (ElevenLabs STT) ★順序重要★
  → +startFrame, +endFrame, +voiceStartFrame, +voiceDurationFrames
  → +telop.pages[].startFrame, +telop.pages[].endFrame
  ※ スクリプト: node scripts/extract-timing-stt.js {run名}

Step 8: punctuation-remover
  → telop.pages[].lines を修正（句読点削除）

Step 9: emphasis-marker
  → +telop.emphasis

Step 10: animation-selector
  → +telop.animation

Step 11: image-generator
  → +image (path, width, height)

Step 12: generate-composition
  → composition.json を生成

Step 13: remotion-renderer
  → output/video.mp4 を生成
```

## 完全なスキーマ

```typescript
interface ScenesJson {
  title: string;                    // 動画タイトル
  scenes: Scene[];                  // シーン配列
  meta: Meta;                       // メタ情報
}

interface Scene {
  // === Step 2: scene-composer ===
  id: string;                       // "scene-001", "scene-002", ...
  type: SceneType;                  // "intro" | "main" | "outro" | "cta"
  text: string;                     // 読み上げテキスト（句読点あり）
  lineIds: string[];                // script.json の line-XXX への参照

  // === Step 3: layout-selector ===
  layout: LayoutType;               // レイアウト種別
  needsImage: boolean;              // 画像が必要か
  imagePrompt?: string;             // 画像生成プロンプト（英語）
  bullets?: Bullet[];               // outro用の箇条書き

  // === Step 4-10: telop 関連 ===
  telop: Telop;

  // === Step 7: timing-extractor ===
  startFrame: number;               // シーン開始フレーム（0始まり）
  endFrame: number;                 // シーン終了フレーム
  voiceStartFrame: number;          // 音声開始フレーム
  voiceDurationFrames: number;      // 音声長（フレーム数）

  // === Step 11: image-generator ===
  image?: Image;                    // 生成された画像情報
}

interface Telop {
  // === Step 4: telop-formatter ===
  lines: string[];                  // シーンタイトル（1-2行、各20文字以内）

  // === Step 6: page-splitter ===
  pages: Page[];                    // 音声同期ページ

  // === Step 7: timing-extractor ===
  // (pages 内の startFrame, endFrame が追加される)

  // === Step 9: emphasis-marker ===
  emphasis: Emphasis[];             // 強調箇所

  // === Step 10: animation-selector ===
  animation: Animation;             // アニメーション設定
}

interface Page {
  lines: string[];                  // 表示テキスト（1行、20文字以内）
  startCharIndex: number;           // 元テキストでの開始位置
  endCharIndex: number;             // 元テキストでの終了位置
  startFrame: number;               // 表示開始フレーム（シーン内相対）
  endFrame: number;                 // 表示終了フレーム（シーン内相対）
}

interface Emphasis {
  word: string;                     // 強調する単語
  type: EmphasisType;               // 強調タイプ
}

interface Animation {
  in: AnimationType;                // 登場アニメーション
  out: AnimationType;               // 退場アニメーション
}

interface Bullet {
  text: string;                     // 箇条書きテキスト
  icon: string;                     // アイコン（"1", "2", "✓" など）
}

interface Image {
  path: string;                     // "runs/{run}/images/scene-XXX.png"
  width: number;                    // 1920
  height: number;                   // 1080
}

interface Meta {
  totalScenes: number;              // シーン総数
  fps: number;                      // フレームレート（30）
  totalFrames: number;              // 総フレーム数
  totalDuration?: number;           // 総時間（秒）
}

// === 型定義 ===

type SceneType = "intro" | "main" | "outro" | "cta";

type LayoutType =
  | "intro"
  | "main-lecture"
  | "main-insert"
  | "main-board"
  | "main-fullimage"
  | "outro"
  | "cta";

type EmphasisType = "keyword" | "positive" | "negative" | "number" | "quote" | "tech";

// おさる式アニメーション（marketing-short で実装済み）
type AnimationType =
  | "popIn"         // デフォルト、spring bounce
  | "stamp"         // 1.8x→1.0x縮小、インパクト重視
  | "shake"         // 振動 + 減衰、強調・警告
  | "pulse"         // 脈動、継続的強調
  | "glow"          // 発光、金額・数字
  | "bounce"        // バウンス
  | "slideInBottom" // 下からスライド
  | "slideInLeft"   // 左からスライド
  | "slideInRight"  // 右からスライド
  | "fadeIn"        // フェードイン
  | "fadeOut"       // フェードアウト（退場用）
  | "popOut";       // 縮小して消える（退場用）
```

## 各ステップ後の必須フィールド

### Step 2 完了後（scene-composer）

```json
{
  "id": "scene-001",
  "type": "intro",
  "text": "今日は...",
  "lineIds": ["line-001"]
}
```

### Step 3 完了後（layout-selector）

```json
{
  "id": "scene-001",
  "type": "intro",
  "text": "今日は...",
  "lineIds": ["line-001"],
  "layout": "intro",
  "needsImage": false
}
```

### Step 4 完了後（telop-formatter）

```json
{
  "id": "scene-001",
  "type": "intro",
  "text": "今日は...",
  "lineIds": ["line-001"],
  "layout": "intro",
  "needsImage": false,
  "telop": {
    "lines": ["投資の基礎", "5つのポイント"]
  }
}
```

### Step 6 完了後（page-splitter）★順序重要★

**注意**: この時点では `startFrame`/`endFrame` はまだない

```json
{
  ...
  "telop": {
    "lines": ["投資の基礎", "5つのポイント"],
    "pages": [
      {
        "lines": ["今日は"],
        "startCharIndex": 0,
        "endCharIndex": 4
      }
    ]
  }
}
```

### Step 7 完了後（timing-extractor）★順序重要★

**実行コマンド**: `node scripts/extract-timing-stt.js {run名}`

```json
{
  ...
  "startFrame": 0,
  "endFrame": 144,
  "voiceStartFrame": 3,
  "voiceDurationFrames": 135,
  "telop": {
    "lines": ["投資の基礎", "5つのポイント"],
    "pages": [
      {
        "lines": ["今日は"],
        "startCharIndex": 0,
        "endCharIndex": 4,
        "startFrame": 3,
        "endFrame": 15
      }
    ]
  }
}
```

### Step 8 完了後（punctuation-remover）

pages[].lines から句読点が削除される（startCharIndex/endCharIndex は変更しない）

### Step 9 完了後（emphasis-marker）

```json
{
  ...
  "telop": {
    ...
    "emphasis": [
      { "word": "5つ", "type": "number" }
    ]
  }
}
```

### Step 10 完了後（animation-selector）

```json
{
  ...
  "telop": {
    ...
    "animation": { "in": "popIn", "out": "fadeOut" }
  }
}
```

**おさる式推奨:**
- hook → `stamp` or `shake`
- point → `popIn`
- cta → `shake` or `glow`
- 金額あり → `glow`

### Step 11 完了後（image-generator）

```json
{
  ...
  "image": {
    "path": "runs/investment-basics/images/scene-001.png",
    "width": 1920,
    "height": 1080
  }
}
```

## バリデーションルール

### 必須チェック

| フィールド | 必須タイミング | 説明 |
|-----------|---------------|------|
| id | Step 2以降 | 常に必須 |
| type | Step 2以降 | 常に必須 |
| text | Step 2以降 | 常に必須 |
| layout | Step 3以降 | 常に必須 |
| telop.lines | Step 4以降 | 常に必須 |
| telop.pages | Step 6以降 | 常に必須 |
| telop.pages[].startFrame | **Step 7以降** | **常に必須**（timing-extractor後） |
| telop.pages[].endFrame | **Step 7以降** | **常に必須**（timing-extractor後） |
| startFrame | **Step 7以降** | 常に必須 |
| endFrame | **Step 7以降** | 常に必須 |
| telop.emphasis | Step 9以降 | 空配列OK |
| telop.animation | Step 10以降 | 常に必須 |
| image | Step 11以降 | needsImage=true の場合のみ必須 |

### 値の制約

| フィールド | 制約 |
|-----------|------|
| telop.lines | 1-2行、各行20文字以内 |
| telop.pages[].lines | 1行、20文字以内 |
| startFrame | >= 0 |
| endFrame | > startFrame |
| pages[].startFrame | >= 0、前のページの endFrame 以上 |
| pages[].endFrame | > startFrame、シーンの endFrame 以下 |

## 重要な注意事項

1. **Step 6 (page-splitter) → Step 7 (timing-extractor) の順序厳守**
   - page-splitter が pages を作成（startFrame/endFrame なし）
   - timing-extractor が pages に startFrame/endFrame を追加
   - 順序を間違えるとテロップが重なる

2. **ElevenLabs STT で正確なタイミングを取得すること**
   - 実行コマンド: `node scripts/extract-timing-stt.js {run名}`
   - 単純な比例計算ではなく、実際の音声解析結果を使用

3. **スキーマチェックを各ステップ後に実行すること**
   - `node scripts/validate-schema.js {run名}` - 最終チェック
   - `node scripts/validate-schema.js {run名} 7` - Step 7後のチェック
