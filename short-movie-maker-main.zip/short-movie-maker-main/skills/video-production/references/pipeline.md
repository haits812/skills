# explainer-video 生成パイプライン

## 全体フロー

```
テーマ入力
    │
    ▼
┌─────────────────┐
│ 1. script-writer │  WebSearchでファクト収集 → 台本生成
└────────┬────────┘
         │ runs/{run名}/script.json
         ▼
┌─────────────────┐
│ 2. scene-composer│  台本をシーンに分割
└────────┬────────┘
         │ runs/{run名}/scenes.json
         ▼
┌─────────────────┐
│ 3. layout-selector│  各シーンのレイアウトを決定
└────────┬────────┘
         │ scenes.json (+layout, +needsImage, +imagePrompt)
         ▼
┌─────────────────────┐
│ 4. telop-formatter  │  シーンタイトルを生成
└────────┬────────────┘
         │ scenes.json (+telop.lines)
         ▼
┌─────────────────────┐
│ 5. voice-synthesizer│  VOICEVOX音声生成
└────────┬────────────┘  ★スクリプト: generate-voice.js
         │ public/runs/{run名}/audio/*.wav
         │ runs/{run名}/voice-meta.json
         ▼
┌─────────────────────┐
│ 6. page-splitter    │  音声テキストをページ分割
└────────┬────────────┘  ※AIエージェントが直接実行
         │ scenes.json (+telop.pages)
         │ ※この時点では startFrame/endFrame はない
         ▼
┌─────────────────────┐
│ 7. timing-extractor │  ElevenLabs STT + LCSマッチング
└────────┬────────────┘  ★スクリプト: extract-timing-stt.js
         │ scenes.json (+startFrame, +endFrame)
         │ scenes.json (+pages[].startFrame, +pages[].endFrame)
         ▼
┌─────────────────────┐
│ 8. punctuation-remover│ 句読点を削除
└────────┬────────────┘  ★スクリプト: remove-punctuation.js
         │ scenes.json (pages[].lines 修正)
         ▼
┌─────────────────────┐
│ 9. emphasis-marker  │  強調箇所をマーキング
└────────┬────────────┘  ※AIエージェントが直接実行
         │ scenes.json (+telop.emphasis)
         ▼
┌─────────────────────────┐
│ 10. animation-selector  │  アニメーション設定
└────────┬────────────────┘  ★スクリプト: add-animations.js
         │ scenes.json (+telop.animation)
         ▼
┌─────────────────────┐
│ 11. image-generator │  Gemini で画像生成
└────────┬────────────┘  ★スクリプト: generate-images.js
         │ public/runs/{run名}/images/*.png
         │ scenes.json (+image.path)
         ▼
┌────────────────────────┐
│ 12. generate-composition│ Remotion props生成
└────────┬───────────────┘  ★スクリプト: generate-composition.js
         │ runs/{run名}/composition.json
         ▼
┌─────────────────────┐
│ 13. remotion-renderer│  最終レンダリング
└────────┬────────────┘  ★スクリプト: render.js
         │ runs/{run名}/output/video.mp4
         ▼
      完成！
```

## ⚠️ 重要: 順序厳守

```
❌ 間違い: timing-extractor → page-splitter
   → pages が後から作成され、startFrame/endFrame がない
   → テロップが重なる

✅ 正解: page-splitter → timing-extractor
   → pages 作成後にタイミングが追加される
   → テロップが正しく表示される
```

## 使用API

| 用途 | API | 環境変数 |
|------|-----|---------|
| 音声合成 (TTS) | VOICEVOX (ローカル) | `VOICEVOX_URL` |
| 文字起こし (STT) | ElevenLabs | `ELEVEN_API_KEY` |
| 画像生成 | Gemini | `GOOGLE_API_KEY` |

## ディレクトリ構造

```
labs/packages/explainer-video/
│
├── public/                    # 【Remotion静的ファイル】
│   └── runs/{run名}/
│       ├── audio/             # 音声ファイル
│       │   └── scene-XXX.wav
│       └── images/            # 画像ファイル
│           └── scene-XXX.png
│
├── runs/                      # 【中間データ・設定】
│   └── {run名}/
│       ├── config.json        # テーマ設定（必須）
│       ├── script.json        # 台本
│       ├── scenes.json        # シーンデータ（メイン）
│       ├── voice-meta.json    # 音声メタデータ
│       ├── composition.json   # Remotion用props
│       └── output/
│           └── video.mp4
│
└── scripts/                   # ツールスクリプト
    ├── generate-voice.js
    ├── extract-timing-stt.js  ★重要
    ├── remove-punctuation.js
    ├── add-animations.js
    ├── generate-images.js
    ├── generate-composition.js
    ├── validate-schema.js
    └── render.js
```

## タイムスタンプ取得フロー

```
VOICEVOX音声 (WAV)
    │
    ▼ ElevenLabs STT
タイムスタンプ付き文字起こし
（誤字脱字あり）
    │
    ▼ LCS Matching Algorithm
元台本とアライメント
    │
    ▼
元台本 + 正確なタイムスタンプ
```

### なぜSTTを使うのか

- VOICEVOXのモーラ情報を使う方法もあるが、他の音声合成に対応できない
- STTは汎用的で、将来ElevenLabs TTSに切り替えても同じフローが使える
- ElevenLabsのSTTは高精度でword-levelタイムスタンプが取れる

## scenes.json 最終構造

```json
{
  "title": "【完全解説】投資の基礎",
  "scenes": [
    {
      "id": "scene-001",
      "type": "intro",
      "layout": "intro",
      "text": "今日は投資の基礎について解説します",
      "lineIds": ["line-001"],
      "needsImage": false,
      "telop": {
        "lines": ["投資の基礎", "5つのポイント"],
        "pages": [
          {
            "lines": ["今日は"],
            "startCharIndex": 0,
            "endCharIndex": 4,
            "startFrame": 3,
            "endFrame": 15
          },
          {
            "lines": ["投資の基礎について"],
            "startCharIndex": 4,
            "endCharIndex": 12,
            "startFrame": 15,
            "endFrame": 40
          }
        ],
        "emphasis": [
          { "word": "投資", "type": "keyword" }
        ],
        "animation": { "in": "scale", "out": "fade" }
      },
      "startFrame": 0,
      "endFrame": 144,
      "voiceStartFrame": 3,
      "voiceDurationFrames": 135
    }
  ],
  "meta": {
    "totalScenes": 19,
    "fps": 30,
    "totalFrames": 3127,
    "totalDuration": 104.23
  }
}
```

## スクリプト一覧

| スクリプト | スキル | 説明 |
|-----------|--------|------|
| `generate-voice.js` | voice-synthesizer | VOICEVOX音声生成 |
| `extract-timing-stt.js` | timing-extractor | ElevenLabs STTタイミング |
| `remove-punctuation.js` | punctuation-remover | 句読点削除 |
| `add-animations.js` | animation-selector | アニメーション設定 |
| `generate-images.js` | image-generator | Gemini画像生成 |
| `generate-composition.js` | - | Remotion props生成 |
| `validate-schema.js` | - | スキーマバリデーション |
| `render.js` | remotion-renderer | 最終レンダリング |

## 環境変数設定

`.env` ファイル:

```env
# Google API (Gemini)
GOOGLE_API_KEY=

# ElevenLabs (STT for timestamp extraction)
ELEVEN_API_KEY=

# VOICEVOX (TTS)
VOICEVOX_URL=http://localhost:50021
```
