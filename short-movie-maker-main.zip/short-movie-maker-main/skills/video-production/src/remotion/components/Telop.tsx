import type { StyleConfig, AnimationType } from "../types";
import { useFadeIn } from "../animations/useFadeIn";
import { useSlideUp, useSlideLeft } from "../animations/useSlideIn";
import { usePopIn } from "../animations/usePopIn";
import { useScaleIn } from "../animations/useScaleIn";

interface TelopProps {
  lines: string[];
  style: StyleConfig;
  animation: AnimationType;
  fontSize?: number;
  align?: "center" | "left" | "right";
}

export const Telop: React.FC<TelopProps> = ({
  lines,
  style,
  animation,
  fontSize,
  align = "center",
}) => {
  // アニメーション適用
  const fadeIn = useFadeIn(0, 10);
  const slideUp = useSlideUp(0, 8);
  const slideLeft = useSlideLeft(0, 8);
  const popIn = usePopIn(0, 6);
  const scaleIn = useScaleIn(0, 10);

  // アニメーションスタイルを決定
  const getAnimationStyle = (): React.CSSProperties => {
    switch (animation) {
      case "fade":
        return { opacity: fadeIn };
      case "slide_up":
        return {
          opacity: slideUp.opacity,
          transform: `translateY(${slideUp.translateY}px)`,
        };
      case "slide_left":
        return {
          opacity: slideLeft.opacity,
          transform: `translateX(${slideLeft.translateX}px)`,
        };
      case "pop":
        return {
          opacity: popIn.opacity,
          transform: `scale(${popIn.scale})`,
        };
      case "scale":
        return {
          opacity: scaleIn.opacity,
          transform: `scale(${scaleIn.scale})`,
        };
      default:
        return { opacity: 1 };
    }
  };

  const containerStyle: React.CSSProperties = {
    display: "flex",
    flexDirection: "column",
    alignItems: align === "center" ? "center" : align === "left" ? "flex-start" : "flex-end",
    justifyContent: "center",
    ...getAnimationStyle(),
  };

  const textStyle: React.CSSProperties = {
    fontFamily: style.telop.fontFamily,
    fontSize: fontSize || style.telop.baseFontSize,
    fontWeight: style.telop.fontWeight,
    color: style.telop.color,
    lineHeight: style.telop.lineHeight,
    textAlign: align,
    margin: 0,
    padding: 0,
  };

  return (
    <div style={containerStyle}>
      {lines.map((line, index) => (
        <p key={index} style={textStyle}>
          {line}
        </p>
      ))}
    </div>
  );
};
