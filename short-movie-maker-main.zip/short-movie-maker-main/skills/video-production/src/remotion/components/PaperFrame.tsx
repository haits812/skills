import { Img, staticFile, interpolate, useCurrentFrame } from "remotion";
import { colors, designTokens } from "../types";

interface PaperFrameProps {
  src: string;
  width?: string | number;
  height?: string | number;
  rotation?: number; // -5 ~ 5度の傾き
  variant?: "plain" | "taped" | "clipped" | "pinned";
  animate?: boolean;
  shadow?: "soft" | "strong";
}

export const PaperFrame: React.FC<PaperFrameProps> = ({
  src,
  width = "100%",
  height = "100%",
  rotation = 0,
  variant = "taped",
  animate = true,
  shadow = "soft",
}) => {
  const frame = useCurrentFrame();

  // アニメーション
  const scale = animate
    ? interpolate(frame, [0, 20], [0.9, 1], { extrapolateRight: "clamp" })
    : 1;
  const opacity = animate
    ? interpolate(frame, [0, 15], [0, 1], { extrapolateRight: "clamp" })
    : 1;
  const dropY = animate
    ? interpolate(frame, [0, 20], [-30, 0], { extrapolateRight: "clamp" })
    : 0;

  // シャドウスタイル
  const shadowStyle =
    shadow === "strong"
      ? "0 12px 40px rgba(0, 0, 0, 0.2), 0 4px 12px rgba(0, 0, 0, 0.1)"
      : "0 8px 24px rgba(0, 0, 0, 0.12), 0 2px 8px rgba(0, 0, 0, 0.08)";

  // テープの装飾
  const renderTape = () => {
    if (variant !== "taped") return null;
    return (
      <>
        {/* 左上のテープ */}
        <div
          style={{
            position: "absolute",
            top: -8,
            left: 20,
            width: 60,
            height: 24,
            background: "linear-gradient(135deg, rgba(255, 245, 200, 0.9), rgba(255, 235, 170, 0.85))",
            transform: "rotate(-15deg)",
            borderRadius: 2,
            boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
            zIndex: 10,
          }}
        />
        {/* 右上のテープ */}
        <div
          style={{
            position: "absolute",
            top: -8,
            right: 20,
            width: 60,
            height: 24,
            background: "linear-gradient(135deg, rgba(255, 245, 200, 0.9), rgba(255, 235, 170, 0.85))",
            transform: "rotate(15deg)",
            borderRadius: 2,
            boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
            zIndex: 10,
          }}
        />
      </>
    );
  };

  // クリップの装飾
  const renderClip = () => {
    if (variant !== "clipped") return null;
    return (
      <div
        style={{
          position: "absolute",
          top: -16,
          left: "50%",
          transform: "translateX(-50%)",
          width: 40,
          height: 56,
          zIndex: 10,
        }}
      >
        {/* クリップ本体 */}
        <div
          style={{
            width: 40,
            height: 56,
            border: "4px solid #666",
            borderRadius: "20px 20px 4px 4px",
            background: "linear-gradient(180deg, #888 0%, #666 100%)",
            boxShadow: "inset 0 2px 4px rgba(255,255,255,0.3), 0 2px 4px rgba(0,0,0,0.2)",
          }}
        />
        {/* クリップの内側 */}
        <div
          style={{
            position: "absolute",
            top: 8,
            left: 8,
            width: 24,
            height: 40,
            border: "3px solid #888",
            borderRadius: "12px 12px 2px 2px",
            background: "transparent",
          }}
        />
      </div>
    );
  };

  // ピンの装飾
  const renderPin = () => {
    if (variant !== "pinned") return null;
    return (
      <div
        style={{
          position: "absolute",
          top: -12,
          left: "50%",
          transform: "translateX(-50%)",
          zIndex: 10,
        }}
      >
        {/* ピンの頭 */}
        <div
          style={{
            width: 28,
            height: 28,
            borderRadius: "50%",
            background: `radial-gradient(circle at 30% 30%, #ff6b6b, #cc4444)`,
            boxShadow: "0 4px 8px rgba(0, 0, 0, 0.3), inset 0 2px 4px rgba(255,255,255,0.3)",
          }}
        />
        {/* ピンの影 */}
        <div
          style={{
            position: "absolute",
            top: 20,
            left: "50%",
            transform: "translateX(-50%)",
            width: 4,
            height: 12,
            background: "rgba(0, 0, 0, 0.2)",
            borderRadius: 2,
          }}
        />
      </div>
    );
  };

  return (
    <div
      style={{
        width,
        height,
        position: "relative",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        transform: `translateY(${dropY}px) rotate(${rotation}deg) scale(${scale})`,
        opacity,
      }}
    >
      {/* 装飾 */}
      {renderTape()}
      {renderClip()}
      {renderPin()}

      {/* 紙のフレーム */}
      <div
        style={{
          width: "100%",
          height: "100%",
          backgroundColor: "#FAFAFA",
          borderRadius: 4,
          padding: 12,
          boxShadow: shadowStyle,
          // 紙っぽいテクスチャ（軽いノイズ感）
          backgroundImage: `
            linear-gradient(135deg, rgba(0,0,0,0.01) 0%, transparent 50%, rgba(255,255,255,0.02) 100%)
          `,
          position: "relative",
        }}
      >
        {/* 角の折れ効果（右下） */}
        <div
          style={{
            position: "absolute",
            bottom: 0,
            right: 0,
            width: 24,
            height: 24,
            background: `linear-gradient(135deg, transparent 50%, rgba(0,0,0,0.05) 50%)`,
            borderRadius: "0 0 4px 0",
          }}
        />

        {/* 画像 */}
        <div
          style={{
            width: "100%",
            height: "100%",
            borderRadius: 2,
            overflow: "hidden",
            backgroundColor: colors.bgWhite,
          }}
        >
          <Img
            src={staticFile(src)}
            style={{
              width: "100%",
              height: "100%",
              objectFit: "cover",
            }}
          />
        </div>
      </div>
    </div>
  );
};
