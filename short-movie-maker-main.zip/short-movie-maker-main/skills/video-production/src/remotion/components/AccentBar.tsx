import { interpolate, useCurrentFrame } from "remotion";

// ブランドカラー（サクラピンク & 紫）
const brandColors = {
  sakuraPink: "#F472B6",
  purple: "#A855F7",
};

interface AccentBarProps {
  position?: "top" | "bottom";
  height?: number;
  animate?: boolean;
}

export const AccentBar: React.FC<AccentBarProps> = ({
  position = "top",
  height = 8,
  animate = true,
}) => {
  const frame = useCurrentFrame();

  const scaleX = animate
    ? interpolate(frame, [0, 20], [0, 1], {
        extrapolateRight: "clamp",
      })
    : 1;

  return (
    <div
      style={{
        position: "absolute",
        [position]: 0,
        left: 0,
        right: 0,
        height,
        background: `linear-gradient(90deg, ${brandColors.sakuraPink} 0%, ${brandColors.purple} 100%)`,
        transform: `scaleX(${scaleX})`,
        transformOrigin: "left center",
      }}
    />
  );
};
