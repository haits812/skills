import { AbsoluteFill } from "remotion";

// ブランドカラー
const brandColors = {
  sakuraPink: "#F472B6",
  purple: "#A855F7",
  sakuraPinkLight: "#FBCFE8",
  purpleLight: "#E9D5FF",
};

interface BrandingOverlayProps {
  showLogo?: boolean;
  showCornerAccents?: boolean;
  showFrame?: boolean;
  frameWidth?: number;
}

export const BrandingOverlay: React.FC<BrandingOverlayProps> = ({
  showLogo = true,
  showCornerAccents = true,
  showFrame = true,
  frameWidth = 12,  // 太めに
}) => {
  return (
    <AbsoluteFill style={{ pointerEvents: "none" }}>
      {/* フレーム（全辺・アニメーションなし） */}
      {showFrame && (
        <>
          {/* 上辺 */}
          <div
            style={{
              position: "absolute",
              top: 0,
              left: 0,
              right: 0,
              height: frameWidth,
              background: `linear-gradient(90deg, ${brandColors.sakuraPink} 0%, ${brandColors.purple} 100%)`,
            }}
          />
          {/* 下辺 */}
          <div
            style={{
              position: "absolute",
              bottom: 0,
              left: 0,
              right: 0,
              height: frameWidth,
              background: `linear-gradient(90deg, ${brandColors.purple} 0%, ${brandColors.sakuraPink} 100%)`,
            }}
          />
          {/* 左辺 */}
          <div
            style={{
              position: "absolute",
              top: 0,
              left: 0,
              bottom: 0,
              width: frameWidth,
              background: `linear-gradient(180deg, ${brandColors.sakuraPink} 0%, ${brandColors.purple} 100%)`,
            }}
          />
          {/* 右辺 */}
          <div
            style={{
              position: "absolute",
              top: 0,
              right: 0,
              bottom: 0,
              width: frameWidth,
              background: `linear-gradient(180deg, ${brandColors.purple} 0%, ${brandColors.sakuraPink} 100%)`,
            }}
          />
        </>
      )}

      {/* コーナーアクセント（アニメーションなし） */}
      {showCornerAccents && (
        <>
          {/* 左上アクセント */}
          <div
            style={{
              position: "absolute",
              top: frameWidth,
              left: frameWidth,
              width: 150,
              height: 150,
              background: `linear-gradient(135deg, ${brandColors.sakuraPinkLight}50 0%, transparent 50%)`,
            }}
          />
          {/* 右上アクセント */}
          <div
            style={{
              position: "absolute",
              top: frameWidth,
              right: frameWidth,
              width: 150,
              height: 150,
              background: `linear-gradient(225deg, ${brandColors.purpleLight}50 0%, transparent 50%)`,
            }}
          />
          {/* 左下アクセント */}
          <div
            style={{
              position: "absolute",
              bottom: frameWidth,
              left: frameWidth,
              width: 120,
              height: 120,
              background: `linear-gradient(45deg, ${brandColors.purpleLight}40 0%, transparent 50%)`,
            }}
          />
          {/* 右下アクセント */}
          <div
            style={{
              position: "absolute",
              bottom: frameWidth,
              right: frameWidth,
              width: 120,
              height: 120,
              background: `linear-gradient(315deg, ${brandColors.sakuraPinkLight}40 0%, transparent 50%)`,
            }}
          />
          {/* 中央上部の小さなアクセント */}
          <div
            style={{
              position: "absolute",
              top: frameWidth + 20,
              left: "50%",
              transform: "translateX(-50%)",
              width: 60,
              height: 4,
              background: `linear-gradient(90deg, transparent, ${brandColors.sakuraPink}60, transparent)`,
              borderRadius: 2,
            }}
          />
        </>
      )}

      {/* ロゴ（右上） - 背景付きで見やすく */}
      {showLogo && (
        <div
          style={{
            position: "absolute",
            top: frameWidth + 12,
            right: frameWidth + 16,
            display: "flex",
            alignItems: "center",
            gap: 10,
            background: "rgba(255, 255, 255, 0.92)",
            backdropFilter: "blur(8px)",
            padding: "8px 16px 8px 12px",
            borderRadius: 12,
            boxShadow: "0 4px 16px rgba(244, 114, 182, 0.25)",
            border: `2px solid ${brandColors.sakuraPinkLight}`,
          }}
        >
          {/* ロゴアイコン */}
          <div
            style={{
              width: 44,
              height: 44,
              borderRadius: 10,
              background: `linear-gradient(135deg, ${brandColors.sakuraPink} 0%, ${brandColors.purple} 100%)`,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              boxShadow: "0 3px 10px rgba(244, 114, 182, 0.4)",
            }}
          >
            {/* 再生ボタン風アイコン */}
            <div
              style={{
                width: 0,
                height: 0,
                borderLeft: "14px solid white",
                borderTop: "8px solid transparent",
                borderBottom: "8px solid transparent",
                marginLeft: 4,
              }}
            />
          </div>

          {/* テキストロゴ */}
          <span
            style={{
              fontFamily: "'Kosugi Maru', 'Rounded Mplus 1c', sans-serif",
              fontSize: 36,
              fontWeight: 700,
              background: `linear-gradient(135deg, ${brandColors.sakuraPink} 0%, ${brandColors.purple} 100%)`,
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              backgroundClip: "text",
              letterSpacing: "0.05em",
            }}
          >
            編集くん
          </span>
        </div>
      )}
    </AbsoluteFill>
  );
};
