import { interpolate, useCurrentFrame } from "remotion";
import type { StyleConfig, AnimationType, Emphasis, EmphasisType } from "../types";
import { colors, designTokens } from "../types";

interface TelopWithEmphasisProps {
  lines: string[];
  emphasis: Emphasis[];
  style: StyleConfig;
  animation: AnimationType;
  fontSize?: number;
  subFontSize?: number;
  align?: "center" | "left" | "right";
  stagger?: number;
  boxEmphasis?: boolean;
}

export const TelopWithEmphasis: React.FC<TelopWithEmphasisProps> = ({
  lines,
  emphasis,
  style,
  animation,
  fontSize,
  subFontSize,
  align = "center",
  stagger = 5,
  boxEmphasis = true,
}) => {
  const frame = useCurrentFrame();

  // 行ごとのアニメーション
  const getLineAnimation = (lineIndex: number): React.CSSProperties => {
    const delay = lineIndex * stagger;
    const progress = Math.max(0, frame - delay);

    const opacity = interpolate(progress, [0, 12], [0, 1], {
      extrapolateRight: "clamp",
    });

    const translateY = interpolate(progress, [0, 15], [30, 0], {
      extrapolateRight: "clamp",
    });

    const scale = animation === "pop" || animation === "scale"
      ? interpolate(progress, [0, 8, 12], [0.8, 1.05, 1], {
          extrapolateRight: "clamp",
        })
      : 1;

    return {
      opacity,
      transform: `translateY(${translateY}px) scale(${scale})`,
    };
  };

  // 強調色を取得
  const getEmphasisColor = (type: EmphasisType): string => {
    return style.emphasis[type];
  };

  // テキストに強調を適用
  const applyEmphasis = (text: string, lineIndex: number): React.ReactNode => {
    if (emphasis.length === 0) {
      return text;
    }

    let result: React.ReactNode[] = [];
    let remainingText = text;
    let keyIndex = 0;

    // 強調箇所を検索して分割
    for (const emp of emphasis) {
      const index = remainingText.indexOf(emp.word);
      if (index !== -1) {
        // 強調前のテキスト
        if (index > 0) {
          result.push(
            <span key={`text-${lineIndex}-${keyIndex++}`}>
              {remainingText.substring(0, index)}
            </span>
          );
        }
        // 強調テキスト（ボックススタイル or テキストカラー）
        const emphasisColor = getEmphasisColor(emp.type);
        result.push(
          boxEmphasis ? (
            <span
              key={`emphasis-${lineIndex}-${keyIndex++}`}
              style={{
                backgroundColor: emphasisColor,
                color: colors.textWhite,
                padding: "6px 20px",
                borderRadius: designTokens.borderRadius.sm,
                marginLeft: 6,
                marginRight: 6,
                display: "inline-block",
              }}
            >
              {emp.word}
            </span>
          ) : (
            <span
              key={`emphasis-${lineIndex}-${keyIndex++}`}
              style={{
                color: emphasisColor,
                fontWeight: 900,
              }}
            >
              {emp.word}
            </span>
          )
        );
        remainingText = remainingText.substring(index + emp.word.length);
      }
    }

    // 残りのテキスト
    if (remainingText) {
      result.push(<span key={`text-${lineIndex}-end`}>{remainingText}</span>);
    }

    return result.length > 0 ? result : text;
  };

  const containerStyle: React.CSSProperties = {
    display: "flex",
    flexDirection: "column",
    alignItems: align === "center" ? "center" : align === "left" ? "flex-start" : "flex-end",
    justifyContent: "center",
    gap: designTokens.spacing.sm,
  };

  const getTextStyle = (lineIndex: number): React.CSSProperties => {
    const isFirstLine = lineIndex === 0;
    const baseFontSize = fontSize || style.telop.baseFontSize;
    const secondaryFontSize = subFontSize || baseFontSize * 0.75;

    return {
      fontFamily: style.telop.fontFamily,
      fontSize: isFirstLine ? baseFontSize : secondaryFontSize,
      fontWeight: isFirstLine ? "bold" : "normal",
      color: isFirstLine ? style.telop.color : colors.textSub,
      lineHeight: style.telop.lineHeight,
      textAlign: align,
      margin: 0,
      padding: 0,
      ...getLineAnimation(lineIndex),
    };
  };

  return (
    <div style={containerStyle}>
      {lines.map((line, index) => (
        <p key={index} style={getTextStyle(index)}>
          {applyEmphasis(line, index)}
        </p>
      ))}
    </div>
  );
};
