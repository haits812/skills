import { interpolate, useCurrentFrame } from "remotion";

interface ChalkboardFrameProps {
  children: React.ReactNode;
  variant?: "dark" | "green";
  width?: string | number;
  height?: string | number;
  animate?: boolean;
}

export const ChalkboardFrame: React.FC<ChalkboardFrameProps> = ({
  children,
  variant = "green",
  width = "90%",
  height = "85%",
  animate = true,
}) => {
  const frame = useCurrentFrame();

  // アニメーション
  const opacity = animate
    ? interpolate(frame, [0, 15], [0, 1], { extrapolateRight: "clamp" })
    : 1;
  const scale = animate
    ? interpolate(frame, [0, 12, 18], [0.95, 1.02, 1], { extrapolateRight: "clamp" })
    : 1;

  // 黒板の色
  const boardColors = {
    green: {
      gradient: "linear-gradient(180deg, #2D5A4A 0%, #1E3D32 50%, #152A24 100%)",
      shadow: "inset 0 2px 8px rgba(0,0,0,0.3), inset 0 -2px 8px rgba(255,255,255,0.05)",
    },
    dark: {
      gradient: "linear-gradient(180deg, #2A2A2A 0%, #1A1A1A 50%, #0F0F0F 100%)",
      shadow: "inset 0 2px 8px rgba(0,0,0,0.4), inset 0 -2px 8px rgba(255,255,255,0.03)",
    },
  };

  const colors = boardColors[variant];

  return (
    <div
      style={{
        width,
        height,
        opacity,
        transform: `scale(${scale})`,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      {/* 木枠 */}
      <div
        style={{
          width: "100%",
          height: "100%",
          background: "linear-gradient(135deg, #8B6914 0%, #6B4F0E 25%, #8B6914 50%, #5C4310 75%, #8B6914 100%)",
          borderRadius: 16,
          padding: 14,
          boxShadow: "0 12px 48px rgba(0,0,0,0.4), 0 4px 16px rgba(0,0,0,0.2)",
          display: "flex",
          alignItems: "stretch",
          justifyContent: "stretch",
        }}
      >
        {/* 木枠の内側ベベル */}
        <div
          style={{
            width: "100%",
            height: "100%",
            background: "linear-gradient(135deg, #5C4310 0%, #8B6914 50%, #5C4310 100%)",
            borderRadius: 8,
            padding: 6,
            boxShadow: "inset 2px 2px 4px rgba(0,0,0,0.3), inset -2px -2px 4px rgba(255,255,255,0.1)",
            display: "flex",
            alignItems: "stretch",
            justifyContent: "stretch",
          }}
        >
          {/* 黒板本体 */}
          <div
            style={{
              width: "100%",
              height: "100%",
              background: colors.gradient,
              borderRadius: 4,
              boxShadow: colors.shadow,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              padding: 40,
              position: "relative",
              overflow: "hidden",
            }}
          >
            {/* チョーク跡のテクスチャ（微妙なノイズ感） */}
            <div
              style={{
                position: "absolute",
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                background: `
                  radial-gradient(circle at 20% 30%, rgba(255,255,255,0.02) 0%, transparent 50%),
                  radial-gradient(circle at 80% 70%, rgba(255,255,255,0.015) 0%, transparent 40%),
                  radial-gradient(circle at 50% 50%, rgba(255,255,255,0.01) 0%, transparent 60%)
                `,
                pointerEvents: "none",
              }}
            />
            {/* コンテンツ */}
            <div
              style={{
                position: "relative",
                zIndex: 1,
                width: "100%",
                height: "100%",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              {children}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
