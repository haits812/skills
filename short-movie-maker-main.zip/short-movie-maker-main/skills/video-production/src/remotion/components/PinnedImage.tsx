import { Img, interpolate, useCurrentFrame, staticFile } from "remotion";

interface PinnedImageProps {
  src: string;
  width?: string | number;
  height?: string | number;
  rotation?: number;  // -10 ~ 10度
  pinPosition?: "top-left" | "top-center" | "top-right";
  pinColor?: string;
  animate?: boolean;
  delay?: number;  // アニメーション遅延フレーム
}

export const PinnedImage: React.FC<PinnedImageProps> = ({
  src,
  width = "100%",
  height = "100%",
  rotation = -2,
  pinPosition = "top-center",
  pinColor = "#E53935",  // 赤いピン
  animate = true,
  delay = 0,
}) => {
  const frame = useCurrentFrame();
  const progress = Math.max(0, frame - delay);

  // アニメーション
  const opacity = animate
    ? interpolate(progress, [0, 12], [0, 1], { extrapolateRight: "clamp" })
    : 1;
  const scale = animate
    ? interpolate(progress, [0, 10, 15], [0.8, 1.05, 1], { extrapolateRight: "clamp" })
    : 1;
  const translateY = animate
    ? interpolate(progress, [0, 15], [-20, 0], { extrapolateRight: "clamp" })
    : 0;

  // ピンの位置
  const pinPositions = {
    "top-left": { left: "15%", right: "auto" },
    "top-center": { left: "50%", right: "auto", transform: "translateX(-50%)" },
    "top-right": { left: "auto", right: "15%" },
  };

  const pinPos = pinPositions[pinPosition];

  return (
    <div
      style={{
        width,
        height,
        position: "relative",
        opacity,
        transform: `rotate(${rotation}deg) scale(${scale}) translateY(${translateY}px)`,
        transformOrigin: "center top",
      }}
    >
      {/* 画像の影（浮いてる感） */}
      <div
        style={{
          position: "absolute",
          top: 8,
          left: 8,
          right: -8,
          bottom: -8,
          background: "rgba(0,0,0,0.25)",
          borderRadius: 8,
          filter: "blur(8px)",
          transform: `rotate(${rotation * 0.5}deg)`,
        }}
      />

      {/* 画像本体 */}
      <div
        style={{
          position: "relative",
          width: "100%",
          height: "100%",
          background: "#FFFFFF",
          borderRadius: 8,
          padding: 8,
          boxShadow: "0 4px 12px rgba(0,0,0,0.15)",
        }}
      >
        <Img
          src={src.startsWith("http") ? src : staticFile(src)}
          style={{
            width: "100%",
            height: "100%",
            objectFit: "cover",
            borderRadius: 4,
          }}
        />
      </div>

      {/* ピン */}
      <div
        style={{
          position: "absolute",
          top: -12,
          ...pinPos,
          width: 28,
          height: 28,
          zIndex: 10,
        }}
      >
        {/* ピンの頭 */}
        <div
          style={{
            width: 28,
            height: 28,
            borderRadius: "50%",
            background: `radial-gradient(circle at 30% 30%, ${pinColor} 0%, ${adjustColor(pinColor, -30)} 100%)`,
            boxShadow: `0 3px 6px rgba(0,0,0,0.3), inset 0 2px 4px rgba(255,255,255,0.3)`,
          }}
        />
        {/* ピンの針（影として表現） */}
        <div
          style={{
            position: "absolute",
            top: 20,
            left: "50%",
            transform: "translateX(-50%)",
            width: 4,
            height: 12,
            background: "linear-gradient(180deg, #888 0%, #444 100%)",
            borderRadius: 2,
          }}
        />
      </div>
    </div>
  );
};

// ヘルパー関数：色を明るく/暗くする
function adjustColor(hex: string, amount: number): string {
  const num = parseInt(hex.replace("#", ""), 16);
  const r = Math.min(255, Math.max(0, (num >> 16) + amount));
  const g = Math.min(255, Math.max(0, ((num >> 8) & 0x00ff) + amount));
  const b = Math.min(255, Math.max(0, (num & 0x0000ff) + amount));
  return `#${((r << 16) | (g << 8) | b).toString(16).padStart(6, "0")}`;
}
