import { interpolate, useCurrentFrame } from "remotion";
import type { BulletItem, StyleConfig } from "../types";
import { colors, designTokens } from "../types";

interface BulletListProps {
  items: BulletItem[];
  style: StyleConfig;
  stagger?: number;  // アイテム間のアニメーション遅延フレーム
  fontSize?: number;
  defaultIcon?: string;  // デフォルトアイコン
}

export const BulletList: React.FC<BulletListProps> = ({
  items,
  style,
  stagger = 8,
  fontSize,
  defaultIcon = "✓",
}) => {
  const frame = useCurrentFrame();

  // アイテムごとのアニメーション
  const getItemAnimation = (index: number): React.CSSProperties => {
    const delay = index * stagger;
    const progress = Math.max(0, frame - delay);

    const opacity = interpolate(progress, [0, 12], [0, 1], {
      extrapolateRight: "clamp",
    });

    const translateX = interpolate(progress, [0, 15], [-30, 0], {
      extrapolateRight: "clamp",
    });

    const scale = interpolate(progress, [0, 10, 15], [0.9, 1.02, 1], {
      extrapolateRight: "clamp",
    });

    return {
      opacity,
      transform: `translateX(${translateX}px) scale(${scale})`,
    };
  };

  const baseFontSize = fontSize || designTokens.fontSize.body;

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        gap: designTokens.spacing.md,
        width: "100%",
      }}
    >
      {items.map((item, index) => (
        <div
          key={index}
          style={{
            display: "flex",
            alignItems: "center",
            gap: designTokens.spacing.md,
            ...getItemAnimation(index),
          }}
        >
          {/* アイコン */}
          <div
            style={{
              width: baseFontSize * 1.2,
              height: baseFontSize * 1.2,
              borderRadius: "50%",
              backgroundColor: colors.primary,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              flexShrink: 0,
            }}
          >
            <span
              style={{
                fontSize: baseFontSize * 0.6,
                color: colors.textWhite,
                fontWeight: "bold",
              }}
            >
              {item.icon || defaultIcon}
            </span>
          </div>
          {/* テキスト */}
          <span
            style={{
              fontFamily: style.telop.fontFamily,
              fontSize: baseFontSize,
              fontWeight: 700,
              color: colors.textMain,
              lineHeight: 1.4,
            }}
          >
            {item.text}
          </span>
        </div>
      ))}
    </div>
  );
};
