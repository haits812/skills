import { interpolate, useCurrentFrame } from "remotion";
import { colors, designTokens } from "../types";
import type { StyleConfig, Emphasis } from "../types";

interface TelopAreaProps {
  lines: string[];
  emphasis?: Emphasis[];
  style: StyleConfig;
  height?: string | number;
}

export const TelopArea: React.FC<TelopAreaProps> = ({
  lines,
  emphasis = [],
  style,
  height = "25%",
}) => {
  const frame = useCurrentFrame();

  const translateY = interpolate(frame, [0, 18], [40, 0], {
    extrapolateRight: "clamp",
  });

  const opacity = interpolate(frame, [0, 15], [0, 1], {
    extrapolateRight: "clamp",
  });

  const renderTextWithEmphasis = (text: string, lineIndex: number) => {
    let result = text;
    const elements: React.ReactNode[] = [];
    let lastIndex = 0;

    // 強調箇所を見つけてハイライト
    const sortedEmphasis = [...emphasis].sort((a, b) => {
      const indexA = text.indexOf(a.word);
      const indexB = text.indexOf(b.word);
      return indexA - indexB;
    });

    for (const emp of sortedEmphasis) {
      const index = text.indexOf(emp.word, lastIndex);
      if (index === -1) continue;

      // 強調前のテキスト
      if (index > lastIndex) {
        elements.push(
          <span key={`text-${lineIndex}-${lastIndex}`}>
            {text.slice(lastIndex, index)}
          </span>
        );
      }

      // 強調テキスト（ボックススタイル）
      const emphasisColor = style.emphasis[emp.type] || colors.primary;
      elements.push(
        <span
          key={`emp-${lineIndex}-${index}`}
          style={{
            backgroundColor: emphasisColor,
            color: colors.textWhite,
            padding: "4px 16px",
            borderRadius: designTokens.borderRadius.sm,
            marginLeft: 4,
            marginRight: 4,
          }}
        >
          {emp.word}
        </span>
      );

      lastIndex = index + emp.word.length;
    }

    // 残りのテキスト
    if (lastIndex < text.length) {
      elements.push(
        <span key={`text-${lineIndex}-end`}>{text.slice(lastIndex)}</span>
      );
    }

    return elements.length > 0 ? elements : text;
  };

  return (
    <div
      style={{
        position: "absolute",
        bottom: 0,
        left: 0,
        right: 0,
        height,
        backgroundColor: `rgba(255, 255, 255, 0.95)`,
        borderTop: `3px solid ${colors.bgAccent}`,
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        padding: `0 ${designTokens.spacing.lg}px`,
        transform: `translateY(${translateY}px)`,
        opacity,
      }}
    >
      {lines.map((line, index) => (
        <div
          key={index}
          style={{
            fontFamily: style.telop.fontFamily,
            fontSize: index === 0 ? designTokens.fontSize.subtitle : designTokens.fontSize.body,
            fontWeight: index === 0 ? "bold" : "normal",
            color: index === 0 ? style.telop.color : colors.textSub,
            lineHeight: 1.4,
            marginBottom: index < lines.length - 1 ? 8 : 0,
          }}
        >
          {renderTextWithEmphasis(line, index)}
        </div>
      ))}
    </div>
  );
};
