import { Img, staticFile } from "remotion";
import type { AnimationType } from "../types";
import { useFadeIn } from "../animations/useFadeIn";
import { useSlideLeft } from "../animations/useSlideIn";

interface SceneImageProps {
  path: string;
  animation: AnimationType;
  width?: string | number;
  height?: string | number;
}

export const SceneImage: React.FC<SceneImageProps> = ({
  path,
  animation,
  width = "100%",
  height = "auto",
}) => {
  const fadeIn = useFadeIn(0, 12);
  const slideLeft = useSlideLeft(0, 10);

  const getAnimationStyle = (): React.CSSProperties => {
    switch (animation) {
      case "fade":
        return { opacity: fadeIn };
      case "slide_left":
        return {
          opacity: slideLeft.opacity,
          transform: `translateX(${slideLeft.translateX}px)`,
        };
      default:
        return { opacity: 1 };
    }
  };

  const containerStyle: React.CSSProperties = {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    width,
    height,
    ...getAnimationStyle(),
  };

  const imageStyle: React.CSSProperties = {
    maxWidth: "100%",
    maxHeight: "100%",
    objectFit: "contain",
    borderRadius: 12,
  };

  return (
    <div style={containerStyle}>
      <Img src={staticFile(path)} style={imageStyle} />
    </div>
  );
};
