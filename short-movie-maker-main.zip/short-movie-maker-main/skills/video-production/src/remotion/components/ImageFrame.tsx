import { Img, staticFile, interpolate, useCurrentFrame } from "remotion";
import { colors, designTokens } from "../types";

interface ImageFrameProps {
  src: string;
  width?: string | number;
  height?: string | number;
  animate?: boolean;
}

export const ImageFrame: React.FC<ImageFrameProps> = ({
  src,
  width = "100%",
  height = "100%",
  animate = true,
}) => {
  const frame = useCurrentFrame();

  const scale = animate
    ? interpolate(frame, [0, 20], [0.92, 1], {
        extrapolateRight: "clamp",
      })
    : 1;

  const opacity = animate
    ? interpolate(frame, [0, 15], [0, 1], {
        extrapolateRight: "clamp",
      })
    : 1;

  return (
    <div
      style={{
        width,
        height,
        borderRadius: designTokens.borderRadius.lg,
        boxShadow: designTokens.shadow.card,
        overflow: "hidden",
        transform: `scale(${scale})`,
        opacity,
        backgroundColor: colors.bgWhite,
      }}
    >
      <Img
        src={staticFile(src)}
        style={{
          width: "100%",
          height: "100%",
          objectFit: "cover",
        }}
      />
    </div>
  );
};
