import { interpolate, useCurrentFrame, Img, staticFile } from "remotion";
import { colors, designTokens } from "../types";

type CardVariant = "text" | "image" | "imageText" | "textImage";

interface ContentCardProps {
  variant: CardVariant;
  title?: string;
  body?: string[];
  imageSrc?: string;
  imagePosition?: "left" | "right" | "top" | "bottom";
  animate?: boolean;
  startFrame?: number;
}

export const ContentCard: React.FC<ContentCardProps> = ({
  variant,
  title,
  body = [],
  imageSrc,
  imagePosition = "left",
  animate = true,
  startFrame = 0,
}) => {
  const frame = useCurrentFrame();
  const progress = Math.max(0, frame - startFrame);

  // カード全体のアニメーション
  const cardOpacity = animate
    ? interpolate(progress, [0, 15], [0, 1], { extrapolateRight: "clamp" })
    : 1;
  const cardScale = animate
    ? interpolate(progress, [0, 12], [0.95, 1], { extrapolateRight: "clamp" })
    : 1;
  const cardTranslateY = animate
    ? interpolate(progress, [0, 15], [20, 0], { extrapolateRight: "clamp" })
    : 0;

  // テキストコンテンツ
  const TextContent = () => (
    <div
      style={{
        flex: 1,
        display: "flex",
        flexDirection: "column",
        gap: designTokens.spacing.sm,
        padding: designTokens.spacing.md,
      }}
    >
      {title && (
        <h2
          style={{
            fontFamily: "Noto Sans JP, sans-serif",
            fontSize: designTokens.fontSize.subtitle,
            fontWeight: 800,
            color: colors.textMain,
            margin: 0,
            lineHeight: 1.3,
          }}
        >
          {title}
        </h2>
      )}
      {body.map((line, index) => (
        <p
          key={index}
          style={{
            fontFamily: "Noto Sans JP, sans-serif",
            fontSize: designTokens.fontSize.body,
            fontWeight: 500,
            color: colors.textSub,
            margin: 0,
            lineHeight: 1.6,
          }}
        >
          {line}
        </p>
      ))}
    </div>
  );

  // 画像コンテンツ
  const ImageContent = ({ size = "full" }: { size?: "full" | "half" }) => (
    <div
      style={{
        flex: size === "half" ? 1 : undefined,
        width: size === "full" ? "100%" : undefined,
        height: size === "full" ? "100%" : undefined,
        padding: designTokens.spacing.sm,
      }}
    >
      {imageSrc && (
        <div
          style={{
            width: "100%",
            height: "100%",
            borderRadius: designTokens.borderRadius.md,
            overflow: "hidden",
            boxShadow: designTokens.shadow.subtle,
          }}
        >
          <Img
            src={staticFile(imageSrc)}
            style={{
              width: "100%",
              height: "100%",
              objectFit: "cover",
            }}
          />
        </div>
      )}
    </div>
  );

  // バリアントに応じたレイアウト
  const renderContent = () => {
    switch (variant) {
      case "text":
        return <TextContent />;
      case "image":
        return <ImageContent size="full" />;
      case "imageText":
      case "textImage":
        const isHorizontal = imagePosition === "left" || imagePosition === "right";
        const imageFirst =
          (variant === "imageText" && imagePosition !== "right") ||
          (variant === "textImage" && imagePosition === "right");

        return (
          <div
            style={{
              display: "flex",
              flexDirection: isHorizontal ? "row" : "column",
              width: "100%",
              height: "100%",
              gap: designTokens.spacing.sm,
            }}
          >
            {imageFirst ? (
              <>
                <ImageContent size="half" />
                <TextContent />
              </>
            ) : (
              <>
                <TextContent />
                <ImageContent size="half" />
              </>
            )}
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div
      style={{
        backgroundColor: colors.bgWhite,
        borderRadius: designTokens.borderRadius.lg,
        boxShadow: designTokens.shadow.card,
        border: `1px solid ${colors.bgAccent}`,
        overflow: "hidden",
        opacity: cardOpacity,
        transform: `scale(${cardScale}) translateY(${cardTranslateY}px)`,
        width: "100%",
        height: "100%",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      {renderContent()}
    </div>
  );
};
