import { AbsoluteFill } from "remotion";
import type { StyleConfig } from "../types";

interface BackgroundProps {
  style: StyleConfig;
}

export const Background: React.FC<BackgroundProps> = ({ style }) => {
  const { background } = style;

  const backgroundStyle: React.CSSProperties = {
    backgroundColor: background.type === "solid" ? background.color : undefined,
    background:
      background.type === "gradient" && background.colors
        ? `linear-gradient(180deg, ${background.colors.join(", ")})`
        : undefined,
  };

  return <AbsoluteFill style={backgroundStyle} />;
};
