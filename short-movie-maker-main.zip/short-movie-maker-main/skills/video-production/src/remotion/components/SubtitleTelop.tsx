import { interpolate, useCurrentFrame } from "remotion";
import { colors, designTokens } from "../types";

type SubtitleAnimation = "fadeSlide" | "fade" | "pop" | "typewriter";

interface SubtitleTelopProps {
  text: string;
  subText?: string; // 2行目（オプション）
  animation?: SubtitleAnimation;
  startFrame?: number;
}

export const SubtitleTelop: React.FC<SubtitleTelopProps> = ({
  text,
  subText,
  animation = "fadeSlide",
  startFrame = 0,
}) => {
  const frame = useCurrentFrame();
  const progress = Math.max(0, frame - startFrame);

  // アニメーション計算
  const getAnimationStyle = (): React.CSSProperties => {
    switch (animation) {
      case "fadeSlide": {
        const opacity = interpolate(progress, [0, 10], [0, 1], {
          extrapolateRight: "clamp",
        });
        const translateY = interpolate(progress, [0, 12], [20, 0], {
          extrapolateRight: "clamp",
        });
        return {
          opacity,
          transform: `translateY(${translateY}px)`,
        };
      }
      case "fade": {
        const opacity = interpolate(progress, [0, 10], [0, 1], {
          extrapolateRight: "clamp",
        });
        return { opacity };
      }
      case "pop": {
        const opacity = interpolate(progress, [0, 8], [0, 1], {
          extrapolateRight: "clamp",
        });
        const scale = interpolate(progress, [0, 6, 10], [0.8, 1.05, 1], {
          extrapolateRight: "clamp",
        });
        return {
          opacity,
          transform: `scale(${scale})`,
        };
      }
      case "typewriter": {
        // typewriterは文字数ベースで表示
        const charsToShow = Math.floor(progress / 2);
        return {
          opacity: 1,
          clipPath: `inset(0 ${Math.max(0, 100 - (charsToShow / text.length) * 100)}% 0 0)`,
        };
      }
      default:
        return {};
    }
  };

  return (
    <div
      style={{
        position: "absolute",
        bottom: 0,
        left: 0,
        right: 0,
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        padding: `${designTokens.spacing.md}px ${designTokens.spacing.lg}px`,
        paddingBottom: designTokens.spacing.lg,
      }}
    >
      <div
        style={{
          background: "rgba(255, 255, 255, 0.95)",
          backdropFilter: "blur(8px)",
          borderRadius: designTokens.borderRadius.md,
          padding: `${designTokens.spacing.sm}px ${designTokens.spacing.lg}px`,
          boxShadow: `0 4px 24px rgba(124, 58, 237, 0.12)`,
          border: `2px solid ${colors.bgAccent}`,
          maxWidth: "85%",
          textAlign: "center",
          ...getAnimationStyle(),
        }}
      >
        {/* メインテキスト */}
        <p
          style={{
            fontFamily: "Noto Sans JP, sans-serif",
            fontSize: designTokens.fontSize.body,
            fontWeight: 700,
            color: colors.primary,
            lineHeight: 1.5,
            margin: 0,
            letterSpacing: "0.02em",
          }}
        >
          {text}
        </p>

        {/* サブテキスト（2行目） - 同じフォントサイズ */}
        {subText && (
          <p
            style={{
              fontFamily: "Noto Sans JP, sans-serif",
              fontSize: designTokens.fontSize.body,
              fontWeight: 700,
              color: colors.primary,
              lineHeight: 1.5,
              margin: 0,
              marginTop: 4,
              letterSpacing: "0.02em",
            }}
          >
            {subText}
          </p>
        )}
      </div>
    </div>
  );
};
