// レイアウト種別
export type LayoutType =
  | 'intro'
  | 'main-insert'
  | 'main-lecture'
  | 'main-board'      // 黒板風レイアウト
  | 'main-fullimage'  // フルサイズ画像レイアウト
  | 'outro'
  | 'cta';

// アニメーション種別
export type AnimationType = 'fade' | 'slide_up' | 'slide_left' | 'pop' | 'scale' | 'none';

// 字幕アニメーション種別
export type SubtitleAnimation = 'fadeSlide' | 'fade' | 'pop' | 'typewriter';

// コンテンツカードバリアント
export type ContentVariant = 'text' | 'image' | 'imageText' | 'textImage';

// 強調色種別
export type EmphasisType = 'keyword' | 'positive' | 'negative' | 'number';

// 強調情報
export interface Emphasis {
  word: string;
  type: EmphasisType;
}

// ページ分割設定（調整可能）
export interface SplitConfig {
  // 1行の目標文字数
  targetCharsPerLine: number;    // デフォルト: 16
  maxCharsPerLine: number;       // デフォルト: 20
  // 1ページの最大行数
  maxLinesPerPage: number;       // デフォルト: 2
  // 最小表示時間（秒）
  minDisplaySeconds: number;     // デフォルト: 1.5
}

// デフォルト分割設定
export const defaultSplitConfig: SplitConfig = {
  targetCharsPerLine: 16,
  maxCharsPerLine: 20,
  maxLinesPerPage: 2,
  minDisplaySeconds: 1.5,
};

// テロップページ（音声同期で順次表示）
export interface TelopPage {
  lines: string[];               // 最大2行（句読点削除済み）
  emphasis: Emphasis[];          // このページ内の強調
  // 文字インデックス（タイムスタンプ計算用）
  startCharIndex: number;
  endCharIndex: number;
  // フレーム（scene-composerで計算）
  startFrame?: number;
  endFrame?: number;
  // アニメーション
  animation?: {
    in: AnimationType;
    out: AnimationType;
  };
}

// テロップ情報（従来互換 + pages対応）
export interface TelopData {
  lines: string[];
  emphasis: Emphasis[];
  animation: {
    in: AnimationType;
    out: AnimationType;
  };
  // 新規: ページ分割されたテロップ（これがあれば優先）
  pages?: TelopPage[];
}

// 画像情報
export interface ImageData {
  path: string;
  prompt?: string;
  animation: {
    in: AnimationType;
    out?: AnimationType;
  };
}

// トランジション
export interface Transition {
  type: AnimationType;
  durationFrames: number;
}

// 字幕データ（音声同期テロップ）
export interface SubtitleData {
  text: string;
  subText?: string;
  animation?: SubtitleAnimation;
}

// コンテンツカードデータ
export interface ContentData {
  variant: ContentVariant;
  title?: string;
  body?: string[];
  imageSrc?: string;
  imagePosition?: 'left' | 'right' | 'top' | 'bottom';
}

// 箇条書きアイテム
export interface BulletItem {
  text: string;
  icon?: string;  // オプションのアイコン/絵文字
}

// シーン情報
export interface Scene {
  id: string;
  layout: LayoutType;
  startFrame: number;
  endFrame: number;
  telop: TelopData;
  image: ImageData | null;
  transition: Transition;
  // 新デザイン用（オプション）
  subtitle?: SubtitleData;
  content?: ContentData;
  bullets?: BulletItem[];  // 箇条書き（OutroLayout等で使用）
}

// 音声トラック
export interface VoiceTrack {
  sceneId: string;
  path: string;
  startFrame: number;
  durationFrames: number;
}

// スタイル設定
export interface StyleConfig {
  background: {
    type: 'solid' | 'gradient';
    color?: string;
    colors?: string[];
  };
  telop: {
    fontFamily: string;
    baseFontSize: number;
    fontWeight: string | number;
    color: string;
    lineHeight: number;
  };
  emphasis: {
    keyword: string;
    positive: string;
    negative: string;
    number: string;
  };
}

// メタ情報
export interface Meta {
  title?: string;
  fps: number;
  width: number;
  height: number;
  durationInFrames: number;
}

// コンポジションProps
export interface CompositionProps {
  meta: Meta;
  scenes: Scene[];
  audio: {
    voice: VoiceTrack[];
  };
  style: StyleConfig;
}

// レイアウトコンポーネントProps
export interface LayoutProps {
  telop: TelopData;
  image: ImageData | null;
  style: StyleConfig;
  durationInFrames: number;
  // 新デザイン用
  subtitle?: SubtitleData;
  content?: ContentData;
  bullets?: BulletItem[];  // 箇条書き
}

// カラーパレット
export const colors = {
  // 背景
  bgBase: '#F8F6FF',
  bgAccent: '#EDE9FE',
  bgWhite: '#FFFFFF',

  // テキスト
  textMain: '#1A1A2E',
  textSub: '#4A4A6A',
  textWhite: '#FFFFFF',

  // 強調色
  primary: '#7C3AED',
  primaryLight: '#A855F7',
  positive: '#10B981',
  negative: '#F59E0B',
  number: '#EC4899',

  // シャドウ
  shadowPurple: 'rgba(124, 58, 237, 0.15)',
  shadowDark: 'rgba(26, 26, 46, 0.1)',
};

// デザイントークン
export const designTokens = {
  // 角丸
  borderRadius: {
    sm: 8,
    md: 16,
    lg: 24,
    xl: 32,
  },
  // シャドウ
  shadow: {
    card: `0 8px 32px ${colors.shadowPurple}`,
    subtle: `0 4px 16px ${colors.shadowDark}`,
  },
  // スペーシング
  spacing: {
    xs: 8,
    sm: 16,
    md: 32,
    lg: 64,
    xl: 96,
  },
  // フォントサイズ（1920x1080向けに最適化）
  fontSize: {
    hero: 120,      // 96 → 120 (+25%)
    title: 96,      // 80 → 96 (+20%)
    subtitle: 72,   // 56 → 72 (+28%)
    body: 56,       // 48 → 56 (+17%)
    caption: 42,    // 36 → 42 (+17%)
  },
};

// デフォルトスタイル（project.yaml準拠 - 白背景・黒テロップ）
export const defaultStyle: StyleConfig = {
  background: {
    type: 'solid',
    color: '#FFFFFF',
  },
  telop: {
    fontFamily: 'Noto Sans JP, sans-serif',
    baseFontSize: 56,
    fontWeight: 'bold',
    color: '#1A1A1A',
    lineHeight: 1.4,
  },
  emphasis: {
    keyword: '#FF6B6B',
    positive: '#4ECDC4',
    negative: '#FFE66D',
    number: '#FF8C42',
  },
};
