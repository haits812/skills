import { AbsoluteFill } from "remotion";
import type { LayoutProps } from "../types";
import { designTokens } from "../types";
import { BaseLayout } from "./BaseLayout";
import { ContentCard } from "../components/ContentCard";
import { PaperFrame } from "../components/PaperFrame";
import { TelopWithEmphasis } from "../components/TelopWithEmphasis";
import { AccentBar } from "../components/AccentBar";

export const MainInsertLayout: React.FC<LayoutProps> = ({
  telop,
  image,
  style,
  subtitle,
  content,
}) => {
  // 新デザイン（subtitle/contentがある場合）
  if (subtitle || content) {
    const imageSrc = content?.imageSrc || image?.path;

    // 画像+テキストの場合
    if (content?.variant === "imageText" || content?.variant === "textImage") {
      return (
        <BaseLayout subtitle={subtitle} showAccentBar={true} style={style}>
          <div style={{ width: "90%", height: "70%" }}>
            <ContentCard
              variant={content.variant}
              title={content.title}
              body={content.body}
              imageSrc={imageSrc}
              imagePosition={content.imagePosition || "left"}
            />
          </div>
        </BaseLayout>
      );
    }

    // 画像のみの場合
    return (
      <BaseLayout subtitle={subtitle} showAccentBar={true} style={style}>
        <div style={{ width: "80%", height: "75%" }}>
          <ContentCard
            variant="image"
            imageSrc={imageSrc}
          />
        </div>
      </BaseLayout>
    );
  }

  // 旧デザイン（テロップ左55% + 画像右40%の横並び、下部にキャプション用スペース）
  const bgColor = style.background.type === 'solid' ? style.background.color : '#FFFFFF';

  return (
    <AbsoluteFill style={{ backgroundColor: bgColor }}>
      <AccentBar position="top" height={6} />

      {/* メインコンテンツエリア（キャプション用スペースを除く） */}
      <div
        style={{
          position: "absolute",
          top: 6,
          left: 0,
          right: 0,
          bottom: 140, // キャプション用スペース
          display: "flex",
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "center",
          gap: "5%",
          padding: designTokens.spacing.lg,
        }}
      >
        {/* テロップエリア（左55%） */}
        <div
          style={{
            width: "55%",
            height: "100%",
            display: "flex",
            flexDirection: "column",
            alignItems: "flex-start",
            justifyContent: "center",
            paddingLeft: designTokens.spacing.lg,
          }}
        >
          <TelopWithEmphasis
            lines={telop.lines}
            emphasis={telop.emphasis}
            style={style}
            animation={telop.animation.in}
            fontSize={designTokens.fontSize.title}
            subFontSize={designTokens.fontSize.subtitle}
            align="left"
            stagger={6}
          />
        </div>

        {/* 画像エリア（右側・横長） */}
        {image && (
          <div
            style={{
              width: "45%",
              height: "65%",  // 横長比率（16:9に近い）
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <PaperFrame
              src={image.path}
              width="100%"
              height="100%"
              variant="taped"
              rotation={2}
              shadow="soft"
            />
          </div>
        )}
      </div>
    </AbsoluteFill>
  );
};
