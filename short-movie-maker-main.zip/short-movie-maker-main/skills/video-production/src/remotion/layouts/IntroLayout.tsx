import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import type { LayoutProps } from "../types";
import { colors, designTokens } from "../types";
import { BaseLayout } from "./BaseLayout";
import { TelopWithEmphasis } from "../components/TelopWithEmphasis";
import { AccentBar } from "../components/AccentBar";

export const IntroLayout: React.FC<LayoutProps> = ({
  telop,
  style,
  subtitle,
}) => {
  const frame = useCurrentFrame();

  // タイトルアニメーション
  const titleOpacity = interpolate(frame, [0, 15], [0, 1], {
    extrapolateRight: "clamp",
  });
  const titleScale = interpolate(frame, [0, 10, 15], [0.9, 1.02, 1], {
    extrapolateRight: "clamp",
  });

  // 新デザイン（subtitleがある場合）
  if (subtitle) {
    return (
      <BaseLayout
        subtitle={subtitle}
        showAccentBar={true}
        accentBarPosition="both"
        style={style}
      >
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            gap: designTokens.spacing.md,
            opacity: titleOpacity,
            transform: `scale(${titleScale})`,
          }}
        >
          <h1
            style={{
              fontFamily: "Noto Sans JP, sans-serif",
              fontSize: designTokens.fontSize.hero,
              fontWeight: 900,
              color: colors.textMain,
              margin: 0,
              textAlign: "center",
              lineHeight: 1.2,
            }}
          >
            {telop.lines[0]}
          </h1>
          {telop.lines[1] && (
            <p
              style={{
                fontFamily: "Noto Sans JP, sans-serif",
                fontSize: designTokens.fontSize.subtitle,
                fontWeight: 500,
                color: colors.textSub,
                margin: 0,
                textAlign: "center",
              }}
            >
              {telop.lines[1]}
            </p>
          )}
        </div>
      </BaseLayout>
    );
  }

  // 旧デザイン（キャプション用スペースを下部に確保）
  const bgColor = style.background.type === 'solid' ? style.background.color : '#FFFFFF';

  return (
    <AbsoluteFill style={{ backgroundColor: bgColor }}>
      <AccentBar position="top" height={10} />
      <div
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          right: 0,
          bottom: 140, // キャプション用スペース
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          padding: designTokens.spacing.xl,
        }}
      >
        <TelopWithEmphasis
          lines={telop.lines}
          emphasis={telop.emphasis}
          style={style}
          animation={telop.animation.in}
          fontSize={designTokens.fontSize.hero}
          subFontSize={designTokens.fontSize.title}
          align="center"
          stagger={8}
        />
      </div>
    </AbsoluteFill>
  );
};
