import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import type { LayoutProps } from "../types";
import { colors, designTokens } from "../types";
import { BaseLayout } from "./BaseLayout";
import { TelopWithEmphasis } from "../components/TelopWithEmphasis";
import { BulletList } from "../components/BulletList";
import { AccentBar } from "../components/AccentBar";

export const OutroLayout: React.FC<LayoutProps> = ({
  telop,
  style,
  subtitle,
  bullets,
}) => {
  const frame = useCurrentFrame();

  // アウトロアニメーション（pop）
  const opacity = interpolate(frame, [0, 12], [0, 1], {
    extrapolateRight: "clamp",
  });
  const scale = interpolate(frame, [0, 8, 14], [0.85, 1.05, 1], {
    extrapolateRight: "clamp",
  });

  // 新デザイン（subtitleがある場合）
  if (subtitle) {
    return (
      <BaseLayout
        subtitle={subtitle}
        showAccentBar={true}
        accentBarPosition="both"
        style={style}
      >
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            gap: designTokens.spacing.sm,
            opacity,
            transform: `scale(${scale})`,
          }}
        >
          <h1
            style={{
              fontFamily: "Noto Sans JP, sans-serif",
              fontSize: designTokens.fontSize.title,
              fontWeight: 900,
              color: colors.textMain,
              margin: 0,
              textAlign: "center",
            }}
          >
            {telop.lines[0]}
          </h1>
          {telop.lines.slice(1).map((line, index) => (
            <p
              key={index}
              style={{
                fontFamily: "Noto Sans JP, sans-serif",
                fontSize: designTokens.fontSize.subtitle,
                fontWeight: 500,
                color: colors.textSub,
                margin: 0,
                textAlign: "center",
              }}
            >
              {line}
            </p>
          ))}
        </div>
      </BaseLayout>
    );
  }

  // 旧デザイン（キャプション用スペースを下部に確保）
  const bgColor = style.background.type === 'solid' ? style.background.color : '#FFFFFF';

  return (
    <AbsoluteFill style={{ backgroundColor: bgColor }}>
      <AccentBar position="top" height={10} />
      <div
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          right: 0,
          bottom: 140, // キャプション用スペース
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          padding: designTokens.spacing.xl,
          gap: designTokens.spacing.lg,
        }}
      >
        {/* タイトル */}
        <TelopWithEmphasis
          lines={[telop.lines[0]]}
          emphasis={telop.emphasis}
          style={style}
          animation="pop"
          fontSize={designTokens.fontSize.title}
          align="center"
          stagger={0}
        />

        {/* 箇条書き（bulletsがある場合） */}
        {bullets && bullets.length > 0 && (
          <div
            style={{
              width: "70%",
              display: "flex",
              justifyContent: "center",
            }}
          >
            <BulletList
              items={bullets}
              style={style}
              fontSize={designTokens.fontSize.body}
              stagger={8}
            />
          </div>
        )}

        {/* 箇条書きがない場合は残りの行を表示 */}
        {(!bullets || bullets.length === 0) && telop.lines.length > 1 && (
          <TelopWithEmphasis
            lines={telop.lines.slice(1)}
            emphasis={telop.emphasis}
            style={style}
            animation="pop"
            fontSize={designTokens.fontSize.subtitle}
            align="center"
            stagger={6}
          />
        )}
      </div>
    </AbsoluteFill>
  );
};
