import { AbsoluteFill } from "remotion";
import { designTokens, defaultStyle, type StyleConfig } from "../types";
import { AccentBar } from "../components/AccentBar";
import { SubtitleTelop } from "../components/SubtitleTelop";

interface BaseLayoutProps {
  children: React.ReactNode;
  subtitle?: {
    text: string;
    subText?: string;
    animation?: "fadeSlide" | "fade" | "pop" | "typewriter";
  };
  showAccentBar?: boolean;
  accentBarPosition?: "top" | "both";
  style?: StyleConfig;
}

export const BaseLayout: React.FC<BaseLayoutProps> = ({
  children,
  subtitle,
  showAccentBar = true,
  accentBarPosition = "top",
  style = defaultStyle,
}) => {
  // テロップエリアの高さを確保
  const subtitleAreaHeight = subtitle ? 140 : 0;

  // 背景色を style から取得
  const backgroundColor = style.background.type === 'solid'
    ? style.background.color
    : '#FFFFFF';

  return (
    <AbsoluteFill
      style={{
        backgroundColor,
      }}
    >
      {/* アクセントバー（上部） */}
      {showAccentBar && <AccentBar position="top" height={6} />}

      {/* アクセントバー（下部、オプション） */}
      {showAccentBar && accentBarPosition === "both" && (
        <AccentBar position="bottom" height={6} />
      )}

      {/* メインコンテンツエリア */}
      <div
        style={{
          position: "absolute",
          top: showAccentBar ? 6 : 0,
          left: 0,
          right: 0,
          bottom: subtitleAreaHeight,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          padding: designTokens.spacing.lg,
        }}
      >
        {children}
      </div>

      {/* 音声同期テロップ */}
      {subtitle && (
        <SubtitleTelop
          text={subtitle.text}
          subText={subtitle.subText}
          animation={subtitle.animation}
        />
      )}
    </AbsoluteFill>
  );
};
