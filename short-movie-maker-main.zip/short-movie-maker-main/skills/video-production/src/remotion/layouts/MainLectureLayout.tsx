import { AbsoluteFill } from "remotion";
import type { LayoutProps } from "../types";
import { designTokens } from "../types";
import { BaseLayout } from "./BaseLayout";
import { ContentCard } from "../components/ContentCard";
import { TelopWithEmphasis } from "../components/TelopWithEmphasis";
import { AccentBar } from "../components/AccentBar";

export const MainLectureLayout: React.FC<LayoutProps> = ({
  telop,
  style,
  subtitle,
  content,
}) => {
  // 新デザイン（subtitle/contentがある場合）
  if (subtitle || content) {
    return (
      <BaseLayout
        subtitle={subtitle}
        showAccentBar={true}
        style={style}
      >
        <div style={{ width: "85%", height: "70%" }}>
          {content ? (
            <ContentCard
              variant={content.variant}
              title={content.title}
              body={content.body}
              imageSrc={content.imageSrc}
              imagePosition={content.imagePosition}
            />
          ) : (
            // contentがなければtelopからカード生成
            <ContentCard
              variant="text"
              title={telop.lines[0]}
              body={telop.lines.slice(1)}
            />
          )}
        </div>
      </BaseLayout>
    );
  }

  // 旧デザイン（キャプション用スペースを下部に確保）
  const bgColor = style.background.type === 'solid' ? style.background.color : '#FFFFFF';

  return (
    <AbsoluteFill style={{ backgroundColor: bgColor }}>
      <AccentBar position="top" height={6} />
      <div
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          right: 0,
          bottom: 140, // キャプション用スペース
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          padding: designTokens.spacing.xl,
        }}
      >
        <TelopWithEmphasis
          lines={telop.lines}
          emphasis={telop.emphasis}
          style={style}
          animation={telop.animation.in}
          fontSize={designTokens.fontSize.title}
          subFontSize={designTokens.fontSize.subtitle}
          align="center"
          stagger={6}
        />
      </div>
    </AbsoluteFill>
  );
};
