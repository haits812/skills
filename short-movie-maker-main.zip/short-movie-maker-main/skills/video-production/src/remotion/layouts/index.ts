export { IntroLayout } from "./IntroLayout";
export { MainInsertLayout } from "./MainInsertLayout";
export { MainLectureLayout } from "./MainLectureLayout";
export { OutroLayout } from "./OutroLayout";
export { CTALayout } from "./CTALayout";
