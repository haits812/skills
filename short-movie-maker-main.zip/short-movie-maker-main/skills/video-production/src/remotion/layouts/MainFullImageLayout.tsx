import { AbsoluteFill, Img, interpolate, useCurrentFrame, staticFile } from "remotion";
import type { LayoutProps } from "../types";
import { designTokens } from "../types";

export const MainFullImageLayout: React.FC<LayoutProps> = ({
  telop,
  image,
  style,
}) => {
  const frame = useCurrentFrame();

  // 画像のズームアニメーション（Ken Burns効果）
  const imageScale = interpolate(frame, [0, 300], [1, 1.08], {
    extrapolateRight: "clamp",
  });

  // テロップアニメーション
  const textOpacity = interpolate(frame, [5, 18], [0, 1], {
    extrapolateRight: "clamp",
  });
  const textTranslateY = interpolate(frame, [5, 20], [30, 0], {
    extrapolateRight: "clamp",
  });

  // 背景オーバーレイのアニメーション
  const overlayOpacity = interpolate(frame, [0, 15], [0, 0.7], {
    extrapolateRight: "clamp",
  });

  const bgColor = style.background.type === 'solid' ? style.background.color : '#FFFFFF';

  return (
    <AbsoluteFill style={{ backgroundColor: bgColor }}>
      {/* メインコンテンツエリア（キャプション用スペースを除く） */}
      <div
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          right: 0,
          bottom: 140, // キャプション用スペース
          overflow: "hidden",
        }}
      >
        {/* 背景画像（フルサイズ） */}
        {image && (
          <div
            style={{
              position: "absolute",
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              transform: `scale(${imageScale})`,
              transformOrigin: "center center",
            }}
          >
            <Img
              src={image.path.startsWith("http") ? image.path : staticFile(image.path)}
              style={{
                width: "100%",
                height: "100%",
                objectFit: "cover",
              }}
            />
          </div>
        )}

        {/* 画像がない場合のフォールバック背景 */}
        {!image && (
          <div
            style={{
              position: "absolute",
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              background: "linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)",
            }}
          />
        )}

        {/* グラデーションオーバーレイ（テロップを読みやすくする） */}
        <div
          style={{
            position: "absolute",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: `linear-gradient(
              180deg,
              rgba(0,0,0,0.1) 0%,
              rgba(0,0,0,0.2) 40%,
              rgba(0,0,0,${overlayOpacity}) 70%,
              rgba(0,0,0,${overlayOpacity + 0.1}) 100%
            )`,
          }}
        />

        {/* テロップエリア（下部） */}
        <div
          style={{
            position: "absolute",
            left: 0,
            right: 0,
            bottom: 0,
            padding: `${designTokens.spacing.lg}px ${designTokens.spacing.xl}px`,
            opacity: textOpacity,
            transform: `translateY(${textTranslateY}px)`,
          }}
        >
          {/* テロップ背景帯 */}
          <div
            style={{
              background: "rgba(0,0,0,0.6)",
              backdropFilter: "blur(8px)",
              borderRadius: designTokens.borderRadius.lg,
              padding: `${designTokens.spacing.md}px ${designTokens.spacing.lg}px`,
              display: "inline-block",
              maxWidth: "90%",
            }}
          >
            {telop.lines.map((line, index) => (
              <p
                key={index}
                style={{
                  fontFamily: style.telop.fontFamily,
                  fontSize: index === 0
                    ? designTokens.fontSize.title
                    : designTokens.fontSize.subtitle,
                  fontWeight: index === 0 ? 900 : 700,
                  color: "#FFFFFF",
                  margin: index > 0 ? `${designTokens.spacing.xs}px 0 0 0` : 0,
                  textShadow: "0 2px 8px rgba(0,0,0,0.5)",
                  lineHeight: 1.3,
                }}
              >
                {applyEmphasis(line, telop.emphasis, style)}
              </p>
            ))}
          </div>
        </div>
      </div>
    </AbsoluteFill>
  );
};

// 強調を適用
function applyEmphasis(
  text: string,
  emphasis: { word: string; type: string }[],
  style: LayoutProps["style"]
): React.ReactNode {
  if (emphasis.length === 0) {
    return text;
  }

  // フルイメージ用の強調色（明るめ）
  const emphasisColors: Record<string, string> = {
    keyword: "#FF6B6B",
    positive: "#4ECDC4",
    negative: "#FFE66D",
    number: "#FF8C42",
  };

  let result: React.ReactNode[] = [];
  let remainingText = text;
  let keyIndex = 0;

  for (const emp of emphasis) {
    const index = remainingText.indexOf(emp.word);
    if (index !== -1) {
      if (index > 0) {
        result.push(
          <span key={`text-${keyIndex++}`}>
            {remainingText.substring(0, index)}
          </span>
        );
      }
      result.push(
        <span
          key={`emphasis-${keyIndex++}`}
          style={{
            color: emphasisColors[emp.type] || style.emphasis[emp.type as keyof typeof style.emphasis] || "#FFFFFF",
            fontWeight: 900,
          }}
        >
          {emp.word}
        </span>
      );
      remainingText = remainingText.substring(index + emp.word.length);
    }
  }

  if (remainingText) {
    result.push(<span key={`text-end`}>{remainingText}</span>);
  }

  return result.length > 0 ? result : text;
}
