import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import type { LayoutProps } from "../types";
import { colors, designTokens } from "../types";
import { BaseLayout } from "./BaseLayout";
import { TelopWithEmphasis } from "../components/TelopWithEmphasis";
import { AccentBar } from "../components/AccentBar";

export const CTALayout: React.FC<LayoutProps> = ({
  telop,
  style,
  subtitle,
}) => {
  const frame = useCurrentFrame();

  // CTAアニメーション（scale + bounce）
  const opacity = interpolate(frame, [0, 10], [0, 1], {
    extrapolateRight: "clamp",
  });
  const scale = interpolate(frame, [0, 8, 12, 16], [0.8, 1.08, 0.98, 1], {
    extrapolateRight: "clamp",
  });

  // 新デザイン（subtitleがある場合）
  if (subtitle) {
    return (
      <BaseLayout
        subtitle={subtitle}
        showAccentBar={true}
        accentBarPosition="both"
        style={style}
      >
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            gap: designTokens.spacing.md,
            opacity,
            transform: `scale(${scale})`,
          }}
        >
          {/* CTAメインテキスト（強調） */}
          <div
            style={{
              backgroundColor: colors.primary,
              padding: `${designTokens.spacing.sm}px ${designTokens.spacing.lg}px`,
              borderRadius: designTokens.borderRadius.lg,
              boxShadow: designTokens.shadow.card,
            }}
          >
            <h1
              style={{
                fontFamily: "Noto Sans JP, sans-serif",
                fontSize: designTokens.fontSize.title,
                fontWeight: 900,
                color: colors.textWhite,
                margin: 0,
                textAlign: "center",
              }}
            >
              {telop.lines[0]}
            </h1>
          </div>
          {telop.lines.slice(1).map((line, index) => (
            <p
              key={index}
              style={{
                fontFamily: "Noto Sans JP, sans-serif",
                fontSize: designTokens.fontSize.subtitle,
                fontWeight: 600,
                color: colors.textMain,
                margin: 0,
                textAlign: "center",
              }}
            >
              {line}
            </p>
          ))}
        </div>
      </BaseLayout>
    );
  }

  // 旧デザイン（キャプション用スペースを下部に確保）
  const bgColor = style.background.type === 'solid' ? style.background.color : '#FFFFFF';

  return (
    <AbsoluteFill style={{ backgroundColor: bgColor }}>
      <AccentBar position="top" height={12} />
      <div
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          right: 0,
          bottom: 140, // キャプション用スペース
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          padding: designTokens.spacing.xl,
        }}
      >
        <TelopWithEmphasis
          lines={telop.lines}
          emphasis={telop.emphasis}
          style={style}
          animation="scale"
          fontSize={designTokens.fontSize.title}
          subFontSize={designTokens.fontSize.subtitle}
          align="center"
          stagger={4}
        />
      </div>
    </AbsoluteFill>
  );
};
