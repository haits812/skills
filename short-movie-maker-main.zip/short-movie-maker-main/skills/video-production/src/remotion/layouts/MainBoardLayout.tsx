import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import type { LayoutProps } from "../types";
import { designTokens } from "../types";
import { ChalkboardFrame } from "../components/ChalkboardFrame";
import { PinnedImage } from "../components/PinnedImage";

export const MainBoardLayout: React.FC<LayoutProps> = ({
  telop,
  image,
  style,
}) => {
  const frame = useCurrentFrame();

  // テロップアニメーション（チョークで書くような感じ）
  const textOpacity = interpolate(frame, [8, 20], [0, 1], {
    extrapolateRight: "clamp",
  });
  const textTranslateX = interpolate(frame, [8, 22], [-20, 0], {
    extrapolateRight: "clamp",
  });

  const bgColor = style.background.type === 'solid' ? style.background.color : '#FFFFFF';

  return (
    <AbsoluteFill style={{ backgroundColor: bgColor }}>
      {/* 背景（教室の壁っぽい色） */}
      <div
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          right: 0,
          bottom: 0, // SubtitleTelopが座布団を持つので白帯不要
          background: "linear-gradient(180deg, #F5F3EF 0%, #E8E4DC 100%)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          padding: designTokens.spacing.md,
        }}
      >
        {/* 黒板 */}
        <ChalkboardFrame variant="green" width="95%" height="92%">
          <div
            style={{
              width: "100%",
              height: "100%",
              display: "flex",
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "center",
              gap: designTokens.spacing.lg,
              padding: designTokens.spacing.md,
            }}
          >
            {/* テロップエリア（左側） */}
            <div
              style={{
                flex: image ? "0 0 50%" : "1",
                display: "flex",
                flexDirection: "column",
                alignItems: image ? "flex-start" : "center",
                justifyContent: "center",
                gap: designTokens.spacing.md,
                opacity: textOpacity,
                transform: `translateX(${textTranslateX}px)`,
              }}
            >
              {telop.lines.map((line, index) => (
                <p
                  key={index}
                  style={{
                    fontFamily: style.telop.fontFamily,
                    fontSize: index === 0
                      ? designTokens.fontSize.title
                      : designTokens.fontSize.subtitle,
                    fontWeight: index === 0 ? 900 : 700,
                    color: "#FFFEF0",  // チョーク風の白
                    margin: 0,
                    textAlign: image ? "left" : "center",
                    textShadow: "2px 2px 4px rgba(0,0,0,0.3)",
                    // チョーク風のざらつき感
                    filter: "url(#chalk-texture)",
                  }}
                >
                  {applyChalkEmphasis(line, telop.emphasis, style)}
                </p>
              ))}
            </div>

            {/* 画像エリア（右側・横長） */}
            {image && (
              <div
                style={{
                  flex: "0 0 48%",
                  height: "70%",  // 横長比率
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <PinnedImage
                  src={image.path}
                  width="100%"
                  height="100%"
                  rotation={-2}
                  pinPosition="top-center"
                  pinColor="#E53935"
                  delay={10}
                />
              </div>
            )}
          </div>
        </ChalkboardFrame>
      </div>

      {/* SVGフィルター（チョーク風テクスチャ） */}
      <svg style={{ position: "absolute", width: 0, height: 0 }}>
        <defs>
          <filter id="chalk-texture">
            <feTurbulence
              type="fractalNoise"
              baseFrequency="0.04"
              numOctaves="5"
              result="noise"
            />
            <feDisplacementMap
              in="SourceGraphic"
              in2="noise"
              scale="1"
              xChannelSelector="R"
              yChannelSelector="G"
            />
          </filter>
        </defs>
      </svg>
    </AbsoluteFill>
  );
};

// 強調をチョーク色で適用
function applyChalkEmphasis(
  text: string,
  emphasis: { word: string; type: string }[],
  style: LayoutProps["style"]
): React.ReactNode {
  if (emphasis.length === 0) {
    return text;
  }

  // チョーク風の強調色（少し淡い色に調整）
  const chalkColors: Record<string, string> = {
    keyword: "#FFB3B3",    // ピンク系
    positive: "#B3FFB3",   // 緑系
    negative: "#FFFFB3",   // 黄色系
    number: "#FFD9B3",     // オレンジ系
  };

  let result: React.ReactNode[] = [];
  let remainingText = text;
  let keyIndex = 0;

  for (const emp of emphasis) {
    const index = remainingText.indexOf(emp.word);
    if (index !== -1) {
      if (index > 0) {
        result.push(
          <span key={`text-${keyIndex++}`}>
            {remainingText.substring(0, index)}
          </span>
        );
      }
      result.push(
        <span
          key={`emphasis-${keyIndex++}`}
          style={{
            color: chalkColors[emp.type] || "#FFFEF0",
            fontWeight: 900,
          }}
        >
          {emp.word}
        </span>
      );
      remainingText = remainingText.substring(index + emp.word.length);
    }
  }

  if (remainingText) {
    result.push(<span key={`text-end`}>{remainingText}</span>);
  }

  return result.length > 0 ? result : text;
}
