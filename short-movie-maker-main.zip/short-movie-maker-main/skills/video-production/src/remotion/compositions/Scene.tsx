import { AbsoluteFill, Sequence, Audio, staticFile } from "remotion";
import type { CompositionProps } from "../types";
import { IntroLayout } from "../layouts/IntroLayout";
import { MainInsertLayout } from "../layouts/MainInsertLayout";
import { MainLectureLayout } from "../layouts/MainLectureLayout";
import { MainBoardLayout } from "../layouts/MainBoardLayout";
import { MainFullImageLayout } from "../layouts/MainFullImageLayout";
import { OutroLayout } from "../layouts/OutroLayout";
import { CTALayout } from "../layouts/CTALayout";
import { Background } from "../components/Background";
import { SubtitleTelop } from "../components/SubtitleTelop";
import { BrandingOverlay } from "../components/BrandingOverlay";

// レイアウトコンポーネントのマッピング
const layoutComponents = {
  intro: IntroLayout,
  "main-insert": MainInsertLayout,
  "main-lecture": MainLectureLayout,
  "main-board": MainBoardLayout,
  "main-fullimage": MainFullImageLayout,
  outro: OutroLayout,
  cta: CTALayout,
};

export const Scene: React.FC<CompositionProps> = ({
  meta,
  scenes,
  audio,
  style,
}) => {
  return (
    <AbsoluteFill>
      {/* 背景 */}
      <Background style={style} />

      {/* シーン */}
      {scenes.map((scene) => {
        const LayoutComponent = layoutComponents[scene.layout];
        const sceneDuration = scene.endFrame - scene.startFrame;
        const pages = scene.telop.pages;

        // pagesがある場合：
        // - telop.lines: シーンタイトル（中央〜上部に表示）
        // - pages: キャプション（下部に音声同期で表示）
        if (pages && pages.length > 0) {
          return (
            <Sequence
              key={scene.id}
              from={scene.startFrame}
              durationInFrames={sceneDuration}
            >
              {/* シーンタイトル + 画像（中央〜上部） */}
              <LayoutComponent
                telop={scene.telop}
                image={scene.image}
                style={style}
                durationInFrames={sceneDuration}
                subtitle={undefined}
                content={scene.content}
                bullets={scene.bullets}
              />
              {/* キャプション（下部・ページごとに切り替え） */}
              {pages.map((page, pageIndex) => {
                const pageStart = page.startFrame ?? 0;
                const pageEnd = page.endFrame ?? sceneDuration;
                const pageDuration = pageEnd - pageStart;

                return (
                  <Sequence
                    key={`${scene.id}-caption-${pageIndex}`}
                    from={pageStart}
                    durationInFrames={pageDuration}
                  >
                    <SubtitleTelop
                      text={page.lines[0] || ""}
                      subText={page.lines[1]}
                      animation="fadeSlide"
                    />
                  </Sequence>
                );
              })}
            </Sequence>
          );
        }

        // pagesがない場合：従来通りシーン全体で1つのテロップ
        return (
          <Sequence
            key={scene.id}
            from={scene.startFrame}
            durationInFrames={sceneDuration}
          >
            <LayoutComponent
              telop={scene.telop}
              image={scene.image}
              style={style}
              durationInFrames={sceneDuration}
              subtitle={scene.subtitle}
              content={scene.content}
              bullets={scene.bullets}
            />
          </Sequence>
        );
      })}

      {/* 音声トラック */}
      {audio.voice.map((track) => (
        <Sequence key={track.sceneId} from={track.startFrame}>
          <Audio src={staticFile(track.path)} />
        </Sequence>
      ))}

      {/* ブランディングオーバーレイ（最上層） */}
      <BrandingOverlay
        showLogo={true}
        showCornerAccents={true}
        showFrame={true}
      />
    </AbsoluteFill>
  );
};
