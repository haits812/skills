import { Composition, getInputProps } from "remotion";
import { Scene } from "./Scene";
import { LayoutPreview } from "./LayoutPreview";
import type { CompositionProps } from "../types";
import { defaultStyle } from "../types";

// デモ用のデフォルトProps
const defaultProps: CompositionProps = {
  meta: {
    title: "サンプル動画",
    fps: 30,
    width: 1920,
    height: 1080,
    durationInFrames: 300,
  },
  scenes: [
    {
      id: "scene-1",
      layout: "intro",
      startFrame: 0,
      endFrame: 90,
      telop: {
        lines: ["サンプル動画", "テスト"],
        emphasis: [],
        animation: { in: "scale", out: "fade" },
      },
      image: null,
      transition: { type: "fade", durationFrames: 10 },
    },
    {
      id: "scene-2",
      layout: "main-lecture",
      startFrame: 90,
      endFrame: 210,
      telop: {
        lines: ["これはサンプルの", "テロップです"],
        emphasis: [{ word: "サンプル", type: "keyword" }],
        animation: { in: "fade", out: "fade" },
      },
      image: null,
      transition: { type: "fade", durationFrames: 10 },
    },
    {
      id: "scene-3",
      layout: "cta",
      startFrame: 210,
      endFrame: 300,
      telop: {
        lines: ["ご視聴ありがとう", "ございました！"],
        emphasis: [],
        animation: { in: "pop", out: "fade" },
      },
      image: null,
      transition: { type: "none", durationFrames: 0 },
    },
  ],
  audio: {
    voice: [],
  },
  style: defaultStyle,
};

export const ExplainerVideo: React.FC = () => {
  // CLIからのpropsを取得（なければデフォルト）
  const inputProps = getInputProps() as Partial<CompositionProps>;

  // styleを深くマージ（レンダリング時にpropsが正しく適用されるように）
  const mergedStyle: CompositionProps["style"] = {
    background: {
      ...defaultStyle.background,
      ...inputProps?.style?.background,
    },
    telop: {
      ...defaultStyle.telop,
      ...inputProps?.style?.telop,
    },
    emphasis: {
      ...defaultStyle.emphasis,
      ...inputProps?.style?.emphasis,
    },
  };

  const props: CompositionProps = {
    ...defaultProps,
    ...inputProps,
    meta: { ...defaultProps.meta, ...inputProps?.meta },
    scenes: inputProps?.scenes || defaultProps.scenes,
    audio: inputProps?.audio || defaultProps.audio,
    style: mergedStyle,
  };

  return (
    <>
      <Composition
        id="ExplainerVideo"
        // @ts-expect-error - Remotion types are strict but this works at runtime
        component={Scene}
        durationInFrames={props.meta.durationInFrames}
        fps={props.meta.fps}
        width={props.meta.width}
        height={props.meta.height}
        defaultProps={props}
      />
      {/* レイアウトプレビュー用 */}
      <Composition
        id="LayoutPreview"
        component={LayoutPreview}
        durationInFrames={450} // 15秒 (5シーン × 3秒)
        fps={30}
        width={1920}
        height={1080}
      />
    </>
  );
};
