import { AbsoluteFill, Sequence } from "remotion";
import { BaseLayout } from "../layouts/BaseLayout";
import { ContentCard } from "../components/ContentCard";
import { colors, designTokens } from "../types";

// プレビュー用コンポジション - 各レイアウトパターンを確認
export const LayoutPreview: React.FC = () => {
  const sceneDuration = 90; // 3秒 × 30fps

  return (
    <AbsoluteFill>
      {/* パターン A: テキストのみ */}
      <Sequence from={0} durationInFrames={sceneDuration}>
        <BaseLayout
          subtitle={{
            text: "AIエージェントは革新的なAIコーディングツールです",
            animation: "fadeSlide",
          }}
        >
          <div style={{ width: "85%", height: "70%" }}>
            <ContentCard
              variant="text"
              title="AIエージェントとは？"
              body={[
                "ターミナルで動作するAIアシスタント",
                "コードの読み書き、実行が可能",
                "自然言語で指示するだけ",
              ]}
            />
          </div>
        </BaseLayout>
      </Sequence>

      {/* パターン B: 画像のみ */}
      <Sequence from={sceneDuration} durationInFrames={sceneDuration}>
        <BaseLayout
          subtitle={{
            text: "実際の画面を見てみましょう",
            animation: "fadeSlide",
          }}
        >
          <div style={{ width: "80%", height: "75%" }}>
            <ContentCard
              variant="image"
              imageSrc="images/scene_2.png"
            />
          </div>
        </BaseLayout>
      </Sequence>

      {/* パターン C: 画像+テキスト（横並び） */}
      <Sequence from={sceneDuration * 2} durationInFrames={sceneDuration}>
        <BaseLayout
          subtitle={{
            text: "左に画像、右にテキストのレイアウト",
            animation: "fadeSlide",
          }}
        >
          <div style={{ width: "90%", height: "70%" }}>
            <ContentCard
              variant="imageText"
              imagePosition="left"
              imageSrc="images/scene_3.png"
              title="主な特徴"
              body={[
                "• ファイル操作が簡単",
                "• Git連携もスムーズ",
                "• テスト実行も自動化",
              ]}
            />
          </div>
        </BaseLayout>
      </Sequence>

      {/* パターン D: テキスト+画像（横並び） */}
      <Sequence from={sceneDuration * 3} durationInFrames={sceneDuration}>
        <BaseLayout
          subtitle={{
            text: "テキストと画像の位置を入れ替えたパターン",
            animation: "pop",
          }}
        >
          <div style={{ width: "90%", height: "70%" }}>
            <ContentCard
              variant="textImage"
              imagePosition="right"
              imageSrc="images/scene_4.png"
              title="使い方は簡単"
              body={[
                "1. インストール",
                "2. コマンド実行",
                "3. 指示を出すだけ",
              ]}
            />
          </div>
        </BaseLayout>
      </Sequence>

      {/* テロップアニメーション比較 */}
      <Sequence from={sceneDuration * 4} durationInFrames={sceneDuration}>
        <BaseLayout
          subtitle={{
            text: "タイプライター風アニメーション",
            animation: "typewriter",
          }}
          accentBarPosition="both"
        >
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              gap: designTokens.spacing.md,
            }}
          >
            <h1
              style={{
                fontFamily: "Noto Sans JP, sans-serif",
                fontSize: designTokens.fontSize.hero,
                fontWeight: 900,
                color: colors.textMain,
                margin: 0,
              }}
            >
              まとめ
            </h1>
            <p
              style={{
                fontFamily: "Noto Sans JP, sans-serif",
                fontSize: designTokens.fontSize.subtitle,
                color: colors.textSub,
                margin: 0,
              }}
            >
              AIエージェントで開発効率アップ！
            </p>
          </div>
        </BaseLayout>
      </Sequence>
    </AbsoluteFill>
  );
};
