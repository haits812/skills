import { registerRoot } from "remotion";
import { ExplainerVideo } from "./compositions/ExplainerVideo";

registerRoot(ExplainerVideo);
