import { interpolate, useCurrentFrame } from "remotion";

export const useScaleIn = (
  startFrame: number = 0,
  duration: number = 10,
  fromScale: number = 0.8
): { scale: number; opacity: number } => {
  const frame = useCurrentFrame();

  const progress = interpolate(
    frame,
    [startFrame, startFrame + duration],
    [0, 1],
    {
      extrapolateLeft: "clamp",
      extrapolateRight: "clamp",
    }
  );

  return {
    scale: interpolate(progress, [0, 1], [fromScale, 1]),
    opacity: progress,
  };
};
