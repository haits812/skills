import { interpolate, useCurrentFrame } from "remotion";

export const useSlideUp = (
  startFrame: number = 0,
  duration: number = 8,
  distance: number = 50
): { translateY: number; opacity: number } => {
  const frame = useCurrentFrame();

  const progress = interpolate(
    frame,
    [startFrame, startFrame + duration],
    [0, 1],
    {
      extrapolateLeft: "clamp",
      extrapolateRight: "clamp",
    }
  );

  return {
    translateY: interpolate(progress, [0, 1], [distance, 0]),
    opacity: progress,
  };
};

export const useSlideLeft = (
  startFrame: number = 0,
  duration: number = 8,
  distance: number = 100
): { translateX: number; opacity: number } => {
  const frame = useCurrentFrame();

  const progress = interpolate(
    frame,
    [startFrame, startFrame + duration],
    [0, 1],
    {
      extrapolateLeft: "clamp",
      extrapolateRight: "clamp",
    }
  );

  return {
    translateX: interpolate(progress, [0, 1], [distance, 0]),
    opacity: progress,
  };
};
