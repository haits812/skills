import { interpolate, useCurrentFrame } from "remotion";

export const useFadeIn = (
  startFrame: number = 0,
  duration: number = 10
): number => {
  const frame = useCurrentFrame();
  return interpolate(frame, [startFrame, startFrame + duration], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
};

export const useFadeOut = (
  endFrame: number,
  duration: number = 8
): number => {
  const frame = useCurrentFrame();
  return interpolate(
    frame,
    [endFrame - duration, endFrame],
    [1, 0],
    {
      extrapolateLeft: "clamp",
      extrapolateRight: "clamp",
    }
  );
};
