import { interpolate, useCurrentFrame, spring, useVideoConfig } from "remotion";

export const usePopIn = (
  startFrame: number = 0,
  duration: number = 6
): { scale: number; opacity: number } => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const progress = spring({
    frame: frame - startFrame,
    fps,
    config: {
      damping: 12,
      stiffness: 200,
      mass: 0.5,
    },
  });

  const opacity = interpolate(
    frame,
    [startFrame, startFrame + Math.min(duration, 4)],
    [0, 1],
    {
      extrapolateLeft: "clamp",
      extrapolateRight: "clamp",
    }
  );

  return {
    scale: interpolate(progress, [0, 1], [0.5, 1]),
    opacity,
  };
};
