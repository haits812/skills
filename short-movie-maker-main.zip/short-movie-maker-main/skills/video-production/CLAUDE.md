# Claude Code Entry

このフォルダで動画制作Skillを使う場合は、まず `SKILL.md` を読む。

Claude Code固有の手順をここに増やさない。実行判断、参照ファイル、ワークフローは `SKILL.md` と `agent-tools/` に集約する。

