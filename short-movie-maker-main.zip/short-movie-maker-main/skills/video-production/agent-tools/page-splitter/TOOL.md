# page-splitter

## 目的

各sceneの `text` を音声同期用の `telop.pages` に分割する。

## ルール

- 原則1ページ1行。
- 1行20文字以内を目安にする。
- 意味の切れ目を優先する。
- `startCharIndex` と `endCharIndex` を必ず入れる。
- `startFrame` と `endFrame` はこの工程では入れない。後続のtiming extractorが入れる。

