# scene-director

## 目的

台本をRemotionで処理できる `scenes.json` に変換する。

## 判断

- 1sceneは1つの意味単位にする。
- 見せ場には `needsImage: true` と `imagePrompt` を付ける。
- 図解向きは `main-board`、画像向きは `main-fullimage`、説明中心は `main-lecture` を使う。
- CTAは講座資料内では営業臭くしすぎず、理解の次の行動として扱う。

## 出力

`references/scenes-schema.md` に従う。

