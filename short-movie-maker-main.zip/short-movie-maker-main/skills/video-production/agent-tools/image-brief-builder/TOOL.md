# image-brief-builder

## 目的

各sceneの理解を助ける画像生成指示を作る。

## 入力

- `runs/{run}/scenes.json`
- style context
- brand context

## 出力

各sceneに以下を追加する。

```json
{
  "needsImage": true,
  "imagePrompt": "English image prompt with clear subject, style, composition, and negative constraints"
}
```

## 注意

- 抽象語だけのpromptにしない。
- 画像内の日本語文字に依存しない。
- 画面で何を見るべきかが一目で伝わる構図にする。

