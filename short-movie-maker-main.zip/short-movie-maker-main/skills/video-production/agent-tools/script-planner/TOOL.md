# script-planner

## 目的

テーマ、対象視聴者、動画尺、style contextを受け取り、動画の大枠構成を `script.json` として作る。

## 入力

- theme: 動画テーマ
- target_audience: 想定視聴者
- target_duration_sec: 目標尺
- style_context: `contexts/styles/*.md`
- brand_context: 任意
- forbidden_patterns: 任意

## 出力

`runs/{run}/script.json`

```json
{
  "title": "動画タイトル",
  "topic": "テーマ",
  "targetDuration": 120,
  "sections": [
    {
      "id": "sec-001",
      "title": "導入",
      "role": "hook",
      "talking_points": ["視聴者の疑問を提示する"]
    }
  ],
  "meta": {
    "style": "business-explainer",
    "generatedAt": "ISO-8601"
  }
}
```

## 注意

- 台本生成は決定論的スクリプトで代替しない。
- ただし出力形式は必ずschemaに寄せる。
- style contextは言い回しだけでなく、構成密度、テンポ、視聴者との距離感に反映する。

