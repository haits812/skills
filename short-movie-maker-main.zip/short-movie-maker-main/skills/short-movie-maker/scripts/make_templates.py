#!/usr/bin/env python3
"""背景テンプレート PNG を数種生成する (1080x1920, 9:16)。

派手な切り抜き動画風の背景を Pillow で描画して templates/ に出力する。
生成物は後からユーザーが自分の画像に差し替え可能 (同じファイル名で置き換えるだけ)。

各テンプレは以下の想定レイアウト:
  - 上部       : タイトル帯領域 (render.py がタイトルを焼き込む)
  - 中央 1080x1080 付近 : 動画配置領域 (16:9 動画を横幅フィットで中央に置く)
  - 下部       : 字幕領域 (render.py が字幕を焼き込む)

Usage:
  python make_templates.py [--outdir <dir>]
"""
import argparse
import math
import os

from PIL import Image, ImageDraw


W, H = 1080, 1920


def _vgrad(w, h, top, bottom):
    """縦方向グラデーション画像を作る。"""
    base = Image.new("RGB", (w, h))
    px = base.load()
    for y in range(h):
        t = y / max(1, h - 1)
        r = int(top[0] + (bottom[0] - top[0]) * t)
        g = int(top[1] + (bottom[1] - top[1]) * t)
        b = int(top[2] + (bottom[2] - top[2]) * t)
        for x in range(w):
            px[x, y] = (r, g, b)
    return base


def tmpl_sunset(path):
    """暖色グラデ + 斜めストライプの派手系。"""
    img = _vgrad(W, H, (255, 94, 58), (120, 20, 90))
    d = ImageDraw.Draw(img, "RGBA")
    # 斜めストライプ
    for i in range(-H, W, 90):
        d.line([(i, 0), (i + H, H)], fill=(255, 255, 255, 18), width=30)
    # 動画枠の目安 (薄い) — 中央
    img.save(path)


def tmpl_pop_blue(path):
    """青→シアンのポップ系 + ドット。"""
    img = _vgrad(W, H, (13, 71, 161), (0, 188, 212))
    d = ImageDraw.Draw(img, "RGBA")
    for y in range(0, H, 70):
        for x in range(0, W, 70):
            d.ellipse([x - 6, y - 6, x + 6, y + 6], fill=(255, 255, 255, 22))
    img.save(path)


def tmpl_dark_neon(path):
    """暗い背景 + ネオン枠 (切り抜き動画で定番の締まった見た目)。"""
    img = _vgrad(W, H, (18, 18, 26), (28, 20, 40))
    d = ImageDraw.Draw(img, "RGBA")
    # ネオン風の枠 (動画配置領域を囲う目安)
    for pad, alpha in [(28, 60), (24, 120), (20, 200)]:
        d.rounded_rectangle(
            [pad, 430 + pad, W - pad, 1490 - pad],
            radius=40,
            outline=(0, 229, 255, alpha),
            width=6,
        )
    img.save(path)


def tmpl_warm_paper(path):
    """やわらかい紙風 (雑談・解説向けの落ち着いた派手さ)。"""
    img = _vgrad(W, H, (255, 236, 179), (255, 183, 77))
    d = ImageDraw.Draw(img, "RGBA")
    for i in range(0, W + H, 120):
        d.line([(i, 0), (i - H, H)], fill=(255, 255, 255, 25), width=40)
    img.save(path)


TEMPLATES = {
    "sunset": tmpl_sunset,
    "pop_blue": tmpl_pop_blue,
    "dark_neon": tmpl_dark_neon,
    "warm_paper": tmpl_warm_paper,
}


def main():
    ap = argparse.ArgumentParser()
    here = os.path.dirname(os.path.abspath(__file__))
    default_out = os.path.normpath(os.path.join(here, "..", "templates"))
    ap.add_argument("--outdir", default=default_out)
    args = ap.parse_args()
    os.makedirs(args.outdir, exist_ok=True)
    for name, fn in TEMPLATES.items():
        out = os.path.join(args.outdir, f"{name}.png")
        fn(out)
        print(f"[make_templates] wrote {out}")


if __name__ == "__main__":
    main()
