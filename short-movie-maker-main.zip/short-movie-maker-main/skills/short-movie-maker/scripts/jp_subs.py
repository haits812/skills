"""keep 区間から整形済み字幕 (subtitles 配列) を自動生成する CLI。

videopocket-local のテキスト整理ロジック (フィラー除去・DP改行・禁則・
文字タイム同期) を short-movie-maker のパイプラインに接続する。

モード:
  auto  : 日本語素材。transcript の文字タイムラインから字幕を全自動生成
  pages : 翻訳字幕/吹き替え字幕モード。Claude が用意した意訳テキスト
          (元動画時間のスパンつき) に改行整形とローカル時間割付だけ行う

Usage:
  # 日本語自動生成 (keep は元動画の絶対秒)
  python jp_subs.py --transcript work/transcript.json --keep "57.0:92.0" \
      [--vad work/vad.json] [--max-line 12.5]

  # 翻訳/吹き替え (pages.json: [{"start":src秒,"end":src秒,"text":"意訳"}])
  python jp_subs.py --mode pages --pages work/pages.json --keep "57.0:92.0"

出力 (stdout): clips.json の subtitles にそのまま入る JSON 配列
  [{"start": ローカル秒, "end": ローカル秒, "text": "1行目\\n2行目"}, ...]
"""

from __future__ import annotations

import argparse
import json
import sys
from typing import List, Tuple

from jp_clean import CharTL, build_char_timeline, clean_chars
from jp_layout import break_two_lines, budoux_boundaries, glyph_width, page_end_quality

PRE_ROLL = 0.12   # 発話より少し早めに出す
POST_ROLL = 0.30  # 発話後に少し残す
PAGE_GAP_SPLIT = 0.45  # この秒数以上のポーズはページ分割候補 (会話の息継ぎ)
MIN_PAGE_WIDTH = 6.0   # ポーズ分割を許す最小ページ幅
MAX_PAGE_WIDTH = 25.0  # 2 行ぶんの上限幅 (12.5 × 2)


def parse_keep(arg: str) -> List[Tuple[float, float]]:
    keeps = []
    for part in arg.split(","):
        a, b = part.split(":")
        keeps.append((float(a), float(b)))
    return keeps


def src_to_local(t: float, keeps: List[Tuple[float, float]]) -> float | None:
    """元動画の絶対秒 → keep 連結後ローカル秒。範囲外は None。"""
    offset = 0.0
    for s, e in keeps:
        if t < s:
            return None
        if s <= t <= e:
            return offset + (t - s)
        offset += e - s
    return None


def _build_atoms(chars: CharTL) -> List[CharTL]:
    """文字タイムラインを budoux 文節単位の atom 列にする。

    ページ境界・改行は必ず atom 境界に落ちるため、単語の途中で
    字幕が切れない (whisper 日本語は句読点が無いのでこれが生命線)。
    whisper segment 境界 (発話単位の切れ目) は budoux 文節がまたぐことが
    あるため、atom 境界として必ず追加する (「思うよ|でもさ」問題の対策)。
    """
    text = "".join(c[0] for c in chars)
    bounds = set(budoux_boundaries(text))
    bounds.update(i + 1 for i, c in enumerate(chars) if c[3])  # seg_end 位置
    bounds.add(len(text))
    atoms: List[CharTL] = []
    prev = 0
    for b in sorted(bounds):
        if b > prev:
            atoms.append(chars[prev:b])
            prev = b
    return atoms


def _split_pages(chars: CharTL) -> List[CharTL]:
    """文字タイムラインを字幕ページ単位に分割する (budoux atom 上の動的計画法)。

    videopocket の layout_dp と同思想で、ページ境界の置き方を全体最適する。
    ページのコスト:
      - ページ内に話者変化があれば不可 (必ず割る)
      - 幅 > MAX_PAGE_WIDTH は不可 / 幅 < MIN_PAGE_WIDTH は軽い減点
      - ページ内部に文末 (。！？)・長ポーズ・segment 境界を抱えると減点
        (= そこで割った案が相対的に有利になる)
      - ページ終端の品質 (文末=0 / segment 境界=0.05 / 禁則系 page_end_quality)
      - ページ数そのものに小さな固定コスト (過剰分割の抑制)
    """
    atoms = _build_atoms(chars)
    n = len(atoms)
    if n == 0:
        return []

    def _spk(c):
        return c[4] if len(c) > 4 else None

    # atom ごとの前計算
    a_text = ["".join(c[0] for c in a) for a in atoms]
    a_width = [glyph_width(t) for t in a_text]
    a_start = [a[0][1] for a in atoms]
    a_end = [a[-1][2] for a in atoms]
    a_spk = [next((_spk(c) for c in a if _spk(c)), None) for a in atoms]
    a_sent_end = [a[-1][0] in "。！？!?" for a in atoms]
    a_seg_end = [a[-1][3] for a in atoms]

    # 境界 k (atom k と k+1 の間) を「ページ内部に抱えた」ときの内部減点
    def internal_penalty(k: int) -> float:
        pen = 0.0
        if a_sent_end[k]:
            pen += 0.9
        gap = a_start[k + 1] - a_end[k]
        if gap >= PAGE_GAP_SPLIT:
            pen += 0.7 + min(gap, 2.0) * 0.3
        elif a_seg_end[k]:
            pen += 0.35
        s1, s2 = a_spk[k], a_spk[k + 1]
        if s1 is not None and s2 is not None and s1 != s2:
            pen += 1e9  # 話者変化はページ内に抱えない (必ず割る)
        return pen

    # 境界 k で「ページを終えた」ときの終端コスト
    def end_cost(k: int) -> float:
        if k == n - 1 or a_sent_end[k]:
            return 0.0
        if a_seg_end[k]:
            return 0.05
        return page_end_quality(a_text[k][-1], a_text[k + 1][0])

    PAGE_CONST = 0.15  # ページ 1 枚あたりの固定コスト (過剰分割の抑制)
    INF = float("inf")
    best = [INF] * (n + 1)   # best[j] = atom 0..j-1 を分割し終えた最小コスト
    prev = [0] * (n + 1)
    best[0] = 0.0
    for j in range(1, n + 1):
        width = 0.0
        internal = 0.0
        i = j - 1
        while i >= 0:
            width += a_width[i]
            if width > MAX_PAGE_WIDTH:
                break
            if i < j - 1:
                internal += internal_penalty(i)
            cost = PAGE_CONST + internal + end_cost(j - 1)
            if width < MIN_PAGE_WIDTH:
                cost += 0.5
            if best[i] + cost < best[j]:
                best[j] = best[i] + cost
                prev[j] = i
            i -= 1
        if best[j] is INF or best[j] == INF:
            # 単一 atom が幅超過している等の退避: 強制 1 atom ページ
            best[j] = best[j - 1] + PAGE_CONST
            prev[j] = j - 1

    # 復元
    cuts = []
    j = n
    while j > 0:
        cuts.append((prev[j], j))
        j = prev[j]
    cuts.reverse()

    pages: List[CharTL] = []
    for i, j in cuts:
        page: CharTL = []
        for a in atoms[i:j]:
            page.extend(a)
        if "".join(c[0] for c in page).strip():
            pages.append(page)
    return pages


FULLWIDTH_SPACE = "　"


def _normalize_display(text: str) -> str:
    """Netflix 日本語ガイド式の句読点正規化 (videopocket から移植)。

    - 読点「、，」→ 半角スペース / 句点「。．」→ 全角スペース
    - 「!?」→ 全角化し、文が続くなら直後に全角スペース
    - 連続スペースは 1 つに、行末スペースは除去
    """
    import re as _re
    t = text
    t = _re.sub(r"[、，]", " ", t)
    t = _re.sub(r"[。．]", FULLWIDTH_SPACE, t)
    t = t.replace("!", "！").replace("?", "？")
    t = _re.sub(r"([！？])(?![ \t！？" + FULLWIDTH_SPACE + r"]|$)", r"\1" + FULLWIDTH_SPACE, t)
    t = _re.sub(r"[ " + FULLWIDTH_SPACE + r"]+",
                lambda m: FULLWIDTH_SPACE if FULLWIDTH_SPACE in m.group() else " ", t)
    return t.strip(" " + FULLWIDTH_SPACE)


def _load_vad(path: str | None) -> List[Tuple[float, float]]:
    if not path:
        return []
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return [(float(s), float(e)) for s, e in data.get("speech", [])]


def _vad_guard_start(t: float, speech: List[Tuple[float, float]]) -> float:
    """字幕開始が発話より早すぎないよう VAD でガードする。"""
    if not speech:
        return t
    for s, e in speech:
        if s <= t <= e:
            return t          # 発話中なら OK
        if t < s and s - t < 1.0:
            return s          # 直後に発話が始まるなら発話開始に合わせる
    return t


MIN_DISPLAY = 0.9   # これ未満の表示時間のページは隣と結合を試みる (coalesce)
COALESCE_GAP = 0.6  # 結合を許す隣接ページ間の最大ギャップ
CPS_WARN = 12.0     # 読速警告 (重み付き文字幅 / 秒)


def _break_and_normalize(raw: str, max_line: float) -> str:
    """改行位置は自然文のまま決め、句読点正規化は行確定後に行う。

    videopocket の設計原則「budoux には自然文を渡し、表示用の改変は最終段だけ」
    に合わせる (句読点が改行アンカーとして機能したまま、表示は Netflix 式になる)。
    正規化で行幅が増えることはない (、0.5→空白0.3 等、全て同幅以下)。
    """
    broken = break_two_lines(raw.strip(), max_line=max_line)
    lines = [_normalize_display(ln) for ln in broken.split("\n")]
    return "\n".join(ln for ln in lines if ln)


KW_OPEN, KW_CLOSE = "‹", "›"  # キーワード色付けマーカー (render が色タグへ変換)


def _build_karaoke(entry: dict, max_line: float) -> tuple[str, list]:
    """カラオケ式ワードハイライト用のデータを作る (M11=karaoke)。

    文字タイムラインから各文字の発話時間 (センチ秒) を取り、ASS の \\k で
    「いま発話中の文字」まで色が塗られていくデータにする。
    句読点は表示から落とし (時間は前の文字に足す)、改行は "\\n" ピースで表す。
    戻り値: (表示テキスト, [[piece, センチ秒], ...])
    """
    page = entry.get("_page") or []
    keeps = entry.get("_keeps") or []
    if not page:
        return _break_and_normalize(entry["raw"], max_line), []

    # 句読点を落としつつ (文字, ローカル開始, ローカル終了) を作る
    items: list[tuple[str, float, float]] = []
    for c in page:
        lt0 = src_to_local(c[1], keeps)
        lt1 = src_to_local(c[2], keeps)
        if lt0 is None or lt1 is None:
            continue
        if c[0] in "、。，．":
            if items:  # 句読点の時間は前の文字に吸収
                ch, a, _ = items[-1]
                items[-1] = (ch, a, lt1)
            continue
        items.append((c[0], lt0, lt1))
    if not items:
        return "", []

    text = "".join(ch for ch, _, _ in items)
    broken = break_two_lines(text, max_line=max_line)
    nl_pos = broken.find("\n")

    pieces: list = []
    cursor = entry["start"]
    for idx, (ch, a, b) in enumerate(items):
        lead = max(0.0, a - cursor)
        if lead >= 0.05:
            pieces.append(["", round(lead * 100)])
        pieces.append([ch, max(1, round((b - max(a, cursor)) * 100))])
        cursor = max(b, cursor)
        if nl_pos >= 0 and idx == nl_pos - 1:
            pieces.append(["\n", 0])
    return broken, pieces


def _mark_keywords(text: str) -> str:
    """字幕内の要点語 (長めの名詞・数値+助数詞) をマーカーで囲む (M12)。

    render がマーカーを色タグに変換する。1 ページ最大 1 箇所 (うるさくしない)。
    """
    from jp_clean import _TOKENIZER, _SPLIT_MODE
    plain = text.replace("\n", "")
    best: tuple[int, int] | None = None
    best_len = 0
    for m in _TOKENIZER.tokenize(plain, _SPLIT_MODE):
        pos = m.part_of_speech()
        surface = m.surface()
        is_noun = pos[0] == "名詞" and pos[1] in ("普通名詞", "固有名詞", "数詞")
        if is_noun and len(surface) > best_len and len(surface) >= 2:
            best = (m.begin(), m.end())
            best_len = len(surface)
    if not best:
        return text
    # plain 上の位置を改行入りテキストの位置に写像
    def to_broken(i: int) -> int:
        count = 0
        for j, ch in enumerate(text):
            if ch == "\n":
                continue
            if count == i:
                return j
            count += 1
        return len(text)
    s0, s1 = to_broken(best[0]), to_broken(best[1] - 1) + 1
    return text[:s0] + KW_OPEN + text[s0:s1] + KW_CLOSE + text[s1:]


def _coalesce(entries: List[dict]) -> List[dict]:
    """短すぎるページを同一話者の隣接ページへ結合する (videopocket coalesce の移植)。"""
    out: List[dict] = []
    for e in entries:
        if out:
            prev = e["start"] - out[-1]["end"]
            same_spk = out[-1].get("speaker") == e.get("speaker")
            short = (out[-1]["end"] - out[-1]["start"] < MIN_DISPLAY
                     or e["end"] - e["start"] < MIN_DISPLAY)
            merged_w = glyph_width(out[-1]["raw"] + e["raw"])
            if short and same_spk and prev <= COALESCE_GAP and merged_w <= MAX_PAGE_WIDTH:
                out[-1]["raw"] += e["raw"]
                out[-1]["end"] = e["end"]
                if "_page" in out[-1] and "_page" in e:
                    out[-1]["_page"] = out[-1]["_page"] + e["_page"]
                continue
        out.append(dict(e))
    return out


def build_auto_subtitles(transcript: dict, keeps: List[Tuple[float, float]],
                         speech: List[Tuple[float, float]], max_line: float,
                         corrections: dict | None = None,
                         motion: str = "none", kw_color: bool = False) -> List[dict]:
    entries: List[dict] = []
    for ks, ke in keeps:
        chars = clean_chars(build_char_timeline(transcript, (ks, ke)), corrections)
        for page in _split_pages(chars):
            raw = "".join(c[0] for c in page).strip()
            if not raw:
                continue
            src_start = _vad_guard_start(page[0][1] - PRE_ROLL, speech)
            src_end = page[-1][2] + POST_ROLL
            ls = src_to_local(max(src_start, ks), keeps)
            le = src_to_local(min(src_end, ke), keeps)
            if ls is None or le is None or le <= ls:
                continue
            # ページ内多数決で話者を決める (話者変化で割っているのでほぼ単一)
            spks = [c[4] for c in page if len(c) > 4 and c[4]]
            entry = {"start": round(ls, 2), "end": round(le, 2), "raw": raw,
                     "_page": page, "_keeps": keeps}
            if spks:
                entry["speaker"] = max(set(spks), key=spks.count)
            entries.append(entry)

    entries = _coalesce(entries)

    subs: List[dict] = []
    for e in entries:
        if motion == "karaoke":
            text, karaoke = _build_karaoke(e, max_line)
        else:
            text, karaoke = _break_and_normalize(e["raw"], max_line), None
        if not text:
            continue
        if kw_color and motion != "karaoke":
            text = _mark_keywords(text)
        dur = e["end"] - e["start"]
        plain = text.replace("\n", "").replace(KW_OPEN, "").replace(KW_CLOSE, "")
        w = glyph_width(plain)
        if dur > 0 and w / dur > CPS_WARN:
            sys.stderr.write(f"[jp_subs] WARN fast page ({w/dur:.1f} w/s): {plain[:20]}\n")
        sub = {"start": e["start"], "end": e["end"], "text": text}
        if karaoke:
            sub["karaoke"] = karaoke
        if e.get("speaker"):
            sub["speaker"] = e["speaker"]
        subs.append(sub)
    # 重なり解消: 次のページ開始を前のページ終了より前にしない
    for i in range(1, len(subs)):
        if subs[i]["start"] < subs[i - 1]["end"]:
            subs[i - 1]["end"] = round(max(subs[i]["start"] - 0.01, subs[i - 1]["start"] + 0.2), 2)
    return subs


def build_pages_subtitles(pages: List[dict], keeps: List[Tuple[float, float]],
                          max_line: float) -> List[dict]:
    """翻訳/吹き替えモード: 意訳テキストに改行整形 + ローカル時間割付。"""
    subs: List[dict] = []
    for p in pages:
        ls = src_to_local(float(p["start"]), keeps)
        le = src_to_local(float(p["end"]), keeps)
        if ls is None or le is None or le <= ls:
            continue
        subs.append({"start": round(ls, 2), "end": round(le, 2),
                     "text": _break_and_normalize(str(p["text"]), max_line)})
    for i in range(1, len(subs)):
        if subs[i]["start"] < subs[i - 1]["end"]:
            subs[i - 1]["end"] = round(max(subs[i]["start"] - 0.01, subs[i - 1]["start"] + 0.2), 2)
    return subs


def main() -> None:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["auto", "pages"], default="auto")
    ap.add_argument("--transcript", help="transcript.json (auto モード)")
    ap.add_argument("--pages", help="pages.json (pages モード)")
    ap.add_argument("--keep", required=True, help='元動画絶対秒 "a:b,c:d"')
    ap.add_argument("--vad", default=None, help="vad.json (開始ガード用、任意)")
    ap.add_argument("--corrections", default=None,
                    help="STT 誤認識の置換テーブル JSON ({\"誤\": \"正\"})。"
                         "glossary を見て Claude が作る")
    ap.add_argument("--max-line", type=float, default=12.5,
                help="1 行の最大幅 (重み付き文字数)。render の字幕フォント 74px・"
                     "マージン 60px で入るのは約 12.9 なので既定 12.5")
    ap.add_argument("--motion", choices=["none", "popin", "karaoke"], default="none",
                    help="M11 字幕モーション。karaoke は文字単位の \\k データも出力する")
    ap.add_argument("--kw-color", action="store_true",
                    help="M12 字幕内キーワード色付け (名詞/数値をマーカーで囲む)")
    args = ap.parse_args()

    keeps = parse_keep(args.keep)
    if args.mode == "auto":
        if not args.transcript:
            raise SystemExit("--transcript is required in auto mode")
        with open(args.transcript, "r", encoding="utf-8") as f:
            transcript = json.load(f)
        corrections = None
        if args.corrections:
            with open(args.corrections, "r", encoding="utf-8") as f:
                corrections = json.load(f)
        subs = build_auto_subtitles(transcript, keeps, _load_vad(args.vad),
                                    args.max_line, corrections,
                                    motion=args.motion, kw_color=args.kw_color)
    else:
        if not args.pages:
            raise SystemExit("--pages is required in pages mode")
        with open(args.pages, "r", encoding="utf-8") as f:
            pages = json.load(f)
        subs = build_pages_subtitles(pages, keeps, args.max_line)

    print(json.dumps(subs, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
