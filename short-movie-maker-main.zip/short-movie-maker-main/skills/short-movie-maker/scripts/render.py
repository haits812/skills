#!/usr/bin/env python3
"""clips.json を受けて、各クリップを 9:16 の完成ショート mp4 に合成する。

処理概要 (1 クリップあたり):
  1. 元動画から keep 区間を切り出し連結する (不要箇所カット)
  2. 動画を縦型キャンバス (1080x1920) に配置:
       - 背景テンプレ PNG を敷く
       - 元動画を配置ゾーンを覆うよう cover スケール + zoom (顔ズーム)
       - 顔が常に中央に来るよう横クロップ位置を時間で動かす (動的トラッキング)
  3. タイトル帯を全編上部に焼き込む (音声オフでも "何の話か" が分かる)
  4. 音声同期字幕を焼き込む (太字白抜き + 黒縁取り、ASS)
  5. mp4 出力

顔トラッキング:
  clip["face_track"] があれば、それを keep 連結後のローカル時間軸に写像して
  crop の x を時間可変にする (見切れ防止のためスケール後幅にクランプ)。
  無ければ clip["face_cx"] (静的) を使う。

clips.json 構造 (Claude が transcript.json / face.json を読んで作成):
{
  "source_video": "path/to/source.mp4",
  "template_dir": "path/to/templates",   # 省略時は skill/templates
  "clips": [
    {
      "id": "clip1",
      "title": "AIが仕事を奪うって本当？",
      "template": "dark_neon",
      "keep": [[12.4, 33.0], [35.5, 48.0]],  # 連結する keep 区間
      "face_cx": 0.53,                        # 省略可 (静的中心)
      "face_track": [                         # 省略可 (元動画の絶対時間で指定)
        {"t": 12.4, "cx": 0.55}, {"t": 20.0, "cx": 0.48}, ...
      ],
      "zoom": 1.12,                           # 省略可 (default 1.08)
      "subtitles": [                          # keep 連結後のローカル時間軸
        {"start": 0.0, "end": 2.4, "text": "..."}, ...
      ]
    }
  ]
}

Usage:
  python render.py --clips clips.json --outdir out [--source <mp4>]
"""
import argparse
import json
import os
import subprocess
import sys

CANVAS_W, CANVAS_H = 1080, 1920

# 動画配置ゾーン。上にタイトル帯、下に字幕。切り抜き動画風に画面を大きく覆う。
CONTENT_TOP = 300
CONTENT_H = 1180
CONTENT_W = CANVAS_W

FONT_CANDIDATES = [
    r"C:\Windows\Fonts\BIZ-UDGothicB.ttc",
    r"C:\Windows\Fonts\meiryob.ttc",
    r"C:\Windows\Fonts\YuGothB.ttc",
    r"C:\Windows\Fonts\msgothic.ttc",
]


def find_font():
    for p in FONT_CANDIDATES:
        if os.path.exists(p):
            return p
    return None


def run(cmd, **kw):
    sys.stderr.write("[render] $ " + " ".join(str(c) for c in cmd) + "\n")
    proc = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8",
                          errors="replace", **kw)
    if proc.returncode != 0:
        sys.stderr.write(proc.stdout + "\n" + proc.stderr + "\n")
        raise SystemExit(f"command failed (code {proc.returncode})")
    return proc


def ass_time(t: float) -> str:
    if t < 0:
        t = 0
    h = int(t // 3600)
    m = int((t % 3600) // 60)
    s = t % 60
    return f"{h:d}:{m:02d}:{s:05.2f}"


def ass_escape(text: str) -> str:
    return text.replace("\\", "\\\\").replace("\n", "\\N")


def _effective_len(text: str) -> float:
    """全角=1 / 半角=0.5 で実効文字数を数える (タイトル幅の見積もり用)。"""
    return sum(1.0 if ord(ch) > 0xFF else 0.5 for ch in text)


def build_ass(clip, ass_path, font_name):
    """字幕 + タイトル帯を含む ASS ファイルを生成する。"""
    dur = clip["_total_dur"]
    title = clip.get("title", "")
    subs = clip.get("subtitles", [])

    # タイトルが帯からはみ出さないようフォントサイズを自動縮小する。
    # 実効幅 = CANVAS_W - 左右マージン(80*2)。1文字 ≈ フォントサイズ px。
    title_fs = 92
    eff = _effective_len(title)
    if eff > 0:
        title_fs = min(92, max(48, int((CANVAS_W - 160) / eff)))

    header = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {CANVAS_W}
PlayResY: {CANVAS_H}
WrapStyle: 0
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Sub,{font_name},74,&H00FFFFFF,&H00888888,&H00202020,&H90000000,-1,0,0,0,100,100,0,0,1,7,3,2,60,60,150,1
Style: Title,{font_name},{title_fs},&H0000F0FF,&H000000FF,&H00101010,&HA0000000,-1,0,0,0,100,100,0,0,1,8,4,8,80,80,120,1
Style: TitleBar,{font_name},{title_fs},&H0000F0FF,&H000000FF,&H00101010,&HA0000000,-1,0,0,0,100,100,0,0,3,20,0,8,80,80,120,1
Style: Emph,{font_name},92,&H0000FFFF,&H000000FF,&H00202020,&HB0000000,-1,0,0,0,100,100,0,0,1,8,4,5,60,60,0,1
Style: Name,{font_name},46,&H00FFFFFF,&H000000FF,&H00181818,&H90000000,-1,0,0,0,100,100,0,0,1,4,2,2,60,60,332,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""

    style = clip.get("subtitle_style") or {}
    motion = style.get("motion", "none")        # none / popin / karaoke
    kw_color = bool(style.get("keyword_color"))
    hook_anim = bool(clip.get("hook"))

    lines = []
    if title:
        t_title = ass_escape(title)
        # M13 冒頭フック演出: タイトル帯を縦に伸び上がるポップで登場させる
        t_anim = ("{\\fscy24\\t(0,220,\\fscy100)}" if hook_anim else "")
        lines.append(
            f"Dialogue: 0,{ass_time(0)},{ass_time(dur)},TitleBar,,0,0,0,,"
            f"{{\\1a&HFF&\\3a&H40&\\bord30\\3c&H101010&}}{t_anim}{t_title}"
        )
        lines.append(
            f"Dialogue: 1,{ass_time(0)},{ass_time(dur)},Title,,0,0,0,,{t_anim}{t_title}"
        )

    # 話者ごとの字幕色 (speaker フィールドがある場合のみ着色)。
    # 太字白抜きを基調に、話者で淡く色を変えて「誰の発話か」を可視化する。
    SPK_COLORS = {
        "A": "&H00FFFFFF&",   # 白 (既定話者)
        "B": "&H00B0FF60&",   # 淡いシアン寄り
        "C": "&H0060D0FF&",   # 淡いオレンジ寄り
        "D": "&H00C0A0FF&",   # 淡いピンク寄り
    }
    # 字幕: end が次の start を超えない / dur を超えないよう安全側にクランプ
    # 【見切れ防止】長い行は行幅に合わせてフォントを自動縮小する (タイトル帯と同じ発想)。
    # 字幕フォント 74px・左右マージン 60px → 実容量 ≈ (1080-120)/74 = 13.0 文字弱。
    SUB_FS = 74
    sub_capacity = (CANVAS_W - 120) / SUB_FS
    KW_MARK_OPEN, KW_MARK_CLOSE = "‹", "›"  # jp_subs のキーワードマーカー
    # M16 話者名ラベル: speaker_names {"A": "太田", ...} があれば、字幕帯の直上に
    # 話者名タグ (字幕と同じ話者色) を出す。誰の発話かが色+名前で分かる。
    speaker_names = clip.get("speaker_names") or {}
    for i, s in enumerate(subs):
        st = max(0.0, float(s["start"]))
        en = float(s["end"])
        if en > dur:
            en = dur
        if en <= st:
            continue
        raw_text = str(s.get("text", "")).strip()
        if not raw_text:
            continue
        spk = s.get("speaker")
        col = SPK_COLORS.get(spk) if spk else None
        color_tag = f"\\1c{col}" if col else ""
        if spk and speaker_names.get(spk):
            ncol = col or "&H00FFFFFF&"
            lines.append(
                f"Dialogue: 6,{ass_time(st)},{ass_time(en)},Name,,0,0,0,,"
                f"{{\\fad(80,80)\\1c{ncol}}}{ass_escape(str(speaker_names[spk]))}"
            )
        plain = raw_text.replace(KW_MARK_OPEN, "").replace(KW_MARK_CLOSE, "")
        widest = max((_effective_len(ln) for ln in plain.split("\n")), default=0.0)
        fs_tag = ""
        if widest > sub_capacity:
            fs = max(50, int((CANVAS_W - 120) / widest))
            fs_tag = f"\\fs{fs}"
        # M11 字幕モーション: ポップイン (出現時に少し拡大して収まる)
        pop_tag = ("\\fscx93\\fscy93\\t(0,140,\\fscx100\\fscy100)"
                   if motion == "popin" else "")
        eff = "{\\fad(80,80)" + color_tag + fs_tag + pop_tag + "}"

        if motion == "karaoke" and s.get("karaoke"):
            # カラオケ式ワードハイライト: 文字ごとに \k (センチ秒) を振る。
            # 未発話部分は SecondaryColour (灰)、発話済みが Primary (話者色)。
            parts = []
            for piece, cs in s["karaoke"]:
                if piece == "\n":
                    parts.append("\\N")
                elif piece == "":
                    parts.append(f"{{\\k{max(int(cs), 0)}}}")
                else:
                    parts.append(f"{{\\k{max(int(cs), 1)}}}{ass_escape(piece)}")
            body = "".join(parts)
        else:
            body = ass_escape(plain if not kw_color else raw_text)
            if kw_color:
                # マーカー → 色タグ (キーワード=黄、閉じで話者色/白へ戻す)
                restore = col or "&H00FFFFFF&"
                body = body.replace(KW_MARK_OPEN, "{\\1c&H0000FFFF&}")
                body = body.replace(KW_MARK_CLOSE, f"{{\\1c{restore}}}")
        lines.append(
            f"Dialogue: 5,{ass_time(st)},{ass_time(en)},Sub,,0,0,0,,{eff}{body}"
        )

    # 強調テロップ pop: キーワードを大きく色付きで、拡大しながらポンと出す。
    # emphasis = [{"start":s,"end":e,"text":"...","color":"yellow"|"pink"|...}]
    # 【配置ルール】顔 (動画コンテンツ) に被らないよう、動画配置ゾーンの
    # 直下・字幕帯の直上にある「安全帯」に固定配置する。
    #   - 動画コンテンツ:  y = CONTENT_TOP .. CONTENT_TOP+CONTENT_H (=300..1480)
    #     → 話者の顔がここに入るので pop を重ねない
    #   - 字幕 (Sub):      画面下部 (MarginV=150 → おおむね y>=1620)
    #   - 安全帯:          その間 (≈1480〜1610)。ここに pop を置く
    # これで「emphasis pop が顔に被る」問題を構造的に解消する。
    COLOR_MAP = {
        "yellow": "&H0000FFFF&", "pink": "&H00B469FF&", "cyan": "&H00FFFF00&",
        "green": "&H0000FF00&", "orange": "&H000080FF&", "red": "&H004040FF&",
        "white": "&H00FFFFFF&",
    }
    emph_x = CANVAS_W // 2
    # 動画ゾーン直下の安全帯の中央 (顔回避)。clip 側で emphasis_y 上書き可。
    safe_top = CONTENT_TOP + CONTENT_H          # 1480
    safe_band_center = safe_top + 55            # 1535: 動画直下・字幕の上
    emph_y = int(clip.get("emphasis_y", safe_band_center))
    for e in clip.get("emphasis", []) or []:
        st = max(0.0, float(e["start"]))
        en = float(e["end"])
        if en > dur:
            en = dur
        if en <= st:
            continue
        etxt = ass_escape(str(e.get("text", "")).strip())
        if not etxt:
            continue
        col = COLOR_MAP.get(str(e.get("color", "yellow")).lower(), "&H0000FFFF&")
        pop_ms = 180  # 立ち上がりの拡大アニメ時間
        # \an5 中央基準 + pos + 拡大 pop (t)。色は 1c で上書き。
        # 【重要】ASS ファイル内の override タグ引数は「素のカンマ」でなければ
        # ならない。ffmpeg の filtergraph 用エスケープ (\,) を混ぜると libass が
        # \pos / \t のパースに失敗し、位置指定もポップアニメも無効化される
        # (=顔にテロップが被る/演出が死ぬ原因だった)。ここでは必ず ',' を使う。
        eff = (
            f"{{\\an5\\pos({emph_x},{emph_y})\\1c{col}\\bord9\\shad4"
            f"\\fscx60\\fscy60\\t(0,{pop_ms},\\fscx112\\fscy112)"
            f"\\t({pop_ms},{pop_ms + 90},\\fscx100\\fscy100)\\fad(40,120)}}"
        )
        lines.append(
            f"Dialogue: 8,{ass_time(st)},{ass_time(en)},Emph,,0,0,0,,{eff}{etxt}"
        )

    with open(ass_path, "w", encoding="utf-8") as f:
        f.write(header + "\n".join(lines) + "\n")


def build_keep_filter(keep):
    """keep 区間を連結する trim/concat フィルタ断片を返す。"""
    v_parts = []
    a_parts = []
    for i, (s, e) in enumerate(keep):
        v_parts.append(f"[0:v]trim=start={s}:end={e},setpts=PTS-STARTPTS[v{i}]")
        a_parts.append(f"[0:a]atrim=start={s}:end={e},asetpts=PTS-STARTPTS[a{i}]")
    n = len(keep)
    vlabels = "".join(f"[v{i}]" for i in range(n))
    alabels = "".join(f"[a{i}]" for i in range(n))
    concat_v = f"{vlabels}concat=n={n}:v=1:a=0[vc]"
    concat_a = f"{alabels}concat=n={n}:v=0:a=1[ac]"
    return ";".join(v_parts + a_parts + [concat_v, concat_a])


def source_to_local(t_src, keep):
    """元動画の絶対時間 t_src を、keep 連結後のローカル時間に写像。

    t_src がどの keep 区間にも入らない場合は None。
    """
    offset = 0.0
    for s, e in keep:
        if t_src < s:
            return None
        if s <= t_src <= e:
            return offset + (t_src - s)
        offset += e - s
    return None


def _decimate_points(pts, min_dt=1.0, x_eps=8, max_points=40):
    """区分線形の点列を間引く。

    - min_dt 秒より近い点は、x の変化が x_eps 未満なら間引く
    - 端点 (最初/最後) は常に残す
    - なお多い場合は等間隔サンプリングで max_points に丸める
    """
    if len(pts) <= 2:
        return pts
    kept = [pts[0]]
    for lt, x in pts[1:-1]:
        plt, px = kept[-1]
        if (lt - plt) < min_dt and abs(x - px) < x_eps:
            continue
        kept.append((lt, x))
    kept.append(pts[-1])
    if len(kept) > max_points:
        idx = [round(i * (len(kept) - 1) / (max_points - 1)) for i in range(max_points)]
        seen = set()
        red = []
        for i in idx:
            if i not in seen:
                seen.add(i)
                red.append(kept[i])
        kept = red
    return kept


def _piecewise_expr(pts, hold_ends=True):
    """(t, value) 点列から ffmpeg の区分線形補間式を組む。

    ffmpeg 式内なのでカンマは `\\,` でエスケープする。
    hold_ends=True: 先頭より前は最初の値、末尾より後は最後の値でホールド。
    """
    if len(pts) == 1:
        return f"{pts[0][1]:.3f}"

    def seg_expr(i):
        t0, v0 = pts[i]
        t1, v1 = pts[i + 1]
        dt = max(1e-3, t1 - t0)
        return f"({v0:.3f}+({v1:.3f}-{v0:.3f})*(t-{t0:.3f})/{dt:.3f})"

    expr = f"{pts[-1][1]:.3f}"
    for i in range(len(pts) - 2, -1, -1):
        t1 = pts[i + 1][0]
        expr = f"if(lt(t\\,{t1:.3f})\\,{seg_expr(i)}\\,{expr})"
    if hold_ends:
        t_first = pts[0][0]
        expr = f"if(lt(t\\,{t_first:.3f})\\,{pts[0][1]:.3f}\\,{expr})"
    return expr


def build_zoom_expr(clip, keep, total_dur, base_zoom):
    """時間可変ズーム倍率 zoom(t) の ffmpeg 式を返す (無ければ静的)。

    clip["zoom_segments"] = [{"t": ローカル秒, "zoom": 倍率}, ...] があれば、
    その点列を区分線形で補間する。無ければ clip["zoom"] (静的)。
    倍率は [1.02, base_zoom] にクランプ。
    """
    segs = clip.get("zoom_segments")
    static_zoom = float(clip.get("zoom", 1.08))
    if not segs:
        return f"{static_zoom:.4f}"
    pts = []
    for s in segs:
        t = max(0.0, min(total_dur, float(s["t"])))
        z = max(1.02, min(base_zoom, float(s["zoom"])))
        pts.append((t, z))
    pts.sort(key=lambda a: a[0])
    dedup = []
    for t, z in pts:
        if dedup and abs(dedup[-1][0] - t) < 1e-3:
            continue
        dedup.append((t, z))
    pts = dedup
    if not pts:
        return f"{static_zoom:.4f}"
    return _piecewise_expr(pts)


def clip_max_zoom(clip):
    """クリップ内で使う最大ズーム (base スケール決定用)。"""
    zs = [float(clip.get("zoom", 1.08))]
    for s in clip.get("zoom_segments", []) or []:
        zs.append(float(s.get("zoom", 1.08)))
    return max(1.02, max(zs))


def build_crop_x_track(clip, keep, scaled_w):
    """顔トラックを keep 連結後ローカル時間に写像した (t, cx) 点列を返す。

    cx は 0..1 のスケール後座標比 (scaled_w に対する顔中心)。crop 幅が時間で
    変わるため、ここでは x (px) ではなく比率で持ち、呼び出し側で幅を引く。
    戻り値: (pts, static_cx)。pts が空なら static_cx を使う。
    """
    static_cx = float(clip.get("face_cx", 0.5))
    track = clip.get("face_track")
    if not track:
        return [], static_cx
    pts = []
    for p in track:
        lt = source_to_local(float(p["t"]), keep)
        if lt is None:
            continue
        cx = min(1.0, max(0.0, float(p["cx"])))
        pts.append((lt, cx))
    if not pts:
        return [], static_cx
    pts.sort(key=lambda a: a[0])
    dedup = []
    for lt, cx in pts:
        if dedup and abs(dedup[-1][0] - lt) < 1e-3:
            continue
        dedup.append((lt, cx))
    # 変化が小さい/近接点を間引く (式を軽く保つ)
    pts = _decimate_points(dedup, min_dt=1.0, x_eps=0.01, max_points=36)
    return pts, static_cx


def build_audio_chain(clip, dub_wav, ducking_db):
    """音声フィルタ断片と最終音声ラベルを返す。

    通常は keep 連結音声 [ac] をそのまま使う。dub_wav (ずんだもん吹き替え wav)
    があれば、原音を全編通して ducking_db まで下げた上に TTS をミックスする。

    【方式: 静的ダッキング (全編一律)】
      原音は「気配が残る程度」(既定 -22dB ≈ 元の8%) まで常時下げ、ずんだもんを
      主役にする。以前はサイドチェイン式 (喋る瞬間だけ沈める) だったが、台詞の
      切れ目で原音が戻り「元の音声とずんだもんが一緒に聞こえてうるさい」と
      ユーザー評価だったため、常時低音量の静的方式に変更した。
      dub 側は +2dB 持ち上げて前に出す。

    戻り値: (extra_input_args, filter_fragment, out_audio_label)
      - extra_input_args: ffmpeg の追加 -i (dub wav)。無ければ []
      - filter_fragment : filter_complex に足す音声処理 (';' 区切り、無ければ "")
      - out_audio_label : -map するラベル ("[ac]" or "[amix]")
    """
    if not dub_wav:
        return [], "", "[ac]"
    # 原音は [ac] (keep 連結済み)。dub は 2 番目の追加入力 [2:a]。
    # ダッキング量を線形ゲインに変換 (例 -22dB → 10^(-22/20)≈0.079)。
    gain = 10 ** (float(ducking_db) / 20.0)
    dub_boost = 10 ** (2.0 / 20.0)
    frag = (
        f"[ac]volume={gain:.4f}[aduck];"
        f"[2:a]aresample=async=1,volume={dub_boost:.4f}[adub];"
        f"[aduck][adub]amix=inputs=2:duration=first:"
        f"dropout_transition=0:normalize=0[amix]"
    )
    return ["-i", dub_wav], frag, "[amix]"


def build_split_chain(clip, src_w, src_h):
    """M17 対談2分割レイアウト: 上下 2 パネルに別々の静的クロップで話者を並べる。

    clip["split_panes"] = [{"cx": 0.30, "cy": 0.5, "zoom": 1.0}, {"cx": 0.70}] の
    2 要素 (上→下)。cx/cy は元フレーム内の話者位置 (0..1、M10 のフレーム分析で決める)。
    パネルは 1080x960 で、16:9 素材なら zoom 1.0 でも横 63% のクロップになり
    左右の話者が自然に分離される。face_track / zoom_segments は使わない (静的)。
    [vc] を受けて [comp] を返すフィルタ断片。
    """
    pane_h = CANVAS_H // 2
    panes = list(clip.get("split_panes") or [{"cx": 0.30}, {"cx": 0.70}])
    panes = (panes + [{"cx": 0.5}, {"cx": 0.5}])[:2]
    frags = [f"[vc]split=2[vp0][vp1]",
             f"[1:v]scale={CANVAS_W}:{CANVAS_H}[bg]"]
    prev = "[bg]"
    for i, p in enumerate(panes):
        zoom = max(1.0, min(2.5, float(p.get("zoom", 1.0))))
        cx = min(1.0, max(0.0, float(p.get("cx", 0.5))))
        cy = min(1.0, max(0.0, float(p.get("cy", 0.5))))
        f = max(CANVAS_W / src_w, pane_h / src_h) * zoom
        sw = int(round(src_w * f / 2) * 2)
        sh = int(round(src_h * f / 2) * 2)
        x = max(0, min(sw - CANVAS_W, int(cx * sw - CANVAS_W / 2)))
        y = max(0, min(sh - pane_h, int(cy * sh - pane_h / 2)))
        frags.append(f"[vp{i}]scale={sw}:{sh},crop={CANVAS_W}:{pane_h}:{x}:{y},"
                     f"setsar=1[pp{i}]")
        out = f"[cs{i}]"
        frags.append(f"{prev}[pp{i}]overlay=x=0:y={i * pane_h}{out}")
        prev = out
    # パネル境界に細い黒ライン
    frags.append(f"{prev}drawbox=x=0:y={pane_h - 3}:w={CANVAS_W}:h=6:"
                 f"color=black:t=fill[comp]")
    return ";".join(frags)


def probe_size(path):
    proc = subprocess.run(
        ["ffprobe", "-v", "error", "-select_streams", "v:0",
         "-show_entries", "stream=width,height", "-of", "csv=p=0:s=x", path],
        capture_output=True, text=True, encoding="utf-8", errors="replace",
    )
    out = proc.stdout.strip()
    try:
        w, h = out.split("x")
        return int(w), int(h)
    except Exception:
        return 1280, 720


_VIDEO_CODEC_ARGS = None


def video_codec_args():
    """GPU (NVENC) が使えれば h264_nvenc、無ければ libx264 にフォールバックする。

    プローブは 256x256 で行う。64x64 など小さすぎるフレームは NVENC の最小
    サイズ制約で常に失敗し、silent fallback で CPU に落ちる (実際に起きた)。
    """
    global _VIDEO_CODEC_ARGS
    if _VIDEO_CODEC_ARGS is not None:
        return _VIDEO_CODEC_ARGS
    try:
        proc = subprocess.run(
            ["ffmpeg", "-hide_banner", "-f", "lavfi",
             "-i", "color=black:s=256x256:d=0.1",
             "-c:v", "h264_nvenc", "-f", "null", "-"],
            capture_output=True, timeout=30,
        )
        nvenc_ok = proc.returncode == 0
    except Exception:
        nvenc_ok = False
    if nvenc_ok:
        _VIDEO_CODEC_ARGS = ["-c:v", "h264_nvenc", "-preset", "p5", "-rc", "vbr",
                             "-cq", "23", "-b:v", "0"]
        sys.stderr.write("[render] encoder: h264_nvenc (GPU)\n")
    else:
        _VIDEO_CODEC_ARGS = ["-c:v", "libx264", "-preset", "medium", "-crf", "20"]
        sys.stderr.write("[render] encoder: libx264 (CPU fallback)\n")
    return _VIDEO_CODEC_ARGS


def verify_output(path):
    """レンダ出力の整合性チェック。0バイト/読めない mp4 を掃除して明示エラー。"""
    broken = False
    if not os.path.exists(path) or os.path.getsize(path) == 0:
        broken = True
    else:
        proc = subprocess.run(
            ["ffprobe", "-v", "error", "-show_entries", "format=duration",
             "-of", "csv=p=0", path],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
        )
        if proc.returncode != 0 or not proc.stdout.strip():
            broken = True
    if broken:
        try:
            if os.path.exists(path):
                os.remove(path)
        except OSError:
            pass
        raise SystemExit(
            f"[render] ERROR: broken output detected and removed: {path}\n"
            f"再実行してください。連続で失敗する場合はディスク容量と ffmpeg ログを確認。")


def render_clip(clip, source, template_dir, outdir, font_name, font_file,
                dub_wav=None, ducking_db=-22.0):
    """1 クリップを 9:16 完成 mp4 に合成する。out_path を返す。"""
    cid = clip.get("id", "clip")
    keep = [(float(s), float(e)) for s, e in clip["keep"]]
    total_dur = sum(e - s for s, e in keep)
    clip["_total_dur"] = total_dur

    # 字幕 + タイトル帯の ASS
    ass_path = os.path.join(outdir, f"{cid}.ass")
    build_ass(clip, ass_path, font_name)

    # 背景テンプレ (無ければ dark_neon にフォールバック)
    tmpl = clip.get("template", "dark_neon")
    tmpl_path = os.path.join(template_dir, f"{tmpl}.png")
    if not os.path.exists(tmpl_path):
        tmpl_path = os.path.join(template_dir, "dark_neon.png")

    src_w, src_h = probe_size(source)
    layout = str(clip.get("layout", "standard"))

    if layout == "split":
        # M17 対談2分割: 上下 2 パネル (静的クロップ)。face_track/zoom は使わない。
        video_chain = build_split_chain(clip, src_w, src_h)
    else:
        # standard: 背景テンプレの上に 1080x1180 のコンテンツゾーン
        # fullscreen: 動画が全画面 (1080x1920) を覆い、テンプレは見えない
        if layout == "fullscreen":
            c_top, c_w, c_h = 0, CANVAS_W, CANVAS_H
        else:
            c_top, c_w, c_h = CONTENT_TOP, CONTENT_W, CONTENT_H

        # 元動画をコンテンツゾーンに cover 配置するための基準スケール。
        # 最大ズーム時でもクロップ窓がはみ出さないよう max_zoom ぶん大きくスケール。
        max_zoom = clip_max_zoom(clip)
        f = max(c_w / src_w, c_h / src_h) * max_zoom
        scaled_w = int(round(src_w * f / 2) * 2)
        scaled_h = int(round(src_h * f / 2) * 2)

        # 時間可変ズーム z(t)。クロップ窓は zoom に反比例 (窓が小さいほど寄り)。
        z_expr = build_zoom_expr(clip, keep, total_dur, max_zoom)
        cw_expr = f"({c_w}*{max_zoom:.4f}/({z_expr}))"
        ch_expr = f"({c_h}*{max_zoom:.4f}/({z_expr}))"

        # 横クロップ位置: 顔トラック (ローカル時間) で窓中心を顔に合わせ、端でクランプ。
        pts, static_cx = build_crop_x_track(clip, keep, scaled_w)
        if pts:
            px_pts = [(lt, cx * scaled_w) for lt, cx in pts]
            cx_expr = _piecewise_expr(px_pts)
        else:
            cx_expr = f"{static_cx * scaled_w:.1f}"
        x_expr = f"max(0\\,min({scaled_w}-{cw_expr}\\,({cx_expr})-({cw_expr})/2))"

        # 縦クロップ位置: crop_bias_y (0.25〜0.32=頭まで入る引き / 0.5=中央 / 0.58=胸元)
        bias_y = float(clip.get("crop_bias_y", 0.5))
        y_expr = f"max(0\\,min({scaled_h}-{ch_expr}\\,{bias_y:.4f}*{scaled_h}-({ch_expr})/2))"

        # 時間可変 crop → コンテンツサイズに scale。crop の w/h も t 依存にすると
        # ffmpeg が毎フレーム評価する。scale で最終的に固定サイズへ。
        video_chain = (
            f"[vc]scale={scaled_w}:{scaled_h},"
            f"crop=w='{cw_expr}':h='{ch_expr}':x='{x_expr}':y='{y_expr}',"
            f"scale={c_w}:{c_h},setsar=1[vs];"
            f"[1:v]scale={CANVAS_W}:{CANVAS_H}[bg];"
            f"[bg][vs]overlay=x=0:y={c_top}[comp]"
        )

    # 字幕フィルタ (Windows パスのコロンをエスケープ)
    ass_esc = ass_path.replace("\\", "/").replace(":", "\\:")
    subtitles_arg = f"subtitles='{ass_esc}'"
    if font_file:
        fonts_dir = os.path.dirname(font_file).replace("\\", "/").replace(":", "\\:")
        subtitles_arg += f":fontsdir='{fonts_dir}'"

    keep_filter = build_keep_filter(keep)
    dub_inputs, audio_frag, audio_label = build_audio_chain(
        clip, dub_wav, ducking_db)

    filter_complex = (
        f"{keep_filter};{video_chain};"
        f"[comp]{subtitles_arg}[vout]"
    )
    if audio_frag:
        filter_complex += ";" + audio_frag

    out_path = os.path.join(outdir, f"{cid}.mp4")
    cmd = [
        "ffmpeg", "-y",
        "-i", source,
        "-loop", "1", "-i", tmpl_path,
        *dub_inputs,
        "-filter_complex", filter_complex,
        "-map", "[vout]",
        "-map", audio_label,
        *video_codec_args(),
        "-pix_fmt", "yuv420p",
        "-c:a", "aac", "-b:a", "192k",
        "-r", "30",
        "-shortest",
        "-movflags", "+faststart",
        out_path,
    ]
    run(cmd)
    verify_output(out_path)
    sys.stderr.write(f"[render] wrote {out_path} ({total_dur:.1f}s)\n")
    return out_path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--clips", required=True)
    ap.add_argument("--outdir", default="out")
    ap.add_argument("--source", default=None, help="clips.json の source_video を上書き")
    ap.add_argument("--dubs", default=None,
                    help="dub.py の出力 JSON (clip_id→wav)。指定時は該当クリップの"
                         "原音をダッキングしてずんだもん音声をミックスする")
    ap.add_argument("--ducking-db", type=float, default=-22.0,
                    help="吹き替え時に原音を下げる量 (dB)。小さいほど原音が小さい")
    args = ap.parse_args()

    with open(args.clips, "r", encoding="utf-8") as f:
        spec = json.load(f)

    source = args.source or spec.get("source_video")
    if not source or not os.path.exists(source):
        raise SystemExit(f"source video not found: {source}")

    here = os.path.dirname(os.path.abspath(__file__))
    template_dir = spec.get("template_dir") or os.path.normpath(
        os.path.join(here, "..", "templates"))

    os.makedirs(args.outdir, exist_ok=True)

    font_file = find_font()
    if not font_file:
        sys.stderr.write("[render] WARNING: no Japanese bold font found; text may be tofu\n")
        font_name = "sans-serif"
    else:
        font_name = "BIZ UDGothic"
        low = font_file.lower()
        if "meiryo" in low:
            font_name = "Meiryo"
        elif "yugoth" in low:
            font_name = "Yu Gothic"
        elif "msgothic" in low:
            font_name = "MS Gothic"

    # 吹き替え wav マップ (dub.py 出力 or clips.json 埋め込み)。
    dub_map = {}
    if args.dubs and os.path.exists(args.dubs):
        with open(args.dubs, "r", encoding="utf-8") as f:
            dj = json.load(f)
        dub_map = dj.get("dubs", dj) if isinstance(dj, dict) else {}

    outputs = []
    for clip in spec["clips"]:
        cid = clip.get("id", "clip")
        # spec 全体の字幕スタイル (M11/M12)・レイアウト (M17)・話者名 (M16) を
        # 各 clip に継承 (clip 側指定が優先)
        clip.setdefault("subtitle_style", spec.get("subtitle_style") or {})
        clip.setdefault("layout", spec.get("layout", "standard"))
        clip.setdefault("speaker_names", spec.get("speaker_names") or {})
        dub_wav = dub_map.get(cid)
        if dub_wav and not os.path.exists(dub_wav):
            sys.stderr.write(f"[render] WARNING dub wav missing for {cid}: {dub_wav}\n")
            dub_wav = None
        outputs.append(render_clip(clip, source, template_dir, args.outdir,
                                   font_name, font_file,
                                   dub_wav=dub_wav, ducking_db=args.ducking_db))

    print(json.dumps({"outputs": outputs}, ensure_ascii=False))


if __name__ == "__main__":
    main()
