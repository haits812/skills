#!/usr/bin/env python3
"""レンダ済みの完成ショート一覧を 1 枚の contact sheet (サムネ + タイトル + 尺)
にまとめる。使い手が「出てきた複数の完成ショートから使うものを選ぶだけ」を
一目で完結できるようにするための一覧画像。

各クリップについて:
  - 縦型 9:16 完成 mp4 の代表フレーム (タイトル帯・字幕が乗った状態) を縮小サムネ
  - その下に id / タイトル / 尺(秒) / テンプレ名 のラベル

出力: out/contact_sheet.png (デフォルト)

Usage:
  python contact_sheet.py --clips work/clips.json --outdir out \
      [--sheet out/contact_sheet.png] [--at 2.0]
"""
import argparse
import io
import json
import os
import subprocess
import sys
import tempfile

from PIL import Image, ImageDraw, ImageFont

FONT_CANDIDATES = [
    r"C:\Windows\Fonts\BIZ-UDGothicB.ttc",
    r"C:\Windows\Fonts\meiryob.ttc",
    r"C:\Windows\Fonts\YuGothB.ttc",
    r"C:\Windows\Fonts\msgothic.ttc",
]

# サムネ 1 枚のサイズ (9:16)
THUMB_W = 300
THUMB_H = 533
PAD = 24            # サムネ間の余白
LABEL_H = 132       # ラベル領域の高さ
BG = (24, 26, 34)   # シート背景 (ダーク)
CARD_BG = (38, 41, 54)
TEXT = (238, 240, 245)
SUB = (150, 200, 255)
DUR = (255, 214, 90)


def find_font(size):
    for p in FONT_CANDIDATES:
        if os.path.exists(p):
            try:
                return ImageFont.truetype(p, size)
            except Exception:
                continue
    return ImageFont.load_default()


def probe_duration(path):
    try:
        out = subprocess.run(
            ["ffprobe", "-v", "error", "-show_entries", "format=duration",
             "-of", "default=noprint_wrappers=1:nokey=1", path],
            capture_output=True, text=True).stdout.strip()
        return float(out)
    except Exception:
        return 0.0


def grab_frame(video, at, tmpdir, idx):
    """完成 mp4 の代表フレーム (タイトル帯・字幕が乗った状態) を PNG で取り出す。"""
    dur = probe_duration(video)
    ts = at if (dur == 0 or at < dur) else max(0.0, dur * 0.35)
    out = os.path.join(tmpdir, f"thumb_{idx}.png")
    proc = subprocess.run(
        ["ffmpeg", "-y", "-v", "error", "-ss", f"{ts:.2f}", "-i", video,
         "-frames:v", "1", out],
        capture_output=True, text=True, encoding="utf-8", errors="replace")
    if proc.returncode != 0 or not os.path.exists(out):
        return None
    return out


def wrap_text(draw, text, font, max_w):
    """max_w に収まるよう日本語を文字単位で折り返す。"""
    lines = []
    cur = ""
    for ch in text:
        trial = cur + ch
        w = draw.textbbox((0, 0), trial, font=font)[2]
        if w > max_w and cur:
            lines.append(cur)
            cur = ch
        else:
            cur = trial
    if cur:
        lines.append(cur)
    return lines[:2]  # 最大 2 行


def build_sheet(clips_json, outdir, sheet_path, at):
    data = json.load(io.open(clips_json, encoding="utf-8"))
    clips = data.get("clips", [])
    if not clips:
        raise SystemExit("no clips in clips.json")

    tmpdir = tempfile.mkdtemp(prefix="contact_")
    entries = []
    for i, c in enumerate(clips):
        cid = c.get("id", f"clip{i+1}")
        video = os.path.join(outdir, f"{cid}.mp4")
        if not os.path.exists(video):
            sys.stderr.write(f"[contact_sheet] missing output, skip: {video}\n")
            continue
        thumb = grab_frame(video, at, tmpdir, i)
        if thumb is None:
            sys.stderr.write(f"[contact_sheet] frame grab failed, skip: {video}\n")
            continue
        entries.append({
            "id": cid,
            "title": c.get("title", ""),
            "template": c.get("template", ""),
            "dur": probe_duration(video),
            "thumb": thumb,
        })

    if not entries:
        raise SystemExit("no renderable clips for contact sheet")

    # レイアウト: 最大 4 列
    n = len(entries)
    cols = min(4, n)
    rows = (n + cols - 1) // cols
    card_w = THUMB_W + PAD
    card_h = THUMB_H + LABEL_H + PAD
    header_h = 96
    sheet_w = cols * card_w + PAD
    sheet_h = header_h + rows * card_h + PAD

    sheet = Image.new("RGB", (sheet_w, sheet_h), BG)
    draw = ImageDraw.Draw(sheet)

    # ヘッダ
    hfont = find_font(40)
    sfont = find_font(22)
    draw.text((PAD + 4, 22), "完成ショート候補 一覧", font=hfont, fill=TEXT)
    draw.text((PAD + 6, 68),
              f"{n} 本 / 使うものを選ぶだけ (9:16・音声同期字幕・タイトル帯付き)",
              font=sfont, fill=SUB)

    title_font = find_font(26)
    meta_font = find_font(22)
    id_font = find_font(20)

    for idx, e in enumerate(entries):
        r, cc = divmod(idx, cols)
        x0 = PAD + cc * card_w
        y0 = header_h + r * card_h
        # カード背景
        draw.rounded_rectangle(
            [x0, y0, x0 + THUMB_W + 8, y0 + THUMB_H + LABEL_H + 8],
            radius=14, fill=CARD_BG)
        # サムネ
        im = Image.open(e["thumb"]).convert("RGB").resize((THUMB_W, THUMB_H))
        sheet.paste(im, (x0 + 4, y0 + 4))
        # ラベル
        ly = y0 + THUMB_H + 12
        # 尺バッジ
        dur_txt = f"{e['dur']:.0f}s"
        draw.text((x0 + 10, ly), dur_txt, font=meta_font, fill=DUR)
        tpl = e["template"]
        if tpl:
            tw = draw.textbbox((0, 0), dur_txt, font=meta_font)[2]
            draw.text((x0 + 20 + tw, ly), f"[{tpl}]", font=meta_font, fill=SUB)
        # タイトル (折り返し)
        tly = ly + 30
        for line in wrap_text(draw, e["title"], title_font, THUMB_W - 16):
            draw.text((x0 + 10, tly), line, font=title_font, fill=TEXT)
            tly += 32
        # id
        draw.text((x0 + 10, y0 + THUMB_H + LABEL_H - 22),
                  e["id"], font=id_font, fill=(120, 124, 140))

    os.makedirs(os.path.dirname(sheet_path) or ".", exist_ok=True)
    sheet.save(sheet_path)
    sys.stderr.write(f"[contact_sheet] wrote {sheet_path} ({n} clips, {cols}x{rows})\n")
    print(json.dumps({"contact_sheet": sheet_path, "clips": n}))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--clips", required=True, help="clips.json のパス")
    ap.add_argument("--outdir", default="out", help="完成 mp4 のあるディレクトリ")
    ap.add_argument("--sheet", default=None, help="出力先 (省略時 outdir/contact_sheet.png)")
    ap.add_argument("--at", type=float, default=2.0,
                    help="サムネに使う秒 (タイトル帯・字幕が乗った代表フレーム)")
    args = ap.parse_args()
    sheet = args.sheet or os.path.join(args.outdir, "contact_sheet.png")
    build_sheet(args.clips, args.outdir, sheet, args.at)


if __name__ == "__main__":
    main()
