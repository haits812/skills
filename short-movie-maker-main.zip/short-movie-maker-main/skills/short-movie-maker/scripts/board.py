"""候補レビュー用 HTML ボード生成 (M14、day02 operator board の移植)。

contact_sheet.png の発展形: 動画プレビュー・字幕全文 (話者色付き)・尺・
サムネ・投稿メタデータを 1 枚の HTML で確認できる。成果物が clips.json より
古い場合は「古い世代」警告を出す (day02 の鮮度チェック)。

Usage:
  python board.py --clips work/clips.json --outdir out [--meta out/metadata.md]
"""

from __future__ import annotations

import argparse
import html
import json
import os
import sys

SPK_CSS = {"A": "#ffffff", "B": "#60ffb0", "C": "#ffd060", "D": "#ffa0c0"}


def esc(v: object) -> str:
    return html.escape(str(v or ""))


def sub_rows(subs: list) -> str:
    rows = []
    for s in subs:
        spk = s.get("speaker") or ""
        color = SPK_CSS.get(spk, "#ffffff")
        text = esc(s.get("text", "")).replace("\n", " / ").replace("‹", "<b class='kw'>").replace("›", "</b>")
        rows.append(
            f"<tr><td class='t'>{s.get('start', 0):.1f}</td>"
            f"<td class='spk' style='color:{color}'>{esc(spk)}</td>"
            f"<td style='color:{color}'>{text}</td></tr>")
    return "".join(rows)


def main() -> None:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser()
    ap.add_argument("--clips", required=True)
    ap.add_argument("--outdir", default="out")
    ap.add_argument("--meta", default=None, help="metadata.md (任意、あれば埋め込む)")
    args = ap.parse_args()

    with open(args.clips, "r", encoding="utf-8") as f:
        spec = json.load(f)
    clips_mtime = os.path.getmtime(args.clips)

    meta_html = ""
    if args.meta and os.path.exists(args.meta):
        with open(args.meta, "r", encoding="utf-8") as f:
            meta_html = f"<details open><summary>投稿メタデータ</summary><pre>{esc(f.read())}</pre></details>"

    cards = []
    for clip in spec.get("clips", []):
        cid = clip.get("id", "clip")
        mp4 = os.path.join(args.outdir, f"{cid}.mp4")
        stale = ""
        if os.path.exists(mp4):
            if os.path.getmtime(mp4) < clips_mtime - 1:
                stale = "<p class='stale'>⚠ この mp4 は clips.json より古い世代です (再レンダ推奨)</p>"
            video = f"<video controls preload='metadata' src='{esc(cid)}.mp4'></video>"
        else:
            video = "<p class='stale'>mp4 未生成</p>"
        thumb = f"thumb_{cid}.png"
        thumb_html = (f"<img class='thumb' src='{esc(thumb)}' alt='thumb'>"
                      if os.path.exists(os.path.join(args.outdir, thumb)) else "")
        dur = sum(e - s for s, e in clip.get("keep", []))
        subs = clip.get("subtitles", [])
        cards.append(f"""
<article>
  <header><h2>{esc(clip.get('title'))}</h2>
  <p class='meta'>{esc(cid)} ・ {dur:.1f}s ・ {esc(clip.get('template'))} ・ 字幕{len(subs)}枚</p>{stale}</header>
  <div class='row'>
    <div class='vid'>{video}{thumb_html}</div>
    <table class='subs'>{sub_rows(subs)}</table>
  </div>
</article>""")

    doc = f"""<!doctype html><html lang="ja"><head><meta charset="utf-8">
<title>候補レビューボード</title>
<style>
 body{{background:#14161c;color:#eee;font-family:'BIZ UDGothic','Meiryo',sans-serif;margin:24px}}
 h1{{font-size:20px}} h2{{font-size:16px;margin:0}}
 article{{background:#1d2130;border-radius:12px;padding:16px;margin:16px 0}}
 .meta{{color:#8b93a8;font-size:12px;margin:4px 0}}
 .stale{{color:#ffb020;font-size:12px}}
 .row{{display:flex;gap:16px;align-items:flex-start}}
 video{{width:240px;border-radius:8px}} .thumb{{width:120px;border-radius:8px;margin-left:8px;vertical-align:top}}
 table.subs{{font-size:12px;border-collapse:collapse;background:#141824;border-radius:8px;padding:8px}}
 table.subs td{{padding:2px 8px;border-bottom:1px solid #262b3d}}
 td.t{{color:#8b93a8}} td.spk{{font-weight:bold}}
 b.kw{{color:#ffe000}}
 pre{{white-space:pre-wrap;background:#141824;padding:12px;border-radius:8px;font-size:12px}}
</style></head><body>
<h1>完成ショート候補 レビューボード</h1>
<p class='meta'>{len(spec.get('clips', []))} 本 / 動画クリックで再生。字幕は話者色付き。</p>
{meta_html}
{''.join(cards)}
</body></html>"""

    out_path = os.path.join(args.outdir, "board.html")
    os.makedirs(args.outdir, exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(doc)
    print(json.dumps({"board": out_path, "clips": len(spec.get("clips", []))},
                     ensure_ascii=False))


if __name__ == "__main__":
    main()
