"""実行環境の一括検査 (day01 video-editing の preflight_check を移植)。

依存が増えたので (NVENC/CUDA/VOICEVOX/HF トークン/pip 群)、初回や
環境が壊れたときに一発で原因を特定できるようにする。

Usage:
  python preflight.py            # 全部検査
  python preflight.py --quick    # CLI と pip だけ (数秒)
"""

from __future__ import annotations

import argparse
import importlib
import json
import os
import shutil
import subprocess
import sys

RESULTS: list[dict] = []


def report(name: str, ok: bool, detail: str = "", required: bool = True) -> None:
    RESULTS.append({"name": name, "ok": ok, "detail": detail, "required": required})
    mark = "OK " if ok else ("FAIL" if required else "WARN")
    sys.stderr.write(f"[{mark}] {name}: {detail}\n")


def check_cli(name: str, required: bool = True) -> bool:
    path = shutil.which(name)
    report(f"cli:{name}", bool(path), path or "not found", required)
    return bool(path)


def check_pip(mod: str, required: bool = True) -> bool:
    try:
        importlib.import_module(mod)
        report(f"pip:{mod}", True, "importable", required)
        return True
    except Exception as e:
        report(f"pip:{mod}", False, str(e)[:80], required)
        return False


def check_nvenc() -> bool:
    try:
        proc = subprocess.run(
            ["ffmpeg", "-hide_banner", "-f", "lavfi", "-i", "color=black:s=256x256:d=0.1",
             "-c:v", "h264_nvenc", "-f", "null", "-"],
            capture_output=True, timeout=30)
        ok = proc.returncode == 0
    except Exception:
        ok = False
    report("gpu:nvenc", ok, "h264_nvenc encode test", required=False)
    return ok


def check_cuda() -> bool:
    try:
        import torch
        ok = torch.cuda.is_available()
        detail = torch.cuda.get_device_name(0) if ok else "cuda not available"
    except Exception as e:
        ok, detail = False, str(e)[:80]
    report("gpu:cuda", ok, detail, required=False)
    return ok


def check_font() -> bool:
    candidates = [r"C:\Windows\Fonts\BIZ-UDGothicB.ttc", r"C:\Windows\Fonts\meiryob.ttc",
                  r"C:\Windows\Fonts\YuGothB.ttc"]
    found = next((p for p in candidates if os.path.exists(p)), None)
    report("font:jp-bold", bool(found), found or "no JP bold font", required=True)
    return bool(found)


def check_hf_token() -> bool:
    here = os.path.dirname(os.path.abspath(__file__))
    tok = (os.environ.get("HF_TOKEN") or os.environ.get("HUGGING_FACE_HUB_TOKEN")
           or (os.path.exists(os.path.join(here, ".hf_token")) and "file"))
    report("token:huggingface", bool(tok),
           "found (話者分離が使える)" if tok else "無し — 話者分離 (diarize) は使えない",
           required=False)
    return bool(tok)


def check_voicevox() -> bool:
    import urllib.request
    try:
        with urllib.request.urlopen("http://127.0.0.1:50021/version", timeout=2) as r:
            report("voicevox:engine", True, f"running v{r.read().decode()[:12]}", required=False)
            return True
    except Exception:
        pass
    # ユーザー名をハードコードせず標準インストール先から解決 (環境変数優先)。
    roots = [
        os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs", "VOICEVOX"),
        os.path.join(os.environ.get("ProgramFiles", ""), "VOICEVOX"),
    ]
    candidates = [os.environ.get("VOICEVOX_ENGINE_RUN")] + [
        os.path.join(r, "vv-engine", "run.exe") for r in roots if r]
    installed = any(c and os.path.exists(c) for c in candidates)
    report("voicevox:engine", installed,
           "installed (未起動、dub.py が自動起動を試みる)" if installed else "not installed — 吹き替え不可",
           required=False)
    return installed


def main() -> None:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true")
    args = ap.parse_args()

    for cli in ("ffmpeg", "ffprobe", "yt-dlp"):
        check_cli(cli)
    for mod in ("faster_whisper", "cv2", "PIL", "budoux", "sudachipy", "kanjize", "silero_vad", "numpy"):
        check_pip(mod)
    check_pip("whisperx", required=False)
    check_font()

    if not args.quick:
        check_nvenc()
        check_cuda()
        check_hf_token()
        check_voicevox()

    failed = [r for r in RESULTS if not r["ok"] and r["required"]]
    warned = [r for r in RESULTS if not r["ok"] and not r["required"]]
    print(json.dumps({
        "ok": not failed,
        "failed": [r["name"] for r in failed],
        "warnings": [r["name"] for r in warned],
        "checks": len(RESULTS),
    }, ensure_ascii=False))
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
