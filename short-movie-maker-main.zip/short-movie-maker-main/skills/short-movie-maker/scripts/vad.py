"""Silero VAD による無音/発話検出 (videopocket-local の vad.silero を移植)。

用途:
  1. 発話区間の検出 → vad.json (字幕開始ガード・無音カットの根拠)
  2. --suggest-keep: 指定範囲内の長い無音を除いた keep 分割案を出す
     (M2 無音カットで Claude が transcript 推測ではなく波形根拠で割れる)

すべてローカル処理 (torch + silero-vad、CPU で十分速い)。

Usage:
  python vad.py --video work/source.mp4 --out work/vad.json
  python vad.py --video work/source.mp4 --suggest-keep "57.0:92.0" --min-silence 0.6
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import tempfile
from typing import List, Tuple

# videopocket-local と同等の既定値
DEFAULT_THRESHOLD = 0.6
DEFAULT_MIN_SPEECH_SEC = 0.25
DEFAULT_MIN_SILENCE_SEC = 0.2
SPEECH_PAD_SEC = 0.15  # keep 提案時に発話の前後へ足す余白


def extract_wav(video: str) -> str:
    """動画から 16kHz mono wav を一時ファイルに抽出する。"""
    fd, path = tempfile.mkstemp(suffix=".wav")
    os.close(fd)
    subprocess.run(
        ["ffmpeg", "-y", "-v", "error", "-i", video,
         "-vn", "-ac", "1", "-ar", "16000", path],
        check=True,
    )
    return path


def detect_speech(video: str, threshold: float, min_speech: float,
                  min_silence: float) -> List[Tuple[float, float]]:
    from silero_vad import get_speech_timestamps, load_silero_vad, read_audio

    wav_path = extract_wav(video)
    try:
        model = load_silero_vad()
        audio = read_audio(wav_path, sampling_rate=16000)
        stamps = get_speech_timestamps(
            audio, model,
            threshold=threshold,
            min_speech_duration_ms=int(min_speech * 1000),
            min_silence_duration_ms=int(min_silence * 1000),
            sampling_rate=16000,
            return_seconds=True,
        )
    finally:
        try:
            os.remove(wav_path)
        except OSError:
            pass
    return [(float(s["start"]), float(s["end"])) for s in stamps]


def suggest_keep(speech: List[Tuple[float, float]], lo: float, hi: float,
                 min_silence: float, pad: float = SPEECH_PAD_SEC) -> List[Tuple[float, float]]:
    """[lo, hi] 内の発話区間を余白つきで結合し、min_silence 以上の無音を落とす。"""
    segs = []
    for s, e in speech:
        s, e = max(s, lo), min(e, hi)
        if e - s <= 0:
            continue
        segs.append((max(lo, s - pad), min(hi, e + pad)))
    if not segs:
        return [(lo, hi)]
    merged = [list(segs[0])]
    for s, e in segs[1:]:
        if s - merged[-1][1] < min_silence:
            merged[-1][1] = max(merged[-1][1], e)
        else:
            merged.append([s, e])
    return [(round(s, 2), round(e, 2)) for s, e in merged]


def main() -> None:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser()
    ap.add_argument("--video", required=True)
    ap.add_argument("--out", default=None, help="vad.json の出力先 (省略時 stdout のみ)")
    ap.add_argument("--threshold", type=float, default=DEFAULT_THRESHOLD)
    ap.add_argument("--min-speech", type=float, default=DEFAULT_MIN_SPEECH_SEC)
    ap.add_argument("--min-silence", type=float, default=DEFAULT_MIN_SILENCE_SEC)
    ap.add_argument("--suggest-keep", default=None,
                    help='"a:b" を渡すとその範囲の無音カット済み keep 案を返す')
    ap.add_argument("--cut-silence", type=float, default=0.6,
                    help="--suggest-keep 時に落とす無音の最小秒数")
    args = ap.parse_args()

    speech = detect_speech(args.video, args.threshold, args.min_speech, args.min_silence)
    result: dict = {"speech": [[round(s, 3), round(e, 3)] for s, e in speech]}

    if args.suggest_keep:
        lo, hi = (float(x) for x in args.suggest_keep.split(":"))
        result["keep"] = suggest_keep(speech, lo, hi, args.cut_silence)

    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False)
        summary = {k: (len(v) if k == "speech" else v) for k, v in result.items()}
        summary["out"] = args.out
        print(json.dumps(summary, ensure_ascii=False))
    else:
        print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
