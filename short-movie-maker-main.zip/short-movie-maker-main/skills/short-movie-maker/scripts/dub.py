#!/usr/bin/env python3
"""ずんだもん吹き替えモード: VOICEVOX でクリップの吹き替え台詞を音声合成する。

clips.json の各クリップに付いた `dub` (Claude が生成した吹き替え台詞) を読み、
VOICEVOX ローカルエンジンで wav を合成して `work/dub/<clip_id>.wav` に書き出す。
各 wav は「そのクリップの keep 連結後ローカル時間軸」の 0 秒から始まる 1 本の
連続音声 (台詞をタイミング順に無音パディングで連結したもの)。render.py はこれを
「原音をダッキングした上にミックスする吹き替えトラック」として重ねる。

エンジン未起動なら自動起動を試み、それでもダメなら分かりやすい案内を出して失敗する。

clips.json の dub スキーマ (クリップ単位、任意):
{
  "dub": {
    "speaker": 7,              # VOICEVOX の style_id。省略時 --default-speaker
                              #   (ずんだもん あまあま=1, ノーマル=3, ツンツン=7, セクシー=5 等)
    "lines": [
      {"start": 0.4, "text": "なんやこれ、AIが仕事奪うてホンマかいな"},
      {"start": 4.2, "text": "ほな、人間は何すんねん…て話やんな", "speed": 1.05}
    ]
  }
}
  - start: keep 連結後ローカル秒 (字幕・emphasis と同じ時間軸)
  - text : 吹き替え台詞 (関西弁等、Claude が生成)
  - speed: 任意。VOICEVOX speedScale (0.8..1.4 目安)。尺に収めたいとき上げる。

出力 (stdout, JSON):
  {"dubs": {"<clip_id>": "work/dub/<clip_id>.wav", ...},
   "engine": "http://127.0.0.1:50021", "speaker_default": 7}

Usage:
  python dub.py --clips work/clips.json --outdir work/dub \
      [--engine http://127.0.0.1:50021] [--default-speaker 7] [--sr 24000]
"""
import argparse
import json
import os
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import wave

DEFAULT_ENGINE = "http://127.0.0.1:50021"
# ずんだもん (話者名 "ずんだもん") の代表的な style_id。
# 世間で「ずんだもんの声」として浸透しているのはノーマル(3)。これをデフォルトにする
# (ユーザー聴き比べで確定)。ツンツン(7)/あまあま(1) はオプション。
DEFAULT_SPEAKER = 3
# VOICEVOX の場所は環境依存。ユーザー名をハードコードせず、環境変数と
# %LOCALAPPDATA% / %PROGRAMFILES% の標準インストール先から解決する。
#   - VOICEVOX_APP / VOICEVOX_ENGINE_RUN 環境変数があれば最優先
#   - 無ければ標準候補を存在チェックして最初に見つかったものを使う
def _voicevox_paths() -> tuple[str, str]:
    app_env = os.environ.get("VOICEVOX_APP")
    eng_env = os.environ.get("VOICEVOX_ENGINE_RUN")
    roots = [
        os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs", "VOICEVOX"),
        os.path.join(os.environ.get("ProgramFiles", ""), "VOICEVOX"),
        os.path.join(os.environ.get("ProgramFiles(x86)", ""), "VOICEVOX"),
    ]
    app = app_env or next(
        (p for r in roots if r for p in [os.path.join(r, "VOICEVOX.exe")]
         if os.path.exists(p)),
        os.path.join(roots[0], "VOICEVOX.exe") if roots[0] else "VOICEVOX.exe")
    eng = eng_env or next(
        (p for r in roots if r for p in [os.path.join(r, "vv-engine", "run.exe")]
         if os.path.exists(p)),
        os.path.join(roots[0], "vv-engine", "run.exe") if roots[0] else "run.exe")
    return app, eng


VOICEVOX_APP, VOICEVOX_ENGINE_RUN = _voicevox_paths()


def engine_alive(engine: str, timeout: float = 2.0) -> bool:
    try:
        with urllib.request.urlopen(engine + "/version", timeout=timeout) as r:
            return r.status == 200
    except Exception:
        return False


def start_engine(engine: str, wait: float = 60.0) -> bool:
    """VOICEVOX エンジンを起動して疎通するまで待つ。成功で True。"""
    exe = None
    if os.path.exists(VOICEVOX_ENGINE_RUN):
        exe = [VOICEVOX_ENGINE_RUN, "--host", "127.0.0.1", "--port", "50021"]
    elif os.path.exists(VOICEVOX_APP):
        # フル GUI 起動 (内部でエンジンが立ち上がる)
        exe = [VOICEVOX_APP]
    if not exe:
        sys.stderr.write(
            "[dub] VOICEVOX が見つかりません。以下を確認してください:\n"
            f"      - エンジン: {VOICEVOX_ENGINE_RUN}\n"
            f"      - アプリ:   {VOICEVOX_APP}\n"
            "      インストール先が違う場合は --engine で起動済みエンジンの\n"
            "      URL を渡すか、VOICEVOX を先に起動してから再実行してください。\n")
        return False
    sys.stderr.write(f"[dub] starting VOICEVOX engine: {exe[0]}\n")
    try:
        creationflags = 0
        if os.name == "nt":
            creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        subprocess.Popen(exe, stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL, creationflags=creationflags)
    except Exception as e:
        sys.stderr.write(f"[dub] failed to launch VOICEVOX: {e}\n")
        return False
    deadline = time.time() + wait
    while time.time() < deadline:
        if engine_alive(engine, timeout=2.0):
            sys.stderr.write("[dub] VOICEVOX engine is up.\n")
            return True
        time.sleep(2.0)
    sys.stderr.write(
        "[dub] VOICEVOX engine did not respond within "
        f"{wait:.0f}s. 手動で VOICEVOX を起動してから再実行してください。\n")
    return False


def _post_json(url: str, payload):
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data,
                                 headers={"Content-Type": "application/json"},
                                 method="POST")
    with urllib.request.urlopen(req, timeout=60) as r:
        return r.read()


def synth_line(engine: str, text: str, speaker: int, speed: float) -> bytes:
    """1 台詞を合成し wav バイト列を返す。"""
    query = json.loads(_audio_query(engine, text, speaker))
    query["speedScale"] = float(speed)
    syn = urllib.parse.urlencode({"speaker": speaker})
    return _post_json(f"{engine}/synthesis?{syn}", query)


def _audio_query(engine: str, text: str, speaker: int) -> bytes:
    q = urllib.parse.urlencode({"text": text, "speaker": speaker})
    req = urllib.request.Request(f"{engine}/audio_query?{q}", data=b"",
                                 method="POST")
    with urllib.request.urlopen(req, timeout=60) as r:
        return r.read()


def read_wav(buf: bytes):
    """wav バイト列を (frames_int16_bytes, sr, nchan, sampwidth) に読む。"""
    import io
    with wave.open(io.BytesIO(buf), "rb") as w:
        sr = w.getframerate()
        nch = w.getnchannels()
        sw = w.getsampwidth()
        frames = w.readframes(w.getnframes())
    return frames, sr, nch, sw


def build_clip_dub(engine, clip, out_path, default_speaker, sr):
    """1 クリップの dub 台詞群を 1 本の wav (0 秒起点) に配置して書き出す。

    各台詞を start 秒の位置に置き、間は無音で埋める。戻り値は台詞数。
    """
    dub = clip.get("dub") or {}
    lines = dub.get("lines") or []
    if not lines:
        return 0, []
    speaker = int(dub.get("speaker", default_speaker))

    total_dur = sum(e - s for s, e in clip["keep"])
    # 16-bit mono バッファ (サンプル数)。末尾に少し余裕。
    n_total = int((total_dur + 2.0) * sr)
    canvas = bytearray(n_total * 2)  # int16 = 2 bytes

    import array
    max_end = 0
    line_times = []
    for ln in lines:
        text = str(ln.get("text", "")).strip()
        if not text:
            continue
        start = max(0.0, float(ln.get("start", 0.0)))
        speed = float(ln.get("speed", 1.0))
        wav_bytes = synth_line(engine, text, speaker, speed)
        frames, wsr, wnch, wsw = read_wav(wav_bytes)
        samples = array.array("h")
        samples.frombytes(frames)
        if wnch == 2:  # downmix to mono
            samples = array.array("h", [
                (samples[i] + samples[i + 1]) // 2
                for i in range(0, len(samples) - 1, 2)])
        # リサンプル (VOICEVOX 既定 24k を出力 sr に合わせる。近傍サンプリング)
        if wsr != sr:
            ratio = sr / wsr
            n_out = int(len(samples) * ratio)
            resampled = array.array("h", [0] * n_out)
            for i in range(n_out):
                src_i = int(i / ratio)
                if src_i < len(samples):
                    resampled[i] = samples[src_i]
            samples = resampled
        # 【重なり防止】前の台詞の終端 + 0.15s より前には置かない。
        # 指定 start が前の台詞に食い込む場合は自動で後ろへずらす
        # (以前は指定位置に重ね書きし、前の台詞が途中で切れて聞こえた)。
        min_gap = int(0.15 * sr)
        off = int(start * sr)
        if off < max_end + min_gap and max_end > 0:
            shifted = (max_end + min_gap) / sr
            sys.stderr.write(
                f"[dub]   WARN: line @{start:.2f}s overlaps previous line "
                f"(ends {max_end / sr:.2f}s) -> shifted to @{shifted:.2f}s\n")
            off = max_end + min_gap
        for i, v in enumerate(samples):
            pos = (off + i) * 2
            if pos + 1 >= len(canvas):
                break
            # 既存 (=無音) に上書き配置
            canvas[pos:pos + 2] = int(v).to_bytes(2, "little", signed=True)
        max_end = max(max_end, off + len(samples))
        line_times.append({"start": round(off / sr, 2),
                           "end": round((off + len(samples)) / sr, 2),
                           "text": text})
        sys.stderr.write(f"[dub]   line @{off / sr:.2f}s ({len(samples)/sr:.2f}s): {text}\n")

    # 実効長で切り詰め (末尾無音を少し残す)
    keep_n = min(len(canvas), (max_end + int(0.3 * sr)) * 2)
    canvas = canvas[:keep_n]

    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with wave.open(out_path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes(bytes(canvas))
    return len(line_times), line_times


def main():
    # Windows コンソール (cp932) でも manifest JSON とログを UTF-8 で安全に出す
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser()
    ap.add_argument("--clips", required=True)
    ap.add_argument("--outdir", default="work/dub")
    ap.add_argument("--engine", default=DEFAULT_ENGINE)
    ap.add_argument("--default-speaker", type=int, default=DEFAULT_SPEAKER)
    ap.add_argument("--sr", type=int, default=24000)
    ap.add_argument("--no-autostart", action="store_true",
                    help="エンジン未起動でも自動起動を試みない")
    args = ap.parse_args()

    with open(args.clips, "r", encoding="utf-8") as f:
        spec = json.load(f)

    if not engine_alive(args.engine):
        sys.stderr.write(f"[dub] VOICEVOX engine not reachable at {args.engine}\n")
        if args.no_autostart or not start_engine(args.engine):
            raise SystemExit(
                "VOICEVOX エンジンに接続できません。VOICEVOX を起動してから "
                "再実行してください (既定 URL: " + args.engine + ")。")

    dubs = {}
    all_line_times = {}
    for clip in spec.get("clips", []):
        cid = clip.get("id", "clip")
        if not (clip.get("dub") or {}).get("lines"):
            continue
        out_path = os.path.join(args.outdir, f"{cid}.wav")
        n, line_times = build_clip_dub(args.engine, clip, out_path,
                           args.default_speaker, args.sr)
        if n > 0:
            dubs[cid] = out_path.replace("\\", "/")
            all_line_times[cid] = line_times
            sys.stderr.write(f"[dub] wrote {out_path} ({n} lines)\n")

    # line_times = 各台詞の実効タイミング (重なり自動シフト後)。
    # 字幕をこれに合わせて調整できるよう manifest に含める。
    print(json.dumps({
        "dubs": dubs,
        "line_times": all_line_times,
        "engine": args.engine,
        "speaker_default": args.default_speaker,
    }, ensure_ascii=False))


if __name__ == "__main__":
    main()
