#!/usr/bin/env python3
"""faster-whisper で動画を word-level timestamps 付きで文字起こしする。

日本語素材 (既定) でも英語等の外国語素材でも扱える。`--language ja` で
日本語固定、`--language en` で英語固定、`--language auto` で Whisper の
自動言語判定にまかせる (v2: 外国語素材の翻訳字幕/吹き替えモード用)。

出力 transcript.json 構造:
{
  "language": "ja",          # 実際に検出/指定された言語
  "duration": 123.4,
  "segments": [
    {"id": 0, "start": 0.0, "end": 3.2, "text": "...",
     "words": [{"start":0.0,"end":0.4,"word":"..."}, ...]},
    ...
  ]
}

Usage:
  python transcribe.py --video <mp4> --out transcript.json \
      [--model large-v3] [--device auto] [--language ja|en|auto|...]
"""
import argparse
import json
import os
import sys


def pick_device(pref: str):
    if pref != "auto":
        return pref, ("float16" if pref == "cuda" else "int8")
    try:
        import torch  # noqa
        if torch.cuda.is_available():
            return "cuda", "float16"
    except Exception:
        pass
    return "cpu", "int8"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--video", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--model", default="large-v3")
    ap.add_argument("--device", default="auto", choices=["auto", "cpu", "cuda"])
    ap.add_argument("--language", default="ja",
                    help="文字起こし言語。'ja'(既定)/'en'/その他 ISO コード、"
                         "または 'auto' で自動判定 (外国語素材向け)")
    args = ap.parse_args()

    if not os.path.exists(args.video):
        raise SystemExit(f"video not found: {args.video}")

    from faster_whisper import WhisperModel

    device, compute = pick_device(args.device)
    lang = None if args.language.lower() in ("auto", "") else args.language
    sys.stderr.write(
        f"[transcribe] model={args.model} device={device} compute={compute} "
        f"language={lang or 'auto'}\n")
    model = WhisperModel(args.model, device=device, compute_type=compute)

    segments_gen, info = model.transcribe(
        args.video,
        language=lang,
        word_timestamps=True,
        vad_filter=True,
        vad_parameters={"min_silence_duration_ms": 500},
        beam_size=5,
    )
    if lang is None:
        sys.stderr.write(
            f"[transcribe] detected language={info.language} "
            f"(p={getattr(info, 'language_probability', 0):.2f})\n")

    segments = []
    for seg in segments_gen:
        words = []
        if seg.words:
            for w in seg.words:
                words.append({
                    "start": round(w.start, 3),
                    "end": round(w.end, 3),
                    "word": w.word,
                })
        segments.append({
            "id": seg.id,
            "start": round(seg.start, 3),
            "end": round(seg.end, 3),
            "text": seg.text.strip(),
            "words": words,
        })
        sys.stderr.write(f"[{seg.start:7.2f}-{seg.end:7.2f}] {seg.text.strip()}\n")

    out = {
        "language": info.language,
        "duration": round(info.duration, 3),
        "segments": segments,
    }
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    sys.stderr.write(f"[transcribe] wrote {args.out} ({len(segments)} segments)\n")


if __name__ == "__main__":
    main()
