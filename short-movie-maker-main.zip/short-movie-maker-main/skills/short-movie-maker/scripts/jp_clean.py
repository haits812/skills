"""文字起こしテキストの整理 (videopocket-local / day01 video-editing のロジックを移植)。

- whisper transcript (word timestamps) → 文字単位タイムライン
- SudachiPy の品詞情報つきフィラー除去 + confidence 段階制
  (「その」「あの」は連体詞なら保護 / 低確度語「ちょっと」「やっぱ」等は削除しない)
- 表記揺れ正規化 (有難う→ありがとう 等) + 固有名詞の正式表記 (YouTube 等)
- 漢数字→算用数字 (助数詞後続時のみ。「三十八度→38度」「十六万人→16万人」)
- corrections (STT 誤認識の置換テーブル、glossary/ユーザー指定から注入)

すべてローカル処理 (ElevenLabs/Gemini 不使用)。
"""

from __future__ import annotations

import re
from typing import Dict, List, Tuple

from sudachipy import dictionary as sudachi_dictionary
from sudachipy import tokenizer as sudachi_tokenizer

try:
    from kanjize import kanji2number as _kanji2number
    _HAS_KANJIZE = True
except ImportError:
    _HAS_KANJIZE = False

_TOKENIZER = sudachi_dictionary.Dictionary().create()
_SPLIT_MODE = sudachi_tokenizer.Tokenizer.SplitMode.C

# フィラー表 (day01 video-editing の 28 パターンを confidence 付きで移植し、
# videopocket の品詞チェック方式と統合)。判定規則:
#   conf >= 0.8       : 品詞ガード (連体詞保護) を通れば削除
#   0.5 <= conf < 0.8 : Sudachi が感動詞と判定したときだけ削除
#   conf < 0.5        : 削除しない (「ちょっと」「やっぱ」「はい」等は意味を持ちうる)
FILLER_TABLE: Dict[str, float] = {
    # hesitation (高確度)
    "えー": 0.9, "えぇ": 0.9, "えーと": 0.95, "えーっと": 0.95, "えっと": 0.95,
    "ええと": 0.95, "あー": 0.85, "あのー": 0.9, "そのー": 0.85, "まー": 0.8,
    "うーん": 0.9,
    # hedging (中確度 — 感動詞のときだけ)
    "あの": 0.7, "まあ": 0.7, "まぁ": 0.7, "なんか": 0.65, "なんかぁ": 0.65,
    "うん": 0.6, "そうそう": 0.6, "そうそうそう": 0.75, "はいはい": 0.7,
    "その": 0.5,
    # 低確度 (削除しない見張り台。閾値未満なので実質保護リスト)
    "ちょっと": 0.4, "やっぱ": 0.45, "こう": 0.45, "ね": 0.4, "ねー": 0.45,
    "はい": 0.3,
}
FILLER_REMOVE_CONF = 0.8       # これ以上は品詞ガードのみで削除
FILLER_POS_CONF = 0.5          # これ以上かつ感動詞なら削除

# 長音バリエーションの正規表現 (「えーーっと」「あーー」等)
FILLER_REGEXES = [
    re.compile(r"^[えエ][ーェ]+[とト]?$"),
    re.compile(r"^[あア][ーァ]+$"),
    re.compile(r"^[うウ][ーゥ]+[んン]?$"),
    re.compile(r"^[そソ][のノ][ーォ]+$"),
    re.compile(r"^[まマ][ーァ]+$"),
]

# 連体詞の可能性がある語 (品詞チェック必須)
REQUIRES_POS_CHECK = {"その", "そのー", "あの", "あのー"}

# 表記揺れ正規化テーブル
HOMOPHONE_TABLE: Dict[str, str] = {
    "有難う": "ありがとう",
    "有り難う": "ありがとう",
    "宜しくお願いします": "よろしくお願いします",
    "御願いします": "お願いします",
    "出来る": "できる",
    "致します": "いたします",
}

# 固有名詞の正式表記 (day01 video-editing から移植)
PROPER_NOUN_MAP: Dict[str, str] = {
    "YOUTUBE": "YouTube", "Youtube": "YouTube", "youtube": "YouTube",
    "INSTAGRAM": "Instagram", "instagram": "Instagram",
    "TIKTOK": "TikTok", "Tiktok": "TikTok", "tiktok": "TikTok",
}

# 文字タイムライン: (ch, start_sec, end_sec, seg_end, speaker) のタプル列。
# seg_end=True はその文字が whisper segment (発話単位) の末尾。
# speaker は diarize.py が付けた話者ラベル (A/B/... or None)
CharTL = List[Tuple[str, float, float, bool, object]]


def build_char_timeline(transcript: dict, src_range: Tuple[float, float] | None = None) -> CharTL:
    """whisper transcript の words を文字単位タイムラインに展開する。

    faster-whisper の日本語 word は実質 1〜3 文字粒度なので、word 区間を
    文字数で等分すればほぼ無損失で文字タイムスタンプになる。
    src_range を渡すと元動画のその時間範囲の文字だけを返す。
    """
    chars: CharTL = []
    lo, hi = src_range if src_range else (float("-inf"), float("inf"))
    for seg in transcript.get("segments", []):
        words = seg.get("words") or []
        if not words:
            # word が無い segment は segment 全体を等分
            words = [{"start": seg["start"], "end": seg["end"], "word": seg.get("text", "")}]
        seg_spk = seg.get("speaker")
        seg_added = 0
        for w in words:
            text = str(w.get("word", "")).strip()
            if not text:
                continue
            ws, we = float(w["start"]), float(w["end"])
            # 境界ちょうどに接する単語は含めない (keep 端 = 次 segment 開始のとき混入する)
            if we <= lo or ws >= hi - 1e-3:
                continue
            spk = w.get("speaker") or seg_spk
            dur = max(we - ws, 1e-3)
            n = len(text)
            for i, ch in enumerate(text):
                cs = ws + dur * i / n
                ce = ws + dur * (i + 1) / n
                chars.append((ch, cs, ce, False, spk))
                seg_added += 1
        if seg_added:
            ch, cs, ce, _, spk = chars[-1]
            chars[-1] = (ch, cs, ce, True, spk)  # segment 末尾フラグ
    return chars


def _should_remove_filler(surface: str, pos: str) -> bool:
    """videopocket-local の品詞優先判定をそのまま移植。"""
    if not surface:
        return False
    normalized = surface.strip().lower()
    base_form = normalized.rstrip("ー〜~")

    def _conf() -> float:
        c = max(FILLER_TABLE.get(normalized, 0.0), FILLER_TABLE.get(base_form, 0.0))
        if c == 0.0 and any(r.match(normalized) for r in FILLER_REGEXES):
            c = 0.85  # 長音バリエーション (えーーっと 等)
        return c

    conf = _conf()
    if pos:
        if "感動詞" in pos and "フィラー" in pos:
            return True
        if pos.startswith("連体詞"):
            return False
        if pos.startswith("感動詞"):
            return conf >= FILLER_POS_CONF
    if normalized in REQUIRES_POS_CHECK or base_form in REQUIRES_POS_CHECK:
        return False
    # 品詞情報が無い/決め手にならない場合は高確度語のみ削除
    return conf >= FILLER_REMOVE_CONF


def remove_fillers(chars: CharTL) -> CharTL:
    """Sudachi 形態素の品詞情報でフィラー文字を除去する。

    【deletion_spans 相当 (videopocket から移植)】削除したフィラーも「音声としては
    鳴っている」ので、直後に残る文字の開始時刻をフィラー開始まで前倒しする。
    これで「えーっと、今日は…」の字幕が「えーっと」の発話開始と同時に出て、
    喋っているのに字幕が無い空白ができない。前倒しは近接時 (2 秒未満) のみ。
    """
    if not chars:
        return chars
    text = "".join(c[0] for c in chars)
    drop = [False] * len(chars)
    for m in _TOKENIZER.tokenize(text, _SPLIT_MODE):
        pos = ",".join(m.part_of_speech())
        if _should_remove_filler(m.surface(), pos):
            for i in range(m.begin(), min(m.end(), len(chars))):
                drop[i] = True

    result: CharTL = []
    pending_start: float | None = None
    for c, d in zip(chars, drop):
        if d:
            if pending_start is None:
                pending_start = c[1]
            continue
        if pending_start is not None:
            if c[1] - pending_start < 2.0:
                c = (c[0], pending_start, c[2], c[3], c[4])
            pending_start = None
        result.append(c)
    return result


def _replace_span(chars: CharTL, idx: int, src_len: int, dst: str) -> CharTL:
    """chars[idx:idx+src_len] を dst に置換。時間は元スパンを等分して引き継ぐ。"""
    span = chars[idx: idx + src_len]
    t0, t1 = span[0][1], span[-1][2]
    dur = max(t1 - t0, 1e-3)
    n = max(len(dst), 1)
    seg_end = span[-1][3]
    spk = span[-1][4]
    repl: CharTL = [
        (ch, t0 + dur * i / n, t0 + dur * (i + 1) / n,
         seg_end and i == n - 1, spk)
        for i, ch in enumerate(dst)
    ]
    return chars[:idx] + repl + chars[idx + src_len:]


def apply_table(chars: CharTL, table: Dict[str, str]) -> CharTL:
    """置換テーブルを文字タイムラインへ適用する (時間・話者を維持)。"""
    if not chars or not table:
        return chars
    text = "".join(c[0] for c in chars)
    for src, dst in table.items():
        if not src or src == dst:
            continue
        idx = text.find(src)
        while idx >= 0:
            chars = _replace_span(chars, idx, len(src), dst)
            text = "".join(c[0] for c in chars)
            idx = text.find(src, idx + max(len(dst), 1))
    return chars


def fix_homophones(chars: CharTL) -> CharTL:
    """表記揺れ + 固有名詞の正式表記をテーブル置換する。"""
    return apply_table(apply_table(chars, HOMOPHONE_TABLE), PROPER_NOUN_MAP)


# ── 漢数字→算用数字 (day01 video-editing から移植) ──────────────────

_KANJI_NUM_CHARS = "〇零一二三四五六七八九十百千万億兆"
_COUNTER_SUFFIXES = (
    "円|個|本|人|回|件|枚|台|匹|頭|冊|杯|"
    "度|時|分|秒|時間|日|週間|ヶ月|か月|カ月|年|"
    "パーセント|%|倍|"
    "フォロワー|名|社|店|"
    "ぐらい|くらい|以上|以下|以内|未満"
)
_KANJI_NUM_PATTERN = re.compile(rf"([{_KANJI_NUM_CHARS}]+)({_COUNTER_SUFFIXES})")


def _format_number(num: int) -> str:
    """万/億/兆は漢字で残す読みやすい表記 (10000 でなく 1万)。"""
    if num >= 1_0000_0000:
        oku, rem = divmod(num, 1_0000_0000)
        man = rem // 1_0000
        return f"{oku}億{man}万" if man else f"{oku}億"
    if num >= 1_0000:
        man, rem = divmod(num, 1_0000)
        return f"{man}万{rem}" if rem else f"{man}万"
    return str(num)


def normalize_kanji_numbers(chars: CharTL) -> CharTL:
    """漢数字+助数詞を算用数字に変換 (「三個→3個」「十六万人→16万人」)。

    助数詞が後続するときだけ変換するので「一般」「三角」は誤変換しない。
    kanjize 未導入ならそのまま返す。
    """
    if not chars or not _HAS_KANJIZE:
        return chars
    while True:
        text = "".join(c[0] for c in chars)
        m = _KANJI_NUM_PATTERN.search(text)
        if not m:
            return chars
        try:
            num = _kanji2number(m.group(1))
        except (ValueError, KeyError):
            return chars  # パース不能な並びで無限ループしないよう打ち切り
        dst = _format_number(num) + m.group(2)
        if dst == m.group(0):
            return chars
        chars = _replace_span(chars, m.start(), len(m.group(0)), dst)


def clean_chars(chars: CharTL, corrections: Dict[str, str] | None = None) -> CharTL:
    """標準パイプライン: フィラー除去 → corrections (誤認識補正) →
    表記揺れ・固有名詞正規化 → 漢数字→算用数字。"""
    chars = remove_fillers(chars)
    if corrections:
        chars = apply_table(chars, corrections)
    chars = fix_homophones(chars)
    return normalize_kanji_numbers(chars)
