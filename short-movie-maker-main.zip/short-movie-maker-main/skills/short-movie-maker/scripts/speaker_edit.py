"""話者ラベルの人手確認・修正 (M9 レビューモード用)。

pyannote の話者分離は完璧ではないので、「話者付き文字起こしを一旦ユーザーに
渡し、間違っている行だけ直してもらい、それを transcript に書き戻す」ための
export / apply の 2 コマンドを提供する。

export: transcript.json → 人が読める speakers_review.txt
    #012 [A] 58.4-59.6 じゃあ3個食べる?
    行頭の [A] を [B] 等に書き換えるだけでよい (他は触らない)。

apply: 編集済み speakers_review.txt → transcript.json の speaker を上書き
    (segment とその中の words 全部に反映)

Usage:
  python speaker_edit.py export --transcript work/transcript.json --out work/speakers_review.txt
  python speaker_edit.py apply  --transcript work/transcript.json --review work/speakers_review.txt
"""

from __future__ import annotations

import argparse
import json
import re
import sys

REVIEW_LINE = re.compile(r"^#(\d+)\s+\[([A-Za-z0-9_]+)\]")


def export(transcript_path: str, out_path: str) -> None:
    with open(transcript_path, "r", encoding="utf-8") as f:
        transcript = json.load(f)
    lines = [
        "# 話者レビュー: 行頭の [A]/[B] だけ書き換えてください (時間・本文は変更不可)",
        "# 話者を増やす場合は [C] [D] など新しいラベルを使ってかまいません",
        "",
    ]
    for i, seg in enumerate(transcript.get("segments", [])):
        spk = seg.get("speaker") or "?"
        lines.append(f"#{i:03d} [{spk}] {seg['start']:.1f}-{seg['end']:.1f} {seg.get('text', '').strip()}")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    print(json.dumps({"exported": out_path,
                      "segments": len(transcript.get("segments", []))}, ensure_ascii=False))


def apply(transcript_path: str, review_path: str) -> None:
    with open(transcript_path, "r", encoding="utf-8") as f:
        transcript = json.load(f)
    segments = transcript.get("segments", [])

    changed = 0
    with open(review_path, "r", encoding="utf-8") as f:
        for raw in f:
            m = REVIEW_LINE.match(raw.strip())
            if not m:
                continue
            idx, spk = int(m.group(1)), m.group(2)
            if idx >= len(segments):
                continue
            seg = segments[idx]
            if seg.get("speaker") != spk:
                changed += 1
            seg["speaker"] = spk
            for w in seg.get("words") or []:
                w["speaker"] = spk

    speakers = sorted({s.get("speaker") for s in segments if s.get("speaker")})
    transcript["speakers"] = speakers
    with open(transcript_path, "w", encoding="utf-8") as f:
        json.dump(transcript, f, ensure_ascii=False, indent=2)
    print(json.dumps({"applied": review_path, "changed_segments": changed,
                      "speakers": speakers}, ensure_ascii=False))


def main() -> None:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser()
    ap.add_argument("mode", choices=["export", "apply"])
    ap.add_argument("--transcript", required=True)
    ap.add_argument("--out", default="work/speakers_review.txt")
    ap.add_argument("--review", default="work/speakers_review.txt")
    args = ap.parse_args()
    if args.mode == "export":
        export(args.transcript, args.out)
    else:
        apply(args.transcript, args.review)


if __name__ == "__main__":
    main()
