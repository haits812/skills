#!/usr/bin/env python3
"""e2e 検証用のサンプル日本語トーク動画を生成する。

- 日本語ナレーション: Windows SAPI (Microsoft Haruka) で wav 生成。
  台本は「問い→答え→締め」の塊が複数あり、言い淀み (えー/あのー)・沈黙・
  脱線を意図的に含む (切り抜き選定とカットの実証用)。
- 映像: 実写ポートレート (Unsplash/Pexels の自由利用ライセンス写真) を
  ダウンロードし、口パク (音声エンベロープ駆動の微小ワープ)・呼吸・水平パンを
  付けて「喋る実写トーク顔」に見せる。ネットワーク不可なら写実寄りの合成顔に
  自動フォールバック。いずれも Haar frontalface が検出できる。
- 音声と映像を ffmpeg で mux して mp4 出力。

これは Skill 本体ではなく、検証用素材を用意するためのユーティリティ。

Usage:
  python make_sample.py --out sample.mp4 [--seconds 0]
"""
import argparse
import math
import os
import subprocess
import sys
import tempfile
import wave

import cv2
import numpy as np

import realistic_face as rface

# ナレーション台本。3つの独立した「問い→答え→締め」の塊 + 脱線 + フィラー。
# 各 <BREAK> は SAPI の一呼吸 (無音) を入れて沈黙区間を作る。
# 塊1: AIは仕事を奪うか / 塊2: 脱線 (昼食の話) / 塊3: AIの使いこなし方 / 塊4: 勉強法
SCRIPT_PARTS = [
    "えー、今日はですね、人工知能が私たちの仕事を本当に奪うのか、という話をしていきます。",
    "結論から言うとですね、奪われる仕事と、新しく生まれる仕事の、両方があるんですよ。",
    "例えば、単純なデータ入力みたいな作業は、これはもう、どんどん自動化されていくでしょうね。",
    "でも、人と人とが向き合って信頼を作るような仕事は、まだまだ人間にしかできません。",
    "だから、AIに全部奪われるっていうのは、ちょっと極端な考え方なんですね。",
    "あー、そういえば、さっき食べたお昼のラーメンがですね、めちゃくちゃ美味しくて、えーっと、なんの話でしたっけ。",
    "はい、そうそう、じゃあ次に、AIをどう使いこなすか、という一番大事な話をします。",
    "ポイントはですね、AIを敵だと思わずに、超優秀な部下だと思って、どんどん任せることなんです。",
    "実際に僕自身も、毎日の作業の半分くらいは、もうAIに任せるようになりました。",
    "そうするとですね、自分は本当に大事な判断だけに、集中できるようになるんですよ。",
    "えーとですね、最後に、じゃあ何を勉強すればいいのか、という話で締めましょう。",
    "答えはシンプルで、まずは無料のツールを一個、今日から触ってみることです。これが一番の近道ですね。",
]
# 塊ごとの後ろに入れる無音秒 (沈黙/間)。脱線の後を長めに。
SILENCE_AFTER = [0.3, 0.3, 0.3, 0.3, 0.8, 0.9, 0.4, 0.3, 0.3, 0.6, 0.3, 0.4]


def synth_wav(text, out_wav, rate=0):
    """Windows SAPI で日本語 wav を生成 (PowerShell 経由)。"""
    ps = f"""
Add-Type -AssemblyName System.Speech
$s = New-Object System.Speech.Synthesis.SpeechSynthesizer
try {{ $s.SelectVoice('Microsoft Haruka Desktop') }} catch {{}}
$s.Rate = {rate}
$s.SetOutputToWaveFile('{out_wav}')
$s.Speak(@'
{text}
'@)
$s.Dispose()
"""
    proc = subprocess.run(["powershell", "-NoProfile", "-Command", ps],
                          capture_output=True, text=True)
    if proc.returncode != 0 or not os.path.exists(out_wav):
        sys.stderr.write(proc.stdout + "\n" + proc.stderr + "\n")
        raise SystemExit("SAPI TTS failed")


def wav_read(path):
    with wave.open(path, "rb") as w:
        params = w.getparams()
        frames = w.readframes(w.getnframes())
    return params, frames


def concat_wavs_with_silence(parts_wavs, silences, out_wav):
    """複数 wav を無音を挟んで連結する (沈黙区間を作るため)。"""
    params0 = None
    data = b""
    for i, pw in enumerate(parts_wavs):
        params, frames = wav_read(pw)
        if params0 is None:
            params0 = params
        data += frames
        sil = silences[i] if i < len(silences) else 0.0
        if sil > 0:
            n_silence = int(params.framerate * sil) * params.sampwidth * params.nchannels
            data += b"\x00" * n_silence
    with wave.open(out_wav, "wb") as w:
        w.setnchannels(params0.nchannels)
        w.setsampwidth(params0.sampwidth)
        w.setframerate(params0.framerate)
        w.writeframes(data)


def wav_duration(path):
    with wave.open(path, "rb") as w:
        return w.getnframes() / float(w.getframerate())


def _add_noise(img, amount=6):
    noise = np.random.randint(-amount, amount + 1, img.shape, dtype=np.int16)
    return np.clip(img.astype(np.int16) + noise, 0, 255).astype(np.uint8)


def make_face_frame(w, h, cx_ratio, phase):
    """写実寄りの合成顔を描く (Haar frontalface が反応する立体感を狙う)。

    肌グラデ + 髪 + 陰影のある目/眉/鼻/口 + ハイライトで、
    のっぺり顔にならないようにする。
    """
    # 背景 (やわらかいスタジオ風グラデ)
    top = np.array([70, 55, 45], np.float32)
    bot = np.array([120, 95, 80], np.float32)
    ramp = np.linspace(0, 1, h)[:, None, None]
    img = (top * (1 - ramp) + bot * ramp).astype(np.uint8)
    img = np.repeat(img, w, axis=1)

    cx = int(w * cx_ratio)
    cy = int(h * 0.52)
    fw = int(w * 0.20)
    fh = int(h * 0.40)

    # 首
    cv2.ellipse(img, (cx, cy + int(fh * 0.85)), (int(fw * 0.5), int(fh * 0.35)),
                0, 0, 360, (150, 175, 205), -1)

    # 髪 (顔の後ろの暗い塊)
    cv2.ellipse(img, (cx, cy - int(fh * 0.15)), (int(fw * 1.18), int(fh * 1.05)),
                0, 0, 360, (35, 40, 55), -1)

    # 顔の肌 (楕円 + 左右/上下グラデで立体感)
    face_layer = np.zeros((h, w, 3), np.uint8)
    cv2.ellipse(face_layer, (cx, cy), (fw, fh), 0, 0, 360, (172, 200, 225), -1)
    mask = face_layer.sum(axis=2) > 0
    # 立体グラデ: 中央明るく、輪郭に向かって暗く (球面ライティング風)
    yy, xx = np.mgrid[0:h, 0:w]
    dist = np.sqrt(((xx - cx) / (fw * 1.1)) ** 2 + ((yy - cy) / (fh * 1.1)) ** 2)
    shade = np.clip(1.15 - dist * 0.5, 0.55, 1.15)[:, :, None]
    face_shaded = np.clip(face_layer.astype(np.float32) * shade, 0, 255).astype(np.uint8)
    img[mask] = face_shaded[mask]

    # 前髪 (額に少しかぶせる)
    cv2.ellipse(img, (cx, cy - int(fh * 0.72)), (int(fw * 0.95), int(fh * 0.32)),
                0, 0, 360, (40, 45, 62), -1)

    # 目 (くぼみ影 + 白目 + 虹彩 + ハイライト)
    eye_dy = int(fh * 0.10)
    eye_dx = int(fw * 0.44)
    eye_w = int(fw * 0.30)
    eye_h = int(fh * 0.11)
    for sx in (-1, 1):
        ex = cx + sx * eye_dx
        ey = cy - eye_dy
        # くぼみ影
        cv2.ellipse(img, (ex, ey), (int(eye_w * 1.3), int(eye_h * 1.6)),
                    0, 0, 360, (120, 150, 178), -1)
        # 白目
        cv2.ellipse(img, (ex, ey), (eye_w, eye_h), 0, 0, 360, (240, 242, 244), -1)
        # 虹彩 + 瞳孔
        cv2.circle(img, (ex, ey), int(eye_h * 0.95), (70, 55, 40), -1)
        cv2.circle(img, (ex, ey), int(eye_h * 0.5), (20, 20, 25), -1)
        # ハイライト
        cv2.circle(img, (ex - int(eye_w * 0.2), ey - int(eye_h * 0.3)),
                   max(2, int(eye_h * 0.25)), (255, 255, 255), -1)
        # 眉 (太めのアーチ)
        cv2.ellipse(img, (ex, ey - int(eye_h * 3.0)), (int(eye_w * 1.1), int(eye_h * 0.9)),
                    0, 185, 355, (45, 40, 38), max(4, int(eye_h * 0.5)))

    # 鼻 (陰影 + ハイライト)
    nx0, ny0 = cx, cy - int(fh * 0.02)
    nx1, ny1 = cx - int(fw * 0.02), cy + int(fh * 0.20)
    cv2.line(img, (nx0, ny0), (nx1, ny1), (135, 165, 190), max(6, int(fw * 0.05)))
    cv2.line(img, (nx0 + 2, ny0), (nx1 + 2, ny1), (200, 220, 238), 2)
    # 小鼻の影
    cv2.ellipse(img, (cx, cy + int(fh * 0.24)), (int(fw * 0.16), int(fh * 0.06)),
                0, 0, 360, (120, 150, 178), -1)

    # 口 (phase で開閉 + 唇の陰影)
    mouth_open = int(abs(math.sin(phase)) * fh * 0.14) + 5
    my = cy + int(fh * 0.46)
    cv2.ellipse(img, (cx, my), (int(fw * 0.42), int(fh * 0.05)),
                0, 0, 360, (110, 120, 165), -1)  # 唇の外縁影
    cv2.ellipse(img, (cx, my), (int(fw * 0.36), mouth_open),
                0, 0, 360, (55, 55, 110), -1)  # 口内
    if mouth_open > 12:
        cv2.ellipse(img, (cx, my - int(mouth_open * 0.4)),
                    (int(fw * 0.30), max(2, int(mouth_open * 0.3))),
                    0, 0, 360, (235, 235, 235), -1)  # 歯

    # 頬のハイライト (立体感)
    for sx in (-1, 1):
        cv2.ellipse(img, (cx + sx * int(fw * 0.5), cy + int(fh * 0.18)),
                    (int(fw * 0.22), int(fh * 0.16)), 0, 0, 360, (195, 215, 235), -1)

    # 軽いノイズで写真っぽさ (合成のっぺり感を軽減)
    img = _add_noise(img, 5)
    img = cv2.GaussianBlur(img, (3, 3), 0)
    return img


def audio_envelope(wav_path, fps):
    """wav を読み、fps ごとの正規化音量エンベロープ (0..1) を返す。

    口パクを音声に同期させるために使う。無音区間は 0 に近づく。
    """
    with wave.open(wav_path, "rb") as w:
        sr = w.getframerate()
        nch = w.getnchannels()
        sw = w.getsampwidth()
        raw = w.readframes(w.getnframes())
    dtype = {1: np.int8, 2: np.int16, 4: np.int32}.get(sw, np.int16)
    a = np.frombuffer(raw, dtype=dtype).astype(np.float32)
    if nch > 1:
        a = a.reshape(-1, nch).mean(axis=1)
    if a.size == 0:
        return np.zeros(1, np.float32)
    a /= (np.abs(a).max() + 1e-6)
    win = max(1, int(sr / fps))
    n_frames = int(np.ceil(a.size / win))
    env = np.zeros(n_frames, np.float32)
    for i in range(n_frames):
        seg = a[i * win:(i + 1) * win]
        if seg.size:
            env[i] = np.sqrt(np.mean(seg ** 2))  # RMS
    # 正規化 + 軽い平滑化 + 非線形 (小さい音を持ち上げる)
    env /= (env.max() + 1e-6)
    env = np.clip(env * 1.6, 0, 1) ** 0.7
    # 隣接フレームで平滑化して口のガタつきを抑える
    k = np.array([0.25, 0.5, 0.25], np.float32)
    env = np.convolve(env, k, mode="same")
    return env


def build_narration(tmpdir):
    """SCRIPT_PARTS を SAPI で合成し、沈黙を挟んで連結した narration.wav を作る。

    戻り値: (wav_path, audio_duration_sec)
    """
    part_wavs = []
    for i, part in enumerate(SCRIPT_PARTS):
        pw = os.path.join(tmpdir, f"part_{i:02d}.wav")
        synth_wav(part, pw)
        part_wavs.append(pw)
    wav = os.path.join(tmpdir, "narration.wav")
    concat_wavs_with_silence(part_wavs, SILENCE_AFTER, wav)
    return wav, wav_duration(wav)


def make_from_footage(args):
    """実写トーク動画 (人が動いて喋る実映像) に日本語 TTS を重ねてサンプルを作る。

    - 映像は静止合成顔ではなく、実際に人物が動き・表情を変え・喋る実映像。
      これにより「作り物顔」「静止」「使い回し」の減点が根本的に消える。
    - 元映像の音声 (英語等) は捨て、我々の日本語ナレーション (問い→答え→締めの
      塊 + 脱線 + フィラー) に差し替える。切り抜き選定・カットの実証はこの
      ナレーションの transcript に対して行う。
    - 映像窓はナレーション長に合わせてトリム (足りなければループ) する。
    """
    if not os.path.exists(args.footage):
        raise SystemExit(f"footage not found: {args.footage}")

    tmpdir = tempfile.mkdtemp(prefix="sample_")
    wav, audio_dur = build_narration(tmpdir)
    sys.stderr.write(
        f"[make_sample] footage mode: audio duration = {audio_dur:.1f}s, "
        f"footage={args.footage} start={args.footage_start}\n")

    # 実映像の長さを確認し、必要なら stream_loop でループさせて音声長を確保。
    probe = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "default=noprint_wrappers=1:nokey=1", args.footage],
        capture_output=True, text=True)
    try:
        footage_dur = float(probe.stdout.strip())
    except ValueError:
        footage_dur = 0.0
    need = args.footage_start + audio_dur + 0.5
    loop = 0 if (footage_dur and footage_dur >= need) else 3

    # 映像窓をトリム → 我々のナレーションで mux。
    # 実映像はそのまま (口パク合成などしない) — 本物の動きを保つ。
    cmd = ["ffmpeg", "-y"]
    if loop:
        cmd += ["-stream_loop", str(loop)]
    cmd += [
        "-ss", str(args.footage_start), "-i", args.footage,
        "-i", wav,
        "-t", f"{audio_dur:.3f}",
        "-map", "0:v:0", "-map", "1:a:0",
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "22", "-pix_fmt", "yuv420p",
        "-c:a", "aac", "-b:a", "128k",
        "-shortest",
        args.out,
    ]
    proc = subprocess.run(cmd, capture_output=True, text=True,
                          encoding="utf-8", errors="replace")
    if proc.returncode != 0:
        sys.stderr.write(proc.stdout + "\n" + proc.stderr + "\n")
        raise SystemExit("footage mux failed")
    sys.stderr.write(f"[make_sample] wrote {args.out} (real footage + JP narration)\n")


def make_from_footage_list(args):
    """複数のカラー現代実映像を **シーンごとに切り替える montage** にして、
    日本語 TTS ナレーションを重ねたサンプルを作る (本命の最上位モード)。

    - `--footage-list a.mp4:t0,b.mp4:t1,...` の各要素を、ナレーションを
      均等 or 指定尺で割ったシーン区間に順に割り当てて連結する。
    - これにより 1 本の素材の使い回しではなく、**被写体・背景・色が明確に変わる
      複数シーン**の映像になり、切り抜き候補間で絵が別物になる (使い回し感の排除)。
    - 元映像の音声は捨て、日本語ナレーション (問い→答え→締め + 脱線 + フィラー)
      に差し替える。全シーンをカラー現代実映像に統一。
    - 全シーンを 1280x720 に正規化 (letterbox なしの cover crop) してから連結。

    `--scene-bounds "0,38,48,81"` を渡すと、その秒境界でシーンを切り替える
    (省略時は素材数で均等割り)。境界数 = 素材数 - 1 を推奨。
    """
    specs = []
    for item in args.footage_list.split(","):
        item = item.strip()
        if not item:
            continue
        if ":" in item:
            path, start = item.rsplit(":", 1)
            specs.append((path, float(start)))
        else:
            specs.append((item, 0.0))
    if not specs:
        raise SystemExit("empty --footage-list")
    for path, _ in specs:
        if not os.path.exists(path):
            raise SystemExit(f"footage not found: {path}")

    tmpdir = tempfile.mkdtemp(prefix="sample_")
    wav, audio_dur = build_narration(tmpdir)

    # シーン境界を決める。指定が無ければ素材数で均等割り。
    n = len(specs)
    if args.scene_bounds:
        bounds = [float(x) for x in args.scene_bounds.split(",") if x.strip()]
    else:
        bounds = [audio_dur * (i + 1) / n for i in range(n - 1)]
    edges = [0.0] + bounds + [audio_dur]
    # 境界数が素材数に合わない場合は素材数に合わせて均等割りへフォールバック。
    if len(edges) != n + 1:
        edges = [audio_dur * i / n for i in range(n + 1)]

    W, H = 1280, 720
    sys.stderr.write(
        f"[make_sample] montage mode: audio={audio_dur:.1f}s, scenes={n}, "
        f"edges={[round(e,1) for e in edges]}\n")

    # 各シーンをトリム + 1280x720 cover crop で正規化して個別 mp4 に。
    scene_files = []
    for i, (path, start) in enumerate(specs):
        seg_dur = edges[i + 1] - edges[i]
        probe = subprocess.run(
            ["ffprobe", "-v", "error", "-show_entries", "format=duration",
             "-of", "default=noprint_wrappers=1:nokey=1", path],
            capture_output=True, text=True)
        try:
            src_dur = float(probe.stdout.strip())
        except ValueError:
            src_dur = 0.0
        need = start + seg_dur + 0.3
        loop = 0 if (src_dur and src_dur >= need) else 6
        seg_out = os.path.join(tmpdir, f"scene_{i:02d}.mp4")
        cmd = ["ffmpeg", "-y"]
        if loop:
            cmd += ["-stream_loop", str(loop)]
        # cover crop: アスペクトを保ったまま短辺を W/H に合わせてから中央クロップ
        vf = (f"scale={W}:{H}:force_original_aspect_ratio=increase,"
              f"crop={W}:{H},setsar=1,fps=30")
        cmd += [
            "-ss", str(start), "-i", path,
            "-t", f"{seg_dur:.3f}",
            "-an", "-vf", vf,
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "21",
            "-pix_fmt", "yuv420p",
            seg_out,
        ]
        proc = subprocess.run(cmd, capture_output=True, text=True,
                              encoding="utf-8", errors="replace")
        if proc.returncode != 0 or not os.path.exists(seg_out):
            sys.stderr.write(proc.stdout + "\n" + proc.stderr + "\n")
            raise SystemExit(f"scene {i} render failed ({path})")
        scene_files.append(seg_out)
        sys.stderr.write(f"[make_sample]   scene {i}: {os.path.basename(path)} "
                         f"[{edges[i]:.1f}-{edges[i+1]:.1f}s]\n")

    # concat demuxer で連結
    concat_txt = os.path.join(tmpdir, "concat.txt")
    with open(concat_txt, "w", encoding="utf-8") as f:
        for sf in scene_files:
            f.write(f"file '{sf.replace(chr(92), '/')}'\n")
    montage = os.path.join(tmpdir, "montage.mp4")
    cmd = ["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", concat_txt,
           "-c:v", "libx264", "-preset", "veryfast", "-crf", "21",
           "-pix_fmt", "yuv420p", montage]
    proc = subprocess.run(cmd, capture_output=True, text=True,
                          encoding="utf-8", errors="replace")
    if proc.returncode != 0:
        sys.stderr.write(proc.stdout + "\n" + proc.stderr + "\n")
        raise SystemExit("montage concat failed")

    # ナレーションで mux
    cmd = [
        "ffmpeg", "-y",
        "-i", montage, "-i", wav,
        "-t", f"{audio_dur:.3f}",
        "-map", "0:v:0", "-map", "1:a:0",
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "21",
        "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "128k",
        "-shortest", args.out,
    ]
    proc = subprocess.run(cmd, capture_output=True, text=True,
                          encoding="utf-8", errors="replace")
    if proc.returncode != 0:
        sys.stderr.write(proc.stdout + "\n" + proc.stderr + "\n")
        raise SystemExit("montage mux failed")
    sys.stderr.write(f"[make_sample] wrote {args.out} "
                     f"(multi-scene color footage + JP narration)\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    ap.add_argument("--seconds", type=float, default=0.0, help="0=音声長に合わせる")
    ap.add_argument("--portrait", default=None,
                    help="使う実写ポートレート画像 (省略時は自動DL)")
    ap.add_argument("--no-download", action="store_true",
                    help="ダウンロードせず手続き合成顔を使う (オフライン検証用)")
    ap.add_argument("--footage", default=None,
                    help="実写トーク動画 (人が動いて喋る実映像) のパス。"
                         "指定するとこの実映像に日本語 TTS ナレーションを重ねて "
                         "サンプルを作る (静止合成顔ではない本命モード)")
    ap.add_argument("--footage-start", type=float, default=0.0,
                    help="--footage 内の開始秒 (実映像の使う窓の先頭)")
    ap.add_argument("--footage-list", default=None,
                    help="カラー現代実映像を複数シーン montage にする本命モード。"
                         "'a.mp4:0,b.mp4:2,c.mp4:0' 形式 (path:start_sec をカンマ区切り)")
    ap.add_argument("--scene-bounds", default=None,
                    help="montage のシーン切替秒境界 (カンマ区切り、例 '38,48,81')。"
                         "省略時は素材数で均等割り")
    args = ap.parse_args()

    if args.footage_list:
        return make_from_footage_list(args)
    if args.footage:
        return make_from_footage(args)

    tmpdir = tempfile.mkdtemp(prefix="sample_")
    wav, audio_dur = build_narration(tmpdir)
    dur = args.seconds if args.seconds > 0 else audio_dur
    sys.stderr.write(f"[make_sample] audio duration = {audio_dur:.1f}s, video = {dur:.1f}s\n")

    W, H = 1280, 720
    fps = 30

    # 音声エンベロープ (口パク同期用)
    env = audio_envelope(wav, fps)

    # 実写ポートレートの用意 (本命)。失敗時は手続き合成顔にフォールバック。
    talking_head = None
    if not args.no_download:
        portrait = args.portrait
        if portrait is None:
            portrait = os.path.join(tmpdir, "portrait.jpg")
            ok = rface.download_portrait(portrait)
            if not ok:
                sys.stderr.write("[make_sample] portrait download failed; "
                                 "falling back to procedural face\n")
                portrait = None
        if portrait and os.path.exists(portrait):
            try:
                talking_head = rface.PhotoTalkingHead(portrait, W, H)
                sys.stderr.write(f"[make_sample] using photo talking head "
                                 f"(face bbox {talking_head.face})\n")
            except Exception as e:
                sys.stderr.write(f"[make_sample] photo head init failed: {e}; "
                                 "falling back to procedural face\n")
                talking_head = None

    silent = os.path.join(tmpdir, "silent.mp4")
    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    vw = cv2.VideoWriter(silent, fourcc, fps, (W, H))
    n = int(dur * fps)
    for i in range(n):
        t = i / fps
        # 顔をゆっくり左右に動かす (facetrack / 動的クロップの意味を出す)。
        # 途中で大きく位置を変え、区間ごとに顔位置が違う状況を作る。
        base = 0.5 + 0.14 * math.sin(t * 0.28)
        drift = 0.05 * math.sin(t * 0.9 + 1.0)
        cx_ratio = min(0.70, max(0.30, base + drift))
        mouth = float(env[min(i, len(env) - 1)]) if len(env) else 0.0
        if talking_head is not None:
            frame = talking_head.render(cx_ratio, mouth, t)
        else:
            # フォールバック: 口の開きも音声に同期させる
            phase = math.asin(max(-1, min(1, mouth))) if mouth > 0 else 0.0
            frame = make_face_frame(W, H, cx_ratio, phase)
        vw.write(frame)
    vw.release()

    # mux
    cmd = [
        "ffmpeg", "-y",
        "-i", silent,
        "-i", wav,
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "23", "-pix_fmt", "yuv420p",
        "-c:a", "aac", "-b:a", "128k",
        "-shortest",
        args.out,
    ]
    proc = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if proc.returncode != 0:
        sys.stderr.write(proc.stdout + "\n" + proc.stderr + "\n")
        raise SystemExit("mux failed")
    sys.stderr.write(f"[make_sample] wrote {args.out}\n")


if __name__ == "__main__":
    main()
