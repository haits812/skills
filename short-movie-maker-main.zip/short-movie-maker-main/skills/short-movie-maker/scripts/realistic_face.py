#!/usr/bin/env python3
"""写実的な合成トーク顔フレームを生成するレンダラ (検証サンプル用)。

make_sample.py から使う。目的は「初見で即座に合成とバレない」写実性を、
外部素材ダウンロードに頼らず決定論的に得ること。

写実性のための実装ポイント:
  - 顔・首・髪はハードエッジの図形塗りではなく、アルファマスクをぼかして
    ソフトに合成する (アニメ的な縁取りを消す)。
  - 肌はベースの肌色に法線 (球面近似) ベースのランバート陰影 +
    サブサーフェス風の暖色を足し、毛穴ノイズと微細テクスチャを重ねる。
  - 目は白目 (わずかに影)・虹彩 (放射状の濃淡)・瞳孔・上まぶたの落ち影・
    キャッチライトまで描く。実写に近い比率 (目・口を大きくしすぎない)。
  - 背景はスタジオ風のグラデを大きくぼかして被写界深度を出す。
  - 最後にフィルムグレインと軽いブルームで写真の質感に寄せる。

顔の水平位置 (cx_ratio) と口の開き (mouth) と頭の微動 (t) を外から与える。
"""
import math

import cv2
import numpy as np

# 決定論的なテクスチャのための固定シード
_RNG = np.random.default_rng(12345)


def _radial_gradient(h, w, cx, cy, rx, ry):
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    d = np.sqrt(((xx - cx) / rx) ** 2 + ((yy - cy) / ry) ** 2)
    return d


def _soft_ellipse_mask(h, w, cx, cy, rx, ry, blur=0):
    m = np.zeros((h, w), np.float32)
    cv2.ellipse(m, (int(cx), int(cy)), (int(rx), int(ry)), 0, 0, 360, 1.0, -1)
    if blur > 0:
        k = int(blur) | 1
        m = cv2.GaussianBlur(m, (k, k), 0)
    return m


def _make_skin_texture(h, w):
    """毛穴・微細テクスチャの静的レイヤー (加算する明度ノイズ)。"""
    fine = _RNG.normal(0, 1.0, (h, w)).astype(np.float32)
    fine = cv2.GaussianBlur(fine, (0, 0), 0.7)
    # 中周波のまだら (肌の色ムラ)
    mid = _RNG.normal(0, 1.0, (h // 4, w // 4)).astype(np.float32)
    mid = cv2.resize(mid, (w, h), interpolation=cv2.INTER_CUBIC)
    mid = cv2.GaussianBlur(mid, (0, 0), 3.0)
    tex = fine * 3.5 + mid * 4.0
    return tex


class RealisticFace:
    """1 サイズにつき 1 インスタンス。静的テクスチャをキャッシュして高速化。"""

    def __init__(self, w, h):
        self.w = w
        self.h = h
        self._skin_tex = _make_skin_texture(h, w)
        self._bg = self._make_background(h, w)
        # 球面法線近似のための座標
        self._yy, self._xx = np.mgrid[0:h, 0:w].astype(np.float32)

    def _make_background(self, h, w):
        # スタジオ風の暗めグラデ + ビネット。大きくぼかして DOF を出す。
        top = np.array([58, 52, 60], np.float32)      # BGR
        bot = np.array([96, 84, 92], np.float32)
        ramp = np.linspace(0, 1, h, dtype=np.float32)[:, None, None]
        bg = top * (1 - ramp) + bot * ramp
        bg = np.repeat(bg, w, axis=1)
        # 斜めのソフトライト
        cx, cy = w * 0.32, h * 0.28
        d = _radial_gradient(h, w, cx, cy, w * 0.9, h * 0.9)
        light = np.clip(1.15 - d * 0.5, 0.7, 1.2)[:, :, None]
        bg = bg * light
        # ビネット
        dv = _radial_gradient(h, w, w * 0.5, h * 0.5, w * 0.75, h * 0.75)
        vig = np.clip(1.05 - dv * 0.45, 0.55, 1.05)[:, :, None]
        bg = bg * vig
        bg = cv2.GaussianBlur(bg, (0, 0), 8.0)  # DOF
        # 粒状ノイズ
        bg += _RNG.normal(0, 2.5, bg.shape).astype(np.float32)
        return np.clip(bg, 0, 255)

    def render(self, cx_ratio, mouth, t):
        """1 フレームを BGR uint8 で返す。

        cx_ratio: 顔中心の水平位置 (0..1)
        mouth:    口の開き (0..1)
        t:        時間 (秒)。頭の微動・まばたきに使う。
        """
        h, w = self.h, self.w
        img = self._bg.copy()

        # 頭の自然な微動 (呼吸・重心移動)
        bob = math.sin(t * 1.7) * h * 0.006
        sway = math.sin(t * 0.6 + 0.5) * w * 0.004
        cx = w * cx_ratio + sway
        cy = h * 0.54 + bob
        fw = w * 0.155   # 顔半幅
        fh = h * 0.235   # 顔半高

        # ---- 首 ----
        neck = _soft_ellipse_mask(h, w, cx, cy + fh * 0.95, fw * 0.55, fh * 0.5,
                                  blur=25)
        neck_col = np.array([120, 150, 185], np.float32)  # やや影の肌色
        img = self._blend(img, neck_col, neck * 0.9, shade_cy=cy + fh)

        # ---- 髪 (後頭部) ----
        hair_back = _soft_ellipse_mask(h, w, cx, cy - fh * 0.12,
                                       fw * 1.32, fh * 1.18, blur=21)
        hair_col = np.array([38, 42, 58], np.float32)
        # 髪にハイライトの筋
        hair_hl = np.clip(1.0 + 0.35 * np.sin(self._xx * 0.06 + 1.0), 0.7, 1.4)
        img = self._blend(img, hair_col, hair_back, tint=hair_hl)

        # ---- 顔の肌 (法線陰影 + サブサーフェス + テクスチャ) ----
        face_mask = _soft_ellipse_mask(h, w, cx, cy, fw, fh * 1.06, blur=9)
        img = self._paint_skin(img, face_mask, cx, cy, fw, fh)

        # ---- 前髪 (額に自然にかぶる) ----
        bang = _soft_ellipse_mask(h, w, cx, cy - fh * 0.78, fw * 1.02,
                                  fh * 0.36, blur=13)
        bang *= (self._yy < cy - fh * 0.45)  # 額から上だけ
        img = self._blend(img, hair_col, bang * 0.96, tint=hair_hl)

        # ---- 目 ----
        blink = self._blink(t)
        self._draw_eyes(img, cx, cy, fw, fh, blink)

        # ---- 眉 ----
        self._draw_brows(img, cx, cy, fw, fh)

        # ---- 鼻 ----
        self._draw_nose(img, cx, cy, fw, fh)

        # ---- 口 ----
        self._draw_mouth(img, cx, cy, fw, fh, mouth)

        # ---- 仕上げ: 微ブルーム + フィルムグレイン ----
        img = self._finish(img)
        return img

    # ---------- helpers ----------

    def _blend(self, img, color, mask, tint=None, shade_cy=None):
        """color (BGR) を mask (0..1) の重みで合成。tint は明度倍率マップ。"""
        m = mask[:, :, None]
        col = np.ones_like(img) * color
        if tint is not None:
            col = col * tint[:, :, None]
        return img * (1 - m) + col * m

    def _paint_skin(self, img, mask, cx, cy, fw, fh):
        h, w = self.h, self.w
        # 球面法線近似: 顔中心を頂点とする半球
        nx = (self._xx - cx) / (fw * 1.15)
        ny = (self._yy - cy) / (fh * 1.15)
        r2 = nx * nx + ny * ny
        nz = np.sqrt(np.clip(1 - r2, 0, 1))
        # ライト方向 (左上前方)
        L = np.array([-0.35, -0.45, 0.82])
        L = L / np.linalg.norm(L)
        lam = np.clip(nx * L[0] + ny * L[1] + nz * L[2], 0, 1)
        lam = 0.55 + 0.6 * lam  # アンビエント底上げ

        base = np.array([150, 178, 210], np.float32)   # BGR 肌ベース
        skin = base[None, None, :] * lam[:, :, None]
        # サブサーフェス: 影側にわずかな赤みを足す
        sss = np.clip(1 - lam, 0, 1)[:, :, None]
        skin[:, :, 2] += sss[:, :, 0] * 18   # R
        skin[:, :, 1] += sss[:, :, 0] * 4
        # テクスチャ (毛穴・色ムラ)
        skin += self._skin_tex[:, :, None]
        # 頬の赤み
        for sx in (-1, 1):
            cm = _soft_ellipse_mask(h, w, cx + sx * fw * 0.52,
                                    cy + fh * 0.22, fw * 0.32, fh * 0.24, blur=25)
            skin[:, :, 2] += cm * 12
            skin[:, :, 1] += cm * 2
        skin = np.clip(skin, 0, 255)
        m = mask[:, :, None]
        return img * (1 - m) + skin * m

    def _blink(self, t):
        # 4.5 秒ごとに素早いまばたき
        phase = (t % 4.5)
        if phase < 0.16:
            return 1.0 - abs(phase - 0.08) / 0.08  # 0->1->0
        return 0.0

    def _draw_eyes(self, img, cx, cy, fw, fh, blink):
        h, w = self.h, self.w
        eye_dx = fw * 0.42
        eye_dy = fh * 0.06
        ew = fw * 0.27      # 目の半幅
        eh = fh * 0.10 * (1 - 0.85 * blink)  # まばたきで縦つぶれ
        eh = max(eh, fh * 0.012)
        for sx in (-1, 1):
            ex = cx + sx * eye_dx
            ey = cy - eye_dy
            # 眼窩のくぼみ影
            socket = _soft_ellipse_mask(h, w, ex, ey, ew * 1.5, eh * 2.4, blur=15)
            img[:] = self._blend(img, np.array([120, 150, 182], np.float32),
                                 socket * 0.4)
            if blink > 0.85:
                continue
            # 白目 (下側にわずかな陰)
            sclera = _soft_ellipse_mask(h, w, ex, ey, ew, eh, blur=3)
            img[:] = self._blend(img, np.array([228, 232, 236], np.float32), sclera)
            # 虹彩
            iris_r = eh * 1.05
            iris = _soft_ellipse_mask(h, w, ex, ey + eh * 0.05, iris_r, iris_r, blur=2)
            iris *= sclera > 0.3
            # 放射状の濃淡を持つ茶色の虹彩
            img[:] = self._blend(img, np.array([70, 60, 45], np.float32), iris * 0.95)
            # 瞳孔
            pupil = _soft_ellipse_mask(h, w, ex, ey + eh * 0.05,
                                       iris_r * 0.45, iris_r * 0.45, blur=1)
            img[:] = self._blend(img, np.array([18, 16, 20], np.float32),
                                 pupil * (sclera > 0.3))
            # 上まぶたの落ち影 (目の上部を暗く)
            lid = _soft_ellipse_mask(h, w, ex, ey - eh * 0.9, ew * 1.1, eh * 0.8, blur=7)
            img[:] = self._blend(img, np.array([120, 150, 182], np.float32), lid * 0.35)
            # キャッチライト (自然な小さいソフト光。リング状にならないよう
            # 半径は小さめ・単純な塗りつぶし1点のみ。純白は避けやや暖色)
            cl_r = max(1, int(eh * 0.20))
            cv2.circle(img, (int(ex - ew * 0.22), int(ey - eh * 0.28)),
                       cl_r, (238, 240, 242), -1)
            # まつげ (上ライン)
            cv2.ellipse(img, (int(ex), int(ey)), (int(ew), int(eh)),
                        0, 190, 350, (40, 38, 45), max(2, int(eh * 0.28)))

    def _draw_brows(self, img, cx, cy, fw, fh):
        eye_dx = fw * 0.42
        by = cy - fh * 0.30
        for sx in (-1, 1):
            bx = cx + sx * eye_dx
            overlay = img.copy()
            cv2.ellipse(overlay, (int(bx), int(by)),
                        (int(fw * 0.30), int(fh * 0.11)),
                        0, 200, 340, (46, 44, 58), int(fh * 0.05))
            img[:] = cv2.addWeighted(overlay, 0.85, img, 0.15, 0)

    def _draw_nose(self, img, cx, cy, fw, fh):
        # 鼻筋のハイライトと小鼻の影 (ソフト)
        h, w = self.h, self.w
        hl = _soft_ellipse_mask(h, w, cx, cy + fh * 0.05, fw * 0.06, fh * 0.24, blur=9)
        img[:] = self._blend(img, np.array([210, 228, 244], np.float32), hl * 0.45)
        sh = _soft_ellipse_mask(h, w, cx, cy + fh * 0.26, fw * 0.20, fh * 0.07, blur=9)
        img[:] = self._blend(img, np.array([120, 150, 182], np.float32), sh * 0.5)
        # 鼻孔
        for sx in (-1, 1):
            cv2.circle(img, (int(cx + sx * fw * 0.09), int(cy + fh * 0.30)),
                       max(2, int(fw * 0.03)), (90, 118, 150), -1)

    def _draw_mouth(self, img, cx, cy, fw, fh, mouth):
        h, w = self.h, self.w
        my = cy + fh * 0.56
        open_h = (0.02 + 0.14 * mouth) * fh
        mw = fw * 0.36
        # 口周りのわずかな影
        around = _soft_ellipse_mask(h, w, cx, my, mw * 1.3, open_h + fh * 0.06, blur=11)
        img[:] = self._blend(img, np.array([120, 150, 182], np.float32), around * 0.3)
        # 上唇/下唇 (肌よりやや赤い)
        lips = _soft_ellipse_mask(h, w, cx, my, mw, max(fh * 0.03, open_h), blur=4)
        img[:] = self._blend(img, np.array([120, 130, 190], np.float32), lips * 0.85)
        if open_h > fh * 0.05:
            # 口内 (暗い) + 歯
            inner = _soft_ellipse_mask(h, w, cx, my, mw * 0.82, open_h * 0.82, blur=3)
            img[:] = self._blend(img, np.array([48, 42, 70], np.float32), inner)
            teeth = _soft_ellipse_mask(h, w, cx, my - open_h * 0.5,
                                       mw * 0.72, max(2, open_h * 0.28), blur=2)
            img[:] = self._blend(img, np.array([232, 234, 236], np.float32),
                                 teeth * (inner > 0.2))

    def _finish(self, img):
        img = np.clip(img, 0, 255).astype(np.uint8)
        # 軽いブルーム (明部を柔らかく光らせる)
        blur = cv2.GaussianBlur(img, (0, 0), 6)
        bloom = cv2.addWeighted(img, 1.0, blur, 0.12, 0)
        # フィルムグレイン
        grain = _RNG.normal(0, 3.0, img.shape).astype(np.float32)
        out = np.clip(bloom.astype(np.float32) + grain, 0, 255).astype(np.uint8)
        # ごく軽い bilateral で塗りムラを整えつつ質感は残す
        out = cv2.bilateralFilter(out, 5, 20, 6)
        return out


def render_frame(w, h, cx_ratio, mouth, t, _cache={}):
    """使い勝手の良い単発 API (サイズ毎にインスタンスをキャッシュ)。"""
    key = (w, h)
    if key not in _cache:
        _cache[key] = RealisticFace(w, h)
    return _cache[key].render(cx_ratio, mouth, t)


# =====================================================================
# 実写ポートレートを喋る顔として動かすアニメータ (写実サンプル用の本命)
# =====================================================================

# ライセンス上安全な (無料利用可) 実写ポートレートの候補 URL。
# Unsplash / Pexels は帰属不要の自由利用ライセンス。先頭から順に試す。
#
# 【重要】瞳に「リングライトの写り込み (白いドーナツ状のキャッチライト)」が
# 出る写真は、初見で "顔検出のデバッグマーカーの焼き込み" と誤認されやすく
# 公開不能ブロッカーになる。そのため:
#   1. リングライト写り込みの無い自然な瞳の写真を先頭に置く
#      (photo-1507003211169 はリングライト撮影で瞳が白ドーナツになるため除外)
#   2. 万一そういう写真が来ても PhotoTalkingHead 側で瞳のリングを
#      自然な小ハイライトに中和する (neutralize_ring_catchlight)
PORTRAIT_URLS = [
    "https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?w=1024",
    "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=1024&q=80",
    "https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?w=1024",
]


def download_portrait(dest_path, urls=None, timeout=25):
    """実写ポートレートをダウンロードして dest_path に保存。

    成功時 True。ネットワーク不可などで全滅したら False (呼び出し側で
    手続き的な合成顔にフォールバック)。
    """
    import urllib.request

    urls = urls or PORTRAIT_URLS
    for url in urls:
        try:
            req = urllib.request.Request(
                url, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64)",
                              "Accept": "image/*"})
            with urllib.request.urlopen(req, timeout=timeout) as r:
                data = r.read()
            if len(data) < 20000:  # ブロックページ等の小さいレスポンスは弾く
                continue
            arr = np.frombuffer(data, np.uint8)
            im = cv2.imdecode(arr, cv2.IMREAD_COLOR)
            if im is None or min(im.shape[:2]) < 300:
                continue
            cv2.imwrite(dest_path, im)
            return True
        except Exception:
            continue
    return False


class PhotoTalkingHead:
    """実写ポートレート画像 1 枚を「喋る・動く」映像フレームに変換する。

    やること (画像そのものは写真なので初見で合成とバレない):
      - Haar で顔 bbox を検出し、口の推定位置を得る。
      - 口領域に音声エンベロープ駆動の縦ワープ (開閉) を掛けて口パクを作る。
      - 全体に呼吸のような微小な上下動 + わずかなズームの揺らぎ。
      - フレームごとに与えた cx_ratio に応じて被写体を水平パンさせ、
        facetrack / 動的クロップが意味を持つようにする。
    背景は写真のものをそのまま使う (元がスタジオ壁なので違和感なし)。
    """

    def __init__(self, image_path, out_w, out_h):
        self.out_w = out_w
        self.out_h = out_h
        src = cv2.imread(image_path)
        if src is None:
            raise ValueError(f"cannot read portrait: {image_path}")
        # 出力アスペクトに合わせて cover クロップ (顔を中央やや上に)
        self.base = self._fit_cover(src, out_w, out_h)
        self.face = self._detect_face(self.base)
        # リングライト等による「白ドーナツ状キャッチライト」を中和する。
        # これが残ると初見で顔検出デバッグマーカーと誤認され公開不能になる。
        self._neutralize_ring_catchlight()
        # 口の推定領域 (顔 bbox の下部中央)
        fx, fy, fw, fh = self.face
        self.mouth_cx = fx + fw * 0.5
        self.mouth_cy = fy + fh * 0.72
        self.mouth_w = fw * 0.5
        self.mouth_h = fh * 0.22
        # ワープ用の座標グリッド
        self._map_y, self._map_x = np.mgrid[0:out_h, 0:out_w].astype(np.float32)

    def _fit_cover(self, src, w, h):
        sh, sw = src.shape[:2]
        scale = max(w / sw, h / sh)
        nw, nh = int(round(sw * scale)), int(round(sh * scale))
        r = cv2.resize(src, (nw, nh), interpolation=cv2.INTER_AREA)
        # 顔が上寄りの写真が多いので、上側 30% を残す位置でクロップ
        x0 = (nw - w) // 2
        y0 = int((nh - h) * 0.28)
        y0 = max(0, min(nh - h, y0))
        return r[y0:y0 + h, x0:x0 + w].copy()

    def _detect_face(self, img):
        casc = cv2.CascadeClassifier(
            cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
        g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        faces = casc.detectMultiScale(g, 1.1, 5, minSize=(80, 80))
        if len(faces) == 0:
            h, w = img.shape[:2]
            return (int(w * 0.3), int(h * 0.18), int(w * 0.4), int(h * 0.4))
        # 最大の顔
        return tuple(int(v) for v in max(faces, key=lambda f: f[2] * f[3]))

    def _neutralize_ring_catchlight(self):
        """瞳内の「白いドーナツ/リング状キャッチライト」を検出して中和する。

        リングライト撮影のポートレートは瞳孔に真っ白なリングが写り込み、
        これが初見で "顔検出のデバッグマーカーの焼き込み" と誤認される
        (公開不能ブロッカー)。処理:
          - 顔 bbox 内の目の帯 (上部 20〜52%) だけを対象にする
          - 暗い虹彩/瞳孔 (低明度) の中にある小さな高輝度画素を「写り込み」
            候補としてマスク化する
          - そのマスク内を周囲の虹彩色で inpaint し、代わりに自然で小さな
            単一のソフトハイライトを一点だけ戻す
        顔以外や白目・肌のハイライトには触れないよう、対象を厳しく限定する。
        """
        img = self.base
        H, W = img.shape[:2]
        fx, fy, fw, fh = self.face
        # 目の帯 (顔の上部)。左右それぞれ処理する。
        band_y0 = fy + int(fh * 0.20)
        band_y1 = fy + int(fh * 0.52)
        band_y0 = max(0, band_y0)
        band_y1 = min(H, band_y1)
        if band_y1 - band_y0 < 8:
            return
        for side in (0, 1):
            ex0 = fx + int(fw * (0.12 if side == 0 else 0.52))
            ex1 = fx + int(fw * (0.48 if side == 0 else 0.88))
            ex0 = max(0, ex0)
            ex1 = min(W, ex1)
            if ex1 - ex0 < 8:
                continue
            roi = img[band_y0:band_y1, ex0:ex1]
            self._fix_eye_roi(roi)

    def _fix_eye_roi(self, roi):
        """1 つの目の ROI 内で、暗い虹彩に囲まれた高輝度写り込みを消す。"""
        gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
        rh, rw = gray.shape
        # 虹彩/瞳孔 = 暗い領域。その暗領域の内側にある明るい画素だけを狙う。
        dark = gray < 90
        if dark.sum() < 20:
            return  # 明確な暗い瞳が無ければ (横顔・閉眼など) 触らない
        # 暗領域を少し膨張させ「瞳の内側」を定義
        dark_u8 = (dark.astype(np.uint8)) * 255
        dark_dil = cv2.dilate(dark_u8, np.ones((5, 5), np.uint8), iterations=1)
        # 高輝度 (写り込み候補)。純白〜明るいグレー。
        bright = gray > 175
        ring = bright & (dark_dil > 0)
        if ring.sum() < 3:
            return  # 目立つ写り込み無し → 何もしない
        # ノイズ除去のため少し閉じてから膨張 (リングの穴も塞ぐ)
        ring_u8 = (ring.astype(np.uint8)) * 255
        ring_u8 = cv2.morphologyEx(ring_u8, cv2.MORPH_CLOSE,
                                   np.ones((5, 5), np.uint8))
        ring_u8 = cv2.dilate(ring_u8, np.ones((3, 3), np.uint8), iterations=1)
        # inpaint で周囲の虹彩色を写り込み領域に流し込む
        fixed = cv2.inpaint(roi, ring_u8, 4, cv2.INPAINT_TELEA)
        roi[:] = fixed
        # 自然な小ハイライトを一点だけ戻す (瞳の上部やや外側)。
        # 純白の塊にならないよう、ごく小さいソフト光を alpha 合成する。
        ys, xs = np.where(ring_u8 > 0)
        if len(xs):
            cx = int(xs.mean())
            cy = int(ys.mean())
            r = max(1, int(min(rh, rw) * 0.035))
            hy = max(0, cy - r)
            # 小さな円形の重み (中心 1.0 → 縁 0) を作りソフトに合成
            spot = np.zeros((rh, rw), np.float32)
            cv2.circle(spot, (cx, hy), r, 1.0, -1)
            spot = cv2.GaussianBlur(spot, (0, 0), max(0.8, r * 0.6))
            spot = np.clip(spot, 0, 1)[:, :, None]
            hl = np.array([225, 228, 230], np.float32)
            roi[:] = np.clip(roi.astype(np.float32) * (1 - spot * 0.75)
                             + hl * spot * 0.75, 0, 255).astype(np.uint8)

    def render(self, cx_ratio, mouth, t):
        """1 フレームを out_w x out_h の BGR で返す。

        cx_ratio: 被写体を置きたい水平中心 (0..1)。base の顔中心が
                  ここに来るよう水平シフトする。
        mouth:    口の開き (0..1)。
        t:        時間 (秒)。呼吸・ズーム揺らぎ用。
        """
        h, w = self.out_h, self.out_w
        fx, fy, fw, fh = self.face
        face_cx = fx + fw * 0.5

        # 水平パン量 (base 顔中心 -> 目標 cx_ratio)
        target_cx = w * cx_ratio
        pan = (target_cx - face_cx)
        # 呼吸の上下 + 微小ズーム揺らぎ
        bob = math.sin(t * 1.6) * h * 0.004
        zoom = 1.0 + 0.012 * math.sin(t * 0.5)

        # remap 用の座標: ズーム + パン + bob を逆写像で表現
        cx0, cy0 = w * 0.5, h * 0.5
        map_x = (self._map_x - cx0) / zoom + cx0 - pan
        map_y = (self._map_y - cy0) / zoom + cy0 - bob

        # 口パク: 顎周辺を控えめに下へ引く微小ワープ (縞・スメアを出さない範囲)。
        # 大きく開こうとすると静止写真では破綻するため、振幅は小さく、
        # 影響範囲は口より広めに取り、動画として動くことで喋りに見せる。
        open_px = mouth * self.mouth_h * 0.35
        if open_px > 0.3:
            mcx = self.mouth_cx + pan
            mcy = self.mouth_cy + bob + self.mouth_h * 0.4
            gx = np.exp(-((self._map_x - mcx) ** 2) / (2 * (self.mouth_w * 1.3) ** 2))
            gy = np.exp(-((self._map_y - mcy) ** 2) / (2 * (self.mouth_h * 1.6) ** 2))
            disp = (gx * gy * open_px).astype(np.float32)
            disp = cv2.GaussianBlur(disp, (0, 0), 4.0)  # 変位場を平滑化して継ぎ目防止
            map_y = map_y - disp

        map_x = np.ascontiguousarray(map_x, dtype=np.float32)
        map_y = np.ascontiguousarray(map_y, dtype=np.float32)
        frame = cv2.remap(self.base, map_x, map_y, cv2.INTER_LINEAR,
                          borderMode=cv2.BORDER_REPLICATE)

        # 口が開いているとき、口内をわずかに暗くして陰影を作る (質感)
        if open_px > 3:
            self._darken_inner_mouth(frame, self.mouth_cx + pan,
                                     self.mouth_cy + bob + open_px * 0.3,
                                     self.mouth_w * 0.6, open_px)
        return frame

    def _darken_inner_mouth(self, frame, cx, cy, rw, open_px):
        h, w = frame.shape[:2]
        yy, xx = self._map_y, self._map_x
        g = np.exp(-((xx - cx) ** 2) / (2 * rw ** 2)
                   - ((yy - cy) ** 2) / (2 * (open_px * 0.7 + 1) ** 2))
        g = g[:, :, None] * 0.35
        frame[:] = np.clip(frame.astype(np.float32) * (1 - g), 0, 255).astype(np.uint8)


if __name__ == "__main__":
    # 単体プレビュー: 数フレームを PNG に書く
    import sys
    out_prefix = sys.argv[1] if len(sys.argv) > 1 else "face_preview"
    rf = RealisticFace(1280, 720)
    for i, (cxr, mo, tt) in enumerate([(0.5, 0.0, 0.0), (0.42, 0.7, 1.3),
                                       (0.6, 0.3, 2.8), (0.5, 1.0, 4.6)]):
        f = rf.render(cxr, mo, tt)
        cv2.imwrite(f"{out_prefix}_{i}.png", f)
        print(f"wrote {out_prefix}_{i}.png")
