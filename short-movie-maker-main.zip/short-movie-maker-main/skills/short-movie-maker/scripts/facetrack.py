#!/usr/bin/env python3
"""顔検出で話者の水平位置を時系列で推定し、動的クロップ用のトラックを返す。

render.py は元動画を縦型 9:16 に cover 配置する際、「顔が常に中央に来る」よう
横方向のクロップ位置を時間ごとに動かす。このスクリプトはそのための
face_cx (フレーム幅比 0..1) の時系列を、EMA スムージングと画面端クランプ付きで返す。

方式:
  - 一定間隔でフレームをサンプリングし OpenCV Haar Cascade で顔検出
  - 検出フレームの顔中心 x (0..1) を記録。未検出は直近値を保持
  - EMA でスムージングし、カクつき/見切れを防止
  - crop_half (= CONTENT_W/2 / scaled_width の目安) を渡すと、
    顔が中央に来せられる範囲に face_cx をクランプ (画面端で見切れ防止)

出力 face.json:
{
  "face_cx": 0.53,               # 全体中央値 (後方互換 / 静的クロップ用)
  "detected_ratio": 0.72,
  "samples": 40, "hits": 29,
  "duration": 53.4,
  "track": [                     # 時系列 (動的クロップ用)
    {"t": 0.0, "cx": 0.51},
    {"t": 0.5, "cx": 0.52}, ...
  ]
}

Usage:
  python facetrack.py --video <mp4> --out face.json [--start 0 --end 60] [--fps 4] [--smooth 0.3]
"""
import argparse
import json
import statistics
import sys

import cv2


def ema_smooth(values, alpha):
    """EMA スムージング (前後 2 パスで位相ずれを抑える)。"""
    if not values:
        return values
    fwd = []
    s = values[0]
    for v in values:
        s = alpha * v + (1 - alpha) * s
        fwd.append(s)
    # backward pass
    out = list(fwd)
    s = fwd[-1]
    for i in range(len(fwd) - 1, -1, -1):
        s = alpha * fwd[i] + (1 - alpha) * s
        out[i] = (out[i] + s) / 2.0
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--video", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--start", type=float, default=0.0)
    ap.add_argument("--end", type=float, default=-1.0)
    ap.add_argument("--fps", type=float, default=4.0, help="サンプリング fps (トラック解像度)")
    ap.add_argument("--smooth", type=float, default=0.3,
                    help="EMA alpha (小さいほど滑らか)。0..1")
    ap.add_argument("--crop-half", type=float, default=0.0,
                    help="クランプ用の half-width 比 (crop幅/scaled幅の半分)。"
                         "0 ならクランプせず 0.05..0.95 に制限のみ")
    args = ap.parse_args()

    cap = cv2.VideoCapture(args.video)
    if not cap.isOpened():
        raise SystemExit(f"cannot open video: {args.video}")

    src_fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    total = cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0
    dur = total / src_fps if src_fps else 0
    end = args.end if args.end > 0 else dur

    cascade_path = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
    cascade = cv2.CascadeClassifier(cascade_path)

    step = max(1, int(round(src_fps / max(0.1, args.fps))))
    start_frame = int(args.start * src_fps)
    end_frame = int(end * src_fps)
    cap.set(cv2.CAP_PROP_POS_FRAMES, start_frame)
    frame_idx = start_frame

    # 時系列 (サンプルごと)。未検出は None を入れておき後で補間。
    raw_times = []
    raw_cx = []
    centers = []  # 検出できたものだけ (中央値算出用)
    samples = 0
    last_cx = None
    DETECT_W = 480  # 検出はこの幅に縮小して行う (cx は相対値なので精度影響は軽微、大幅高速化)
    while frame_idx <= end_frame:
        if (frame_idx - start_frame) % step == 0:
            ret, frame = cap.read()
            if not ret:
                break
            samples += 1
            h, w = frame.shape[:2]
            if w > DETECT_W:
                scale = DETECT_W / w
                frame = cv2.resize(frame, (DETECT_W, max(1, int(h * scale))),
                                   interpolation=cv2.INTER_AREA)
            sh, sw = frame.shape[:2]
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            faces = cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5,
                                             minSize=(int(sw * 0.05), int(sh * 0.05)))
            t = (frame_idx - start_frame) / src_fps + args.start
            if len(faces) > 0:
                fx, fy, fw, fh = max(faces, key=lambda b: b[2] * b[3])
                cx = (fx + fw / 2.0) / sw
                centers.append(cx)
                last_cx = cx
                raw_cx.append(cx)
            else:
                # 未検出は直近値を保持 (先頭連続未検出は後で 0.5 埋め)
                raw_cx.append(last_cx)
            raw_times.append(round(t, 3))
        else:
            # 検出しないフレームはデコード最小限の grab() でスキップ
            if not cap.grab():
                break
        frame_idx += 1
    cap.release()

    # 先頭側の None (まだ一度も検出していない) を最初の有効値 or 0.5 で埋める
    first_valid = next((v for v in raw_cx if v is not None), 0.5)
    filled = [v if v is not None else first_valid for v in raw_cx]

    smoothed = ema_smooth(filled, max(0.01, min(1.0, args.smooth)))

    # クランプ: 顔を中央に置くと crop がはみ出す端を制限。
    half = args.crop_half
    lo = max(0.05, half) if half > 0 else 0.05
    hi = min(0.95, 1.0 - half) if half > 0 else 0.95
    track = [{"t": raw_times[i], "cx": round(min(hi, max(lo, smoothed[i])), 4)}
             for i in range(len(smoothed))]

    if centers:
        face_cx = round(min(hi, max(lo, statistics.median(centers))), 4)
    else:
        face_cx = 0.5
    result = {
        "face_cx": face_cx,
        "detected_ratio": round(len(centers) / samples, 3) if samples else 0.0,
        "samples": samples,
        "hits": len(centers),
        "duration": round(end - args.start, 3),
        "track": track,
    }
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False)
    sys.stderr.write(
        f"[facetrack] face_cx={face_cx} detected={result['detected_ratio']} "
        f"track_pts={len(track)}\n")
    # stdout は track を省いた要約 (Claude が読みやすいよう)
    summary = {k: v for k, v in result.items() if k != "track"}
    summary["track_points"] = len(track)
    print(json.dumps(summary, ensure_ascii=False))


if __name__ == "__main__":
    main()
