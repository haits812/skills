#!/usr/bin/env python3
"""入力 (ローカルパス or YouTube URL) を作業ディレクトリのローカル mp4 に正規化する。

- ローカルファイル : 存在チェックのみして絶対パスを返す (コピーしない)
- URL (http/https): yt-dlp でダウンロードして mp4 を取得

結果は JSON で stdout に出す: {"video_path": "...", "title": "...", "source": "local|url"}

Usage:
  python fetch.py --input "<path or url>" --workdir <dir>
"""
import argparse
import json
import os
import re
import subprocess
import sys


def is_url(s: str) -> bool:
    return bool(re.match(r"^https?://", s.strip(), re.IGNORECASE))


def fetch_url(url: str, workdir: str) -> dict:
    os.makedirs(workdir, exist_ok=True)
    out_tmpl = os.path.join(workdir, "source.%(ext)s")
    # mp4 に統一。最良の映像+音声を mp4 にマージ。
    cmd = [
        "yt-dlp",
        "-f", "bv*+ba/b",
        "--merge-output-format", "mp4",
        "-o", out_tmpl,
        "--no-playlist",
        "--print", "after_move:filepath",
        "--no-simulate",
        url,
    ]
    proc = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if proc.returncode != 0:
        sys.stderr.write(proc.stdout + "\n" + proc.stderr + "\n")
        raise SystemExit(f"yt-dlp failed (code {proc.returncode})")
    # print で出た最終パスを拾う。無ければ探索。
    path = None
    for line in reversed(proc.stdout.strip().splitlines()):
        line = line.strip()
        if line and os.path.exists(line):
            path = line
            break
    if not path:
        for ext in ("mp4", "mkv", "webm"):
            cand = os.path.join(workdir, f"source.{ext}")
            if os.path.exists(cand):
                path = cand
                break
    if not path:
        raise SystemExit("yt-dlp: could not locate downloaded file")

    # タイトル取得 (best effort)
    title = ""
    # yt-dlp が Windows コンソール既定 (cp932) でタイトルを出すと化けるため UTF-8 を強制
    env = {**os.environ, "PYTHONIOENCODING": "utf-8"}
    tp = subprocess.run(
        ["yt-dlp", "--no-playlist", "--encoding", "utf-8",
         "--print", "title", "--skip-download", url],
        capture_output=True, text=True, encoding="utf-8", errors="replace", env=env,
    )
    if tp.returncode == 0:
        title = tp.stdout.strip().splitlines()[0] if tp.stdout.strip() else ""
    return {"video_path": os.path.abspath(path), "title": title, "source": "url"}


def fetch_local(path: str) -> dict:
    if not os.path.exists(path):
        raise SystemExit(f"input file not found: {path}")
    title = os.path.splitext(os.path.basename(path))[0]
    return {"video_path": os.path.abspath(path), "title": title, "source": "local"}


def main():
    # Windows コンソール (cp932) でも動画タイトル等の Unicode を安全に出力する
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--workdir", default=".")
    args = ap.parse_args()
    if is_url(args.input):
        result = fetch_url(args.input, args.workdir)
    else:
        result = fetch_local(args.input)
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
