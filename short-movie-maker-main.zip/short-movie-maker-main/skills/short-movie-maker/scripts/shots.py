"""ショット (カメラカット) 検出 + 代表フレーム抽出 (day02 detect_shots を切り抜き用に移植)。

用途 (M10 映像分析):
  1. カット切替点の一覧 → keep 境界をショット境界にスナップ (ぶつ切り感の解消)
  2. 各ショットの代表フレーム PNG → Claude が実際に見て
     構図 (引き/寄り)・絵かぶり・焼き込みテロップ・ベストフレームを判断する

Usage:
  python shots.py --video work/source.mp4 --out work/shots.json \
      [--frames-dir work/shots] [--threshold 0.30] [--range "58:100"]

出力 shots.json:
  {"cuts": [t1, t2, ...],                       # カット切替の絶対秒
   "shots": [{"start":s, "end":e, "frame": "work/shots/shot_003.png"}, ...]}
"""

from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys


def detect_cuts(video: str, threshold: float,
                t_range: tuple[float, float] | None) -> tuple[list[float], float]:
    """ffmpeg scene 検出でカット時刻列と対象範囲の長さを返す。"""
    pre = []
    if t_range:
        pre = ["-ss", str(t_range[0]), "-to", str(t_range[1])]
    proc = subprocess.run(
        ["ffmpeg", "-hide_banner", *pre, "-i", video,
         "-vf", f"select='gt(scene,{threshold})',showinfo",
         "-f", "null", "-"],
        capture_output=True, text=True, encoding="utf-8", errors="replace")
    base = t_range[0] if t_range else 0.0
    cuts = [round(base + float(m), 3)
            for m in re.findall(r"pts_time:([0-9.]+)", proc.stderr or "")]
    dur_m = re.findall(r"time=(\d+):(\d+):([\d.]+)", proc.stderr or "")
    dur = 0.0
    if dur_m:
        h, mnt, s = dur_m[-1]
        dur = base + int(h) * 3600 + int(mnt) * 60 + float(s)
    return sorted(set(cuts)), dur


def extract_frame(video: str, t: float, out_path: str) -> None:
    subprocess.run(
        ["ffmpeg", "-y", "-v", "error", "-ss", f"{t:.3f}", "-i", video,
         "-frames:v", "1", "-vf", "scale=640:-2", out_path],
        check=True, capture_output=True)


def main() -> None:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser()
    ap.add_argument("--video", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--frames-dir", default=None,
                    help="代表フレームの出力先 (省略時は out と同じ場所の shots/)")
    ap.add_argument("--threshold", type=float, default=0.30,
                    help="scene 検出閾値。低いほど敏感 (トーク番組 0.25〜0.35 目安)")
    ap.add_argument("--range", default=None, help='対象範囲 "start:end" (絶対秒)。省略時は全編')
    ap.add_argument("--max-frames", type=int, default=40,
                    help="代表フレームの最大枚数 (多すぎる場合は等間隔に間引く)")
    args = ap.parse_args()

    t_range = None
    if args.range:
        a, b = args.range.split(":")
        t_range = (float(a), float(b))

    cuts, dur = detect_cuts(args.video, args.threshold, t_range)
    start = t_range[0] if t_range else 0.0
    end = t_range[1] if t_range else dur

    # ショット区間 = [start, cut1), [cut1, cut2), ...
    bounds = [start] + [c for c in cuts if start < c < end] + [end]
    shots = [{"start": round(bounds[i], 3), "end": round(bounds[i + 1], 3)}
             for i in range(len(bounds) - 1)
             if bounds[i + 1] - bounds[i] > 0.2]

    frames_dir = args.frames_dir or os.path.join(os.path.dirname(args.out) or ".", "shots")
    os.makedirs(frames_dir, exist_ok=True)

    # フレームを抽出 (多すぎるときは等間隔に間引き)
    idxs = list(range(len(shots)))
    if len(idxs) > args.max_frames:
        step = len(idxs) / args.max_frames
        idxs = [int(i * step) for i in range(args.max_frames)]
    for n, i in enumerate(idxs):
        s = shots[i]
        mid = (s["start"] + s["end"]) / 2
        path = os.path.join(frames_dir, f"shot_{i:03d}.png").replace("\\", "/")
        try:
            extract_frame(args.video, mid, path)
            s["frame"] = path
        except subprocess.CalledProcessError:
            pass

    result = {"cuts": cuts, "shots": shots,
              "range": [start, round(end, 3)], "threshold": args.threshold}
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=1)
    print(json.dumps({"cuts": len(cuts), "shots": len(shots),
                      "frames": sum(1 for s in shots if s.get("frame")),
                      "out": args.out}, ensure_ascii=False))


if __name__ == "__main__":
    main()
