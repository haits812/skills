"""音声の盛り上がり検出 (M15): 音量ピークから「音で盛り上がっている箇所」を出す。

transcript (意味) だけでは拾えない盛り上がり — 笑い声・リアクション・声の爆発 — を
選定シグナルとして Claude に渡す。RMS 音量の z-score でピーク区間を検出し、
transcript と突き合わせて speech (発話の盛り上がり) / nonverbal (笑い・歓声など
文字にならない盛り上がり) に分類する。

Usage:
  python energy.py --video work/source.mp4 --out work/energy.json \
      [--transcript work/transcript.json] [--top 15] [--z 1.0]

出力 energy.json:
  {"peaks": [{"start": s, "end": e, "score": 平均z, "peak": 最大z,
              "kind": "speech"|"nonverbal", "context": "近傍の発話テキスト"}],
   "curve": {"step": 2.0, "z": [2秒刻みの平均z, ...]},
   "duration": 秒}

使い方 (Claude 向け):
  - score の高い peaks を含む区間を切り抜き候補として優先する
  - kind=nonverbal は笑い・リアクションの可能性が高い。context (直前の発話) が
    そのオチ/フリ。文字起こしだけでは普通に見えても音では一番面白い瞬間
  - keep 内に nonverbal peak が入るなら、その区間を無音カットで削らない
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import tempfile
import wave

import numpy as np

SR = 16000


def extract_pcm(video: str) -> np.ndarray:
    """ffmpeg で 16kHz mono PCM を抜き出して float32 配列で返す。"""
    fd, tmp = tempfile.mkstemp(suffix=".wav")
    os.close(fd)
    try:
        subprocess.run(
            ["ffmpeg", "-y", "-v", "error", "-i", video,
             "-vn", "-ac", "1", "-ar", str(SR), "-c:a", "pcm_s16le", tmp],
            check=True, capture_output=True)
        with wave.open(tmp, "rb") as w:
            raw = w.readframes(w.getnframes())
        return np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
    finally:
        try:
            os.remove(tmp)
        except OSError:
            pass


def rms_db_curve(x: np.ndarray, hop: float, win: float) -> np.ndarray:
    """hop 秒刻み・win 秒窓の RMS (dB) 列。累積和で O(n)。"""
    hop_n = max(1, int(SR * hop))
    win_n = max(hop_n, int(SR * win))
    if len(x) < win_n:
        return np.array([])
    csq = np.concatenate([[0.0], np.cumsum(x.astype(np.float64) ** 2)])
    starts = np.arange(0, len(x) - win_n + 1, hop_n)
    rms = np.sqrt((csq[starts + win_n] - csq[starts]) / win_n)
    return 20.0 * np.log10(rms + 1e-8)


def find_peaks(z: np.ndarray, hop: float, win: float, z_thr: float,
               merge_gap: float, min_dur: float) -> list[dict]:
    """z >= z_thr の連続区間をピークとして抽出 (近接はマージ)。"""
    mask = z >= z_thr
    runs: list[list[int]] = []
    i = 0
    while i < len(mask):
        if mask[i]:
            j = i
            while j + 1 < len(mask) and mask[j + 1]:
                j += 1
            runs.append([i, j])
            i = j + 1
        else:
            i += 1
    # 近接マージ
    gap_frames = int(merge_gap / hop)
    merged: list[list[int]] = []
    for r in runs:
        if merged and r[0] - merged[-1][1] <= gap_frames:
            merged[-1][1] = r[1]
        else:
            merged.append(r)
    peaks = []
    for a, b in merged:
        start = a * hop
        end = b * hop + win
        if end - start < min_dur:
            continue
        seg = z[a:b + 1]
        peaks.append({
            "start": round(start, 2), "end": round(end, 2),
            "score": round(float(seg.mean()), 2),
            "peak": round(float(seg.max()), 2),
        })
    return peaks


def classify_peaks(peaks: list[dict], transcript_path: str | None) -> None:
    """transcript と突き合わせて speech / nonverbal を貼り、近傍テキストを添える。"""
    segs: list[tuple[float, float, str]] = []
    if transcript_path and os.path.exists(transcript_path):
        with open(transcript_path, "r", encoding="utf-8") as f:
            tr = json.load(f)
        segs = [(float(s["start"]), float(s["end"]), str(s.get("text", "")).strip())
                for s in tr.get("segments", [])]
    for p in peaks:
        if not segs:
            p["kind"] = "unknown"
            continue
        covered = 0.0
        ctx = ""
        for s, e, text in segs:
            lo = max(p["start"], s - 0.2)
            hi = min(p["end"], e + 0.2)
            if hi > lo:
                covered += hi - lo
                if not ctx:
                    ctx = text
        ratio = covered / max(0.1, p["end"] - p["start"])
        p["kind"] = "speech" if ratio >= 0.35 else "nonverbal"
        if not ctx:
            # 発話が被らない (笑い等) → 直前の発話 = フリ/オチ を context に
            before = [t for t in segs if t[1] <= p["start"] + 0.3]
            if before:
                ctx = before[-1][2]
        p["context"] = ctx[:40]


def main() -> None:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser()
    ap.add_argument("--video", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--transcript", default=None,
                    help="transcript.json (speech/nonverbal 分類と context 用)")
    ap.add_argument("--top", type=int, default=15, help="残すピーク数 (score 降順)")
    ap.add_argument("--z", type=float, default=1.0, help="ピーク判定の z-score 閾値")
    ap.add_argument("--hop", type=float, default=0.25)
    ap.add_argument("--win", type=float, default=0.5)
    ap.add_argument("--merge-gap", type=float, default=0.6)
    ap.add_argument("--min-dur", type=float, default=0.5)
    args = ap.parse_args()

    x = extract_pcm(args.video)
    duration = len(x) / SR
    db = rms_db_curve(x, args.hop, args.win)
    if len(db) == 0:
        raise SystemExit("[energy] ERROR: audio too short")

    # ~1 秒の移動平均で平滑化
    k = max(1, int(round(1.0 / args.hop)))
    db_s = np.convolve(db, np.ones(k) / k, mode="same")

    # デジタル無音 (曲間等) を統計から除いて z-score 化
    active = db_s > db_s.max() - 45.0
    base = db_s[active] if active.any() else db_s
    z = (db_s - base.mean()) / max(1e-6, base.std())

    peaks = find_peaks(z, args.hop, args.win, args.z, args.merge_gap, args.min_dur)
    classify_peaks(peaks, args.transcript)
    peaks.sort(key=lambda p: p["score"], reverse=True)
    peaks = peaks[:args.top]
    peaks.sort(key=lambda p: p["start"])

    # 2 秒刻みの俯瞰カーブ (どの辺が全体的に熱いか)
    step = 2.0
    per = max(1, int(step / args.hop))
    n_b = len(z) // per
    curve = [round(float(z[i * per:(i + 1) * per].mean()), 1) for i in range(n_b)]

    result = {"peaks": peaks, "curve": {"step": step, "z": curve},
              "duration": round(duration, 2), "z_threshold": args.z}
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=1)
    kinds = {}
    for p in peaks:
        kinds[p.get("kind", "?")] = kinds.get(p.get("kind", "?"), 0) + 1
    print(json.dumps({"peaks": len(peaks), "kinds": kinds,
                      "duration": round(duration, 1), "out": args.out},
                     ensure_ascii=False))


if __name__ == "__main__":
    main()
