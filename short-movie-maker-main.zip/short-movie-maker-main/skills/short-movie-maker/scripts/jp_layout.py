"""日本語字幕レイアウトの純粋関数群 (videopocket-local から移植)。

- 禁則処理 (行頭の句読点禁止・助詞での行末終わり回避)
- 文字幅の重み付き見積もり (半角/小書き仮名を考慮)
- 分割禁止パターン (数量範囲・金額・日時)
- budoux 文節境界 + DP による 1〜2 行への最適改行

移植元: videopocket-local/packages/workflow-core (kinsoku.py / textwidth.py /
pattern_protection.py / layout_dp.py の考え方)。ElevenLabs/Gemini 依存はない。
"""

from __future__ import annotations

import re
from typing import Dict, List, Sequence, Set, Tuple

import budoux

_PARSER = budoux.load_default_japanese_parser()

# ---------------------------------------------------------------- kinsoku ---

HEAD_FORBIDDEN = set(")] }）】〙〛〉》」』、。.,!?！？:;・…")
TAIL_FORBIDDEN = set("([{（【〈《「『")
OPEN_QUOTES = set("『「（【《〈")
CLOSE_QUOTES = set("』」）)】〙〗〉》")
# 行末に来てほしくない助詞・接続語尾
LINE_SUFFIX_FORBIDDEN = set("はがをにとものでへやかのとてでしな")
CONNECTIVE_SUFFIX = set("てでしなく")
SENTENCE_END = set("。？！?.!…‥")
COMMA_LIKE = set("、，,;；：:")


def kinsoku_penalty(prev_last: str, next_first: str) -> float:
    """禁則違反のペナルティ (0=違反なし)。"""
    penalty = 0.0
    if next_first and next_first in HEAD_FORBIDDEN:
        penalty += 1.0
    if prev_last and prev_last in TAIL_FORBIDDEN:
        penalty += 1.0
    if (next_first and next_first in OPEN_QUOTES) or (prev_last and prev_last in OPEN_QUOTES):
        penalty += 0.5
    return penalty


def break_quality(prev_last: str, next_first: str) -> float:
    """改行位置の不自然さコスト (0=最良)。"""
    if not prev_last:
        return 0.4
    if prev_last in SENTENCE_END:
        return 0.0
    if prev_last in COMMA_LIKE:
        return 0.15
    if prev_last in LINE_SUFFIX_FORBIDDEN:
        return 0.8
    if prev_last in CONNECTIVE_SUFFIX:
        return 0.7
    if next_first and (next_first in CLOSE_QUOTES or next_first in COMMA_LIKE):
        return 0.2
    if prev_last in OPEN_QUOTES:
        return 0.7
    return 0.45


def page_end_quality(last_char: str, next_first: str | None) -> float:
    """ページ (字幕1枚) 終端の不自然さコスト (0=最良)。"""
    if not last_char:
        return 0.4
    if last_char in SENTENCE_END:
        return 0.0
    if last_char in LINE_SUFFIX_FORBIDDEN or last_char in CONNECTIVE_SUFFIX:
        return 0.9
    if last_char in CLOSE_QUOTES:
        return 0.1
    if last_char in OPEN_QUOTES:
        return 0.8
    if next_first and next_first in set("、。？！?.!」』）)］】》>"):
        return 0.3
    return 0.4


# -------------------------------------------------------------- textwidth ---

_WIDTH_WEIGHTS: Dict[str, float] = {
    "ascii_alnum": 0.55,
    "ascii_space": 0.30,
    "ascii_punct": 0.50,
    "cjk_punct": 0.50,
    "small_kana": 0.85,
    "long_dash": 0.90,
    "default": 1.00,
}


def _classify(ch: str) -> str:
    if ch == " ":
        return "ascii_space"
    if "0" <= ch <= "9" or "A" <= ch <= "Z" or "a" <= ch <= "z":
        return "ascii_alnum"
    code = ord(ch)
    if 0x3000 <= code <= 0x303F:
        return "cjk_punct"
    if ch in {"ー", "―"}:
        return "long_dash"
    if ch in {"ぁ", "ぃ", "ぅ", "ぇ", "ぉ", "ゃ", "ゅ", "ょ", "っ"}:
        return "small_kana"
    if ch in {"!", "?", ",", ".", "-", "'", '"'}:
        return "ascii_punct"
    return "default"


def glyph_width(text: str) -> float:
    """全角=1.0 基準の重み付き表示幅。"""
    return sum(_WIDTH_WEIGHTS.get(_classify(ch), 1.0) for ch in text)


# ----------------------------------------------------- pattern protection ---

PROTECTED_PATTERNS: Dict[str, re.Pattern] = {
    # 数量範囲 (漢数字): 三、四年 / 二〜三人
    "kanji_range": re.compile(
        r"[一二三四五六七八九十百千万億兆数]+"
        r"[、,〜～・\-]"
        r"[一二三四五六七八九十百千万億兆数]+"
        r"(?:[年月日時分秒個人回件本枚台杯匹頭羽冊軒棟畳坪歳才円])?"
    ),
    # 概数: 十数個 / 数百人
    "approx": re.compile(r"[一二三四五六七八九十百千]*数[十百千万億]*[年月日時分秒個人回件本枚台円]?"),
    # 数値+単位 (算用数字): 1,000円 / 3.5倍 / 100km
    "numeric_unit": re.compile(r"[0-9][0-9,.]*(?:[a-zA-Z%℃]+|[年月日時分秒個人回件本枚台円倍歳才])?"),
    # 575 のような数字並び
    "digits": re.compile(r"[0-9]{2,}"),
}


def forbidden_spans(text: str) -> List[Tuple[int, int]]:
    """行分割してはいけない文字範囲 [start, end) を返す。"""
    spans: List[Tuple[int, int]] = []
    for pat in PROTECTED_PATTERNS.values():
        for m in pat.finditer(text):
            if m.end() - m.start() >= 2:
                spans.append((m.start(), m.end()))
    return spans


def _crosses_forbidden(pos: int, spans: Sequence[Tuple[int, int]]) -> bool:
    return any(s < pos < e for s, e in spans)


# ------------------------------------------------------------- line break ---

def budoux_boundaries(text: str) -> List[int]:
    """budoux の文節境界 (分割してよい文字位置) を返す。"""
    bounds: List[int] = []
    pos = 0
    for chunk in _PARSER.parse(text):
        pos += len(chunk)
        if pos < len(text):
            bounds.append(pos)
    return bounds


def _mid_word_penalty(prev_last: str, next_first: str) -> float:
    """カタカナ語・英数字列の途中で割ることへの強いペナルティ。

    budoux は稀にカタカナ複合語 (「コンビニ」等) を途中で切る境界を返すため、
    候補に入っても選ばれないようコストで抑える。
    """
    def _kata(ch: str) -> bool:
        return "ァ" <= ch <= "ヶ" or ch == "ー"

    def _latin(ch: str) -> bool:
        return ch.isascii() and ch.isalnum()

    if _kata(prev_last) and _kata(next_first):
        return 2.0
    if _latin(prev_last) and _latin(next_first):
        return 2.0
    return 0.0


def break_two_lines(text: str, max_line: float = 16.0, target: float = 13.0) -> str:
    """テキストを 1〜2 行に最適改行して返す (改行は \\n)。

    - 幅 <= max_line なら 1 行のまま
    - 2 行に割る場合、budoux 境界のうち「バランス + 禁則 + 改行品質」の
      コスト最小の位置で割る (分割禁止パターンはまたがない)
    """
    text = text.strip()
    if not text:
        return text
    if glyph_width(text) <= max_line:
        return text

    spans = forbidden_spans(text)
    candidates = budoux_boundaries(text)
    # budoux 境界が無い/粗すぎる場合は全文字位置を候補にする (禁則で絞られる)
    if not candidates:
        candidates = list(range(1, len(text)))

    # max_line はソフト制約: 少しの超過 (〜12%) は減点で許容する。
    # render 側に行幅超過の自動フォント縮小があるため、僅かな超過よりも
    # 「カタカナ語の分断」や「極端な行バランス」を避ける方が読みやすい。
    hard_line = max_line * 1.12
    best_pos = None
    best_cost = float("inf")
    for pos in candidates:
        if _crosses_forbidden(pos, spans):
            continue
        left, right = text[:pos], text[pos:]
        wl, wr = glyph_width(left), glyph_width(right)
        if wl > hard_line or wr > hard_line:
            continue
        overflow = max(0.0, wl - max_line) + max(0.0, wr - max_line)
        cost = (
            abs(wl - wr) / max(target, 1.0)          # 2 行のバランス
            + kinsoku_penalty(left[-1], right[0]) * 2.0
            + break_quality(left[-1], right[0])
            + _mid_word_penalty(left[-1], right[0])
            + overflow * 1.5
        )
        if cost < best_cost:
            best_cost = cost
            best_pos = pos

    if best_pos is None:
        # 最終手段: 中央付近で禁則だけ避けて割る
        mid = len(text) // 2
        order = sorted(range(1, len(text)), key=lambda p: abs(p - mid))
        for pos in order:
            if _crosses_forbidden(pos, spans):
                continue
            if kinsoku_penalty(text[pos - 1], text[pos]) == 0:
                best_pos = pos
                break
        if best_pos is None:
            best_pos = mid
    return text[:best_pos] + "\n" + text[best_pos:]
