"""サムネイル生成 (M14): 指定フレーム + タイトル文字の PNG を作る。

ベストフレーム (表情のピーク等) は Claude が shots.py の代表フレームを見て選ぶ。

Usage:
  python make_thumb.py --video work/source.mp4 --time 123.4 \
      --title "3個選ぶならおにぎりの具は?" --out out/thumb_clip1.png
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import tempfile

from PIL import Image, ImageDraw, ImageFont

FONT_CANDIDATES = [
    r"C:\Windows\Fonts\BIZ-UDGothicB.ttc",
    r"C:\Windows\Fonts\meiryob.ttc",
    r"C:\Windows\Fonts\YuGothB.ttc",
]


def _font(size: int) -> ImageFont.FreeTypeFont:
    for p in FONT_CANDIDATES:
        if os.path.exists(p):
            return ImageFont.truetype(p, size)
    return ImageFont.load_default()


def main() -> None:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser()
    ap.add_argument("--video", required=True)
    ap.add_argument("--time", type=float, required=True, help="フレームの絶対秒")
    ap.add_argument("--title", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--size", default="1080x1920", help="出力サイズ WxH")
    args = ap.parse_args()

    w, h = (int(x) for x in args.size.split("x"))
    fd, tmp = tempfile.mkstemp(suffix=".png")
    os.close(fd)
    try:
        subprocess.run(
            ["ffmpeg", "-y", "-v", "error", "-ss", f"{args.time:.3f}",
             "-i", args.video, "-frames:v", "1", tmp],
            check=True, capture_output=True)
        src = Image.open(tmp).convert("RGB")
    finally:
        try:
            os.remove(tmp)
        except OSError:
            pass

    # cover で 9:16 (等) に切り出し
    scale = max(w / src.width, h / src.height)
    rs = src.resize((round(src.width * scale), round(src.height * scale)))
    x0 = (rs.width - w) // 2
    y0 = (rs.height - h) // 3  # やや上寄せ (顔が上半分に来やすい)
    img = rs.crop((x0, y0, x0 + w, y0 + h))

    # タイトル文字 (上部・黄色・黒縁取り。長ければ自動縮小)
    draw = ImageDraw.Draw(img)
    fs = int(w * 0.085)
    eff = sum(1.0 if ord(c) > 0xFF else 0.5 for c in args.title)
    fs = min(fs, int((w * 0.92) / max(eff, 1)))
    font = _font(fs)
    tw = draw.textlength(args.title, font=font)
    tx, ty = (w - tw) // 2, int(h * 0.06)
    for dx in range(-6, 7, 3):
        for dy in range(-6, 7, 3):
            draw.text((tx + dx, ty + dy), args.title, font=font, fill=(16, 16, 16))
    draw.text((tx, ty), args.title, font=font, fill=(255, 240, 0))

    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
    img.save(args.out)
    print(json.dumps({"thumb": args.out, "time": args.time}, ensure_ascii=False))


if __name__ == "__main__":
    main()
