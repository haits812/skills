"""話者分離を既存 transcript.json に重ねる (pyannote、完全ローカル・GPU)。

設計: 文字起こしは faster-whisper (transcribe.py) の細かい segment/word を活かし、
pyannote の話者ターン (start,end,speaker) を時間重なりで各 word に貼るだけにする。
WhisperX の transcribe を丸ごと置き換えると VAD が話者をまたぐ巨大 segment を作り
字幕分割に不利なので、この「オーバーレイ」方式を採る。

入力 : transcribe.py が出した transcript.json + 元動画
出力 : 同じ transcript.json に各 word/segment の "speaker" を追記して上書き
        (segment.speaker は含まれる word の多数決)

話者分離は pyannote/speaker-diarization-3.1 (gated) を使うため HF トークンが要る。
env HF_TOKEN → skill/scripts/.hf_token → 既存GUI設定 の順で探す。

Usage:
  python diarize.py --video work/source.mp4 --transcript work/transcript.json \
      [--num-speakers 2]   # 話者数が既知なら渡すと安定 (太田上田=2 等)
"""

from __future__ import annotations

import argparse
import functools
import json
import os
import sys
from collections import Counter
from typing import List, Optional, Tuple

import torch

# PyTorch 2.6+ の weights_only 既定 True で pyannote チェックポイントが読めない対策。
_ORIG_LOAD = torch.load
torch.load = functools.wraps(_ORIG_LOAD)(
    lambda *a, **k: _ORIG_LOAD(*a, **{**k, "weights_only": False}))


def load_token() -> Optional[str]:
    tok = os.environ.get("HF_TOKEN") or os.environ.get("HUGGING_FACE_HUB_TOKEN")
    if tok:
        return tok.strip()
    here = os.path.dirname(os.path.abspath(__file__))
    # .hf_token (スキル同梱) を第一に、任意で WHISPERX_CONFIG 環境変数が指す
    # JSON からも読む。機種依存の絶対パスはハードコードしない。
    extra = os.environ.get("WHISPERX_CONFIG")
    for path in [os.path.join(here, ".hf_token")] + ([extra] if extra else []):
        if not path or not os.path.exists(path):
            continue
        try:
            raw = open(path, "r", encoding="utf-8").read().strip()
            return json.loads(raw).get("hf_token") if path.endswith(".json") else raw
        except Exception:
            continue
    return None


def run_diarization(video: str, token: str, num_speakers: Optional[int]
                    ) -> List[Tuple[float, float, str]]:
    """pyannote で話者ターンを検出し (start, end, speaker) のリストを返す。"""
    import whisperx
    from whisperx.diarize import DiarizationPipeline

    device = "cuda" if torch.cuda.is_available() else "cpu"
    audio = whisperx.load_audio(video)
    dia = DiarizationPipeline(use_auth_token=token, device=device)
    df = dia(audio, num_speakers=num_speakers) if num_speakers else dia(audio)
    turns = [(float(r["start"]), float(r["end"]), str(r["speaker"]))
             for _, r in df.iterrows()]
    turns.sort(key=lambda t: t[0])
    return turns


def speaker_at(t0: float, t1: float, turns: List[Tuple[float, float, str]]) -> Optional[str]:
    """時間区間 [t0,t1] と最も重なる話者ターンの speaker を返す。"""
    mid = (t0 + t1) / 2.0
    best, best_ov = None, 0.0
    for s, e, spk in turns:
        ov = min(t1, e) - max(t0, s)
        if ov > best_ov:
            best_ov, best = ov, spk
    if best is not None:
        return best
    # 重なりゼロなら中点に最も近いターン
    near, near_d = None, 1e9
    for s, e, spk in turns:
        d = 0.0 if s <= mid <= e else min(abs(mid - s), abs(mid - e))
        if d < near_d:
            near_d, near = d, spk
    return near


def main() -> None:
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser()
    ap.add_argument("--video", required=True)
    ap.add_argument("--transcript", required=True)
    ap.add_argument("--num-speakers", type=int, default=None,
                    help="話者数が既知なら指定すると安定 (例: 太田上田=2)")
    args = ap.parse_args()

    token = load_token()
    if not token:
        raise SystemExit(
            "HF トークンが見つかりません。env HF_TOKEN か skill/scripts/.hf_token を用意してください。")

    with open(args.transcript, "r", encoding="utf-8") as f:
        transcript = json.load(f)

    sys.stderr.write("[diarize] running pyannote...\n")
    turns = run_diarization(args.video, token, args.num_speakers)
    spk_set = sorted({spk for _, _, spk in turns})
    sys.stderr.write(f"[diarize] {len(turns)} turns, {len(spk_set)} speakers: {spk_set}\n")

    # 各 word に speaker を貼り、segment は word 多数決
    for seg in transcript.get("segments", []):
        words = seg.get("words") or []
        seg_spks: List[str] = []
        for w in words:
            if "start" not in w or "end" not in w:
                continue
            spk = speaker_at(float(w["start"]), float(w["end"]), turns)
            w["speaker"] = spk
            if spk:
                seg_spks.append(spk)
        if seg_spks:
            seg["speaker"] = Counter(seg_spks).most_common(1)[0][0]
        else:
            seg["speaker"] = speaker_at(float(seg["start"]), float(seg["end"]), turns)

    # 話者ラベルを見やすい連番に正規化 (SPEAKER_00→A, 01→B, ...)
    label_map = {spk: chr(ord("A") + i) for i, spk in enumerate(spk_set)}
    for seg in transcript.get("segments", []):
        if seg.get("speaker") in label_map:
            seg["speaker"] = label_map[seg["speaker"]]
        for w in seg.get("words") or []:
            if w.get("speaker") in label_map:
                w["speaker"] = label_map[w["speaker"]]
    transcript["speakers"] = list(label_map.values())

    with open(args.transcript, "w", encoding="utf-8") as f:
        json.dump(transcript, f, ensure_ascii=False, indent=2)
    sys.stderr.write(f"[diarize] wrote speakers into {args.transcript}\n")
    print(json.dumps({"speakers": list(label_map.values()),
                      "turns": len(turns), "transcript": args.transcript}, ensure_ascii=False))


if __name__ == "__main__":
    main()
