# short-movie-maker

解説・雑談系の長尺動画 (ローカルファイル or YouTube URL) から、YouTube Shorts 用の
縦型完成ショート動画 (9:16・60 秒以内) を複数本、全自動で生成する Claude Code Skill。

Whisper 文字起こし → 切り抜き箇所の選定 → 不要箇所カット → 顔検出ズーム →
派手な切り抜き風テロップ・タイトル帯・背景テンプレ合成までを一気通貫で行う。

## 特長

- **入力**: ローカル動画ファイル or YouTube URL (yt-dlp)
- **出力**: `out/` に複数本の完成 `.mp4` (各 9:16・60 秒以内・音声同期焼き込み字幕)
- **冒頭オプションメニュー (M1〜M7)**: 顔追跡 / 無音・フィラーカット / 外国語の見せ方 /
  吹き替えの声・口調 / 候補本数 / テロップのテイスト / 尺 を実行開始時に選択
  (全部推奨のままなら従来どおりワンショットで完走)
- **外国語対応**: 英語等の素材を「日本語翻訳字幕」または
  「ずんだもん吹き替え (VOICEVOX・原音ダッキング)」で日本語話者向けに加工
- **GPU 優先**: 文字起こしは CUDA、レンダは h264_nvenc (NVENC)。
  使えない環境は自動で CPU フォールバック

## 構成

```
skills/short-movie-maker/   (インストール先: ~/.claude/skills/short-movie-maker/)
  SKILL.md            Skill 本体 (Claude が読むオーケストレーション手順書)
  scripts/
    fetch.py          入力 (パス/URL) を正規化しローカル mp4 を得る
    transcribe.py     faster-whisper で word-level 文字起こし
    facetrack.py      顔検出で話者の水平位置を時系列推定 (縮小検出で高速化)
    render.py         clips.json を受けて 9:16 完成 mp4 を合成 (NVENC/ダッキング)
    dub.py            VOICEVOX でずんだもん吹き替え音声を合成 (台詞重なり自動防止)
    contact_sheet.py  全候補のサムネ+尺+タイトル一覧を生成
    make_templates.py 背景テンプレ PNG を生成
    make_sample.py / realistic_face.py  検証用サンプル生成
  templates/          背景テンプレ 4 種 (dark_neon / sunset / pop_blue / warm_paper)
  contexts/           options.md (デフォルト設定チェック表) / glossary.md (固有名詞辞書)
  eval/               goal.json (確定ゴール / scene_contract) と goal-v1.json (履歴)
```

## 前提環境 (Windows)

`ffmpeg` (NVENC 対応) / `ffprobe` / `faster-whisper` (CUDA) / `yt-dlp` /
`opencv-python` / `Pillow` / Python 3.12 / VOICEVOX (吹き替え利用時)。

## 使い方

Claude Code から Skill として起動する。動画パス or YouTube URL を 1 つ渡すだけで、
文字起こし → 切り抜き選定 → カット → 合成 → 候補一覧提示まで自動で走る。

```
「この動画をショートにして <パス>」
「この URL からショート量産して <YouTube URL>」
「英語のこの動画を日本語字幕/ずんだもん吹き替えでショートにして」
```

> 作業ディレクトリ (`work*/`) とレンダ出力 (`out*/`) は巨大なため `.gitignore` 済み。
> リポジトリには Skill 本体と設計ドキュメントのみを含む。
