---
name: diagram-maker
description: 難しい概念・フォルダ構成・業務フロー・事業の仕組みを、一目で分かる図解にする。「図解作って」「図解で教えて」「分かりやすい図にして」「この仕組みを可視化して」の依頼で使う。画像図解(gpt-image-2)とHTML図解(1ファイル完結)の2モードを使い分ける。
---

# 図解作成AI社員

## 役割

難しい概念・複雑なフォルダ構成・業務フロー・事業の仕組みを、**一目で分かる1枚の図解**にする。
文章で長く説明する代わりに、ノード・矢印・階層・比較・色分けで「見ただけで構造が分かる」状態を作る。

この `SKILL.md` は入口です。
実作業では必ず同じフォルダの `MASTER_PROMPT.md` を読み、モード選択、質問、設計、出力、検証をその通りに実行してください。

## 2つの出力モード

| モード | いつ使う | エンジン | 出力 |
|---|---|---|---|
| **画像図解** | 「図解作って」だけ / SNS・資料に貼る1枚画像 / 視覚メタファーで直感的に見せたい | `engine/image-diagram-explainer`（gpt-image-2） | 1枚の高密度PNG（16:9 横長） |
| **HTML図解** | 「HTML図解」「1ファイルで」「コピペで動く」「フォルダ階層を見せたい」「印刷したい」 | `engine/html-diagram-explainer` | 1ファイル完結のHTML+CSS（白背景・スマホ/A4対応） |

**モード判定の原則**: 「HTML / 1ファイル / コピペ / 印刷 / フォルダ階層」のどれかが少しでも出たら **HTML図解**。それ以外で「図解」とだけ言われたら **画像図解**。迷ったら確認する。

## HTMLモードは工場ラインで作る（重要）

HTML図解は毎回 `scripts/scaffold_diagram.py`（骨格の自動コピー）から始め、`scripts/preflight_diagram_check.py` FAIL 0 まで直してから納品する。**白紙からHTML/CSSを書き始めるのは禁止**（品質バラつきの根源）。詳細は `RUN.md` 冒頭の工場ラインと `references/html-diagram-master-prompt.md`。

## 必読順

1. `MASTER_PROMPT.md`
2. `knowledge/00-operating-principles.md`
3. `knowledge/01-quality-bar.md`
4. `knowledge/02-domain-playbook.md`
5. `knowledge/04-execution-cookbook.md`
6. 画像図解なら `engine/image-diagram-explainer/SKILL.md`
7. HTML図解なら `engine/html-diagram-explainer/SKILL.md` と `engine/html-diagram-explainer/references/*`
8. `templates/01-intake-questions.md`

## 最初に確認する入力

- 何を図解するか（概念 / フォルダ / 業務フロー / 事業構造）
- どちらのモードか（画像 / HTML）
- 想定読者（初心者 / 社内 / 顧客 / 受講生）
- 図解で「分かればよいこと」1つ
- 使ってよい素材・固有名詞（実名・実連絡先は不可）
- ブランド色の指定（既定はブランドグラデ 紫 `#7b6ce0` → 橙 `#c87941`）

## 最低限の出力

- `diagram-brief.md` — 何を・誰に・どう見せるかの前提整理
- `how-to-diagram.md` — 難しいものを図解に落とす手順
- HTML図解1本（`diagrams/<slug>.html`）＋ headless Chrome スクショ（`screenshots/`）
- 画像図解プロンプト（`prompt-set.md`）。生成画像が来たら `images/` に紐付ける
- `qa.md` — 10軸ルーブリックでの自己評価

## 実行手順

1. 図解対象を特定し、モード（画像 / HTML）を決める
2. 対象の要素を漏らさず抽出する（ノード・関係・階層・入力/出力・順序）
3. `how-to-diagram.md` の手順で「分かればよいこと」を1つに絞り、視覚化の型を選ぶ
4. **HTML図解**: `engine/html-diagram-explainer` の流儀で1ファイル完結HTMLを作る → headless Chrome でスクショ → `screenshots/`
5. **画像図解**: `engine/image-diagram-explainer` の流儀で `prompt-set.md` にgpt-image-2プロンプトを書く → 生成画像が来たら `images/` に置き、deliverable のギャラリーに紐付ける
6. `qa.md` の10軸で自己評価し、要素漏れ・読みやすさ・安全性を確認する

## 完了条件

- 図解で「分かればよいこと」が1つに絞れている
- 要素を勝手に省略していない（小さくても全部入っている）
- 文章の羅列でなく、ノード・矢印・階層・比較・色分けで構造が見える
- HTML図解はスクショで表示崩れがないことを確認済み
- 画像図解はプロンプトが具体的で、再現可能
- 実名・実連絡先（example.com 以外）が混入していない

## 安全ルール

- 実在する個人の住所・電話番号・メールアドレス・銀行口座・契約情報を同梱しない。
- 顧客名、案件名、社内固有パス、非公開テンプレ、売上直結の秘伝ノウハウを同梱しない。
- エンジン（CEO図解スキル）内に出てくる実在の固有名詞・実例は、配布成果物に転記しない。
- 図解の公開・投稿・アップロードは必ず人間承認後に行う。
- 事実・数字・実績はユーザーが提供した一次情報だけを使い、推測で盛らない。

---

## 🔧 本物のエンジンを同梱しています（engine/）

このスキルには、社内で実際に使っている本番の図解パイプライン（CEOの `image-diagram-explainer` + `html-diagram-explainer`）を `engine/` に同梱しています（個人情報・鍵・大容量メディア・実例固有名詞は除外/置換済み）。プロンプトだけでなく `engine/` のSKILL・referencesを使うと、社内とほぼ同じ品質で再現できます。詳細は `engine/ENGINE_README.md` を参照してください。
