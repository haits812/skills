# 04-execution-cookbook.md — 図解作成AI社員

## このAI社員の完成フォルダ例

```text
YYYY-MM-DD_task-name/
├── diagram-brief.md       … 何を・誰に・どう見せるかの前提整理
├── how-to-diagram.md      … 難しいものを図解に落とす手順
├── diagrams/
│   └── <slug>.html        … HTML図解（1ファイル完結）
├── screenshots/
│   ├── <slug>-desktop.png … headless Chrome 全体スクショ
│   └── <slug>-mobile.png  … 狭幅スクショ
├── images/
│   └── diagram-*.png       … gpt-image-2 で生成した画像図解
├── prompt-set.md          … 画像図解の gpt-image-2 プロンプト
└── qa.md                  … 10軸ルーブリックでの自己評価
```

## 入力から図解へ変換する順番

1. 図解対象とモード（画像/HTML）を決める。
2. 対象の要素を全部読む（フォルダなら `SKILL.md` / `_RULE.md`、概念なら定義と関係）。
3. 要素を `ノード`・`関係(矢印)`・`階層`・`入力/出力`・`順序` に分ける。
4. 「この図解1枚で何が分かればよいか」を1つに絞る。
5. 対象に合う視覚化の型を選ぶ（domain-playbook の型カタログ参照）。
6. 視線の流れと色の意味を固定する。
7. 制作する（HTMLを書く / 画像プロンプトを書く）。
8. HTMLは headless Chrome でスクショ。画像はプロンプトを `prompt-set.md` に残す。
9. 安全チェック（実名・実連絡先・実例固有名詞なし）と再現メモを残す。

## headless Chrome でHTML図解をスクショする

macOS の Google Chrome を headless で使う。

```bash
CHROME="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
OUT="<出力フォルダ>"
# デスクトップ全体（縦に長い図解も全体を撮る）
"$CHROME" --headless --disable-gpu --hide-scrollbars \
  --window-size=1280,2400 --screenshot="$OUT/screenshots/<slug>-desktop.png" \
  "file://$OUT/diagrams/<slug>.html"
# モバイル幅（1カラム化の確認）
"$CHROME" --headless --disable-gpu --hide-scrollbars \
  --window-size=390,2400 --screenshot="$OUT/screenshots/<slug>-mobile.png" \
  "file://$OUT/diagrams/<slug>.html"
```

`--window-size` の高さは図解の縦長さに合わせる。全体が入らない場合は高さを増やす。

## HTML図解の検証

```bash
python3 -c "import html.parser,sys; html.parser.HTMLParser().feed(open('<file>').read()); print('OK')"
rg -n "<script|@import|https?://|cdn|fonts.googleapis" <file> || echo "外部参照なし"
```

## 画像図解プロンプトの型（gpt-image-2）

```text
用途: infographic-diagram。16:9 横長（3840x2160 推奨）。
テーマ: <図解したい概念/仕組み>。
読者: <初心者/社内/顧客>。
入れる要素（省略しない）: <要素を全部列挙>。
構図: <左上→右下の流れ / 中央ハブ＋放射 / 上位→下位の階層 など>。
視覚メタファー: <城/工場/橋/金庫 など内容に合うもの>。
比較: <良い例=緑チェック / 悪い例=赤バツ など>。
色: ブランドグラデ 紫 #7b6ce0 → 橙 #c87941 を基調、背景は明るい白〜淡い空色。
文字: 日本語中心。固有名詞・番号は正確に。見出し大きく、詳細は短いラベル。
禁止: 過度な装飾・ネオン・意味のない抽象背景・文字だけのカード羅列。
```

## レビュー質問

- この図解1枚で何が分かるか、1文で言えるか。
- 要素を省略していないか。
- 文章でなく、ノード・矢印・階層・比較で構造が見えるか。
- 30秒で全体像をつかめるか。文字は潰れていないか。
- 実名・実連絡先・実例固有名詞が混ざっていないか。
- 効いた視覚化の型を次回再現できる形で残したか。

## 引き継ぎ文テンプレ

```md
図解できました。

- HTML図解: diagrams/<slug>.html（スクショ: screenshots/<slug>-desktop.png）
- 画像図解プロンプト: prompt-set.md（生成画像: images/diagram-*.png）

判断ポイント:
- モード: <画像/HTML> を選んだ理由
- 視覚化の型: <選んだ型>

未確認:
-

次にやるなら:
-
```

## 失敗時の立て直し

- 何を伝えたいか不明: 「分かればよいこと」を1つに絞り直す。
- 図解に見えない: 文章カードを削り、ノード・矢印・階層・比較に置き換える。
- 密度過多で読めない: レイヤー分け・色の意味固定・余白を増やす。見出しと詳細の大小差をつける。
- HTMLが崩れる: スクショを見てCSSを直す。スマホ幅で1カラムになるか確認。
- 画像が再現できない: プロンプトに全要素・構図・色・メタファーを明記する。
