#!/usr/bin/env python3
"""HTML図解の機械QAゲート（07-html-diagram-explainer P4）。

diagram.html と付随3点セットを検査し、FAIL 0 件で exit 0。
FAIL が1件でも残る図解は納品してはいけない。

2つの承認骨格を自動判別して検査する:
  - structure型: assets/design-skeleton.html 由来（OD-TOKENS マーカーで判別）
  - flow型:      output/reusable/flow-timeline-ball-ownership-template.html 由来
                 （「タイムライン×ボール所在型」マーカーで判別）
どちらの骨格でもないHTMLは FAIL（白紙CSSから書いた図解は不合格）。

使い方:
    python3 scripts/preflight_diagram_check.py --dir "output/archive/2026-07-05_line-reply-flow"
    python3 scripts/preflight_diagram_check.py --html path/to/diagram.html   # 単体HTMLだけ検査
    オプション:
      --require-tree      階層ツリー欠落をFAILに昇格（フォルダ・成果物を扱う図解）
      --require-timeline  実働タイムライン欠落をFAILに昇格（AI社員・スキル・フロー説明。flow型は自動合格）
      --min-patterns N    structure型の data-pattern 最低種類数（既定5）

前提: python3 標準ライブラリのみ。
"""

import argparse
import re
import sys
from html.parser import HTMLParser
from pathlib import Path

SKILL_DIR = Path(__file__).resolve().parent.parent
SKELETON_STRUCTURE = SKILL_DIR / "assets" / "design-skeleton.html"
SKELETON_FLOW = SKILL_DIR / "output" / "reusable" / "flow-timeline-ball-ownership-template.html"

STRUCTURE_MARKER = "OD-TOKENS v1 START"
FLOW_MARKER = "タイムライン×ボール所在型"

STRUCTURE_DEFAULT_TITLE = "HTML図解デザイン骨格 v1（このタイトルは必ず案件名に差し替える）"
FLOW_DEFAULT_TITLE = "フロー図解 標準テンプレート — タイムライン×ボール所在型（見本: ローンチ工場 実働フロー）"

REQUIRED_TOKENS_STRUCTURE = [
    "--ink:", "--sub:", "--line:", "--paper:", "--blue:", "--green:",
    "--orange:", "--red:", "--purple:", "--shadow:",
]
REQUIRED_BLOCKS_STRUCTURE = ["hero", "key-points", "caution", "today", "edit-notes", "changelog"]

VOID_TAGS = {
    "area", "base", "br", "col", "embed", "hr", "img", "input",
    "link", "meta", "param", "source", "track", "wbr",
}


class TagBalanceChecker(HTMLParser):
    """開始/終了タグの対応だけを緩く検査する。"""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.stack = []
        self.errors = []

    def handle_starttag(self, tag, attrs):
        if tag not in VOID_TAGS:
            self.stack.append((tag, self.getpos()[0]))

    def handle_endtag(self, tag):
        if tag in VOID_TAGS:
            return
        if not self.stack:
            self.errors.append(f"L{self.getpos()[0]}: 対応する開始タグのない </{tag}>")
            return
        if self.stack[-1][0] == tag:
            self.stack.pop()
            return
        # 少し遡って探す（liの省略などHTMLの緩さを許容）
        for i in range(len(self.stack) - 1, -1, -1):
            if self.stack[i][0] == tag:
                del self.stack[i:]
                return
        self.errors.append(f"L{self.getpos()[0]}: 対応する開始タグのない </{tag}>")


def extract_od_token_block(text: str) -> str:
    """structure型のトークン正本ブロック（マーカー間）を正規化して返す。"""
    m = re.search(r"OD-TOKENS v1 START(.*?)OD-TOKENS v1 END", text, re.S)
    if not m:
        return ""
    body = re.sub(r"/\*.*?\*/", "", m.group(1), flags=re.S)
    return re.sub(r"\s+", "", body)


def extract_root_block(text: str) -> str:
    """flow型の :root{...} を正規化して返す。"""
    m = re.search(r":root\s*\{(.*?)\}", text, re.S)
    if not m:
        return ""
    return re.sub(r"\s+", "", m.group(1))


def check_common(text: str, fails: list, warns: list, passes: list) -> None:
    """骨格系統に関係ない共通検査。"""
    checker = TagBalanceChecker()
    checker.feed(text)
    checker.close()
    leftovers = [t for t in checker.stack if t[0] not in ("html", "body", "head")]
    if checker.errors or leftovers:
        for e in checker.errors[:5]:
            fails.append(f"タグ対応: {e}")
        for tag, line in leftovers[:5]:
            fails.append(f"タグ対応: L{line}: 閉じられていない <{tag}>")
    else:
        passes.append("タグ対応OK")

    ext = re.findall(r"https?://[^\s\"'<>)]+", text)
    if ext:
        fails.append(f"外部URLが {len(ext)} 件ある（例: {ext[0][:60]}）。1ファイル完結が原則")
    else:
        passes.append("外部URLなし")
    for pat, name in [
        (r"<script", "<script>"),
        (r"@import", "@import"),
        (r"fonts\.googleapis", "Webフォント"),
        (r"<link[^>]+stylesheet", "外部CSS"),
        (r"<img\b", "<img>（画像はインラインSVG・絵文字で描く）"),
    ]:
        if re.search(pat, text, re.I):
            fails.append(f"禁止要素あり: {name}")

    if 'lang="ja"' not in text:
        warns.append('lang="ja" がない')
    if re.search(r"<meta[^>]+charset", text, re.I) is None:
        fails.append("charset メタがない")
    if re.search(r"<meta[^>]+viewport", text, re.I) is None:
        fails.append("viewport メタがない（スマホ対応必須）")
    if "@media print" not in text:
        fails.append("@media print がない（A4印刷対応必須）")
    if re.search(r"@media\s*\(max-width", text) is None:
        fails.append("@media (max-width) がない（スマホ幅対応必須）")

    m = re.search(r'diagram-status"\s+content="([^"]+)"', text)
    if not m:
        fails.append('meta name="diagram-status" がない（scaffoldで骨格をコピーして始める）')
    elif m.group(1) != "FILLED":
        fails.append(f"diagram-status が {m.group(1)}（完成時に FILLED へ変える）")

    body_text = re.sub(r"<style.*?</style>", "", text, flags=re.S)
    body_text = re.sub(r"<!--.*?-->", "", body_text, flags=re.S)
    body_text = re.sub(r"<[^>]+>", "", body_text)
    body_text = re.sub(r"\s+", "", body_text)
    if len(body_text) < 1200:
        fails.append(f"本文テキストが {len(body_text)} 文字と少なすぎる（要点・注意点・説明を入れる）")


def check_structure(text: str, args, fails: list, warns: list, passes: list) -> None:
    """structure型（design-skeleton.html 由来）の検査。"""
    missing = [t for t in REQUIRED_TOKENS_STRUCTURE if t not in text]
    if missing:
        fails.append(f"必須トークン欠落: {', '.join(missing)}")
    if SKELETON_STRUCTURE.exists():
        skel_block = extract_od_token_block(SKELETON_STRUCTURE.read_text(encoding="utf-8"))
        if skel_block and extract_od_token_block(text) != skel_block:
            fails.append("トークン定義が骨格正本と一致しない（OD-TOKENSは1文字も編集禁止）")
        else:
            passes.append("トークン正本一致（structure骨格）")
    else:
        warns.append(f"骨格正本が見つからず一致検査をスキップ: {SKELETON_STRUCTURE}")

    tm = re.search(r"<title>(.*?)</title>", text, re.S)
    if not tm or not tm.group(1).strip():
        fails.append("<title> がない")
    elif STRUCTURE_DEFAULT_TITLE in tm.group(1):
        fails.append("<title> が骨格デモのまま（案件名に差し替える）")

    blocks = set(re.findall(r'data-block="([^"]+)"', text))
    missing_blocks = [b for b in REQUIRED_BLOCKS_STRUCTURE if b not in blocks]
    if missing_blocks:
        fails.append(f"必須ブロック欠落: {', '.join(missing_blocks)}")
    else:
        passes.append(f"必須ブロック{len(REQUIRED_BLOCKS_STRUCTURE)}種OK")
    patterns = set(re.findall(r'data-pattern="([^"]+)"', text))
    if len(patterns) < args.min_patterns:
        fails.append(f"図解形式が {len(patterns)} 種類（{args.min_patterns}種類以上を混ぜる）: {sorted(patterns)}")
    else:
        passes.append(f"図解形式 {len(patterns)} 種類")

    svg_count = len(re.findall(r"<svg\b", text))
    if svg_count < 3:
        fails.append(f"インラインSVGが {svg_count} 個（3個以上。ヒーローのイラストは必須）")
    else:
        passes.append(f"インラインSVG {svg_count} 個")

    if 'class="tree"' not in text and "pre.tree" not in text:
        (fails if args.require_tree else warns).append(
            "階層ツリーがない（フォルダ・成果物を扱う図解では必須）"
        )

    if "timeline" not in patterns:
        (fails if args.require_timeline else warns).append(
            '実働タイムラインがない（AI社員・スキル・フローの説明図解では必須。data-pattern="timeline" か flow型骨格を使う）'
        )

    size = len(text.encode("utf-8"))
    if size < 25000:
        warns.append(f"ファイルが {size:,} bytes と小さい（内容が薄い可能性。骨格だけで約30KB）")


def check_flow(text: str, args, fails: list, warns: list, passes: list) -> None:
    """flow型（タイムライン×ボール所在型テンプレ由来）の検査。"""
    if SKELETON_FLOW.exists():
        skel_root = extract_root_block(SKELETON_FLOW.read_text(encoding="utf-8"))
        if skel_root and extract_root_block(text) != skel_root:
            fails.append("フロー骨格の :root トークンが正本と一致しない（配色の勝手な変更は禁止）")
        else:
            passes.append("トークン正本一致（flow骨格）")
    else:
        warns.append(f"フロー骨格正本が見つからず一致検査をスキップ: {SKELETON_FLOW}")

    tm = re.search(r"<title>(.*?)</title>", text, re.S)
    if not tm or not tm.group(1).strip():
        fails.append("<title> がない")
    elif FLOW_DEFAULT_TITLE in tm.group(1):
        fails.append("<title> がテンプレのまま（案件名に差し替える）")

    # 型の3原則が守られているか（縦タイムライン・4色ボール所在・ゲート）
    beat_count = len(re.findall(r'class="beat ', text))
    if 'class="flow"' not in text:
        fails.append("縦タイムライン（.flow）がない（この型の原則1）")
    if beat_count < 6:
        fails.append(f".beat（工程カード）が {beat_count} 個（6個以上で流れを見せる）")
    else:
        passes.append(f".beat {beat_count} 個")
    actor_kinds = {k for k in ("ichi", "ai", "script", "dele") if f'class="beat {k}"' in text}
    if len(actor_kinds) < 3:
        fails.append(f"ボール所在の色が {len(actor_kinds)} 種類（ichi/ai/script は最低限使う）: {sorted(actor_kinds)}")
    else:
        passes.append(f"ボール所在 {len(actor_kinds)} 色")
    if 'class="gate"' not in text:
        fails.append("🚪ゲートバンド（.gate）がない（人間が止まる場所を必ず見せる）")
    if 'class="legend"' not in text:
        fails.append("登場人物の凡例（.legend）がない")
    if 'class="map"' not in text:
        warns.append("冒頭の全体ミニマップ（.map）がない（長いフローでは必須）")

    if len(re.findall(r'class="caution"', text)) < 3:
        fails.append("注意点（.caution）が3個未満")
    if 'class="today"' not in text:
        fails.append("今日の一歩（.today）がない")
    if 'class="hist"' not in text:
        fails.append("更新履歴（.hist）がない")
    if 'class="edit-box"' not in text:
        warns.append("編集メモ（.edit-box）がない")

    if args.require_tree and 'class="tree"' not in text and "pre.tree" not in text:
        fails.append("階層ツリーがない（フォルダ・成果物を扱う図解では必須）")
    # flow型は文書全体がタイムラインなので --require-timeline は自動合格


def main() -> int:
    parser = argparse.ArgumentParser(description="HTML図解の機械QAゲート")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--dir", help="案件フォルダ（diagram.html + source-map.md + prompt.md）")
    group.add_argument("--html", help="diagram.html 単体を検査")
    parser.add_argument("--require-tree", action="store_true", help="階層ツリー欠落をFAILにする")
    parser.add_argument("--require-timeline", action="store_true",
                        help="実働タイムライン欠落をFAILにする（AI社員・スキル・フローの説明図解で必須）")
    parser.add_argument("--min-patterns", type=int, default=5,
                        help="structure型の data-pattern 最低種類数（既定5）")
    args = parser.parse_args()

    fails, warns, passes = [], [], []

    if args.dir:
        workdir = Path(args.dir)
        html_path = workdir / "diagram.html"
    else:
        html_path = Path(args.html)
        workdir = None

    if not html_path.exists():
        print(f"FAIL: HTMLが見つからない: {html_path}")
        return 1
    text = html_path.read_text(encoding="utf-8")

    # 骨格系統の判別（第一候補: 身分証メタ。旧成果物向けフォールバック: 骨格固有マーカー）
    sk = re.search(r'diagram-skeleton"\s+content="([a-z]+)-v\d+"', text)
    if sk and sk.group(1) in ("structure", "flow"):
        mode = sk.group(1)
    elif STRUCTURE_MARKER in text:
        mode = "structure"
    elif FLOW_MARKER in text:
        mode = "flow"
    else:
        mode = None

    check_common(text, fails, warns, passes)

    if mode == "structure":
        passes.append("骨格系統: structure（design-skeleton.html）")
        check_structure(text, args, fails, warns, passes)
    elif mode == "flow":
        passes.append("骨格系統: flow（タイムライン×ボール所在型）")
        check_flow(text, args, fails, warns, passes)
    else:
        fails.append(
            "承認骨格のどちらでもない（OD-TOKENSマーカーもフロー型マーカーもない）。"
            "scaffold_diagram.py --type structure/flow で骨格コピーから作り直す"
        )

    # 3点セット
    if workdir is not None:
        for name in ("source-map.md", "prompt.md"):
            p = workdir / name
            if not p.exists():
                fails.append(f"{name} がない（3点セット必須）")
            elif len(p.read_text(encoding="utf-8").strip()) < 120:
                warns.append(f"{name} がほぼ空（読んだ正本・判断理由まで書く）")
        source_map = workdir / "source-map.md"
        if source_map.exists() and "（ここに読んだファイルと要点を書く）" in source_map.read_text(encoding="utf-8"):
            fails.append("source-map.md がテンプレのまま（読んだファイルを記録する）")

    # 結果出力
    print(f"=== preflight_diagram_check: {html_path} ===")
    for msg in passes:
        print(f"  PASS  {msg}")
    for msg in warns:
        print(f"  WARN  {msg}")
    for msg in fails:
        print(f"  FAIL  {msg}")
    print(f"--- PASS {len(passes)} / WARN {len(warns)} / FAIL {len(fails)} ---")
    if fails:
        print("FAILを全て解消するまで納品しない（自己修正して再実行）。")
        return 1
    print("合格: ブラウザで開いて目視確認へ。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
