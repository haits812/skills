#!/usr/bin/env python3
"""HTML図解の案件骨格を生成する（07-html-diagram-explainer P0）。

承認済みデザイン骨格をコピーして
output/archive/YYYY-MM-DD_<slug>/ に diagram.html / source-map.md / prompt.md を作る。

骨格は原則1系統（v1.3 / 2026-07-05 依頼者裁定）:
    structure: assets/design-skeleton.html（既定・これだけ使う）
               リッチ骨格。構造・提案・流れ系すべて対応
               （流れ系はタイムライン部品 tl-* / touch-row を主役にする）
    flow:      レガシー互換のみ。依頼者の明示指定なしに使わない
               （旧軽量テンプレ。v1.3で「品質が低い」と差し戻されたため降格）

使い方:
    python3 scripts/scaffold_diagram.py --slug line-reply-flow --title "LINE返信フロー図解"
    python3 scripts/scaffold_diagram.py --slug test --title "テスト" --dest /tmp/somewhere  # テスト用

前提: python3 標準ライブラリのみ。
"""

import argparse
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

JST = timezone(timedelta(hours=9))
SKILL_DIR = Path(__file__).resolve().parent.parent

SKELETONS = {
    "structure": {
        "path": SKILL_DIR / "assets" / "design-skeleton.html",
        "default_title": "HTML図解デザイン骨格 v1（このタイトルは必ず案件名に差し替える）",
    },
    "flow": {
        "path": SKILL_DIR / "output" / "reusable" / "flow-timeline-ball-ownership-template.html",
        "default_title": "フロー図解 標準テンプレート — タイムライン×ボール所在型（見本: ローンチ工場 実働フロー）",
    },
}

SOURCE_MAP_TEMPLATE = """# source-map — {title}

- 作成日: {date}
- 作業フォルダ: この source-map.md があるフォルダ（output/archive/ 配下・パック内相対）

## 読んだファイル（正本）

| パス | 抽出した要点 |
|---|---|
| （ここに読んだファイルと要点を書く） | |

## 図解の設計判断

- 想定読者:
- 要点（10行以内）:
- 採用した図解形式（5種類以上）と理由:
- 使わなかった任意ブロックと理由:
"""

PROMPT_TEMPLATE = """# prompt — 次回同じ図解を出すための入力

以下をそのままAIに渡すと、この図解を再現できる。

```text
「{title}」をHTML図解で作ってください。
正本: 28-diagram-maker/MASTER_PROMPT.md（工場ラインの手順は RUN.md 冒頭）
対象: （図解にした対象ファイル・テーマをここに書く）
読者: （想定読者）
強調したい点: （今回の図解で特に伝えたかったこと）
```
"""


def main() -> int:
    parser = argparse.ArgumentParser(description="HTML図解の案件骨格を生成する")
    parser.add_argument("--slug", required=True, help="案件スラッグ（例: line-reply-flow）")
    parser.add_argument("--title", required=True, help="図解タイトル（<title>とMarkdownに入る）")
    parser.add_argument("--type", default="structure", choices=sorted(SKELETONS),
                        help="骨格系統。原則省略（structure=リッチ骨格固定）。flowはレガシー互換のみ")
    parser.add_argument("--date", default=None, help="日付 YYYY-MM-DD（省略時はJST今日）")
    parser.add_argument("--dest", default=None, help="出力先の親ディレクトリ上書き（テスト用）")
    args = parser.parse_args()

    skeleton = SKELETONS[args.type]
    if args.type == "flow":
        print("WARN: --type flow はレガシー互換で、flow骨格はこのパックに同梱していない。既定のstructure（リッチ骨格）を使うこと。")
        print("      依頼者の明示指定がない限り、--type を省略してリッチ骨格で作ること。")
    if not skeleton["path"].exists():
        print(f"FAIL: デザイン骨格が見つからない: {skeleton['path']}")
        return 1

    date = args.date or datetime.now(JST).strftime("%Y-%m-%d")
    parent = Path(args.dest) if args.dest else SKILL_DIR / "output" / "archive"
    outdir = parent / f"{date}_{args.slug}"
    if outdir.exists() and any(outdir.iterdir()):
        print(f"FAIL: 出力先が既に存在して空でない: {outdir}")
        print("      別のslugを使うか、既存フォルダを確認すること（上書きしない）。")
        return 1
    outdir.mkdir(parents=True, exist_ok=True)

    html = skeleton["path"].read_text(encoding="utf-8")
    # <title> だけ案件名に差し替える（骨格デモタイトルの残留をpreflightがFAILにするため）
    html = html.replace(
        f"<title>{skeleton['default_title']}</title>",
        f"<title>{args.title}</title>",
        1,
    )
    if args.type == "structure":
        # ヒーローのメタチップの日付を今日に
        html = html.replace("作成日: 2026-07-05", f"作成日: {date}", 1)
    if 'name="diagram-status"' not in html:
        # flow骨格には品質宣言メタが無いので、viewportの直後に TEMPLATE 状態で注入する
        html = html.replace(
            "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">",
            "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n"
            "<!-- 完成時に content を FILLED に変える。TEMPLATE のままだと preflight が FAIL になる -->\n"
            "<meta name=\"diagram-status\" content=\"TEMPLATE\">",
            1,
        )
        if 'name="diagram-status"' not in html:
            print("FAIL: diagram-status メタを注入できなかった（骨格のviewport行が想定と違う）")
            return 1
    if 'name="diagram-skeleton"' not in html:
        # 骨格系統の身分証（preflightの検査系統判別に使う）
        html = html.replace(
            '<meta name="diagram-status" content="TEMPLATE">',
            '<meta name="diagram-status" content="TEMPLATE">\n'
            f'<meta name="diagram-skeleton" content="{args.type}-v1">',
            1,
        )
        if 'name="diagram-skeleton"' not in html:
            print("FAIL: diagram-skeleton メタを注入できなかった")
            return 1

    (outdir / "diagram.html").write_text(html, encoding="utf-8")
    (outdir / "source-map.md").write_text(
        SOURCE_MAP_TEMPLATE.format(title=args.title, date=date, outdir=outdir), encoding="utf-8"
    )
    (outdir / "prompt.md").write_text(PROMPT_TEMPLATE.format(title=args.title), encoding="utf-8")

    print("OK: 案件骨格を生成した")
    print(f"  {outdir}/")
    print("  ├── diagram.html   ← 骨格コピー。中身を差し替え、meta diagram-status を FILLED にする")
    print("  ├── source-map.md  ← 読んだ正本と判断理由を埋める")
    print("  └── prompt.md      ← 再現用プロンプトを埋める")
    print("次: 中身を作り込んだら preflight_diagram_check.py --dir で検査（FAIL 0まで）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
