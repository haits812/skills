# engine/ — 社内と同じ「本物のパイプライン」

このフォルダには、図解作成の本物スキル（CEO の image-diagram-explainer + html-diagram-explainer を複製。難しい概念やビジネスを一目で分かる図解にする） を、社内で実際に動いているコードのまま同梱しています。
プロンプトだけでなくスクリプト/テンプレが入っているので、社内とほぼ同じ品質で再現できます。

## 配布安全のために加工した点
- 実在する個人名・協業者名は一般名（講師 / ゲストA など）に置換しています。
- 絶対パスは `<WORKSPACE>` / `<HOME>/`、メール/電話はダミーに置換しています。
- 鍵・トークン・送信用認証・実データ CSV・大容量メディア・node_modules は同梱していません。
- メール送信 / LINE 配信 / 公開デプロイなど外部に出る操作は、必ず人間の承認後に実行してください。

## 使い方の基本
1. このフォルダを自分の環境にコピーする。
2. `SKILL.md` / `MASTER.prompt.md`（あれば）と各 `scripts/` の冒頭 docstring を読む。
3. 依存（ffmpeg / Remotion の npm install / Python パッケージ等）は各スクリプトの説明に従って入れる。
4. 自分の素材（動画・原稿・画像）を入力に渡して実行する。

## 中身
├── html-diagram-explainer/
│   ├── SKILL.md
│   └── references/
│       ├── html-diagram-master-prompt.md
│       ├── html-diagram-patterns.md
│       └── html-diagram-quality-checklist.md
└── image-diagram-explainer/
    └── SKILL.md
