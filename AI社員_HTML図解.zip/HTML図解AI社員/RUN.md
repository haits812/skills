# RUN.md — 図解作成AI社員を動かす（最短手順）

このファイルだけ読めば、ZIP単体で同じ品質の図解を再現できます。
詳しい思想は `MASTER_PROMPT.md` と `knowledge/`、エンジン仕様は `engine/` を参照してください。

---

> **🏭 HTML図解の工場ライン（2026-07-07新設・社内図解工場の移植版）**
> 0. コマンドは **この社員フォルダ（28-diagram-maker/）で実行**する（`cd` してから）
> 1. `python3 scripts/scaffold_diagram.py --slug <英語名> --title "<タイトル>"` — 作業フォルダ＋**デザイン骨格**（`assets/design-skeleton.html` のコピー）＋3点セット（diagram.html / source-map.md / prompt.md）を自動生成
> 2. 骨格の**中身だけ**差し替える（色・影の共通CSSとトークンは編集禁止。ゼロからCSSを書いた時点で品質バラつきが始まる）。完成したら `<meta name="diagram-status">` を `FILLED` に
> 3. `python3 scripts/preflight_diagram_check.py --dir output/archive/<日付>_<slug>` — 外部参照ゼロ・トークン無改変・必須ブロック・形式数を機械検査。**FAIL 0まで直す**
> 4. ブラウザで開いて目視（はみ出し・詰まり）
> 型で迷ったら `references/html-diagram-patterns.md`、品質基準は `references/html-diagram-quality-checklist.md`。

## ① 作るもの

**難しい概念・フォルダ構成・業務フロー・事業の仕組みを、一目で分かる1枚の図解にする。**
文章で長く説明する代わりに、ノード・矢印・階層・比較・色分けで「見ただけで構造が分かる」状態を作ります。

出力は2モードを使い分けます。

| モード | いつ使う | 出力 |
|---|---|---|
| **画像図解**（gpt-image-2） | 「図解作って」だけ / SNS・資料に貼る1枚画像 / 視覚メタファーで直感的に見せたい | 1枚の高密度PNG（16:9 横長） |
| **HTML図解**（1ファイル完結） | 「HTML / 1ファイル / コピペ / 印刷 / フォルダ階層を見せたい」 | 1ファイルのHTML+CSS（白背景・スマホ/A4対応） |

判定の原則: HTML系の語が少しでも出たら **HTML図解**。それ以外で「図解」とだけ言われたら **画像図解**。迷ったら確認する。

---

## ② 必要なツール

### 画像図解モード
- **Python 3**
- **OpenAI SDK**: `pip install openai`
- **APIキー**: `export OPENAI_API_KEY=sk-...`（gpt-image-2 は画像生成の**従量課金**。1枚生成ごとに費用が発生します）
- 画像生成モデル: `gpt-image-2`

### HTML図解モード
- **Python 3**（`python3 -m http.server` でプレビュー、構文確認に標準ライブラリのみ使用）
- **headless Chrome / Chromium**（スクショ用。`google-chrome --headless` または `chromium`）
- 外部ライブラリ・CDN・Webフォントは**使いません**（HTML図解は1ファイル完結が必須）

> APIキー・課金が不要なのは HTML図解モードです。画像図解モードのみ OpenAI の従量課金がかかります。

---

## ③ 入力（あなたが渡すもの）

最低限これだけ決めれば動きます（不足は最大10問で質問。詳細は `templates/01-intake-questions.md`）。

1. **図解したい対象** — 概念 / フォルダ構成 / 業務フロー / 事業構造のどれか。
2. **モード** — 画像 / HTML（不明なら任せてOK、原則は上表で判定）。
3. **読者** — 初心者 / 社内 / 顧客 / 受講生など。
4. **「分かればよいこと」1つ** — この図を見た人に最終的に何が伝わればよいか。
5. **入れたい要素・ステップ・数字** — 漏らさず列挙したいものすべて。
6. **入れてはいけない情報** — 実名・実連絡先・社内パスなど（`example.com` 以外の実連絡先は不可）。
7. **ブランド色（任意）** — 既定はグラデ 紫 `#7b6ce0` → 橙 `#c87941`。指定があれば差し替え。
8. **ロゴ・案内役キャラ（任意）** — 指定があれば使用。**実在ロゴ・実在人物は描かない**。

---

## ④ 実行手順

### 共通
1. `SKILL.md` → `MASTER_PROMPT.md` → `knowledge/00`〜`02`,`04` を読む。
2. 対象の要素を漏らさず抽出する（ノード・関係・階層・入力/出力・順序）。
3. 「分かればよいこと」を1つに絞り、視覚化の型を選ぶ（**対比 / フロー / 循環 / 階層ツリー / マトリクス / チェックリスト** から内容に合うものを混ぜる）。視線の流れ（左上→右下、入力→出力、上位→下位）と色の意味を固定する。
4. `output/<slug>/` を作る。

### 画像図解モード（`engine/image-diagram-explainer/SKILL.md` の流儀）
5. `prompt-set.md` に gpt-image-2 プロンプトを書く。必須要件:
   - 用途 `infographic-diagram` / 16:9 横長 / 推奨 `3840x2160`（速度優先 `2048x1152`）
   - 視覚メタファー（城・金庫・橋・倉庫・信号・宝箱・働くロボット等、内容に合うもの）
   - 良い/悪い・安全/危険を 緑チェック・赤バツ・盾・警告で直感化
   - 入れる要素を「省略しない」と明記、見出し大・説明は短いラベル
   - 「実在ロゴ・実在人物・実名は描かない」と明記
6. gpt-image-2 で生成（最小例）:
   ```python
   from openai import OpenAI
   client = OpenAI()  # OPENAI_API_KEY を環境変数で読む
   r = client.images.generate(model="gpt-image-2", prompt=open("prompt-set.md").read(), size="1536x1024")
   # 返ってきた画像データを images/<slug>_diagram.png に保存する
   ```
   > 上下に黒帯/クリーム帯（letterbox）を付けず、ネイティブ出力をそのまま保存する。
7. 画像を `output/<slug>/images/<slug>_diagram.png` に保存。`source-map.md` に読んだ資料と入れた要素を残す。

### HTML図解モード（`engine/html-diagram-explainer/SKILL.md` の流儀）
5. 1ファイル完結のHTMLを書く（CSSは `<style>` 内、外部参照0件、白背景・余白多め・`@media print` あり、スマホで縦並び）。1枚に最低4〜6種の見せ方を混ぜる。
6. headless Chrome でスクショを撮り `output/<slug>/screenshots/` に保存:
   ```bash
   google-chrome --headless --screenshot=screenshots/<slug>-desktop.png --window-size=1280,2400 diagrams/<slug>.html
   ```
   モバイル幅でも1枚撮り、表示崩れがないか目視する。
7. `python3 -m html.parser` 相当で構文確認、外部URL/ライブラリ参照0件を確認。`source-map.md` と `prompt.md` を残す。

### 仕上げ
8. `templates/05-output-evaluation-rubric.md` の10軸で自己評価し、`qa.md` に記録する。

---

## ⑤ 成果物

```
output/<slug>/
├── diagram-brief.md        前提整理（何を・誰に・どう見せるか）
├── how-to-diagram.md       難しいものを図解に落とした手順
├── prompt-set.md           画像図解: gpt-image-2 プロンプト（再現可能）
├── images/<slug>_diagram.png   画像図解の成果物（16:9 PNG）
├── diagrams/<slug>.html        HTML図解の成果物（1ファイル完結）
├── screenshots/                HTML図解のスクショ（desktop / mobile）
├── source-map.md           読んだ資料・入れた要素
└── qa.md                   10軸ルーブリックの自己評価
```

（モードに応じて画像系 or HTML系のどちらかが主成果物。両方欲しいと言われたら両方作る。）

---

## ⑥ 品質のコツ（外すと事故るポイント）

- **全領域をコンテンツに使う** — 右上のプロフィールバッジ等を重ねない。図の隅々まで情報に使う。
- **letterbox禁止** — 上下にクリーム/黒の帯を入れず、16:9ネイティブ出力をそのまま保存する。
- **要素を漏らさない** — 小さくても全要素を入れる。勝手に省略して「簡略化」しない。
- **文章カードの羅列にしない** — 主役はノード・状態差・矢印・比較・危険/安全の対比。視覚メタファーに置き換える。
- **文字を潰さない** — 見出しは大きく、詳細は短いラベルに圧縮。情報量は多くてよいが、レイヤー・番号・色分け・余白で読ませる。
- **色の意味を固定** — 緑=良い/安全、赤=悪い/危険 など。色だけに頼らず枠線・太字・ラベルでも強調。
- **HTML図解は必ずスクショ確認** — 撮らずに完了にしない。スマホ幅で文字がはみ出さないこと。
- **安全** — 実名・実連絡先・実在ロゴ・実在人物・社内固有情報を入れない。公開・投稿・アップロードは人間承認後。

参考サンプル（架空企業「株式会社アイウエオ / AIO Marketing OS」で作った見本）:
`_quality_audit/generated/28-diagram-maker/`（画像2枚・HTML図解・prompt-set・qa が揃っています）
