---
type: note
title: "GAN 着想の generator × evaluator ハーネスで 4〜6 時間の自律開発 — 部品はどれも「モデルにできないこと」の仮定"
source: https://www.anthropic.com/engineering/harness-design-long-running-apps
about: [concept/agent-design, org/anthropic]
by: [org/anthropic]
---

結論: 長時間の自律開発は「生成エージェント + 外部評価エージェント」の分離 (GAN 着想) で成立し、solo 実行 ($9/20 分) の 20 倍のコスト ($200/6 時間) で機能実装が段違いになる。ただしハーネスの各部品は「モデルが独力でできないこと」の仮定の符号化であり、新モデルが出るたびに荷重の無い部品を剥がして再検証すべき、と主張する。

## 骨格 (章単位の構造抽出 — point は残す価値 0-5)

### 1. 素朴な実装が落ちる理由 — compaction でも context 不安は残り、自己評価は甘い [point 5]
要点: 文脈ウィンドウの詰まりは compaction では解けず (連続性は保つが白紙にはならない)、エージェントは自作の成果物を過信して褒める。文脈リセットと外部評価の分離が処方箋。
> While compaction preserves continuity, it doesn't give the agent a clean slate, which means context anxiety can still persist.
> When asked to evaluate work they've produced, agents tend to respond by confidently praising the work—even when, to a human observer, the quality is obviously mediocre.

### 2. 主観品質を採点可能にする — 4 基準 + Playwright 実操作の評価者 [point 4]
要点: Design Quality / Originality / Craft / Functionality の 4 基準で「良いデザインか」を採点可能な語に落とし、評価エージェントが Playwright で UI を実際に操作しながら採点。生成側はフィードバックを受けて 5〜15 回反復し、最大 4 時間走る。
> Building an evaluator that graded outputs reliably—and with taste—meant first developing a set of criteria that could turn subjective judgments like 'is this design good?' into concrete, gradable terms.

### 3. フルスタック構成 — Planner → Generator → Evaluator と sprint contract [point 4]
要点: Planner が短いプロンプトを詳細スペックへ展開、Generator がスプリント単位で実装、Evaluator がテストで検証する 3 役構成。スプリント前に生成側と評価側が「何をもって done とするか」を合意してから書き始める。
> Before each sprint, the generator and evaluator negotiated a sprint contract: agreeing on what 'done' looked like for that chunk of work before any code was written.
元の型: React + Vite + FastAPI + SQLite/PostgreSQL / Claude Agent SDK / Playwright MCP

### 4. 実測 — solo $9/20 分 vs ハーネス $200/6 時間 [point 4]
要点: レトロゲームメーカー生成で比較。solo 版はゲーム機能が実装されずエンティティが入力に応答しない。ハーネス版はフルスタックで動き、遊べた。コスト 20 倍の対価は「動くかどうか」の差。
> The biggest difference was in play mode. I was actually able to move my entity and play the game.

### 5. ハーネスの縮退 — 部品は「モデルにできないこと」の仮定 [point 5]
要点: Opus 4.6 への更新でスプリント構造を撤去でき、評価は単一パスの後置に変わった。ハーネスの全部品はモデルの欠落能力への仮定の符号化なので、新モデルごとに荷重テストして剥がす。
> Every component in a harness encodes an assumption about what the model can't do on its own.
> When a new model lands, it is generally good practice to re-examine a harness, stripping away pieces that are no longer load-bearing to performance.
元の型: v2 ハーネス (DAW 生成): Planner → Build ×3 → QA ×3 / 3 時間 50 分 / $124.70

### 6. 設計空間は消えず移動する [point 3]
要点: モデル能力が上がるとハーネス設計が不要になるのではなく、より複雑なタスクを達成する新しい組み合わせの発見へ課題が移る、と締める。

依頼者の言葉:

> https://www.anthropic.com/engineering/harness-design-long-running-apps この解説も見てみたいね
>
> — オーナー, 2026-08-16
