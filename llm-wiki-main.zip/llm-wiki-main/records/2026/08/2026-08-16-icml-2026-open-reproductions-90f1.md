---
type: note
title: "ICML 2026 の 2,226 論文をエージェントで再現監査 — 51% 検証・23% 反証、再現性は二進でなく敵対的"
source: https://huggingface.co/blog/icml-2026-open-reproductions
about: [concept/ml, concept/agent-design, org/hugging-face]
by: [org/hugging-face]
---

結論: 1,221 人がコーディングエージェントを持ち込み、ICML 2026 採択論文の 34% (2,226 本) の主張 35,908 個を 19 日で再現監査した — 検証できた論文 51%、反証を含む論文 23%。「再現性は二進的でなく敵対的」で、最良の結果は純エージェントでなく人間がループ内にいる運用から出た。

## 骨格 (章単位の構造抽出 — point は残す価値 0-5)

### 1. 査読が投稿の伸びに追いつかない [point 3]
要点: ICML 2026 は 23,918 投稿から 6,352 本を採択 (前年比ほぼ倍) だが、ボランティア査読者は証明の検証まで手が回らない。エージェントはそこを並列で埋められる。
> Checking a paper carefully used to cost a reviewer a weekend; an agent can attempt it in an afternoon, in parallel, thousands of times over.

### 2. ハッカソンの型 — logbook 公開 + LLM 判定 [point 4]
要点: 2026-07-15〜08-02 に 1,221 人が参加し、論文選択 → 主張抽出 → 各自のエージェント (Claude Code / Codex / Cursor / Pi) で再現 → Trackio logbook 公開 → GLM-5.2 が verified/falsified/toy/inconclusive を自動判定、の流れ。実行証跡も公開される。
> 6,816 reproduction logbooks published
元の型: 参加 1,221 人 / logbook 6,816 / 対象 2,226 論文 (34%) / 主張 35,908 / HF Jobs 2,962 / エージェント実行トレース公開 274

### 3. 結果の数字 — 検証 51%・反証 23% [point 5]
要点: 少なくとも 1 主張を独立検証できた論文 51% (1,103、うち完全再現 266)。少なくとも 1 主張が反証された論文 23% (496)。242 本では複数チームの判定が対立した。
> Reproducibility is not binary; it is adversarial.
元の型: 完全再現 266 / 部分再現 (反証なし) 632 / 検証済み主張 3,978 / 判定対立 242 論文

### 4. 反証の中身 — 証明の破綻・理論と実装の乖離・偽反証 [point 5]
要点: 人間の対抗検証を通った反証には、証明ステップ 224 で壊れる paging 論文 (O(1) が実際は Θ(ln k))、定理の反例が t=224 で出る Frank-Wolfe、理論は逆 KL なのに実装が順 KL の self-distillation、評価値の 66% が EOS パディングで perplexity を 3 倍水増しした transformer projections が含まれる。再現側の算術エラーによる偽反証 (実際は 8 倍高速だった) も 1 件。
> The true robustness is H_k + Θ(log k).

### 5. 著者との対話 — 即日確認と独立収束 [point 3]
要点: 全反証について著者へ連絡し、建設的な応答を得た。即日エラーを認めた例、ハッカソンが見つける 1 ヶ月前に著者が arXiv 上で静かに直していた例 (独立収束と数える) がある。
> in one case an author had quietly fixed the error in a new arXiv version a month before the challenge found it, which we count as independent convergence

### 6. 人間の役割 — 純エージェントは限界に当たる [point 5]
要点: 最良の結果は人間がエージェントを操舵し、仮説と前提を確認するループ内運用から出た。優勝した量子化論文の再現は、人間が 128 画像ペアを知覚評価し、エージェントが一貫性を検証する分業。人間の役割は教授が PI を導くような「知識の管理者」と位置づけられる。
> Pure agent execution hits real limits.

依頼者の言葉:

> https://huggingface.co/blog/icml-2026-open-reproductions　これ
>
> — オーナー, 2026-08-15
