---
type: obs
title: "Y Combinator 創業 — 2005 年 3 月"
about: [org/y-combinator]
confidence: 事実
---

依頼者の言葉:

> Y Combinator は 2005 年 3 月創業 (広く知られた実事実)。org のページに創業年が引けるよう出来事として記録して

補足 (司書): 出来事日は「2005 年 3 月」までしか与えられていないので、ファイル名の日は月初 (2005-03-01) を置いただけで日そのものの主張ではない。
[[org/y-combinator]] の `created: 2026-08-02` はこの wiki に器を立てた日で創業年ではないため、創業年はこの記録から引く
(`scripts/wiki links org/y-combinator` の被リンク記録に出る)。
