---
type: obs
title: "OpenAI 設立 — 非営利の AI 研究所として発足し、Sam Altman と Elon Musk が共同議長に就いた"
about: [org/openai, person/sam-altman, person/elon-musk, concept/ml]
confidence: 事実
---

依頼者の言葉:

> 広く知られた事実として、OpenAI は 2015年12月11日に非営利の AI 研究所として設立され、Sam Altman と Elon Musk が共同議長に就いた。これを出来事の日付で記録しておいて。私の判断: この wiki には既に YC の会長交代 (2014) と GPT-5 の記録があるが、その間をつなぐ起点が抜けている。人物と組織の年表として辿れるようにしておきたい。

補足 (司書): 依頼者が言う年表の両端は [[2014-02-01-yc-presidency-pg-to-altman-b221]] ([[person/paul-graham]] →
[[person/sam-altman]] の YC 社長交代) と [[2025-08-07-openai-gpt5-router-single-system-07a1]] (GPT-5 リリース) で、
本記録はその間の起点にあたる。[[person/elon-musk]] は本件の参照先として新規に立てた stub ([[org/tesla]] は既存)。

出所: 一次ソースの URL は依頼に添付されていないため `source` を持たない。2015-12-11 は司書の一般知識では
OpenAI 自身による設立の公表日 (「Introducing OpenAI」の発表日) で、法人としての登記日とは一致しない可能性がある。
発足時の形態 (非営利) と共同議長の 2 名は公開情報として確認できる範囲なので confidence は「事実」に置くが、
日付の性質 (公表日か登記日か) は未検証 — 一次ソースを当てた人が訂正 obs で上書きできる。
