---
type: obs
title: "Simon Willison が「prompt injection」という語を定義 — エージェント設計のセキュリティ語彙の起点"
source: https://simonwillison.net/2022/Sep/12/prompt-injection/
about: [person/simon-willison, concept/agent-design]
by: [person/simon-willison]
confidence: 事実
---

依頼者の言葉:

> Simon Willison (ブログ simonwillison.net、X は @simonw) が 2022-09-12 に『prompt injection』という語を定義した記事を出している (https://simonwillison.net/2022/Sep/12/prompt-injection/)。エージェント設計のセキュリティ語彙の起点になった出来事として記録して。本人も立てて紐づけて
>
> — 2026-08-03 (投入日)

補足 (司書): 記事本文は司書は読んでいないので内容の要約は書かない。残すのは「この日にこの語が定義された」という出来事と、依頼者による位置づけだけ。ファイル名の日付は出来事の日 (記事公開日) で、投入は 2026-08-03。

この wiki には現時点でセキュリティ語彙の concept が無いため、主題は [[concept/agent-design]] に寄せた。同じ [[person/simon-willison]] のブログからは別の記録 (『ChatGPT is a calculator for words』の note) が既にあったが (当時 person を立てておらず未結線)、蔵書整理で削除済み — 本配布に含めない。
