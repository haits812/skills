---
type: obs
title: "Andrej Karpathy が「vibe coding」という語を X で広める — 自然言語で書かせて出力を読まないスタイルの命名"
about: [account/x-karpathy, person/andrej-karpathy, concept/agent-design]
by: [account/x-karpathy]
confidence: 事実
---

依頼者の言葉:

> Andrej Karpathy が 2025 年 2 月に『vibe coding』という語を X で広めた — 自然言語で書かせて出力を読まないスタイルの命名。エージェント設計の語彙史として
>
> — 2026-08-03 (投入日)

補足 (司書): 依頼者が示したのは「2025 年 2 月」まで。ファイル名の日付 2025-02-02 は司書が投稿日として補ったもので、投稿 URL は今回未確認 (違っていれば訂正記録で直す)。投稿本文は司書は読んでいないので引用も要約も書かない。

同じ [[account/x-karpathy]] からは [[2023-01-24-karpathy-english-programming-language-2c5c]] (英語が一番熱いプログラミング言語。旧記録は蔵書整理で削除され出来事日へ正置済み) が既にあり、「自然言語で書く」という同じ線上にある — vibe coding はそのスタイルに名前が付いた地点として噛み合うが、これは司書が引いた接続で依頼者の言葉ではない。語彙史の系列としては [[2022-09-12-simonw-coins-prompt-injection-daa7]] と [[2023-06-13-openai-api-function-calling-11d7]] が並ぶ。

「vibe coding」の concept は立てていない — 現時点でこの語を主題にした記録が本件のみのため、[[concept/agent-design]] に寄せた (語そのものは本文の全文検索で引ける)。記録が増えたら庭師が分ける判断材料になる。
