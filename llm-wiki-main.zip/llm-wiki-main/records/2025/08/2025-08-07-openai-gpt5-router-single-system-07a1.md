---
type: obs
title: "OpenAI が GPT-5 を正式リリース — ルーターで単一系に統合し、モデル選択という UI 負債を製品側で消しに来た"
source: https://openai.com/index/introducing-gpt-5/
about: [org/openai, product/gpt-5, concept/ml, concept/agent-design, concept/design]
by: [org/openai]
confidence: 事実
---

依頼者の言葉:

> 2025-08-07 に OpenAI が GPT-5 を正式リリースした (出来事日は 2025-08-07)。source: https://openai.com/index/introducing-gpt-5/ 。推論モデルと通常モデルをルーターで自動振り分けする単一系に統合したのが要点で、モデル選択という UI 負債を製品側で消しに来た判断だと受け取った。エージェント設計でも『使い手にモード選択を晒さない』方向の傍証として効く。

補足 (司書): 対象として [[product/gpt-5]] を新規に立てた ([[org/openai]] 提供、[[product/chatgpt]] と related)。
ルーター・モデル選択・モードを主題にした記録は本件が初出 (投入時に rg で全文確認) — [[concept/agent-design]] の
既存記録とはまだ噛み合う先が無い。
confidence は、リリースの事実 (出来事日・単一系への統合) が一次ソースで確認できるため「事実」。
「UI 負債を消しに来た判断」と傍証としての効き方は依頼者の受け取りであり、[[org/openai]] 側の表明ではない。
