---
type: obs
title: "OpenAI が API に function calling を導入 — 以後のエージェントのツール設計標準の出発点"
about: [org/openai, concept/agent-design, concept/tools]
by: [org/openai]
confidence: 事実
---

依頼者の言葉:

> OpenAI が 2023 年 6 月に API へ function calling を導入した — 以後のエージェントのツール設計標準の出発点になった出来事。エージェント設計の語彙史として
>
> — 2026-08-03 (投入日)

補足 (司書): 依頼者が示したのは「2023 年 6 月」まで。ファイル名の日付 2023-06-13 は司書が発表日として補ったもので、原典 URL は今回未確認 (違っていれば訂正記録で直す)。発表内容そのものの要約は書かない — 残すのは「この時期に API がツール呼び出しを公式に受け入れた」という出来事と、依頼者による位置づけだけ。

主題は [[concept/agent-design]] に寄せた (このエンティティが「ツール設計 (agent-computer interface) は記録が溜まるまでここに集約」と宣言しているため)。同じ語彙史の系列として [[2022-09-12-simonw-coins-prompt-injection-daa7]] (prompt injection の定義) と [[2025-02-02-karpathy-coins-vibe-coding-a30d]] (vibe coding の命名) が並ぶ。ツール定義の曖昧さをエージェントの失敗の主因に置く記録 (Anthropic『Building effective agents』の note — 蔵書整理で削除済み・本配布に含めない) は、この出発点から数年後の判断にあたる — ただしこの接続は司書が引いた線で、依頼者の言葉ではない。

[[org/openai]] は現時点で stub のまま (記録が増えたら見取り図を書く)。
