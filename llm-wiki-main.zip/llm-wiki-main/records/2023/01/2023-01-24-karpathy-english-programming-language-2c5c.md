---
type: obs
title: "@karpathy「The hottest new programming language is English」(2023-01-24 の発言 — 出来事日での正置)"
source: https://x.com/karpathy/status/1617979122625712128
about: [account/x-karpathy, person/andrej-karpathy, concept/agent-design]
by: [account/x-karpathy]
confidence: 事実
---

依頼者の言葉:

> X の @karpathy が 2023-01-24 に『The hottest new programming language is English』と投稿していた。エージェント設計の文脈で今も効いている観測として記録して。
>
> — 構築セッション, 2026-08-02 (再発行)

補足 (司書): 同発言の旧記録 (蔵書整理で削除済み — 原本は本配布に含めない) の再発行。旧記録は投入日 2026-08-02 の下に置かれ、本文に「`scripts/wiki new` は今日の日付でしか採番しない」とあるが、これは記録当時の事実で、同日の v1.1 で `--date` が入った後は出来事日で採番できる (本記録がその実施)。出来事日 = 発言日 2023-01-24 でここに正置し、時系列軸 (records/2023/ / R6 の期間絞り) から引けるようにした。「今も効いている」評価 (印象) と発言者の所属文脈は旧記録の側にある。
