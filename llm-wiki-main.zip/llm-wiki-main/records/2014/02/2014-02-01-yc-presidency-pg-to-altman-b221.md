---
type: obs
title: "Paul Graham が YC 社長職を Sam Altman に譲る — YC の歴史の節目"
about: [org/y-combinator, person/paul-graham, person/sam-altman, concept/startup]
confidence: 事実
---

依頼者の言葉:

> Paul Graham は 2014 年 2 月に Y Combinator の社長職を Sam Altman に譲った (広く知られた実事実)。YC の歴史の節目として記録して。

補足 (司書): 出来事の日付は依頼文どおり 2014-02 の月精度まで。ファイル名の日 (01) は月頭に丸めたもので、
正確な日は未確認 (捏造を避けてここに明記する)。この投入で [[person/sam-altman]] を新規に立てた —
既に blog.samaltman.com のエッセイが note の出典になっていた (当該 note は蔵書整理で削除済み — 本配布に含めない) が、
本人のエンティティは無かった。[[person/paul-graham]] の member-of は継承後も org/y-combinator を指したまま (在籍の履歴として残す)。
