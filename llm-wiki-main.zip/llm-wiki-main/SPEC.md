# SPEC.md — llm-wiki 統合設計仕様 (v1.0)

2026-08-02。正本は BRIEF.md (矛盾したら BRIEF が勝つ)。本書は 3 設計案 (a-minimal / b-graph / c-ops)、
3 敵対批評、3 judge の審査結果を統合した**実装仕様**であり、実装はこれ以上何も決めずに済むことを目標とする。
骨格は b-graph (3 judge 全会一致の winner)。c-ops から並行安全と司書動線を、a-minimal から劣化許容と
規約予算を移植し、批評が実測で潰した欠陥 (F1-F18 / 致命 1-5 ほか) は全て設計側で修理した。
設計過程の一次文書 (3 案・批評・審査・E2E 証跡) は本配布に含めない — 本文中の指摘番号 (B-F12 / C-致命3 等) は
設計審査での指摘・実測の整理番号で、主張は本文に統合済み (番号の先の文書を探しに行かなくてよい)。

規約の逐語の**運用正本は `.claude/skills/ref-wiki-schema/` (SKILL.md + templates/)**。
本書と ref がずれたら、データ契約 (§1-§4, §7) は本書が勝ち、レシピ・手順 (§5-§6) は ref が勝つ。
実行可能な正本は `scripts/wiki` の lint (本書 §5-5 と 1:1 対応を保つこと)。

---

## 0. 決定要約表

| # | 決定 | 出自 | 根拠 (審査・批評) |
|---|---|---|---|
| D1 | ノートは**エンティティ 8 型 + 記録 2 型**の 2 階のみ。ID = `<type>/<slug>` (全域ユニーク・パスと純関数変換) | B | 素の全文 grep = backlink (D4)。3 judge 全員が「検索・辿りの核として唯一実測で生き残る」と評価 |
| D2 | 階層は `part-of` リンク (**多重親 DAG・深さ無制限**)。ディレクトリは型でフラット | B | 合弁・事業をまたぐコミュニティが表せる。BRIEF §2-1/2-2 直答 |
| D3 | **親は子を指さない。子が親を指す単方向**。既存ファイルは原則触らない (追記型) | B | 並行 4 セッションのコンフリクト面を実質ゼロにする |
| D4 | frontmatter は**フラット key: value + インライン配列のみ**。述語 7 個をトップレベルに置く | B | 1 行 grep が構造クエリになる。YAML パーサ 30 行自作 = 依存 0 |
| D5 | 記録ファイル名に **`-<4hex>` サフィックス**、エンティティ新規作成は **O_EXCL 予約** (`wiki new`) | C | B-F8 / C-致命3 (同一パス同時作成の silent overwrite = git にも残らない唯一の消失経路) を構造的に消す。3 judge 全員が graft 指定 |
| D6 | **`cards` (1 ファイル = 1 行圧縮)** + 読み出し既定 `sort -r \| head -30` (新しい順・上限付き) | C | B-F12 (ハブ 804 件 → 45KB で context が死ぬ・既定が最古順) の直接の解毒剤。3 judge 全員が graft 指定 |
| D7 | **SessionStart hook が現況 6 行を注入** (型別件数・直近 3 件・今日の 1 枚)。全経路 exit 0・pull しない | C | boot 直後の repo 知識ゼロを 0 コマンドで埋める。器の重複増殖 (B-F3) の最安の抑止 |
| D8 | commit は **pathspec 限定** (`git add -- p && git commit -q -m msg -- p`)。`git add -A` 禁止。save に `pull --rebase` を入れない | C+A | A-F1 / B-F2 / C-致命2 の共通穴 (index 汚染・rebase 状態拒否) を消す。C 批評 23 で pathspec commit の無衝突を実測確認済み |
| D9 | **劣化許容の等級制**: ERROR は「そのファイル単体の書式」のみ。横断検査 (壊れリンク・aka 衝突・閉路・domain/range) は **commit を止めず庭師レポート**。Stop hook のゲートは**自セッションが書いたファイル限定** | A | B-F2-d の毒饅頭 (1 ERROR が全セッションの commit を恒久停止) を解毒。3 judge 全員が graft 指定 |
| D10 | **規約予算**: 逐語は ref-wiki-schema + templates のみ (他は参照)。CLAUDE.md ≤ 40 行 / ref ≤ 120 行 / 各 run skill ≤ 100 行。規約を足すなら削る (総量固定制) | A | B-F15 (逐語 4-6 箇所コピー → 必ずどこかが嘘になる) への歯止め |
| D11 | 分類は **concept エンティティへのリンク** (tags フィールドは持たない)。ただし capture に**既存突合の強制** + X2 を正規化一致で検査 + 「**迷ったら記録。中身の無い器は墓場になる**」のタイブレーク | B+A | B-F3 (表記ゆれ concept の増殖) の修理。D8 の論拠「ゆれが lint で死ぬ」は偽と判明したため、防衛線を lint から capture 手順 + 正規化突合に移した |
| D12 | 記録本文は「**依頼者の言葉 (逐語)** / **司書の補足 (出所明示)**」の 2 ブロック分離。C 案の E6 (一人称意見の強制) は**不採用** | C→修正 | B-F14 / C-重大8 (LLM の作文が依頼者の判断として保存され提案書に混入) — この wiki の唯一の保存価値の汚染防止 |
| D13 | `alias-of` は必ず **1 段展開してから検索** — 合成器は `wiki links` (被リンク記録 = 一族 + alias union。R9・recall 契約に逐語。shell での ID 合成は方言で壊れるため禁止)。投入日は **git author date** (レシピ R10) | B→修正 | B-F4 (person 引きが無言の 0 件) / B-F6 (「先月入れた」が外れる) — サイレント誤答 2 経路の封鎖 |
| D14 | X3 閉路検出は**3 色 DFS (O(V+E)・メモ化)** — 多重親 DAG は合法・閉路は長さ無制限で検出。多重親 4 パターンの回帰 fixture を lint に同梱 | B→修正 | B-F1 (菱形を循環と誤判定 → D2 の存在理由を lint が殺す)。fixture 無しでは再発する (F17 の教訓) |
| D15 | 全日付は **TZ=Asia/Tokyo 固定** (scripts 冒頭で強制)。未来日判定は +1 日許容 | C→修正 | C-致命5 (JST 00:00-09:00 の書き込みが毎日 1 日ずれる) |
| D16 | 読み出し需要を**外側に作る**: 運用環境側の導線 1 行の設置と E2E「嘘を返したら fail」検収を受け入れ条件に明記 (§10) | 設計審査 | 3 judge 共通の最大リスク「誰も読みに来ない」(v1 fusen の死因) は設計内では解けない — 作業項目として固定する |

---

## 1. エンティティモデル

### 1-1. 定義

- **エンティティ (entity)** — 世界に持続的に存在し同一性を持つ名詞。ページは 1 つ。更新はまれ。
  内容は「1 行定義 + 安定した属性 + リンク」。
- **記録 (record)** — ある時点の観測・出来事・意見。**書いたら本文を書き換えない** (訂正は新しい記録で)。
  日付が意味の一部。同じ対象に何十件でも積む。

### 1-2. 線引きテスト (3 問 + タイブレーク)

1. その名前で来月また参照するか? → YES ならエンティティ
2. 日付を外すと意味が壊れるか? → YES なら記録
3. 同じことが 2 回起きうるか? → YES なら「起きたこと」が記録、「起きる対象」がエンティティ
4. **それでも迷ったら記録へ。中身の無い器は墓場になる** (記録は後から昇格できる。器は増えたら消せない)

> 補足 (C-中14 の修理): 1 と 2 が両方 YES になるもの (例:「nav.al の『富はレバレッジから』の記事」) は
> **2 が勝つ = 記録**。記事は「読んだという出来事」であり、器にしない (§1-5)。

### 1-3. エンティティ型 (8 — 凍結。追加条件は §7-3)

| type | 意味 | slug 例 |
|---|---|---|
| `org` | 会社・法人・組織・チーム | `org/anthropic` `org/acme-ai` |
| `person` | 人 (実名の人格。持続的人格を持つ AI エージェントを含む) | `person/naval-ravikant` |
| `project` | 事業・案件・プロジェクト | `project/agent-ops-biz` |
| `task` | タスクの**記述的記録** — 外の世界の案件、および自事業/自プロジェクトのマイルストーン。作業**管理** (issue 追跡) はイシュー管理ツールへ — BRIEF §3 | `task/contract-review-acme` |
| `community` | Discord / Slack / フォーラム / 勉強会など「場」 | `community/dc-agent-builders` |
| `account` | プラットフォーム上のアカウント (X / GitHub / …) | `account/x-naval` |
| `product` | 製品・サービス・OSS・ツール | `product/claude-code` |
| `concept` | 概念・トピック・技術・イベント名。**MOC (見取り図) の器・分類の結節点** | `concept/agent-design` |

- **account を person と分ける理由**: 「@naval が言った」から観測が入る。本名不明のまま積める。
  人物が判明したら `alias-of: [person/...]` を足すだけで繋がる (検索側は R9 で必ず展開する — §4-3)。
- **concept の作成規律 (D11)**: 新規 concept を立てる前に**必ず既存の title/aka を正規化突合** (§5-4 の
  capture 必須手順)。既存があれば必ず再利用。無ければまず `related` で近い concept に吸収できないか
  検討し、それでも要る時だけ作る。作る時は `aka` に日本語 + 英語 + 略称を必ず書く
  (並行セッションが同時に立てた同義ページを X2 正規化一致で捕まえるための布石)。

### 1-4. 記録型 (2 — 凍結)

| type | 意味 | 必須 |
|---|---|---|
| `note` | 外部ソース (記事/動画/論文/スレッド) の**構造抽出** — 結論 1-2 文 + 章単位の「要点 + 原文逐語引用 + 元の型」、章見出しに [point 0-5] (残す価値、LLM ジャッジ)。司書の評論は書かない (BRIEF §4-1) | `source`, `about` |
| `obs` | 日付を持つ観測・出来事・発言記録 | `about` |

### 1-5. 境界のエッジケース (判断済み)

| 入力 | 判定 |
|---|---|
| 催しの固有名 (「AI Engineer Summit で〜」) | `concept/ai-engineer-summit` (event 型は作らない) |
| 「Anthropic の Claude Code」 | `product/claude-code` + `by: [org/anthropic]` (`part-of` は使わない — 製品は成果物) |
| 記事そのもの | **器にしない**。note (記録) 1 枚。同じ URL の 2 回目も新しい note (`rg -lF 'source: <URL>' records/` で束ねる — -F 必須) |
| 対象を同定できない入力 (「事業△の件」で△が引けない) | **投入を断らない** (foyer は一問一答 — 断ると情報が消える。設計審査の指摘)。`about: [concept/unresolved]` で原文逐語を obs 化し、本文に「未解決: 事業△が同定できない」を書く。庭師が `concept/unresolved` の被リンクを毎回処理する |
| 「面白い」だけの断片 (対象なし・文脈なし) | 上記 unresolved で受ける (原文が短くても消さない) |
| 会社の改名 | 旧ページを `alias-of` stub 化 (§7-5)。ファイルを消さない |

---

## 2. ディレクトリ・命名

### 2-1. レイアウト

```
llm-wiki/
├── CLAUDE.md                     # 司書の動線ディスパッチャ (≤40 行) — §5-2
├── README.md                     # 外から来た人間/エージェント向け 1 画面 — §5-8
├── BRIEF.md                      # 要件の正本 (不変)
├── SPEC.md                       # 本書 (データ契約と設計判断の正本。末尾に変更履歴)
├── .gitignore                    # ハーネス揮発物のみ (.DS_Store)。wiki 自身の揮発物は /tmp へ (§5-6)
├── .rgignore                     # scripts/ .claude/ ルート直下 *.md を検索から除外 — §4-6
├── entities/
│   ├── org/  person/  project/  task/  community/  account/  product/  concept/
├── records/
│   └── <YYYY>/<MM>/<YYYY-MM-DD>-<slug>-<4hex>.md
├── scripts/
│   ├── wiki                      # 9 動詞 (node・依存 0・状態 0・単一ファイル ~1,000 行) — §5-4
│   ├── test.sh                   # §5-7 の完了定義を機械化した回帰スイート (fixtures + /tmp sandbox)
│   ├── hook-boot.sh  hook-lint.sh  hook-stop.sh
│   └── fixtures/                 # lint の回帰テスト (正常系 = 閉じた集合 / 異常系 / 多重親 4 パターン) — §5-7
└── .claude/
    ├── settings.json             # hook 3 本 — §5-6
    └── skills/
        ├── ref-wiki-schema/
        │   ├── SKILL.md          # 語彙・レシピ・禁止事項の逐語正本 (≤120 行)
        │   └── templates/        # frontmatter 現物 (entity.md / record-note.md / record-obs.md)
        ├── run-wiki-capture/SKILL.md
        ├── run-wiki-recall/SKILL.md
        └── run-wiki-garden/SKILL.md
```

ディレクトリは entities/ と records/ の 2 本だけ。**inbox/ archive/ maps/ tmp/ を作らない**
(未整理の置き場は必ず墓場になる。保留は `concept/unresolved` で表現する — §1-5)。

### 2-2. 階層をディレクトリにしない理由 (B §2-2 を継承)

1. 物理階層は親を 1 つしか持てない (合弁・事業をまたぐコミュニティが表せない)
2. 親が変わるとファイルが動き、git 履歴と全リンクが壊れる
3. フラットなら `ls entities/project/` で一覧が終わる

階層は `part-of` で表し深さ無制限。BRIEF §2-1 の「会社→人→PJ→タスク」は下限であって上限ではない。

### 2-3. slug 規則

- 文字集合: `^[a-z0-9]+(-[a-z0-9]+)*$` (ASCII 固定。日本語は `title`/`aka` へ — NFC/NFD 事故の回避)
- エンティティ: `entities/<type>/<slug>.md`。account はプラットフォーム prefix 必須:
  `x-` / `dc-` / `gh-` / `yt-` / `li-` (例 `account/x-naval`)
- 同名衝突は修飾語 (`org/apple-inc` vs `org/apple-records`)。**曖昧なら長い方**を採る — ただし
  検索は必ず境界付き grep (§4-2) なので prefix 誤爆 (C-致命4) は起きない
- 記録: `records/<YYYY>/<MM>/<YYYY-MM-DD>-<slug>-<4hex>.md`
  - 日付の定義 (B-F6 の修理): **note = 読んで判断した日 (= 通常は投入日)** / **obs = 出来事が起きた日**。
    出来事の日が不明な obs は投入日を使い、本文に「時期不明」と書く。**月まで確定なら月初 (YYYY-MM-01) を使い本文に「日は不明 (月まで確定)」と書く** (日を捏造しない — シミュレーション S-4/S-8 で司書たちが独立に収束した運用の規約化)
  - slug は「誰が/何を」が分かる 3-6 語。4hex は `wiki new` が採番 (司書は考えない)
- 日付・月は全て **JST** (`TZ=Asia/Tokyo`)。scripts は冒頭で `process.env.TZ='Asia/Tokyo'` を強制 (D15)

### 2-4. ID ⇔ パス (純関数・テーブルなし)

| | ID | パス |
|---|---|---|
| エンティティ | `org/acme-ai` | `entities/org/acme-ai.md` |
| 記録 | `2026-08-02-naval-leverage-judgment-3f9c` | `records/2026/08/2026-08-02-naval-leverage-judgment-3f9c.md` |

ID に `/` があればエンティティ、数字 4 桁始まりなら記録。`id` フィールドは持たない (パスが正本)。

---

## 3. frontmatter スキーマ

### 3-1. 書式の制約 (= 自作パーサ 30 行の成立条件。違反は E1)

1. フラットな `key: value` のみ (**ネスト禁止** — インデントした行は違反)
2. 配列はインライン `[a, b]` 固定 (`- ` の block 記法は違反)
3. コメント (`#`)・複数行スカラ (`|` `>`) 禁止
4. 改行は LF (**CRLF は E1** — 「frontmatter 無し」ではなくエラーとして検出する。C-軽24)
5. `title` が `[` で始まる / `:` `"` を含む場合は `"` で括る (配列誤読 = B-F16 の防止。
   lint は E3 で「title が文字列でない」を検出する)
6. **配列要素にカンマを含めない** (カンマは区切り専用。`Foo, Inc.` は `Foo Inc` と書く)

### 3-2. フィールド一覧

**全ノート共通 (必須)**: `type` (10 型のいずれか・パスと一致 = E4) / `title` (表示名・日本語可)

**エンティティのみ**

| field | 必須 | 値 |
|---|---|---|
| `created` | 必須 | `YYYY-MM-DD` (JST)。以後書き換えない |
| `aka` | 任意 (**非 ASCII title を持つなら実質必須** — W8) | 別名・日本語名・旧名・略称の配列。再現率を上げる唯一の仕掛け |
| `status` | 任意 | `active` / `paused` / `done` / `dead` |

**記録のみ**

| field | 必須 | 値 |
|---|---|---|
| `about` | **必須 1 件以上** | 対象エンティティ ID の配列 (D9 の墓場化防止)。**登場する固有名のエンティティは省略せず全部書く** (場・人・事業。C-中16 の修理) |
| `source` | note 必須 / obs 任意 | 一次ソース URL |
| `confidence` | obs 任意 | `事実` / `印象` / `推測` (C から移植) |

**述語 7 個 (凍結。全ノート任意 — `about` を除く)**

| 述語 | domain | range | 意味 |
|---|---|---|---|
| `part-of` | person 以外のエンティティ | エンティティ | 階層の親。複数可 (多重親 DAG) |
| `member-of` | person / account | org / community | 所属 |
| `works-on` | person / account | project / task | 担当・関与 |
| `by` | 記録 / product | person / account / org | 著者・発話者・提供元 |
| `about` | 記録 | 任意のエンティティ | 主題 (記録必須) |
| `alias-of` | エンティティ | エンティティ | 同一実体の正本 (account→person / 旧名→新名) |
| `related` | 任意 | エンティティ | 逃げ道。**要素は `<ID>` または `"<自由述語> <ID>"`** (例 `"hosted-by org/acme"`)。lint は ID 部だけを検査し述語は検査しない — スキーマ変更ゼロの語彙進化経路 (C から移植)。6 件以上で W1 |

- 値は必ず配列 (`part-of: [org/acme-ai]`)。空ならキーごと省く。
- **述語の対象はエンティティ限定** (E18)。記録への参照は本文 `[[記録ID]]` のみ。
- domain/range 違反は X4 (横断検査・庭師行き。B-F5 の修理 — 未実装のまま出荷しない)。

**持たないフィールド**: `updated` (git) / `id` (パス) / `backlinks`・`children` (grep) / `tags`
(concept リンク — D11) / `date` (ファイル名) / `schema_version` (§7-6) / `by:` マシン名 (ゼロ情報 — C-中17)

### 3-3. 本文の規約

- **エンティティ**: 最初の非空行は `> ` 始まりの 1 行定義 (E11)。`rg '^> ' entities/org/*.md` が名簿になる。
- **記録**: 出所分離 (D12)。lint は機械検査しない — capture skill が逐語で課す:
  1. **依頼者の言葉**: 依頼文に含まれた判断・意見を**逐語**で残す (引用 `> ` 推奨)
  2. **note の中身** (v1.14): 結論 + 章単位の構造抽出は source を読んで書く。**司書の評論は書かない**
  3. **obs の司書の補足**: 司書 (LLM) が加えた文脈・接続は「補足 (司書):」の下にのみ書く。
     **依頼に無い判断を依頼者のものとして書くのは禁止**。読んでいない記事の内容を作文しない
     (C 案 E6 の逆 — 書けと強制するのではなく、書くなら出所を分けよと縛る)
- 本文 `[[wikilink]]`: `[[org/acme-ai]]` / `[[org/acme-ai|アクメ社]]`。**ID の完全形のみ** (短縮解決なし)。
  リンク先は記録でもエンティティでも可。fenced code block 内の `[[…]]` はリンクとして扱わない (B-F7 の修理)。

### 3-4. サンプル現物 (templates/ と fixtures/ に同型を置く。相互に解決する閉じた集合)

#### ① `entities/org/anthropic.md` — entity / org

```markdown
---
type: org
title: Anthropic
aka: [アンソロピック, Anthropic PBC]
created: 2026-08-02
---

> Claude を作っている米 AI ラボ。エージェント設計の一次情報源として追っている。

engineering blog の実務密度が高く、[[concept/agent-design]] の語彙はここ発が実質の標準。
提供している製品は [[product/claude-code]] (product 側が `by` で指している)。
```

#### ② `entities/account/x-naval.md` — entity / account (alias-of で person に橋渡し)

```markdown
---
type: account
title: "@naval (X)"
aka: [naval, ナヴァル, Naval Ravikant]
created: 2026-08-02
alias-of: [person/naval-ravikant]
---

> X 上の投資家・起業家アカウント。レバレッジ / 判断の語彙を供給してくる観測対象。

まとまった記事を書かない人なので、時系列に obs を積む。刺さった投稿は都度 obs にし
`about` に対応する concept を必ず付ける。
```

#### ③ `entities/community/dc-agent-builders.md` — entity / community (多重親の実例)

```markdown
---
type: community
title: Agent Builders (Discord)
aka: [エージェントビルダーズ, agent-builders, AB Discord]
created: 2026-08-02
status: active
part-of: [project/agent-ops-biz, project/dev-rel]
---

> 実装者中心の Discord (約 1,200 人)。事業のリード獲得と現場の詰まりどころの一次観測を兼ねる。

流量が多いのは #tooling。中心的な実装者は [[person/kenji-sato]]。
```

#### ④ `entities/concept/agent-design.md` — entity / concept (MOC)

```markdown
---
type: concept
title: agent design (エージェント設計)
aka: [エージェント設計, agentic design, agent-design]
created: 2026-08-02
---

> どう組むと壊れないかの設計論。この wiki で最も記録が集まる結節点。

## 見取り図 (2026-08 時点)

- 主戦場はプロンプトからツール設計へ → [[2026-08-02-anthropic-building-effective-agents-9c1a]]
- 現場の詰まりは運用側 (権限・再実行・観測) に出る → [[community/dc-agent-builders]] の観測群

## 読む順

1. [[2026-08-02-anthropic-building-effective-agents-9c1a]] — 語彙の土台
2. 以降は時系列。一覧はここに書かない (二重管理) — 導出:
   `rg -Pl '\bconcept/agent-design(?![a-z0-9-])' records/ | sort -r | head -30`
```

#### ⑤ `records/2026/08/2026-08-02-anthropic-building-effective-agents-9c1a.md` — record / note

```markdown
---
type: note
title: "Building Effective Agents — ツール設計が主戦場"
source: https://www.anthropic.com/engineering/building-effective-agents
about: [org/anthropic, concept/agent-design, concept/tool-design]
by: [org/anthropic]
---

依頼者の言葉:

> ツール設計がエージェント設計の主戦場、という指摘が刺さった。失敗の多くはモデルでなく
> ツール定義の曖昧さから来る、は実感と一致する。

補足 (司書): [[project/agent-ops-biz]] で再試行ループに入って燃えた案件と同じ構図
(→ [[2026-08-02-dc-agent-builders-tool-retry-8b21]] の観測とも一致)。
要約は置かない。原文は source を読めばいい。ここに残すのは判断だけ。
```

#### ⑥ `records/2026/08/2026-08-02-naval-leverage-judgment-3f9c.md` — record / obs (発信者の観測)

```markdown
---
type: obs
title: "naval「レバレッジとは判断の複製であって労働の複製ではない」"
source: https://x.com/naval/status/1234567890123456789
about: [account/x-naval, concept/leverage]
by: [account/x-naval]
confidence: 事実
---

依頼者の言葉:

> X で "Leverage is the reproduction of judgment, not of labor." と投稿していた。記録して。

補足 (司書): [[project/agent-ops-biz]] の提案書の「労働の代替」フレームより「判断の複製」の方が
単価の説明がつく — 効きどころとして接続しておく。
```

---

## 4. リンクと階層の規約

### 4-1. 3 層モデル (B の核を継承)

| 層 | 置き場 | 書く義務 | 検査 |
|---|---|---|---|
| 構造層 | frontmatter の 7 述語 | `about` のみ必須 | 語彙 (E8) / 存在 (X1) / domain-range (X4) |
| 言及層 | 本文 `[[id]]` | 自由 | 存在 (X1・コードブロック除外) |
| 導出層 | どこにも保存しない | — | — |

### 4-2. grep の型 (これ以外の形で ID を検索しない)

```bash
rg -Pl '\borg/acme-ai(?![a-z0-9-])' entities/ records/
```

- `-P` + 否定先読みが無いと `org/acme-ai-labs` に誤爆する。`-w` では防げない (設計審査での実測)。
- 検索スコープは**常に `entities/ records/` を明示** (`.` を使わない — 設計文書・skill・fixtures が
  混ざる。C-中21)。`.rgignore` で二重に防御する。
- **rg (PCRE2) は必須依存** (実行環境に rg 15.1 実測あり)。`grep -rE` は否定先読みを表現できない
  (B-F11 実測) ため代替形を約束しない。rg 不在時の退避路 (劣化モード): 本文リンクは
  `grep -rF '[[org/acme-ai]]'` で正確、frontmatter は `grep -rE '^(part-of|member-of|works-on|by|about|alias-of|related):.*org/acme-ai'`
  で過剰一致込みで拾い、目視で ID 完全形を確認する。

### 4-3. 定型レシピ 10 本 (逐語の運用正本は ref-wiki-schema。R5/R7/R9/R10 は焼き込み必須)

```bash
# R1 エンティティ探索 — まず find (正規化突合・EXACT/NEAR)。rg は補助
scripts/wiki find アクメ acme-ai
rg -in '^(title|aka):.*アクメ' entities/

# R2 型で一覧
ls entities/project/ ; rg -l '^status: active' entities/project/

# R3 下向き 1 段 (子)
rg -Pln '^(part-of|member-of|works-on):.*\borg/acme-ai(?![a-z0-9-])' entities/

# R4 被リンク全部 (backlink) — 記録 ID も同じ型で引ける。source URL 内の文字列にも当たる (過剰側) — 構造リンクだけ数えるなら links
rg -Pl '\borg/acme-ai(?![a-z0-9-])' entities/ records/
rg -Pl '\b2022-09-12-simonw-coins-prompt-injection-daa7(?![a-z0-9-])' entities/ records/

# R5 記録を時系列で (★ 既定は新しい順・30 件上限 — 古い順で読み始めない。同日内は slug 逆順 — 時刻は持たない)
rg -Pl '\bconcept/agent-design(?![a-z0-9-])' records/ | sort -r | head -30

# R6 期間 × テーマ × 型 (R5 と同じく新しい順・上限を外さない)
rg -Pl '\bconcept/agent-design(?![a-z0-9-])' records/2026/07/ | xargs rg -l '^type: note' | sort -r | head -30

# R7 Read 前の当たり付け (★ 必ず cards で 1 件 1 行に圧縮してから選ぶ)
scripts/wiki cards $(rg -Pl '\bconcept/agent-design(?![a-z0-9-])' records/ | sort -r | head -30)

# R8 全文 (ID を知らない自然文検索)
rg -in 'ツール定義' entities/ records/

# R9 alias/一族 union の被リンク (★ person/account/改名/集約は必ずこの経路 — 生 ID の grep は嘘の 0 件、
#    shell での ID 合成は方言 (zsh) で静かに壊れるため禁止。links が唯一の合成器)
scripts/wiki links person/naval-ravikant   # 親 / 子孫 / 被リンクエンティティ (by・related の入リンク) / 被リンク記録 = 一族+alias union・新しい順 head 30
scripts/wiki cards $(scripts/wiki links org/acme-ai --paths | head -8)   # 集約: 一族の記録を圧縮してから Read

# R10 期間で引く — 必ず両軸を 1 セットで打つ (投入日 = git author date / 出来事・判断日 = 日付ディレクトリ)。片方だけだと移行分が黙って落ちる
git log --diff-filter=A --since='2026-07-01 00:00' --until='2026-08-01 00:00' --format='%aI' --name-only -- records/ | rg '^records/'; ls records/2026/07/   # 裸日付は現在時刻が補われ境界日が落ちる (approxidate)
```

集約 (BRIEF §6-4) は R1 → `wiki links` (一族 union が被リンク記録に出る) → `--paths | head` → cards → Read (§6-4 トレース)。shell で ID 群を合成しない。

### 4-4. 偶発的再会 (BRIEF §4-4)

1. **recall の隣接返し**: 答えの末尾に「grep の途中で隣接して見つかったもの 2-3 件」を必ず添える (契約)
2. **SessionStart の「今日の 1 枚」**: 毎 boot に `wiki dust -n 1` を混ぜる (seed = セッション ID —
   日付 seed だと 1 日 20 boot で同じ 1 枚が 20 回出る。C-重大11)
3. **庭師のランダム再訪**: garden は毎回 `wiki dust -n 3` で 3 件開き 1 行判定 (node 実装 — `shuf` は
   実行環境に存在しない。B-F11)
4. **concept の読む順** (MOC): 新参の司書が最初に開く場所に古い記録への導線を残す

### 4-5. 並行書き込みの安全 (D5 + D8)

- 新規作成は**必ず `wiki new` 経由** (エンティティ = O_EXCL 予約 / 記録 = 4hex 採番)。
  既存パスに素の Write で新規作成しない。
- 既存エンティティの Edit (aka 追記等) は Read → Edit。old_string 不一致なら Read し直して再試行 (楽観ロック)。
- commit recipe (逐語):
  ```bash
  git add -- "$p" && git commit -q -m "$msg" -- "$p"
  # 失敗時 0.1-0.4s ランダム sleep で最大 12 回 retry
  # "nothing to commit" / "did not match" は成功扱い (隣が取り込んだ)
  ```
  pathspec を add と commit の**両方**に渡す (新規ファイルには add が必要だが、per-path add は他セッションの
  stage を巻き込まない — C 批評 23 実測)。`git add -A` / pathspec 無し commit / save 中の `pull --rebase` は禁止。
- push は `git push -q || true` (best-effort)。rebase を要する同期は庭師専用の `wiki sync` のみ
  (index が clean であることを precheck してから `git pull --rebase && git push` — 並行 rebase の禁止)。

### 4-6. 検索スコープの固定

`.rgignore` に `/scripts/` `/.claude/` `/*.md` (ルート直下) を書く。lint の走査ルートも
`entities/ records/` にハードコード。設計文書やテンプレの ID 例が backlink・孤児判定を汚染しない。

---

## 5. 司書ハーネス構成

### 5-1. 規約予算 (D10 — 変更時に必ず守る)

| 文書 | 上限 | 役割 |
|---|---|---|
| CLAUDE.md | 40 行 | 動線ディスパッチャ + 不変条件 + grep の型 1 行 (逐語の唯一の例外) |
| ref-wiki-schema/SKILL.md | 120 行 | 語彙表・レシピ 10 本・禁止事項の**逐語正本** |
| templates/ 3 枚 | — | frontmatter 現物 (写して埋める — 転記ミスの構造的排除) |
| 各 run skill | 100 行 | 手順のみ。規約は「ref を開け」の参照で書く (逐語コピー禁止) |

### 5-2. CLAUDE.md (実物 — 予算 ≤40 行。逐語の運用正本は repo の CLAUDE.md — ずれたらそちらが勝つ)

```markdown
# llm-wiki — エージェントの知識ベース (司書はあなた)

外の世界のエンティティと観測を貯める git repo。書き手も読み手もエージェント。人間は読まない。
サーバ・DB・常駐・cron・導出インデックスは作らない。正本は entities/ と records/ の markdown だけ。

## 依頼が来たら (最初の 1 手 — skill を開かずに書き始めない)

| 依頼の形 | 開くもの |
|---|---|
| 入れて / 記録して / これ良かった / 〜と言ってた | Skill(ref-wiki-schema) → Skill(run-wiki-capture) |
| 〜について教えて / どれだっけ / 全部出して | Skill(run-wiki-recall) |
| 掃除して / 壊れてない? / 整えて | Skill(run-wiki-garden) |
| 消して / 取り消して / 間違ってた | Skill(run-wiki-capture) — **訂正記録**を作る。ファイルは消さない |
| 入れて + 教えて (複合) | 投入 → 読み出しの順に両方こなす (どちらかを黙って落とさない) |
| 書式・ID・リンクで迷ったら | Skill(ref-wiki-schema) |

## 不変条件 (破ると壊れる)

1. 禁止は全文の中立要約と note への司書の評論。note は構造抽出で中身を運ぶ — 結論 + 章単位の要点・原文逐語引用・元の型、章見出しに [point 0-5] (URL は腐る)。依頼者の言葉は逐語、obs の司書補足は出所明示
2. 導出物を保存しない。backlink・一覧・件数は毎回 rg で読み時導出する
3. 親ファイルを触らない。リンクは常に子が親を指す (並行セッションが衝突する)
4. 記録の本文を書き換えない。訂正は新しい記録で (エンティティは Read → Edit で編集可)
5. 新規作成は必ず scripts/wiki new 経由 (衝突予約)。ディレクトリを増やさない

## grep の型 (ID 検索はこの形のみ。-P と否定先読みが無いと別 ID に誤爆する)

    rg -Pl '\borg/acme-ai(?![a-z0-9-])' entities/ records/

## 地図と作法

entities/<type>/<slug>.md (8 型) / records/<YYYY>/<MM>/<日付>-<slug>-<4hex>.md (note|obs)
scripts/wiki — 9 動詞: new entity / new record / save / lint / find / links / cards / dust / sync (--help あり)。日付は JST。
書いたら scripts/wiki save <paths> (pathspec 限定 commit + push)。git add -A 禁止。
foyer — 登録されたエージェント作業場に自然言語の依頼を届ける窓口 CLI。foyer が無い環境では、この repo で Claude Code セッションを開いて同じ依頼文を打てば同じ動線が回る。
foyer への返し方 — 投入: 作ったパス / 繋いだ ID / 新規に立てた ID を 3 行。
読み出し: 答え + 根拠パス + 隣接 2-3 件。長文はファイルパス渡しで来る → Read で開く。
```

### 5-3. skill 4 本 (ref-*/run-* の命名規約準拠)

| skill | kind | 契約 (description の骨子) |
|---|---|---|
| `ref-wiki-schema` | docs | 型 10・述語 7・ID/パス規則・書式制約 6・レシピ R1-R10・禁止事項の逐語正本。templates/ に frontmatter 現物 3 枚。書き込み系の実行前に必読 |
| `run-wiki-capture` | — | 自然言語の投入 1 件を完走: 重複確認 (source URL + 既存エンティティの**正規化突合**) → 不足エンティティを `wiki new` 予約で作成 → 記録 1 ファイル → 結線 → lint → `wiki save` → 作ったパスと結線先を返す |
| `run-wiki-recall` | — | **読み取り専用** (一切書かない — 直したい点は「庭師タスク」として答えに列挙するだけ)。R9 alias 展開を必ず 1 段やる。R5/R7 の新しい順 + 上限 + cards を必ず通す。答え + 根拠パス + 隣接 2-3 件。見つからなければ「無い」と明言する |
| `run-wiki-garden` | — | `wiki lint --all` の E + X + W を裁く。1 件 1 commit。`wiki dust -n 3` のランダム再訪。最後に `wiki sync`。直せない残件は依頼元へ列挙 (判断の宛先は §10-3) |

**capture の必須手順 (SKILL.md に逐語で置く 5 行 — D11/D12/D5 の実効化)**:

1. 書く前に `rg -lF 'source: <URL>' records/` で重複投入を確認する (-F 必須 — URL の ? や . は正規表現に食われて無言の 0 件になる)
2. エンティティを立てる前に **`scripts/wiki find <候補名 日英 略称...>` で既存突合する** (正規化一致は
   EXACT/NEAR で返る — rg の手組み・全量 dump をしない)。既存があれば必ず再利用 (aka 追記のみ可)
3. 新規は `wiki new` の予約経由のみ。EXISTS = 既存を再利用 / **EXISTS-EMPTY = 他セッションが予約中** —
   自分の予約でなければ数秒待って再確認し、埋まっていれば再利用 (勝手に埋めると last-writer-wins になる)
4. note は source を読んで構造抽出する — 結論 1-2 文 + 章単位の「要点 + 原文逐語引用 + 元の型」、章見出しに [point 0-5]。司書の評論は書かない (読めない・中身が書けないなら unresolved の obs で受け、空の note を作らない)
5. concept は迷ったら作らない — find 0 件でも立てる前に R8 (全文) でテーマの既存濃度を見る (related で吸収 → それでも要る時だけ。aka に日英 + 略称を必ず書く)

### 5-4. `scripts/wiki` — 9 動詞 (node・依存 0・状態 0)

冒頭で `process.env.TZ = 'Asia/Tokyo'` を強制 (D15)。読むのは entities/ records/ と git だけ。

| 動詞 | 契約 |
|---|---|
| `new entity <type> <slug>` | パスを導出し **O_EXCL で 0 バイトファイルを作成して予約**、パスを print。既存が実体ありなら `EXISTS <path>`、**0 バイト予約中なら `EXISTS-EMPTY <path>`** (後発は数秒待って再確認 — 予約中に埋めると last-writer-wins) を print して exit 0。type/slug の形式違反は exit 1。予約後は Read (空) → Write で埋める |
| `new record <type> <slug> [--date YYYY-MM-DD]` | `records/<YYYY>/<MM>/` を mkdir -p し、`<日付>-<slug>-<4hex>.md` を O_EXCL 予約 (衝突したら 4hex を引き直し)。パスを print。日付の既定は今日 JST — **obs は出来事日を `--date` で指定する** (§2-3。未来日は +1 日まで、違反は exit 1) |
| `save <path...>` | §4-5 の commit recipe を path ごとに実行 → `git push -q \|\| true`。push 失敗は warn を出す (握り潰さない)。**防護 (v1.2)**: 対象は entities/ records/ の実在 .md 単体のみ (ディレクトリ・対象外・不存在は拒否/NOT-SAVED で exit 1) / git が rebase・merge 中断か detached なら commit せず拒否 (その状態の commit は abort で消える) / 「saved」は git の追跡を確認してから言う |
| `sync` | **庭師専用・直列**。rebase/merge 中断状態は abort で原状復帰して exit 1。`git status --porcelain` が非空なら拒否 (exit 1)。clean なら `git pull --rebase && git push` — **rebase 衝突時は必ず abort で原状復帰**し、衝突ファイルと回復手順を出して exit 1 (衝突を放置すると以後の commit が消える) |
| `lint [--hook \| --all \| <path...>]` | §5-5。path 引数は `path.resolve` で ROOT 相対に正規化 (cwd 依存の偽 ERROR = B-F9 の修理) |
| `links <id> [--depth 4] [--paths]` | 5 セクション整形: 親 (自 frontmatter) / **祖先** (part-of 連鎖・根まで) / 子孫 (逆引き・多重親 OK・**改名 stub の alias 閉包も辿る**。表示は depth と 60 ノードで打ち切り明示、**union は深さ無制限の全閉包**) / **被リンクエンティティ** (by・related・alias-of・本文の入リンク — head 30 + 全件数) / 被リンク記録 = **一族 + alias 推移閉包の union** (新しい順・head 30・全件数明示 — 集約の正規経路)。表示は打ち切っても件数は常に全数。`--paths` は被リンク記録の全パスのみ出力 (cards への pipeline 用)。0 バイト予約の ID には「予約のまま」と明示して exit 1。状態ゼロ |
| `find <候補名...>` | 候補名を NFKC 正規化・小文字化・記号除去して**エンティティの** title/aka/slug の正規形と照合 (EXACT/NEAR・head 20 — 記録の title は対象外、テーマの既存濃度は R8 で見る)。**capture の既存突合はこの動詞に一本化** — 手組みの rg は方言・打ち忘れで劣化する (同義増殖 = 最大の劣化要因)。0 件なら「新規に立ててよい」と明言 |
| `cards <path...>` | 各ファイルの先頭 8KB (frontmatter は閉じ --- まで・最大 60 行) を `日付 │ type │ title │ about │ パス` の 1 行に圧縮 (title 120 字・about 8 ID 打ち切り — パス列があるので序数対応に頼らず根拠パスを引用できる)。状態ゼロ (毎回 head 読み — 導出インデックスではない) |
| `dust [-n 3]` | 決定的乱択で記録パスを n 件。seed = `$CLAUDE_SESSION_ID` (無ければ PID+時刻)。node 実装 (shuf 非依存) |

### 5-5. lint の検査項目 (等級制 — D9)

**ERROR (E) — そのファイル単体で判定できる書式の壊れ。作業ゲート (書いた瞬間 + Stop の自ファイル) で止める**

| # | 内容 |
|---|---|
| E1 | frontmatter が無い / 閉じていない / ネスト・block 配列・コメント・複数行スカラ・CRLF・**重複キー・閉じ忘れインライン配列** (§3-1) |
| E2 | `type` が語彙外 / 欠落 |
| E3 | `title` が無い / **文字列でない** (配列化 = B-F16 を検出) / 空 |
| E4 | パスと `type` の不整合 |
| E5 | slug 形式違反 (account の platform prefix 欠落を含む) / 記録名が `YYYY-MM-DD-<slug>-<4hex>` 形式でない |
| E6 | 記録に `about` が無い / 空 |
| E8 | 未知のフィールド名 (`tgas` 等のタイポ) / **記録専用フィールド (`source`/`confidence`) がエンティティにある** |
| E9 | 記録の日付とディレクトリ `records/YYYY/MM/` の不整合 |
| E11 | エンティティ本文の最初の非空行が `> ` でない |
| E13 | note に `source` が無い |
| E14 | エンティティに `created` が無い / 形式不正 |
| E15 | 述語・`aka` の値が配列でない (スカラー aka は X2/W8 の材料から silent 脱落するため E) |
| E16 | 記録に `created`/`aka`/`status` がある |
| E17 | エンティティに `about` がある |
| E18 | 述語の対象が記録 ID (frontmatter はエンティティ限定) / `confidence`・`status` が語彙外 |

**0 バイトファイル (`wiki new` の予約) の扱い (明文ポリシー)**: 単体 E 検査の対象外 (予約直後の hook lint で
差し戻さないため) で、W9 でのみ報告。参照された場合は X1 が「参照先が 0 バイト予約のまま」と明示する。
`wiki save` は 0 バイトを NOT-SAVED で拒否し、`wiki links` は「予約のまま」と言って exit 1 — silent には扱わない。

**横断検査 (X) — `--all` でのみ実行。commit を止めない。庭師のレポート**

| # | 内容 |
|---|---|
| X1 | 壊れリンク (述語 + 本文 `[[…]]`。**fenced code block を除外**。`[[id#sec]]` は id 部で解決) |
| X2 | title/aka の**正規化衝突** (NFKC → 小文字化 → `[-_ .]` 除去で一致) = 重複エンティティの兆候。alias-of で結ばれた対は意図的な同名として除外 |
| X3 | `part-of` の**閉路** — **3 色 DFS (O(V+E)・メモ化。菱形・多重親は合法、閉路は長さ無制限。B-F1 と敵対検証のラティス爆発の修理)** |
| X4 | 述語 domain/range 不一致 (§3-2 の表どおり — B-F5 の修理) |

**WARN (W) — 庭師の材料。既定出力は E/X のみ、W は `--warn` か `--json` でのみ出す。さらにコード別 50 件で打ち切り + 件数集約行 (数千ノートで W4 数千行が E/X を沈める洪水の防止)**

| # | 内容 |
|---|---|
| W1 | `related` 6 件以上 |
| W2 | 孤児エンティティ (被リンク 0・発リンク 0、**created から 30 日超** — 猶予日数を実装する) |
| W4 | created から 90 日超で紐づく記録 0 |
| W5 | 本文が定義 1 行のみ **30 日超** (alias-of stub は特例で除外) |
| W6 | 同一 `source` の記録 (note/obs) 2 件以上 (再発行の可視化 — 意図的な再発行は庭師の残件判断) |
| W7 | 未来日付 (JST 基準・**+1 日まで許容** — マシン間時差の吸収) |
| W8 | 非 ASCII の title に対し aka に非 ASCII が 1 つも無い (日本語からの到達性 — C-中15) |
| W9 | 0 バイトファイル (`wiki new` 予約の死骸 — 庭師が削除) |
| W10 | 記録の `by` の対象が `about` に無い (「登場する固有名は about に全部」§3-2 — 集約からの取り落とし。庭師が about へ追記可) |

**exit code**: `--hook` = E があれば **2** (stderr に理由 — Claude に返る) / それ以外 0。
`entities/ records/` 外のパスは検査対象外 (無出力で素通し)。ディレクトリは対象外エラー (全走査は `--all`)。
X1 の報告は 1 ファイル 20 件で打ち切り (件数明示 — 出力洪水の防止)。
`<path...>` = E があれば 1。`--all` = E か X があれば 1 (庭師と E2E の出荷ゲート)。

### 5-6. hook 3 本 (`.claude/settings.json` — repo に commit)

```json
{ "hooks": {
  "SessionStart": [ { "matcher": "", "hooks": [
    { "type": "command", "timeout": 10, "command": "bash \"$CLAUDE_PROJECT_DIR/scripts/hook-boot.sh\"" } ] } ],
  "PostToolUse": [ { "matcher": "Write|Edit", "hooks": [
    { "type": "command", "timeout": 20, "command": "bash \"$CLAUDE_PROJECT_DIR/scripts/hook-lint.sh\"" } ] } ],
  "Stop": [ { "hooks": [
    { "type": "command", "timeout": 60, "command": "bash \"$CLAUDE_PROJECT_DIR/scripts/hook-stop.sh\"" } ] } ] } }
```

共通規約: stdin の hook JSON は **`node -e` の `JSON.parse` で読む** (sed 抽出は整形 JSON で
無言破綻する — B-F2-c)。セッション台帳・ガードは `/tmp/llm-wiki-<sid>.*` (揮発・セッションローカル。消えても動作の正しさが
変わらない = 導出物禁止に当たらない。掃除は OS の /tmp 回収に委ねる — 再起動・定期清掃で消える)。`.gitignore` に頼らない (repo 内に揮発物を置かない)。

**(1) hook-boot.sh — 現況 6 行 + 滞留 1 行 (条件付き) の注入 (全経路 exit 0・git は読み取りのみ・LLM 0・ネットワーク 0)**

```
[llm-wiki] entities: org 12 / person 34 / project 8 / task 5 / community 6 / account 9 / product 4 / concept 18 (計 96)
[llm-wiki] records: 412 (2026-08 は 23)  最新: 2026-08-02
[llm-wiki] 直近 3: <records の新しい順 3 件のパス + title>
[llm-wiki] 今日の 1 枚: <wiki dust -n 1 の出力>  ← 偶発的再会
[llm-wiki] ⚠ 滞留: 未 commit N 件 / 未 push M 件 — …   ← 滞留がある時だけ (v1.8)
```

glob + head + `wiki dust -n 1` (node) + **git の読み取り (status / rev-list — pull はしない)** で作る —
ネットワーク 0・LLM 0。**未 commit のパスは出さない** (worktree は共有 — 他セッションの書きかけを
新セッションに拾わせる事故 = C-致命1 の boot 側経路を作らない) が、滞留の**件数だけ**は末尾 1 行で出す (v1.8)。

**(2) hook-lint.sh — 書いた瞬間の検査 + 自セッション台帳の記帳**

```
stdin JSON → sid, file_path
file_path が entities/|records/ 配下の .md でなければ exit 0
file_path を /tmp/llm-wiki-<sid>.paths へ「<内容 sha256> <絶対パス>」で**追記** (O_APPEND = 原子的。同一パスは Stop 側が最後の行を採る)。台帳に載るのは Write/Edit 経由のみ — Bash 等で直接書いたファイルは Stop の対象外 (自分で wiki save を打つ。save 側にも E ゲートあり)
scripts/wiki lint --hook <file_path>   # E のみ検査 (X はやらない — 記録を先に書き参照先を後で
                                       # 作る正当な順序を邪魔しない)。E があれば理由を stderr に出して exit 2
```

**(3) hook-stop.sh — 自セッション分だけの安全網 (B-F2-a/b/d の修理)**

```
stdin JSON → sid, stop_hook_active
stop_hook_active = true → **差し戻し (exit 2) だけを封印し、save はやる** (即 exit 0 にすると
「E を直したのに commit されないまま終了」になる — fresh レビューが live で実証したバグの修理。
無限ループの原因は exit 2 であって save ではない)
台帳 /tmp/llm-wiki-<sid>.paths が無い/空 → exit 0     # 他セッションのファイルには一切触らない
台帳のうち「未 commit かつ 現在の内容 hash = 記帳 hash」のものだけを対象にする (不一致 = 他セッションが
  その後に変更 → 対象外と stderr に明示して触らない — 所有権の誤認で他人の編集を commit しない)。無ければ exit 0
per-file に scripts/wiki lint <path> で clean と E に分ける (全体 lint はしない)
  clean 分 → 先に scripts/wiki save <clean paths> (E の巻き添えで正常な記録を滞留させない)
  E 分あり → ガード /tmp/llm-wiki-stop-<sid> が無ければ作って理由と共に exit 2 (1 セッション 1 回だけ差し戻し)
             2 回目は「未 commit のまま残す (E あり): <bad paths>」を stderr に出して exit 0 (毒饅頭にしない)
```

### 5-7. fixtures (回帰テスト — 「中心決定が壊れるケース」から並べる。B-F17 の教訓)

`scripts/fixtures/ok/` は §3-4 の 6 枚 + 依存 stub で**閉じた集合** (参照先を全部含める —
C-重大6 の再発防止)。fixtures の検査は `wiki lint --all --root scripts/fixtures/ok` で行い、
本体データの走査からは常に除外する。必須の異常系:

1. **多重親 4 パターン** (菱形 / 深い合流ラティス / 2 親別祖先 / 真の閉路) — X3 が菱形を通し閉路だけ検出すること
2. E1 (block 配列・CRLF) / E3 (title 配列化) / E5 (4hex 無し) / E8 (tgas タイポ) / E9 / E15-E18 の各 1 枚
3. X1 (壊れリンク + code block 内 `[[…]]` は非検出) / X2 (正規化一致の重複) / X4 (domain 違反)
4. `--hook` モード: X1 相当 (未作成参照の壊れリンク) が**発火しない**こと

実装完了の定義: `wiki lint --all --root scripts/fixtures/ok` が 0 件、異常系が期待コードで全発火。

### 5-8. README.md (外向け 1 画面)

何のリポジトリか / 入口は `foyer ask llm-wiki "…"` / 直接編集せず foyer から /
ディレクトリ 2 本の意味 / 正本は SPEC.md と ref-wiki-schema、の 5 点のみ。

---

## 6. シナリオ 1-6 の正式トレース

> 注: トレース中の ID (org/acme-ai 配下の agent-ops-biz / dc-agent-builders / kenji-sato 等) は**設計例**で、
> 実体は `scripts/fixtures/ok/` にある (実データに全部あるとは限らない)。実データでの等価実走は
> 設計審査時の E2E で実測済み (一次証拠は本配布に含めない) — 検収 (§10-2) は等価データで読み替えて実測する。

`$` = 司書のコマンド、`→` = 書くファイル。前提: SessionStart の 6 行が context にある。

### 6-1. 記事投入 (BRIEF §6-1)

入力: 「この記事いいなと思った: https://www.anthropic.com/engineering/building-effective-agents
ツール設計が主戦場という指摘が刺さった。wiki に入れて」

```bash
# Skill(ref-wiki-schema) → Skill(run-wiki-capture)
$ rg -lF 'source: https://www.anthropic.com/engineering/building-effective-agents' records/   # 重複投入チェック (-F)
$ rg -in '^(title|aka):' entities/ | rg -i 'anthropic|agent'     # 既存突合 (正規化して照合)
$ scripts/wiki new entity org anthropic                          # → EXISTS entities/org/anthropic.md (再利用)
$ scripts/wiki new entity concept tool-design                    # → 予約成功 → Read → Write (3 行 stub + aka 日英)
$ scripts/wiki new record note anthropic-building-effective-agents
# → records/2026/08/2026-08-02-anthropic-building-effective-agents-9c1a.md
→ Write (§3-4 ⑤ の形。依頼者の言葉を逐語 / 補足は「補足 (司書):」)
#   PostToolUse hook が E を即検査 (壊れリンク X1 はここで出ない — 正当な作成順序を邪魔しない)
$ scripts/wiki save records/2026/08/2026-08-02-…-9c1a.md entities/concept/tool-design.md
```

返答: `入れた: <パス> / 繋いだ: org/anthropic, concept/agent-design, concept/tool-design /
新規: concept/tool-design (stub — 記録が増えたら見取り図を書く)`

### 6-2. 発信者の観測 (BRIEF §6-2)

```bash
$ rg -in '^(title|aka):.*naval' entities/                        # account と person 両方を突合
$ scripts/wiki new entity account x-naval                        # 無ければ予約 → Write (alias-of は person が
                                                                 # 判明していれば張る。無理に stub を作らない — 庭師が繋ぐ)
$ scripts/wiki new record obs naval-leverage-judgment
→ Write  # about: [account/x-naval, concept/leverage] / by: [account/x-naval] / confidence: 事実
$ rg -Pl '\baccount/x-naval(?![a-z0-9-])' records/ | sort -r | head -30   # 過去の観測と並べて返す
$ scripts/wiki save <paths>
```

### 6-3. コミュニティと事業の紐づけ (BRIEF §6-3)

```bash
$ rg -in '^(title|aka):' entities/ | rg -i 'agent.?builders|事業△|agent ops'   # 3 固有名すべて突合
# 「事業△」が同定できない場合 → 断らず concept/unresolved 経由の obs で受ける (§1-5)
$ scripts/wiki new entity project agent-ops-biz     → Write (part-of: [org/acme-ai])
$ scripts/wiki new entity community dc-agent-builders → Write (part-of: [project/agent-ops-biz])  # ★ 親から作る
$ scripts/wiki new record obs dc-agent-builders-tool-retry
→ Write  # about: [community/dc-agent-builders, concept/tool-design] / by: [person/kenji-sato]
$ rg -Pn '^part-of:.*\bproject/agent-ops-biz(?![a-z0-9-])' entities/   # 辿れることを確認してから返す
$ scripts/wiki save <paths>
```

### 6-4. エンティティ集約 (BRIEF §6-4「acme-ai について知ってること全部」)

```bash
# Skill(run-wiki-recall) — 読み取り専用
$ rg -in '^(title|aka):.*アクメ' entities/            # ① ID 特定 → org/acme-ai
$ Read entities/org/acme-ai.md                        # ② 本体 (> の 1 行定義)
$ scripts/wiki links org/acme-ai --depth 4            # ③ 子孫を 4 段 (visited 集合・多重親 OK)
#   = rg -Pln '^(part-of|member-of|works-on):.*\borg/acme-ai(?![a-z0-9-])' entities/ を再帰したもの
#   org/acme-ai → project/agent-ops-biz → community/dc-agent-builders → person/kenji-sato
#                → task/contract-review-acme                     (4 階層 = BRIEF §2-1)
# ④⑤ 一族 union + alias 展開の記録は links が返す (③ と同じコマンド — shell で ID 合成しない)。
#    --paths で全件パスを取り、cards で 1 件 1 行に圧縮してから上位 5-8 本だけ Read (新しい順が既定)
$ scripts/wiki cards $(scripts/wiki links org/acme-ai --paths | head -8)
$ Read <上位 5-8 本>
```

返答の型: `■ 本体 (1 行定義) / ■ 配下 4 階層のツリー / ■ 紐づく記録 (新しい順・件数明示) /
■ 隣接して見つかったもの 2-3 件`。**検収条件: 4 段目の子孫 (kenji-sato) に紐づく記録が集約に出ること。
alias-of 先 (account 経由の観測) が出ること。出なければこのシナリオは fail** (§10-2)。

### 6-5. 横断検索 (BRIEF §6-5「先月 agent design 関連で入れた記事どれだっけ」)

```bash
# 「入れた」= 投入日 → R10 (git author date) が正。note の日付 = 判断日 ≒ 投入日なので
# ディレクトリでも大半は当たるが、正確には git で引く (B-F6 の修理)
$ git log --diff-filter=A --since=2026-07-01 --until=2026-08-01 --format='%aI' --name-only -- records/ | rg '^records/'
$ <上記> | xargs rg -Pl '\bconcept/agent-design(?![a-z0-9-])' | xargs rg -l '^type: note'
$ scripts/wiki cards <上記>
# 表記ゆれの保険: concept の aka を読んで全文でも当てる
$ rg -n '^aka:' entities/concept/agent-design.md ; rg -in 'エージェント設計|agentic design' records/2026/07/
```

### 6-6. 庭師 (BRIEF §6-6)

```bash
# Skill(run-wiki-garden)
$ scripts/wiki lint --all --json          # E + X + W。stdout を読むだけ (ファイルに書かない)
# E 系 (過去の混入分): 単体書式 — 1 件 1 commit で直す (記録の frontmatter の機械的訂正は庭師のみ可 — §7-5)
# X1 壊れリンク: 近い slug を探す → 誤記なら直す / 未作成なら stub / 不要なら素の名前に戻す
# X2 正規化衝突: 統合手順 (§7-5)。自動で統合しない — 別物かもしれないものは残件として列挙
# X3 閉路: どちらかを related に落とす
# X4 domain/range: 正しい述語に置き換え
# concept/unresolved の被リンクを毎回全件処理する (同定できたら about を張り替えた新記録で訂正)
$ scripts/wiki dust -n 3                  # ランダム再訪 — 「今も有効か」を 1 行ずつ。古い判断は新 obs で訂正
$ scripts/wiki lint --all --warn          # W 系を裁く (W9 予約死骸の削除 / W2 孤児 / W6 重複投入の集約)
$ scripts/wiki save <直したpaths> && scripts/wiki sync    # sync は庭師だけが打つ (直列 rebase + push)
```

返答: 直した件数 + **判断が要る残件の列挙** (宛先は §10-3)。

---

## 7. スキーマ進化

1. **lazy migration** — 旧ノートは触らない。触った時に直す。一括 sed を禁止
2. **フィールド追加は optional から**。手順: lint の FIELD に足す (先) → ref-wiki-schema に 1 行 →
   templates 更新。必須化は 3 ヶ月 optional で充足率 9 割を実測してから
3. **型・述語の追加は実測条件付き** (D10 の総量固定制が上位規律 — 足すなら削る議論を必ず経る):
   新述語 = related の同種関係 20 件超 / 新エンティティ型 = concept 内の同種 30 件超 + 専用属性の必要 /
   新記録型 = obs 内で別の検索動線が要るもの 50 件超。**必須フィールドの上限: エンティティ 5・記録 7** (C)
4. **廃止**は lint で `DEPRECATED = {old: new}` の WARN + 置換先提示。0 件になったら消す。
   述語を足したら**レシピ側を新旧 or 検索にする** (B-F18-g — 旧データが検索から抜けるのを防ぐ)
5. **改名・統合 (X2 の解消)**: ファイルを消さない。中身と aka を正本へ寄せ、旧ページを
   `alias-of` stub 化 (§3-4 ② の形・W5 特例)。主要リンク元だけ張り替える — 残っても links の alias 推移閉包が辿る (旧名を part-of で指す子・多段の改名連鎖も子孫/union に入る)。
   **記録の本文は不変**だが、frontmatter の機械的訂正 (about の typo 等) は**庭師のみ可**と明文化する
   (C-重大9 の矛盾解消。訂正は 1 件 1 commit・本文に触らない)
6. **schema_version は持たない**。実行可能な正本は lint。SPEC.md 末尾に日付 1 行の変更履歴

---

## 8. 維持コスト検算 (BRIEF §4-2)

| 項目 | 値 | 根拠 |
|---|---|---|
| 常駐プロセス / cron | **0 / 0** | hook は走って終わる。庭師は依頼駆動 |
| 書き時に更新する導出物 | **0** | backlink・一覧・件数・更新日を保存しない。cards/links は毎回 head 読み/grep (状態ゼロ) |
| 外部依存 | **node 22+ / git / rg (PCRE2)** | すべて実行環境に実測あり。npm 依存 0 (パーサ自作)。rg は必須と正直に宣言 (B-F11 — `grep -rE` 代替は原理的に不可能なため約束しない) |
| 二重管理される事実 (データ) | **0** | 日付 = パス / 更新日 = git / ID = パス / backlink = grep / 親子 = 子側のみ |
| 二重管理される規約 (文書) | **運用正本 1 箇所** (ref + templates。SPEC §4-3/§5-2/§5-3 は設計写しで、ずれたら ref/実物が勝つ — 冒頭の優先順位規定) | D10。CLAUDE.md の grep 型 1 行のみ例外 |
| 1 投入の書き込み | 1-3 ファイル (全て新規) | 既存編集は aka 追記と庭師の訂正のみ |
| コンフリクト面 | 新規追加は構造的に 0 (O_EXCL + 4hex + pathspec commit + EXISTS-EMPTY の予約中明示)。**既存エンティティ編集 (aka 追記等) は Read→Edit 規約 + Stop 台帳 hash が防衛線 (機構強制ではない — 素の Write の同時上書きは検出しない)** | index.lock は retry 12 回 |
| 性能 (3,000 ノート ≈ 5MB) | grep 30-90ms / lint --all 0.5-1s / links 4 段 ≈ 200ms | B §10-1 + 批評実測 (3,012 件で 88-95ms)。1 万ノートでも 1 秒以内 (BRIEF §5 充足) |
| 読み出しの context 上限 | links の全節に打ち切り (子孫 60 / 被リンクエンティティ 30 / 記録 30 — 件数は常に全数明示)・cards 1 件 1 行・W コード別 50 件 | ハブ 804 件でも links + cards で数 KB (B-F12 の 45KB を封鎖) |
| 壊れうるもの | lint/scripts 自身・hook 設定・リンク整合 の 3 つのみ | どれが壊れても markdown は全部読める。サイレント破損経路は D13 (alias 展開・author date) と D5 (O_EXCL) で封鎖済み |
| 警告の量 | 既定出力は E/X のみ | W は --warn 時のみ + 猶予日数付き (B-F10 の洪水防止) |

---

## 9. 不採用と理由

### a-minimal から採らなかったもの

| 案 | 理由 |
|---|---|
| 型 4 語 (org/person/work/thing) + 記録型なし | 「記事 = src の有無」の前提が偽 (X も Discord も URL を持つ — A-S3)。型軸のシナリオ 5 が機能しない |
| `up:` 単一親 | 多重親 (BRIEF §2-2 の合弁・事業またぎ) が表せない。末尾スペースで静かに消える実測 (A-F3) |
| 必須 H1 のみ・frontmatter 全任意 | about 必須 (D9) を失うと孤児記録が既定になる。集約 (A-F2: 子孫の記録 0 件) が実測で崩壊した |
| 自由 `tags` | 発見手段が無く発散一方 (A-S6)。分類は concept リンク + 突合強制で解く (D11) |
| 短縮 `[[slug]]` | 曖昧解決にインデックスか全走査が要る。ID 完全形なら grep が即答 |
| 総量固定制の「規約数の絶対固定」 | 穴を塞ぐ追加を構造的に拒否する (A-F7/S5 のジレンマ)。**予算と「足すなら削る議論」に転用**して採った (D10) |

### b-graph から採らなかったもの (骨格採用・ここだけ差し替え)

| 案 | 理由 |
|---|---|
| Stop hook の全体 lint ゲート | 毒饅頭 + 相互デッドロック (B-F2 実測)。自セッション台帳 + 等級制に差し替え (D9) |
| 「表記ゆれは壊れリンク検査で死ぬ」という D8 の論拠 | 偽 (書き手が参照先を同時に作るので X1 は発火しない — B-F3 実測)。concept 自体は残し、防衛線を capture 突合 + X2 正規化一致に移した (D11) |
| `shuf` 依存のランダム再訪 / `grep -rE` フォールバックの約束 | 実行環境に shuf が無い・ERE で否定先読みは不可能 (B-F11 実測)。dust (node) と正直な依存宣言に差し替え |
| `.wiki-stop-retry` (repo 内・単一ガード) | 並行 2 セッションで無力化 (B-F2-b)。/tmp のセッション別ガードに差し替え |
| 記録の `by:` に司書判断を混ぜた模範解答 | LLM の作文が依頼者の判断として保存される (B-F14)。2 ブロック分離 (D12) に差し替え |
| `wiki-links.sh` (仕様参照のみで実体未定義) | `wiki links` として契約を明文化 (§5-4)。再帰集約が無いと S4 が回らない (B-F12) |

### c-ops から採らなかったもの

| 案 | 理由 |
|---|---|
| kind 6 語彙 + `topic`/`tags` の二重系 | tags と topic の同 slug 空間は「同じ語を 2 箇所に書く」二重管理。concept 1 本に統一 |
| `parent:` 単一親 (0..1) | 多重親要件 (BRIEF §2-2) を rel へ逃がすと構造層の grep (R3) から抜ける。part-of 複数可に統一 |
| E6 (kind: read に一人称の意見を error で強制) | 読んでいない記事への意見を機械的に強制 = 捏造の量産装置 (C-重大8)。**3 judge が明示的に「移植するな」と指定** |
| `by:` マシン名必須 / `date:` フィールド | 単一マシン運用で全記録同値 = ゼロ情報 (C-中17)。日付はファイル名と二重管理 |
| save 内の `pull --rebase` | 並行下で必ず状態拒否 (C-致命2 実測)。庭師専用 `sync` に分離 |
| 裸文字列 grep (`rg -l "person/naval"`) | prefix 誤爆 (C-致命4 実測)。境界付き grep の型 (§4-2) に統一 |
| 日付 seed の dust / `head -q` `shuf` の素コマンド等価物 | 1 日 20 boot で同じ 1 枚が 20 回 (C-重大11) / BSD で動かない (C-重大7 実測)。セッション seed + node 実装 |
| 統制語彙ファイル・digest cron・SQLite 等 | 3 案共通の却下 (BRIEF §4-2/4-5 違反) — B §11 の却下表をそのまま引き継ぐ |

---

## 10. 立ち上げ手順と受け入れ条件

### 10-1. 立ち上げ (この順で 1 セッション) — 実施状況は各行末尾 [済/残]

1. ディレクトリ骨格 + `.rgignore` + `scripts/wiki` (9 動詞) + hook 3 本 + fixtures (§5-7) [済 2026-08-02]
2. `wiki lint --all --root scripts/fixtures/ok` 0 件・異常系全発火を確認 (**多重親 4 パターン必須**) [済 — scripts/test.sh]
3. CLAUDE.md (§5-2・≤40 行) / skill 4 本 / templates 3 枚 → skill frontmatter の規約検定 [済 — 0 error。検定器の版・設定により ref-* 慣行の WARN が 0-2 件出る (user-invocable/disable-model-invocation — 司書がモデル起動で ref を開く設計のための意図的逸脱として受容)]
4. 新しい claude セッションを実際に立て、hook 発火を実測 (boot 6 行 / 壊れ frontmatter の exit 2 差し戻し /
   Stop の自セッション限定 commit) [済 — 一次証拠は設計審査時の E2E 実測 (ask 8 本と repo 側検証の突合表 — 本配布に含めない)。A4 (O_EXCL/4hex) は test.sh (c)、A5/A7 と hook 系は (d)(e)(g)(h) ブロックで恒常回帰化、A6 の重複生成率は実測 10/10 捕捉・すり抜け 0]
5. foyer のカタログに `llm-wiki` を登録 (自然文の依頼がこの repo の司書セッションへ届く経路を開通) [済]
6. **読み出し需要の設置 (D16 — これを飛ばすと全設計が v1 fusen の再演になる)**:
   foyer カタログの description を「外の世界の人物・会社・コミュニティ・記事の背景を自然文で聞ける/入れられる」
   と読み出し側から書く + 運用環境の共通ガイド (全エージェントが読む規約) に
   「人物・会社・コミュニティの背景が要るときは `foyer ask llm-wiki`」の導線 [済 — 共通ガイドの
   「記憶の書き分け」へ恒久の行き先として設置 (オーナー採択・全マシンへ配布)]

**初期蔵書の注記**: 立ち上げ期の構築メタ記録はオーナー指示 (2026-08-03) で整理済み — プロセス記録 8 枚 +
架空のシミュレーション入力 3 枚を削除し、総括 1 枚に統合 (原本は本配布に含めない)。整理後のメタ比率は
約 24/60。以後も実運用の投入で希釈される。

### 10-2. E2E 受け入れ (BRIEF §2-6 の 95 点ループに載せる検収 — 「嘘を返したら fail」)

| # | 検収 | fail 条件 |
|---|---|---|
| A1 | S1-S3 を foyer 実走 → 生成パス・結線が返答どおり repo に実在 | 自己申告と実体の不一致 |
| A2 | S4: **4 階層目の子孫**の記録が集約に含まれる / **alias-of 先** (account 経由の観測) が person 引きで返る | どちらか欠けたら fail (B-F2/F4 の再演) |
| A3 | S4/S5 の提示が新しい順・上限付き・cards 経由 | 最古順で 45KB を吐いたら fail |
| A4 | 並行 2 セッションで同一人物を同時投入 → エンティティ 1 つ・aka 消失なし・両記録が残る | silent overwrite で fail |
| A5 | 片方のセッションに E を仕込んで Stop → **もう片方の commit が止まらない** | 毒饅頭の再演で fail |
| A6 | 同義 concept を 2 セッションで別名投入 → capture 突合か X2 が捕まえる。**重複生成率を実測して報告** | 両方 lint 0 件のまま共存し続けたら fail |
| A7 | JST 早朝相当 (TZ 偽装) の投入で日付が 1 日ずれない | ずれたら fail |

### 10-3. 庭師の駆動と判断の宛先 (設計審査で挙がった最大リスクへの回答)

- **駆動**: capture / recall の返答末尾に、`wiki lint --all` の E+X 件数が 0 でない時だけ
  「⚠ wiki に要修理 N 件 — `foyer ask llm-wiki "掃除して"` で回収できます」を 1 行添える (契約)。
  cron は使わない — 書き込み・読み出しのついでに可視化し、呼び出し元に庭師起動の材料を渡す
- **判断が要る残件** (統合の是非・孤児の削除など) は保留台帳を作らず、庭師の返答で依頼元へ列挙する。
  人の判断が本当に要るものは運用側の人間の承認・レビューへの送付を**提案として**返す
  (司書が勝手に送らない)

---

## 変更履歴

| 日付 | 変更 |
|---|---|
| 2026-08-15 | v1.14 — **note を構造抽出へ (オーナーとの盲検較正 + 承認レビュー 2 往復の裁定)**: 盲検較正で v1.13 形式が 1 点 (source の中身まで踏み込めておらず、構造化した切り出しが足りないという裁定)、承認レビュー 2 回で確定形を承認。note = 結論 1-2 文 → 骨格 (章単位の「要点 + 原文逐語引用 + 元の型」、章見出しに [point 0-5] = LLM ジャッジの残す価値) → 依頼者の言葉 (逐語)。**司書の評論は全廃** (司書補足に価値なしの裁定)。「引き出し方」欄は不採用。型定義 §1-4・不変条件 1・§3 記録本文・BRIEF §4-1・templates/record-note.md・capture 手順 4 を同期 |
| 2026-08-15 | v1.13 — **note に中身の義務化 (note の中身が薄いというオーナー裁定)**: 必須 3 点 (論旨 2-4 文 / 刺さった箇所の原文逐語引用 1-3 本 / なぜ良いかの判断) を型定義 §1-4・不変条件 1・BRIEF §4-1・templates/record-note.md・capture 手順に統合し、禁止を「全文の中立要約」だけに限定 (URL は腐るので中身ごと残す)。source を読めない・論旨が書けない投入は unresolved の obs で受け、空の note を作らない。併せてオーナー指示の蔵書整理第 2 弾 — プロセス記録 18 枚を総括 1 枚へ統合し、棚を外の世界の知識に一意化 |
| 2026-08-02 | v1.0 — 3 案 + 3 批評 + 3 judge 審査の統合初版 |
| 2026-08-02 | v1.1 — `wiki new record --date` を追加 (E2E 実走で発覚: obs の「出来事日 = ファイル名」§2-3 を CLI が満たせなかった。庭師も同穴を独立指摘)。capture skill / test.sh 追随 |
| 2026-08-03 | v1.12 — **live 実運用ルールで合格 ([95, 96, 94.5] 平均 95.2 — 評価者 3 名が foyer 読み書き両方を実走し嘘 0、第三者セッションとの並行完走も実観測)**。合格後の磨き: 庭師再訪に「判定前に訂正記録の被リンク確認」(live で失効見落としが実測された根因の手順化) / 滞留カウントを -uall に (新規 dir の畳み込みで 3,026→298 と過少申告していた) / dust の 0 バイト予約スキップ / links の記録 ID に R4 への案内 / find の entities 限定を §5-4 に明記 / R5 同日内順序の開示 / /tmp 台帳の掃除方針明記 |
| 2026-08-03 | v1.11 — live 採点 Round 2 ([98,92.5,93] — 評価者が実在コンテンツの投入と庭師 end-to-end を live 検証) の指摘を修理: **W10 (by の対象が about に無い) を新設し既存 18 件を一括訂正** (live 投入で実測された about 抜けの機械化 — 評価者自身の投入分も検出) / hook-stop ヘッダと §5-6(1) 散文 (4 箇所目) の stale 一掃 / cards 打ち切りを stdout 末尾へ (パイプで消える stderr 通知の解消) / find を entities/ のみ走査に (記録量に線形の無駄を除去) / §6 トレースに設計例注記 / CLAUDE.md に複合依頼の行 / capture に「繋がり主張も実測軸だけ」 / R4 に過剰一致注記 |
| 2026-08-03 | v1.10 — 書き込み live 込み採点 Round ([98,91.5,90]) の指摘を修理: hook-boot の契約文 2 箇所を v1.8 実装 (滞留行) に追随 (SPEC §5-6(1) 見出し・サンプル・script ヘッダ — 契約が実装の嘘になっていた) / §10-1-5/6 の実施状況を実態へ (カタログ登録済・共通ガイド導線設置済) / cards の 0 件明言と help 5 列表記 / R10 に approxidate 注記 (裸日付は境界日が落ちる) / capture・recall に「補足 3 点以内」「lint 言及は実測範囲だけ」の返答規律 (live で W 未実測断言が出た穴) / test.sh に D10 行数予算の機械ガード / 初期蔵書の構築メタ比率を §10-1 に正直化 / シミュレーション由来の投入 2 枚に出所明示の訂正記録 |
| 2026-08-03 | v1.9 — 実運用シミュレーション 12 本 (live foyer: 投入・alias・曖昧→unresolved・一括分割・訂正・重複 URL・ファイルパス渡しの長文・並行 2 ask・集約・共通ガイド導線の fresh 経路・庭師・時系列 + 接続断からの回収) を走破。逸脱 2 件を規約化: **月精度日付は月初 + 本文明記** (S-4/S-8 で司書が独立収束した運用の追認) / **庭師が本文内申し送り (未結線等) を grep 回収する手順** (ephemeral 返答に埋もれて回収されない構造の修理) |
| 2026-08-03 | v1.8 — オーナー依頼の context-fresh レビュー (live claude セッション実走 — 合成 stdin では見えない層) の指摘を修理: **差し戻し後の継続ターン (stop_hook_active=true) で修正済みファイルが commit されず置き去りになるバグ** (active 中は exit 2 だけ封印し save は実行する形へ) / boot に滞留件数行 (未 commit / 未 push — exit-0 stderr の warn は誰にも届かない実証への対処) / hash 不一致メッセージの誤誘導修正 (「別セッション」断定をやめ Bash 自己編集の可能性と対処を明示)。レビュー提案 3 のうち「hash 不一致でも lint clean なら save」は不採用 (他セッションの書きかけを commit する A5 系の危険)。回帰 109 本 |
| 2026-08-02 | v1.7 — 採点 Round 6 ([94,96.5,90.5] — live foyer 読み出しで「嘘 0」を 2 名が実測) の減点根拠を修理: **一族 union を深さ無制限の全閉包に** (depth 打ち切りで 5 段目の記録が「全 0 件」になる silent 経路の封鎖 — 表示だけ depth で打ち切り明示) / §3-1-6 (配列要素のカンマ) を E1 に実装 / find に編集距離 1-2 の近接ゆれ (カーパシー→カルパシー) / --help 見出し 9 動詞・test.sh の find 網羅 / ref の task 定義を v1.6 と同期・禁止 5 に W9 例外 / capture 手順 5 に R8 濃度確認 / §5-6(1)・§10-1-3 の記述を実装と一致へ / §5-3 ミラーも同期ガード化 (3 本目) |
| 2026-08-02 | v1.6 — 採点 Round 5 ([98,92.5,86.5]) の減点根拠を修理: **`wiki find` 動詞を追加 (9 動詞)** — capture の既存突合を正規化一致の機械実行に一本化 (同義増殖 = 最大劣化要因への機構防衛。手続き依存を廃止) / `EXISTS-EMPTY` で「予約中」と「実体あり」を区別 (予約窓の last-writer-wins を明示) / `links --paths` 200 件超 warn + `cards` 60 件上限 / R10 を両軸 1 セット化 (author date + 日付 dir — 片肺の黙った 0 件封鎖) / R1 に find・R4 に記録 ID 例 / §5-3 ミラーを skill 実物と同期 / §8 の性能・コンフリクト面を実測値で正直化 / recall に同一 source 再発行の束ね規律 / BRIEF §3 の task 境界を明文化 (記述的記録は可・管理はイシュー管理ツール) |
| 2026-08-02 | v1.5 — 採点 Round 4 ([97,86,94]) の減点根拠を修理: links の全節に打ち切り + 件数明示 (ハブ 51KB の context 洪水封鎖)・**祖先節** (上向き非対称の解消)・alias を**推移閉包**に (2 段改名の取り落とし封鎖)・改名 stub の旧名を part-of で指す子も子孫/union に (張り替え漏れの配下記録の救済) / W をコード別 50 件で打ち切り / W6 を記録全般に拡張 (obs 再発行の可視化) / X1 のインラインコード誤検出除去 / capture 突合・garden の context 節度 (skill 側) / cards・行数等の文書 stale 一掃 / test.sh に A7 (TZ)・ミラー同期ガード・改名連鎖の回帰 |
| 2026-08-02 | v1.4 — 採点 Round 3 ([98,87,87]) の減点根拠を修理: links に**被リンクエンティティ節** (by/related/alias の入リンク — 「OpenAI ← ChatGPT」型の取り落とし封鎖) / 0 バイト予約の明文ポリシー (E 免除 + X1 明示 + save 拒否 + links 明示) / E15 に aka スカラー / cards の読み窓 8KB + UTF-8 安全化 + about/title 上限 / save の push honesty (未 commit 時に「保存済み」と言わない) / R6 に新しい順・上限 / hook 3 本の回帰を test.sh に編入 / karpathy obs の出来事日再発行 / A6 重複生成率の実測記録 / 実データに 4 階層 (org→project→task→task) |
| 2026-08-02 | v1.3 — 採点 Round 2 ([97,72,85] 不合格) の減点根拠を全修理: **集約の正規経路を `wiki links` の一族 union に一本化** (shell の ID 合成レシピは zsh で「全件誤一致 / 0 件」に静かに壊れることが実証されたため全廃・`--paths` 追加) / save に E ゲート (Bash 書きのすり抜け封鎖) / E18 に status 語彙 / hook 台帳を追記専用 (競合窓の除去) / Stop の clean/E 分割 save / §5-2 写しの同期・§1-5 -F・R10 fallback の SPEC 側反映 |
| 2026-08-02 | v1.2 — レビュー Round 1 (5 レンズ + 敵対検証 24 agents) の修理: save の git 状態 precheck + NOT-SAVED (rebase 中断中の silent 消失 = critical の封鎖) / sync の衝突自動 abort / Stop hook 台帳に内容 hash (所有権誤認の封鎖) / X3 を 3 色 DFS 化 (ラティス指数爆発の修理・深さ上限撤廃) / X1 の予約許容と出力上限 / E1 に重複キー・閉じ忘れ配列 / 「消して」動線 (訂正記録) / R10 フォールバック / source 重複確認の -F 化 / 文書 stale 一掃 (E7・E10・E12 → X 系、行数、レイアウト、§10-1 実施状況)。回帰 71 本 |
