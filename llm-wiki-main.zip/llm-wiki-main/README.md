# llm-wiki

エージェントのための知識ベース。外の世界のエンティティ (会社・人・プロジェクト・コミュニティ・
発信者アカウント…) と、それにまつわる観測・判断の記録を markdown で貯める git repo。
書き手も読み手もエージェント — 人間はこの repo を直接読まない・触らない。

> **デモ版について** — これは第三者配布用のデモです。収録データは公開情報から作ったサンプルで、
> 実在の非公開情報は含みません。

## 思想 (v1 の失敗から引き継いだ原則)

- **正本は markdown だけ** — サーバ・DB・常駐プロセス・cron・導出インデックスは作らない
  (人間が中を覗く時だけ、別配布の読み取り専用ビューア llm-wiki-preview を立てられる — wiki 本体は何も持たない)
- **検索は grep、backlink も grep** — 一覧・件数は毎回読み時に導出する。壊れうる導出物を持たない
- **追記中心** — 記録は書いたら書き換えない。訂正は新しい記録で。並行書き込みはこれで衝突しない
- **クエリエンジンは Claude そのもの** — repo に入った Claude が「司書」として振る舞うよう、
  CLAUDE.md / skills / hooks / 軽量スクリプトでハーネスを組んである

## 入口

```bash
foyer ask llm-wiki "この記事いいなと思った: <URL>。〜が刺さった。入れて"
foyer ask llm-wiki "org/anthropic について知ってること全部"
foyer ask llm-wiki "掃除して"
```

foyer — 登録されたエージェント作業場に自然言語の依頼を届ける窓口 CLI。foyer が無い環境では、
この repo で Claude Code セッションを開いて同じ依頼文を打てば同じ動線が回る:

```bash
git clone <this-repo> && cd llm-wiki-demo
claude    # セッション内で上と同じ依頼文を打つ
```

ファイルを直接編集しない。投入も読み出しも自然言語で完結する。
push 先 (remote) が無くても使える — `scripts/wiki save` は commit まで通り、push と `wiki sync` は
警告を出すだけ。git 履歴なし (tarball 等) で受け取った場合は、使い始める前に `git init` と初期 commit を作る。

## 中身

```
entities/<type>/<slug>.md     世界に持続する名詞 — 8 型: org / person / project / task /
                              community / account / product / concept
records/<YYYY>/<MM>/          日付を持つ観測・判断 — 2 型: note / obs (合わせて型 10)
scripts/wiki                  9 動詞 CLI (node、依存 0、状態 0)
.claude/                      司書ハーネス — skills 4 本 + hooks 3 本
SPEC.md / BRIEF.md            データ契約・設計判断 / 要件
```

## CLI — `scripts/wiki` (9 動詞、詳細は `--help`)

| 動詞 | 何をするか |
|---|---|
| `new entity` / `new record` | 衝突しない新規ファイルの予約 (O_EXCL、records は 4hex 付き) |
| `save <path...>` | pathspec 限定 commit + push。`git add -A` はしない |
| `lint` | 書式検査 — E=単体 / X=横断 (`--all`) / W=警告 (fixtures 同梱) |
| `find` | エンティティの重複確認 (title/aka/slug を正規化突合) |
| `links <id>` | 親・祖先・子孫・被リンクを読み時導出 (一族 + alias union) |
| `cards <path...>` | 記録を 1 ファイル 1 行に圧縮 (集約の前処理) |
| `dust` | 決定的乱択で記録を数枚 — 偶発的再会 |
| `sync` | 庭師専用。clean な時だけ pull --rebase + push |

hooks は自動で回る: SessionStart で蔵書サマリ 6 行 + 今日の 1 枚、Write/Edit の瞬間に lint、
Stop で自セッション分の検査と save。

## 正本 (ドキュメント)

- [SPEC.md](SPEC.md) — データ契約と設計判断 (述語 7・レシピ R1-R10・不変条件)
- [BRIEF.md](BRIEF.md) — 要件ブリーフ。矛盾したらこれが勝つ
- `.claude/skills/ref-wiki-schema/` — 書き方・レシピの運用正本 (templates 付き)

世代の呼称 (固定): v1 fusen 構想 → v2 Cloudflare Worker → v3 repo 完結 CLI → **v4 現行
(filesystem + Claude ハーネス駆動)**。この demo repo は v4 の設計だけを収録している —
過去世代の実装は含まない。

## 利用条件

本 repo にオープンソースライセンスは付与していない (All rights reserved)。
閲覧・評価を超える複製・改変・再配布・商用利用はできない。
