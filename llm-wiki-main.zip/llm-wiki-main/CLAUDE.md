# llm-wiki — エージェントの知識ベース (司書はあなた)

外の世界のエンティティと観測を貯める git repo。書き手も読み手もエージェント。人間は読まない。
サーバ・DB・常駐・cron・導出インデックスは作らない。正本は entities/ と records/ の markdown だけ。

## 依頼が来たら (最初の 1 手 — skill を開かずに書き始めない)

| 依頼の形 | 開くもの |
|---|---|
| 入れて / 記録して / これ良かった / 〜と言ってた | Skill(ref-wiki-schema) → Skill(run-wiki-capture) |
| 〜について教えて / どれだっけ / 全部出して | Skill(run-wiki-recall) |
| 掃除して / 壊れてない? / 整えて | Skill(run-wiki-garden) |
| 消して / 取り消して / 間違ってた | Skill(run-wiki-capture) — **訂正記録**を作る。ファイルは消さない |
| 入れて + 教えて (複合) | 投入 → 読み出しの順に両方こなす (どちらかを黙って落とさない) |
| 書式・ID・リンクで迷ったら | Skill(ref-wiki-schema) |

## 不変条件 (破ると壊れる)

1. 禁止は全文の中立要約と note への司書の評論。note は構造抽出で中身を運ぶ — 結論 + 章単位の要点・原文逐語引用・元の型、章見出しに [point 0-5] (URL は腐る)。依頼者の言葉は逐語、obs の司書補足は出所明示
2. 導出物を保存しない。backlink・一覧・件数は毎回 rg で読み時導出する
3. 親ファイルを触らない。リンクは常に子が親を指す (並行セッションが衝突する)
4. 記録の本文を書き換えない。訂正は新しい記録で (エンティティは Read → Edit で編集可)
5. 新規作成は必ず scripts/wiki new 経由 (衝突予約)。ディレクトリを増やさない

## grep の型 (ID 検索はこの形のみ。-P と否定先読みが無いと別 ID に誤爆する)

    rg -Pl '\borg/acme-ai(?![a-z0-9-])' entities/ records/

## 地図と作法

entities/<type>/<slug>.md (8 型) / records/<YYYY>/<MM>/<日付>-<slug>-<4hex>.md (note|obs)
scripts/wiki — 9 動詞: new entity / new record / save / lint / find / links / cards / dust / sync (--help あり)。日付は JST。
書いたら scripts/wiki save <paths> (pathspec 限定 commit + push)。git add -A 禁止。
foyer — 登録されたエージェント作業場に自然言語の依頼を届ける窓口 CLI。foyer が無い環境では、この repo で Claude Code セッションを開いて同じ依頼文を打てば同じ動線が回る。
foyer への返し方 — 投入: 作ったパス / 繋いだ ID / 新規に立てた ID を 3 行。
読み出し: 答え + 根拠パス + 隣接 2-3 件。長文はファイルパス渡しで来る → Read で開く。
