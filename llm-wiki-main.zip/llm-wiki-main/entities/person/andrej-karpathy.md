---
type: person
title: Andrej Karpathy
aka: [アンドレイ・カルパシー, Andrej Karpathy, カルパシー, karpathy]
created: 2026-08-02
status: active
related: ["former-member-of org/tesla", "former-member-of org/openai"]
---

> 元 Tesla の AI director で OpenAI 創設メンバー (依頼者による)。X の [[account/x-karpathy]] から発信し、その言葉がエージェント設計の文脈で繰り返し引かれる人物としてこの wiki で追う。

所属は両方とも過去のものとして `related` の自由述語で持つ (現所属は未確認のため `member-of` を張らない)。
