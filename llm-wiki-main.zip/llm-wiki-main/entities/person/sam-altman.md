---
type: person
title: Sam Altman
aka: [サム・アルトマン, Sam Altman, sama]
created: 2026-08-03
member-of: [org/y-combinator, org/openai]
---

> [[org/y-combinator]] の 2 代目社長 (2014 年に [[person/paul-graham]] から継承)・[[org/openai]] CEO。YC の世代交代の当事者としてこの wiki に立てた stub — 記録が増えたら見取り図を書く。
