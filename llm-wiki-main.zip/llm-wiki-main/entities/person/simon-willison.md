---
type: person
title: Simon Willison
aka: [サイモン・ウィリソン, Simon Willison, simonw, simonwillison]
created: 2026-08-03
status: active
---

> ブログ simonwillison.net で LLM 周辺を書き続ける人物。2022-09-12 に「prompt injection」という語を定義し、エージェント設計のセキュリティ語彙の起点を作った人としてこの wiki で追う (依頼者による)。

X は [[account/x-simonw]]。発言の観測はそちらの ID を対象に記録する。

司書注: 一般には Django 共同開発者 / Datasette 作者としても知られるが、これは依頼者の言及ではなく司書の一般知識で未検証。
