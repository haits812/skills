---
type: person
title: Elon Musk
aka: [イーロン・マスク, Elon Musk, マスク]
created: 2026-08-03
member-of: [org/tesla]
---

> 起業家。[[org/tesla]] を率いる。この wiki では [[org/openai]] 設立時 (2015) の共同議長としての参照先に立てた stub — 記録が増えたら見取り図を書く。
