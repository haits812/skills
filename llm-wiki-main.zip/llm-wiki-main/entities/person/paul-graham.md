---
type: person
title: Paul Graham
aka: [ポール・グレアム, PG, pg]
created: 2026-08-02
member-of: [org/y-combinator]
---

> Y Combinator 共同創業者・エッセイスト。この wiki には YC の歴史の実事実 (創業・社長交代) の当事者として登場する。
