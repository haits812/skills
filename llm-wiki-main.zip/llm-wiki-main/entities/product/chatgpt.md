---
type: product
title: ChatGPT
aka: [チャットジーピーティー, chatgpt, チャットGPT]
created: 2026-08-02
by: [org/openai]
---

> [[org/openai]] の対話型 LLM サービス。「言葉の電卓」の喩えの対象として棚に入った。
