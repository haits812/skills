---
type: product
title: GPT-5
aka: [ジーピーティー5, GPT-5, gpt5]
created: 2026-08-03
status: active
by: [org/openai]
related: [product/chatgpt]
---

> [[org/openai]] が 2025-08-07 に正式リリースした LLM。推論モデルと通常モデルをルーターで自動振り分けする単一系として出され、
> 「使い手にモード選択を晒さない」製品判断の実例としてこの wiki に入った ([[2025-08-07-openai-gpt5-router-single-system-07a1]])。
