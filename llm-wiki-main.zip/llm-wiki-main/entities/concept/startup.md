---
type: concept
title: スタートアップ
aka: [起業, 事業立ち上げ, startup, startups]
created: 2026-08-02
---

> 事業・スタートアップの進め方。初期のユーザー獲得や競争優位など、事業判断の記録が集まる結節点 (旧 v3 統制語彙 startup から移行)。

    rg -Pl '\bconcept/startup(?![a-z0-9-])' records/ | sort -r | head -30
