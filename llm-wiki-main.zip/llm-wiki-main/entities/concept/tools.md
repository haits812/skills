---
type: concept
title: 道具と環境
aka: [道具, ツール, 開発環境, tools]
created: 2026-08-02
---

> 道具・環境の選び方。ファイル形式や開発環境など、何を使って作るかの判断が集まる結節点 (旧 v3 統制語彙 tools から移行)。

    rg -Pl '\bconcept/tools(?![a-z0-9-])' records/ | sort -r | head -30
