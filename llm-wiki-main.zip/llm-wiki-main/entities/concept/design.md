---
type: concept
title: デザイン
aka: [見た目, UX, design, aesthetics, 美的センス]
created: 2026-08-02
---

> デザイン・見た目・UX。味覚 (taste) は改善できるかなど、美と使い勝手の判断が集まる結節点 (旧 v3 統制語彙 design から移行)。

    rg -Pl '\bconcept/design(?![a-z0-9-])' records/ | sort -r | head -30
