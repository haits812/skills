---
type: concept
title: 機械学習・LLM
aka: [機械学習, LLM, machine learning, ML, AI, deep learning]
created: 2026-08-02
---

> 機械学習・LLM そのもの。訓練の失敗様式や言語モデルの捉え方など、モデル自体についての記録が集まる結節点 (旧 v3 統制語彙 ml から移行)。

エージェントとしての組み方の話は [[concept/agent-design]] が別に受ける。

    rg -Pl '\bconcept/ml(?![a-z0-9-])' records/ | sort -r | head -30
