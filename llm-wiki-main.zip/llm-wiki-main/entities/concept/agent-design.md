---
type: concept
title: エージェント設計
aka: [エージェント設計, agent design, ツール設計, tool design, ACI]
created: 2026-08-02
---

> LLM エージェントをどう組むかの設計論。ツール定義・ワークフローとエージェントの使い分け・失敗の切り分けなど、実装の判断が集まる結節点。

ツール設計 (agent-computer interface) はこの concept の下位話題として一旦ここに集約する。記録が溜まったら分ける。

    rg -Pl '\bconcept/agent-design(?![a-z0-9-])' records/ | sort -r | head -30
