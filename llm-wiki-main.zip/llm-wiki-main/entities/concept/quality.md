---
type: concept
title: 品質
aka: [ソフトウェア品質, テスト, quality, testing]
created: 2026-08-02
---

> 品質・テスト。内部品質への投資と開発速度の関係など、品質をめぐる判断が集まる結節点 (旧 v3 統制語彙 quality から移行)。

    rg -Pl '\bconcept/quality(?![a-z0-9-])' records/ | sort -r | head -30
