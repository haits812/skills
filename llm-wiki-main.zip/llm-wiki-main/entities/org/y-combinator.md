---
type: org
title: Y Combinator
aka: [ワイコンビネーター, Y Combinator, YC]
created: 2026-08-02
status: active
---

> 米のスタートアップアクセラレータ。投資先を期ごとのバッチで受け入れる形式で知られ、創業者向け言説の発信源として追う。

配下 (Hacker News・創業メンバー) と紐づく記録は `wiki links org/y-combinator` で読み時導出する (ここに列挙しない)。
