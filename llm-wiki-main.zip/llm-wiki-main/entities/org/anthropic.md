---
type: org
title: Anthropic
aka: [アンソロピック, Anthropic, Claude の開発元]
created: 2026-08-02
status: active
---

> Claude を開発する AI 研究企業。engineering blog でエージェント構築の実践知を公開しており、この wiki では発信元として追う。
