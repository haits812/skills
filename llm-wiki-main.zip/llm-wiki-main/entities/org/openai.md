---
type: org
title: OpenAI
aka: [オープンAI, OpenAI, オープンエーアイ]
created: 2026-08-02
status: active
---

> GPT 系を開発する AI 研究企業。この wiki では [[person/andrej-karpathy]] の創設メンバー所属の参照先として立てた stub — 記録が増えたら見取り図を書く。
