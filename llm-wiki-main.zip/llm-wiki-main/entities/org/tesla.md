---
type: org
title: Tesla
aka: [テスラ, Tesla, テスラモーターズ]
created: 2026-08-02
status: active
---

> EV メーカー。自動運転の AI 部門を持つ。stub — 記録が増えたら見取り図を書く (関係は wiki links の被リンクで導出)。
