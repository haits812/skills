---
type: org
title: Hugging Face
aka: [ハギングフェイス, hugging face, HF, huggingface]
created: 2026-08-16
---

> ML モデル・データセットの共有ハブを運営する企業。blog と community イベント (ICML 2026 再現ハッカソン等) がこの wiki の note の出典になる。
