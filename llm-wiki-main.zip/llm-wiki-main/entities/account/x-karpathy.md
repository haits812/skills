---
type: account
title: @karpathy
aka: [@karpathy, karpathy, カルパシーの X アカウント]
created: 2026-08-02
status: active
alias-of: [person/andrej-karpathy]
---

> X 上の [[person/andrej-karpathy]] 本人のアカウント (本人であることは依頼者の確認による)。発言の観測はこの ID を対象に記録する。
