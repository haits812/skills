---
type: account
title: "@simonw"
aka: ["@simonw", simonw, サイモン・ウィリソンの X アカウント]
created: 2026-08-03
status: active
alias-of: [person/simon-willison]
---

> X 上の [[person/simon-willison]] 本人のアカウント (本人であることは依頼者の申告による)。発言の観測はこの ID を対象に記録する。
