#!/usr/bin/env bash
# hook-lint.sh — PostToolUse(Write|Edit): 書いた瞬間の E 検査 + 自セッション台帳の記帳 (SPEC §5-6 (2))
#
# 契約:
#   - stdin の hook JSON は node の JSON.parse で読む (sed 抽出は整形 JSON で無言破綻する — B-F2-c)
#   - entities/ | records/ 配下の .md 以外は exit 0 (触らない)
#   - 台帳 /tmp/llm-wiki-<sid>.paths に追記 (揮発・セッションローカル。repo に揮発物を置かない)
#   - scripts/wiki lint --hook <file> で E のみ検査 (X はやらない — 記録を先に書き参照先を
#     後で作る正当な順序を邪魔しない)。E があれば理由を stderr に出して exit 2
set -u
export TZ=Asia/Tokyo

ROOT=$(cd -P -- "$(dirname -- "${BASH_SOURCE[0]}")/.." 2>/dev/null && pwd -P) || exit 0

raw=""
[ -t 0 ] || raw=$(cat 2>/dev/null)
[ -n "$raw" ] || exit 0

fields=$(printf '%s' "$raw" | node -e '
let b = "";
process.stdin.on("data", (d) => (b += d));
process.stdin.on("end", () => {
  let j = {};
  try { j = JSON.parse(b || "{}"); } catch (e) { j = {}; }
  const pick = (k) => {
    let v = j;
    for (const p of k.split(".")) v = v && typeof v === "object" ? v[p] : undefined;
    return v == null ? "" : String(v);
  };
  process.stdout.write([pick("session_id"), pick("tool_input.file_path")].join("\n"));
});' 2>/dev/null) || exit 0

sid=${fields%%$'\n'*}
fp=${fields#*$'\n'}
fp=${fp%%$'\n'*}
[ -n "$fp" ] || exit 0

sid=${sid//[!A-Za-z0-9_.-]/_}
[ -n "$sid" ] || sid="nosid"

# 絶対パス + symlink 正規化 (/tmp → /private/tmp 等) して ROOT 相対へ
case "$fp" in /*) ;; *) fp="$ROOT/$fp" ;; esac
dir=$(cd -P -- "$(dirname -- "$fp")" 2>/dev/null && pwd -P) || exit 0
[ -n "$dir" ] || exit 0
abs="$dir/$(basename -- "$fp")"
rel=${abs#"$ROOT"/}
[ "$rel" != "$abs" ] || exit 0            # ROOT 外
case "$rel" in
  entities/*.md | records/*.md) ;;
  *) exit 0 ;;                            # 対象外 (skill / SPEC / scripts / .md 以外)
esac

# 台帳へ記帳: 「<内容hash> <絶対パス>」の追記専用 (O_APPEND は行単位で原子的 — 読み→全書きの
# 競合窓を持たない)。同一パスの重複は Stop 側が「最後の行が勝つ」で解決する。
# hash は Stop hook が「自セッションが最後に書いた内容のまま」のファイルだけを裁くための材料
# (パスだけだと他セッションのその後の編集を自分の物と誤認する)。
ledger="/tmp/llm-wiki-$sid.paths"
hash=$(shasum -a 256 -- "$abs" 2>/dev/null | cut -d' ' -f1) || hash=""
[ -n "$hash" ] || hash="nohash"
printf '%s %s\n' "$hash" "$abs" >>"$ledger" 2>/dev/null || true

[ -x "$ROOT/scripts/wiki" ] || exit 0
out=$("$ROOT/scripts/wiki" lint --hook "$abs" 2>&1)
rc=$?
if [ "$rc" -eq 2 ]; then
  {
    printf '[llm-wiki] 書式エラー (E): %s\n' "$rel"
    printf '%s\n' "$out"
    printf '%s\n' '直してから次へ (規約は Skill(ref-wiki-schema) / templates/ を写す)。'
  } >&2
  exit 2
fi
exit 0
