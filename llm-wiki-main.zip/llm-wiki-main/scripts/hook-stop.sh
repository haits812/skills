#!/usr/bin/env bash
# hook-stop.sh — Stop: 自セッション分だけの安全網 + 自動 save (SPEC §5-6 (3) / D9)
#
# 契約:
#   - stdin の hook JSON は node の JSON.parse で読む (sed 禁止 — B-F2-c)
#   - stop_hook_active=true → 差し戻し (exit 2) だけ封印し **save は実行** (即 exit 0 だと「E を直したのに
#     commit されないまま終了」— live 実証バグ。無限ループの原因は exit 2 であって save ではない)
#   - 台帳 /tmp/llm-wiki-<sid>.paths が無い/空 → exit 0 (他セッションのファイルには一切触らない)
#   - 台帳のうち「未 commit のもの」だけが対象。全体 lint はしない (毒饅頭にしない — B-F2-d)
#   - E あり → ガード /tmp/llm-wiki-stop-<sid> が無ければ作って理由と共に exit 2 (1 セッション 1 回だけ差し戻し)
#              2 回目は「未 commit のまま残す」を stderr に出して exit 0
#   - E なし → scripts/wiki save <対象> (pathspec 限定 commit + push -q || true)
set -u
export TZ=Asia/Tokyo

ROOT=$(cd -P -- "$(dirname -- "${BASH_SOURCE[0]}")/.." 2>/dev/null && pwd -P) || exit 0

raw=""
[ -t 0 ] || raw=$(cat 2>/dev/null)
[ -n "$raw" ] || exit 0

fields=$(printf '%s' "$raw" | node -e '
let b = "";
process.stdin.on("data", (d) => (b += d));
process.stdin.on("end", () => {
  let j = {};
  try { j = JSON.parse(b || "{}"); } catch (e) { j = {}; }
  const sid = j && j.session_id;
  const act = j && j.stop_hook_active;
  process.stdout.write([sid == null ? "" : String(sid), act === true ? "true" : "false"].join("\n"));
});' 2>/dev/null) || exit 0

sid=${fields%%$'\n'*}
active=${fields#*$'\n'}
active=${active%%$'\n'*}
# stop_hook_active=true (= 直前の Stop が exit 2 で差し戻した継続ターン) でも **save はやる**。
# ここで即 exit 0 すると「E を直したのに commit されないまま終了」になる (fresh レビューの live 実証)。
# 無限ループの原因は exit 2 (差し戻し) であって save ではない — active 中は絶対に exit 2 しない。
bounce_allowed=1
[ "$active" != "true" ] || bounce_allowed=0

sid=${sid//[!A-Za-z0-9_.-]/_}
[ -n "$sid" ] || sid="nosid"
ledger="/tmp/llm-wiki-$sid.paths"
guard="/tmp/llm-wiki-stop-$sid"
[ -s "$ledger" ] || exit 0

cd "$ROOT" 2>/dev/null || exit 0

# 台帳 (行 = "<内容hash> <絶対パス>" の追記専用、旧形式 = パスのみ) → **逆順に読んで最後の記帳を採用**
# (同一パスの再 Write は後の行が新しい)。実在し、かつ「内容が自セッションの最後の書き込みのまま」の
# ファイルだけを拾う。hash 不一致 = その後に別セッションが触った → 所有権なしとして一切触らない (A5/A4 の再入防止)。
nl=$'\n'
seen=$nl
targets=()
skipped_foreign=()
while IFS= read -r line || [ -n "$line" ]; do
  [ -n "$line" ] || continue
  case "$line" in
    *' '*) rec_hash=${line%% *}; p=${line#* } ;;
    *) rec_hash=""; p=$line ;;
  esac
  case "$seen" in *"$nl$p$nl"*) continue ;; esac
  seen="$seen$p$nl"
  [ -f "$p" ] || continue
  rel=${p#"$ROOT"/}
  [ "$rel" != "$p" ] || continue
  if [ -n "$rec_hash" ] && [ "$rec_hash" != "nohash" ]; then
    cur_hash=$(shasum -a 256 -- "$p" 2>/dev/null | cut -d' ' -f1) || cur_hash=""
    if [ -n "$cur_hash" ] && [ "$cur_hash" != "$rec_hash" ]; then
      skipped_foreign+=("$rel")
      continue
    fi
  fi
  targets+=("$rel")
done < <(tail -r "$ledger" 2>/dev/null || tac "$ledger" 2>/dev/null)
[ ${#skipped_foreign[@]} -eq 0 ] || printf '[llm-wiki] 対象外 (Write/Edit の後に内容が変わっている — Bash で自分が編集したなら wiki save を自分で打つ。別セッションの可能性もあるため自動 commit しない): %s\n' "${skipped_foreign[*]}" >&2
[ ${#targets[@]} -gt 0 ] || exit 0

# 未 commit のものだけ対象 (既に commit 済み = 触らない)
in_git=1
git rev-parse --is-inside-work-tree >/dev/null 2>&1 || in_git=0
pending=()
for rel in "${targets[@]}"; do
  if [ "$in_git" -eq 0 ]; then
    pending+=("$rel")                     # git が無い時は安全側 (lint ゲートは効かせる)
    continue
  fi
  st=$(git status --porcelain -uall -- "$rel" 2>/dev/null)
  [ -n "$st" ] && pending+=("$rel")
done
[ ${#pending[@]} -gt 0 ] || exit 0

[ -x "$ROOT/scripts/wiki" ] || exit 0

# 自ファイルの E を per-file で判定 (全体 lint はしない — 他セッションの E で止まらない)。
# clean なファイルは E の巻き添えにせず先に save する (正常な記録がセッション終了で滞留しない)
clean=()
bad=()
badout=""
for rel in "${pending[@]}"; do
  o=$("$ROOT/scripts/wiki" lint "$rel" 2>&1)
  if [ $? -eq 0 ]; then clean+=("$rel"); else bad+=("$rel"); badout="$badout$o"$'\n'; fi
done

if [ ${#clean[@]} -gt 0 ]; then
  sout=$("$ROOT/scripts/wiki" save "${clean[@]}" 2>&1)
  src=$?
  [ -n "$sout" ] && printf '%s\n' "$sout" >&2
  [ "$src" -eq 0 ] || printf '[llm-wiki] save 失敗 (未 commit のまま残す): %s\n' "${clean[*]}" >&2
fi

if [ ${#bad[@]} -gt 0 ]; then
  if [ "$bounce_allowed" = 1 ] && [ ! -e "$guard" ]; then
    : >"$guard" 2>/dev/null || true
    {
      printf '%s\n' '[llm-wiki] 自セッションが書いた未 commit ファイルに書式エラー (E) があります:'
      printf '%s' "$badout"
      printf '%s\n' '直すと Stop 時に自動で commit されます (規約は Skill(ref-wiki-schema))。'
    } >&2
    exit 2
  fi
  printf '[llm-wiki] 未 commit のまま残す (E あり): %s\n' "${bad[*]}" >&2
fi
exit 0
