#!/usr/bin/env bash
# hook-boot.sh — SessionStart: llm-wiki の現況 6 行を context に注入 (SPEC §5-6 (1) / D7)
#
# 契約:
#   - 全経路 exit 0 (空 repo / git 不在 / scripts/wiki 不在 / node 不在でも黙って 0)
#   - git は読み取りのみ (status/rev-list — pull しない)。未 commit の**パスは表示しない** (C-致命1 の boot 側経路を作らない) が、滞留の**件数**だけは末尾 1 行で出す
#   - LLM 0 / ネットワーク 0。集計は glob + head だけ (ls/wc 相当) + 今日の 1 枚は wiki dust -n 1
#   - 日付は JST 固定 (D15)
set -u
export TZ=Asia/Tokyo
export LC_ALL=C   # glob のソート順を byte 順に固定 (records のパス順 = 日付順)

ROOT=$(cd -P -- "$(dirname -- "${BASH_SOURCE[0]}")/.." 2>/dev/null && pwd -P) || exit 0
cd "$ROOT" 2>/dev/null || exit 0
shopt -s nullglob

P='[llm-wiki]'

# frontmatter の title を先頭 12 行から拾う (head だけ。書式は §3-1 のフラット key: value)
title_of() {
  local line t
  line=$(head -n 12 -- "$1" 2>/dev/null | grep -m 1 '^title:')
  t=${line#title:}
  t=${t%$'\r'}
  t=${t# }
  case "$t" in '"'*'"') t=${t#\"}; t=${t%\"} ;; esac
  if [ -n "$t" ]; then printf '%s' "$t"; else printf '%s' '(no title)'; fi
}

# --- 1 行目: エンティティの型別件数 -------------------------------------------
line=""
total=0
for t in org person project task community account product concept; do
  fs=(entities/"$t"/*.md)
  n=${#fs[@]}
  total=$((total + n))
  if [ -z "$line" ]; then line="$t $n"; else line="$line / $t $n"; fi
done
printf '%s entities: %s (計 %s)\n' "$P" "$line" "$total"

# --- 2 行目: records の総数 / 当月件数 / 最新日 --------------------------------
recs=(records/*/*/*.md)
rn=${#recs[@]}
ym=$(date +%Y-%m 2>/dev/null) || ym=""
cn=0
if [ -n "$ym" ]; then
  cur=(records/"${ym%-*}"/"${ym#*-}"/*.md)
  cn=${#cur[@]}
fi
latest="-"
if [ "$rn" -gt 0 ]; then
  base=${recs[$((rn - 1))]}
  base=${base##*/}
  case "$base" in [0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]-*) latest=${base:0:10} ;; esac
fi
printf '%s records: %s (%s は %s)  最新: %s\n' "$P" "$rn" "${ym:--}" "$cn" "$latest"

# --- 3-5 行目: 直近 3 件 (新しい順・パス + title) ------------------------------
i=$rn
c=0
while [ "$i" -gt 0 ] && [ "$c" -lt 3 ]; do
  i=$((i - 1))
  c=$((c + 1))
  f=${recs[$i]}
  if [ "$c" -eq 1 ]; then
    printf '%s 直近 3: %s — %s\n' "$P" "$f" "$(title_of "$f")"
  else
    printf '%s         %s — %s\n' "$P" "$f" "$(title_of "$f")"
  fi
done
[ "$c" -eq 0 ] && printf '%s 直近 3: (まだ無い)\n' "$P"

# --- 6 行目: 今日の 1 枚 (偶発的再会 §4-4) -------------------------------------
# dust の seed は セッション ID (日付 seed だと 1 日 20 boot で同じ 1 枚が 20 回 — C-重大11)。
# stdin の hook JSON は node の JSON.parse で読む (sed 抽出は整形 JSON で無言破綻する — B-F2-c)。
raw=""
[ -t 0 ] || raw=$(cat 2>/dev/null)
sid=""
if [ -n "$raw" ]; then
  sid=$(printf '%s' "$raw" | node -e '
let b = "";
process.stdin.on("data", (d) => (b += d));
process.stdin.on("end", () => {
  let j = {};
  try { j = JSON.parse(b || "{}"); } catch (e) { j = {}; }
  const v = j && j.session_id;
  process.stdout.write(v == null ? "" : String(v));
});' 2>/dev/null) || sid=""
fi
sid=${sid//[!A-Za-z0-9_.-]/_}
[ -n "$sid" ] || sid=${CLAUDE_SESSION_ID:-}

dust=""
if [ "$rn" -gt 0 ] && [ -x scripts/wiki ]; then
  dust=$(CLAUDE_SESSION_ID="$sid" ./scripts/wiki dust -n 1 2>/dev/null | head -n 1) || dust=""
fi
if [ -n "$dust" ]; then
  printf '%s 今日の 1 枚: %s — %s  ← 偶発的再会\n' "$P" "$dust" "$(title_of "$dust")"
else
  printf '%s 今日の 1 枚: (まだ無い)\n' "$P"
fi

# 滞留の可視化 (件数のみ・パスは出さない — 他セッションの書きかけを新セッションに拾わせない)。
# exit-0 stderr の warn は誰にも届かない (fresh レビューの live 実証) ため、唯一 context に届くここで数を出す
if command -v git >/dev/null 2>&1 && git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  un=$(git status --porcelain --untracked-files=all -- entities/ records/ 2>/dev/null | grep -c '.') || un=0
  ahead=$(git rev-list --count '@{u}..HEAD' 2>/dev/null) || ahead=0
  if [ "${un:-0}" -gt 0 ] || [ "${ahead:-0}" -gt 0 ]; then
    printf '%s ⚠ 滞留: 未 commit %s 件 / 未 push %s 件 — 自分の書きかけなら wiki save、心当たりが無ければ「掃除して」(庭師が回収)\n' "$P" "${un:-0}" "${ahead:-0}"
  fi
fi

exit 0
