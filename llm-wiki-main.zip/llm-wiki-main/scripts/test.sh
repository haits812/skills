#!/usr/bin/env bash
# scripts/test.sh — 完走定義の機械化 (SPEC §5-7 / §10-1-2)
#   (a) fixtures/ok が lint --all で 0 件 exit 0
#   (b) 異常系が期待 exit code・期待番号で全発火 (多重親 4 パターン含む)
#   (c) new/save/sync/links/cards/dust を /tmp の git sandbox で実走 (本物 repo に書かない)
set -u

REPO="$(cd "$(dirname "$0")/.." && pwd)"
WIKI="$REPO/scripts/wiki"
FIX="$REPO/scripts/fixtures"
PASS=0
FAIL=0

ok() { PASS=$((PASS + 1)); echo "ok   - $1"; }
ng() { FAIL=$((FAIL + 1)); echo "FAIL - $1"; }

# check <name> <expected_exit> <expected_substr(空=不問)> -- <cmd...>
check() {
  local name="$1" want="$2" substr="$3" out code
  shift 3
  out="$("$@" 2>&1)"
  code=$?
  if [ "$code" != "$want" ]; then
    ng "$name (exit $code != $want)"
    printf '%s\n' "$out" | sed 's/^/       /'
    return
  fi
  if [ -n "$substr" ] && ! printf '%s' "$out" | grep -qF -- "$substr"; then
    ng "$name (output missing: $substr)"
    printf '%s\n' "$out" | sed 's/^/       /'
    return
  fi
  ok "$name"
}

# check_empty <name> -- <cmd...> : exit 0 かつ出力 0 件
check_empty() {
  local name="$1" out code
  shift
  out="$("$@" 2>&1)"
  code=$?
  if [ "$code" != 0 ] || [ -n "$out" ]; then
    ng "$name (exit=$code out=[$out])"
    return
  fi
  ok "$name"
}

echo "=== (a) 正常系: fixtures/ok は閉じた集合で lint --all 0 件 ==="
check_empty "ok: lint --all 0 件 exit 0" "$WIKI" lint --all --root "$FIX/ok"
check_empty "ok: --warn でも W 0 件 (fixtures の衛生)" "$WIKI" lint --all --warn --root "$FIX/ok"

echo "=== (b) 異常系 E: 期待番号で発火・exit 1 ==="
check "E1 block 配列" 1 "E1 " "$WIKI" lint --root "$FIX/bad/e1-block" "$FIX/bad/e1-block/entities/org/block-array.md"
check "E1 CRLF" 1 "CRLF" "$WIKI" lint --root "$FIX/bad/e1-crlf" "$FIX/bad/e1-crlf/entities/org/crlf-org.md"
check "E3 title 配列化" 1 "E3 " "$WIKI" lint --root "$FIX/bad/e3-title-array" "$FIX/bad/e3-title-array/entities/org/title-array.md"
check "E5 4hex 無し" 1 "E5 " "$WIKI" lint --root "$FIX/bad/e5-no-4hex" "$FIX/bad/e5-no-4hex/records/2026/08/2026-08-02-missing-hex.md"
check "E8 tgas タイポ" 1 "E8 " "$WIKI" lint --root "$FIX/bad/e8-typo" "$FIX/bad/e8-typo/entities/org/typo-field.md"
check "E9 日付とディレクトリ不整合" 1 "E9 " "$WIKI" lint --root "$FIX/bad/e9-dir-mismatch" "$FIX/bad/e9-dir-mismatch/records/2026/07/2026-08-02-wrong-dir-ab12.md"
check "E15 述語が配列でない" 1 "E15 " "$WIKI" lint --root "$FIX/bad/e15-not-array" "$FIX/bad/e15-not-array/entities/community/scalar-parent.md"
check "E16 記録に created" 1 "E16 " "$WIKI" lint --root "$FIX/bad/e16-record-created" "$FIX/bad/e16-record-created/records/2026/08/2026-08-02-has-created-ab12.md"
check "E17 エンティティに about" 1 "E17 " "$WIKI" lint --root "$FIX/bad/e17-entity-about" "$FIX/bad/e17-entity-about/entities/org/has-about.md"
check "E18 述語が記録を指す" 1 "E18 " "$WIKI" lint --root "$FIX/bad/e18-record-target" "$FIX/bad/e18-record-target/records/2026/08/2026-08-02-bad-target-ab12.md"

echo "=== (b) exit code 契約: --hook ==="
check "--hook: E で exit 2 + stderr に理由" 2 "E3 " "$WIKI" lint --hook --root "$FIX/bad/e3-title-array" "$FIX/bad/e3-title-array/entities/org/title-array.md"
check_empty "--hook: 未作成参照 (E7 相当) は発火しない" "$WIKI" lint --hook --root "$FIX/bad/x1-broken" "$FIX/bad/x1-broken/entities/org/good-org.md"

echo "=== (b) 異常系 X: --all のみ・exit 1 ==="
check "X1 壊れリンク" 1 "X1 " "$WIKI" lint --all --root "$FIX/bad/x1-broken"
check_empty "X1 非検出: code block 内 [[..]]" "$WIKI" lint --all --root "$FIX/bad/x1-codeblock"
check "X2 正規化一致の重複" 1 "X2 " "$WIKI" lint --all --root "$FIX/bad/x2-dup"
check "X4 domain 違反 (person に part-of)" 1 "X4 " "$WIKI" lint --all --root "$FIX/bad/x4-domain"

echo "=== (b) 多重親 4 パターン (D14) ==="
check_empty "菱形は X3 を発火させない" "$WIKI" lint --all --root "$FIX/bad/dag-diamond"
check_empty "深い合流ラティスは X3 を発火させない" "$WIKI" lint --all --root "$FIX/bad/dag-lattice"
check_empty "2 親別祖先は X3 を発火させない" "$WIKI" lint --all --root "$FIX/bad/dag-two-parents"
check "真の閉路は X3 発火" 1 "X3 " "$WIKI" lint --all --root "$FIX/bad/dag-cycle"

echo "=== (c) /tmp git sandbox: new / save / sync (本物 repo に触らない) ==="
SB="$(mktemp -d /tmp/llm-wiki-test.XXXXXX)"
trap 'rm -rf "$SB"' EXIT
BARE="$SB/remote.git"
WORK="$SB/work"
git init -q --bare "$BARE"
mkdir -p "$WORK/scripts"
cp "$WIKI" "$WORK/scripts/wiki"
git init -q -b main "$WORK"
git -C "$WORK" config user.email test@example.com
git -C "$WORK" config user.name llm-wiki-test
git -C "$WORK" remote add origin "$BARE"
git -C "$WORK" add scripts/wiki
git -C "$WORK" commit -qm init
git -C "$WORK" push -qu origin main
W2="$WORK/scripts/wiki"
TODAY="$(TZ=Asia/Tokyo date +%F)"

# new entity — O_EXCL 予約
p="$("$W2" new entity org acme)"
if [ "$p" = "entities/org/acme.md" ] && [ -f "$WORK/$p" ] && [ ! -s "$WORK/$p" ]; then
  ok "new entity: 予約成功 (0 バイト・パス print)"
else
  ng "new entity: 予約 (p=$p)"
fi
check "new entity: 予約直後 (0 バイト) の再 new は EXISTS-EMPTY" 0 "EXISTS-EMPTY entities/org/acme.md" "$W2" new entity org acme
check "new entity: slug 形式違反は exit 1" 1 "" "$W2" new entity org 'Bad_Slug'
check "new entity: type 語彙外は exit 1" 1 "" "$W2" new entity event foo
check "new entity: account の prefix 無しは exit 1" 1 "" "$W2" new entity account naval

# new record — 4hex 採番
rp="$("$W2" new record obs first-event)"
if printf '%s' "$rp" | grep -qE "^records/[0-9]{4}/[0-9]{2}/${TODAY}-first-event-[0-9a-f]{4}\.md$" && [ -f "$WORK/$rp" ]; then
  ok "new record: 今日 JST + slug + 4hex で予約"
else
  ng "new record: 採番 (rp=$rp)"
fi
check "new record: type 語彙外は exit 1" 1 "" "$W2" new record foo bar

# new record --date (obs の出来事日)
rp2="$("$W2" new record obs past-event --date 2023-01-24)"
if printf '%s' "$rp2" | grep -qE '^records/2023/01/2023-01-24-past-event-[0-9a-f]{4}\.md$' && [ -f "$WORK/$rp2" ]; then
  ok "new record --date: 過去の出来事日で採番 (dir も追随)"
else
  ng "new record --date: 採番 (rp2=$rp2)"
fi
rm -f "$WORK/$rp2"
check "new record --date: 形式違反は exit 1" 1 "" "$W2" new record obs bad-date --date 2023-13-99
check "new record --date: 未来日 (+2 日) は exit 1" 1 "" "$W2" new record obs future-date --date "$(TZ=Asia/Tokyo date -v+2d +%F 2>/dev/null || date -d '+2 days' +%F)"

# 中身を書いて lint → save
cat > "$WORK/$p" <<EOF
---
type: org
title: Acme
aka: [アクメ]
created: $TODAY
---

> sandbox テスト用の組織。
EOF
cat > "$WORK/$rp" <<EOF
---
type: obs
title: sandbox の観測
about: [org/acme]
confidence: 事実
---

依頼者の言葉:

> sandbox で観測した。
EOF
check_empty "lint <path...>: 正しいファイルは 0 件 exit 0" "$W2" lint "$WORK/$p" "$WORK/$rp"
check "new entity: 実体ありは EXISTS exit 0" 0 "EXISTS entities/org/acme.md" "$W2" new entity org acme

check "save: pathspec commit + push 成功" 0 "saved entities/org/acme.md" "$W2" save "$WORK/$p" "$WORK/$rp"
if git -C "$WORK" log --format=%s -- "$p" | grep -q "wiki save entities/org/acme.md"; then
  ok "save: commit message が pathspec 単位"
else
  ng "save: commit message"
fi
if [ "$(git -C "$WORK" rev-parse main)" = "$(git -C "$BARE" rev-parse main)" ]; then
  ok "save: push が remote に到達"
else
  ng "save: push が remote に到達していない"
fi
check "save: 変更なし再実行は nothing to commit を成功扱い" 0 "saved" "$W2" save "$WORK/$p"

# sync — porcelain 非空なら拒否
echo "dirty" >> "$WORK/$p"
check "sync: dirty なら exit 1" 1 "拒否" "$W2" sync
"$W2" save "$WORK/$p" > /dev/null 2>&1
check "sync: clean なら pull --rebase && push で exit 0" 0 "" "$W2" sync

# 予約の死骸は E にならず W9 (--warn のみ)
"$W2" new entity org empty-stub > /dev/null
check_empty "lint --all: 0 バイト予約は E/X を出さない" "$W2" lint --all
check "lint --all --warn: 0 バイト予約は W9" 0 "W9 " "$W2" lint --all --warn

# push 失敗は warn + exit 0 (|| true 経路)
WORK2="$SB/work2"
mkdir -p "$WORK2/scripts"
cp "$WIKI" "$WORK2/scripts/wiki"
git init -q -b main "$WORK2"
git -C "$WORK2" config user.email test@example.com
git -C "$WORK2" config user.name llm-wiki-test
p2="$("$WORK2/scripts/wiki" new entity org lonely)"
cat > "$WORK2/$p2" <<EOF
---
type: org
title: Lonely
created: $TODAY
---

> remote の無い sandbox。
EOF
check "save: remote 無しの push 失敗は warn で exit 0" 0 "push 失敗" "$WORK2/scripts/wiki" save "$WORK2/$p2"

echo "=== (d) save/sync の防護 (レビュー Round 1 の修理回帰) ==="
check "E1 インライン配列の閉じ忘れ" 1 "閉じていない" "$WIKI" lint --root "$FIX/bad/e1-unclosed" "$FIX/bad/e1-unclosed/entities/org/unclosed-array.md"
check "save: ディレクトリは拒否 exit 1" 1 "対象外パス" "$W2" save "$WORK/entities/org"
check "save: entities/records 外は拒否 exit 1" 1 "対象外パス" "$W2" save "$WORK/scripts/wiki"
check "save: 存在しないファイルは NOT-SAVED exit 1" 1 "NOT-SAVED" "$W2" save "$WORK/records/2026/08/2026-08-02-nonexistent-0000.md"
check "lint: ディレクトリは対象外エラー exit 1" 1 "ディレクトリ" "$WIKI" lint "$FIX/ok/entities" 2>/dev/null || true
mkdir -p "$WORK2/.git/rebase-merge"
check "save: rebase 中断中は拒否 exit 1" 1 "rebase 中断中" "$WORK2/scripts/wiki" save "$WORK2/$p2"
check "sync: rebase 中断中は abort 復旧を試みて exit 1" 1 "中断" "$WORK2/scripts/wiki" sync
rm -rf "$WORK2/.git/rebase-merge"

# sync の rebase 衝突 → 必ず abort で原状復帰 (放置すると以後の commit が rebase 巻き戻しで消える)
rm -f "$WORK/entities/org/empty-stub.md"   # 前段テストの 0 バイト予約 (untracked) を片付けて clean に戻す
WORK3="$SB/work3"
git clone -q -b main "$BARE" "$WORK3"
git -C "$WORK3" config user.email peer@example.com
git -C "$WORK3" config user.name llm-wiki-peer
echo "peer 側の追記" >> "$WORK3/entities/org/acme.md"
git -C "$WORK3" commit -qam "peer edit" && git -C "$WORK3" push -q
echo "local 側の別の追記" >> "$WORK/$p"
"$W2" save "$WORK/$p" > /dev/null 2>&1   # commit は通り push は non-ff で warn
check "sync: rebase 衝突は abort で原状復帰 + exit 1" 1 "原状復帰" "$W2" sync
if [ -z "$(git -C "$WORK" status --porcelain)" ] && [ ! -d "$WORK/.git/rebase-merge" ]; then
  ok "sync: 衝突後も worktree clean・rebase 残骸なし"
else
  ng "sync: 衝突後の状態が汚れている"
fi
if git -C "$WORK" log --format=%s | grep -q "wiki save entities/org/acme.md"; then
  ok "sync: 衝突 abort 後もローカル commit は保全"
else
  ng "sync: ローカル commit が消えた"
fi

echo "=== (e) X3 — 深い閉路と多重親ラティス (3 色 DFS の回帰) ==="
XC="$SB/xcycle"
mkdir -p "$XC/entities/concept"
for i in $(seq 1 14); do
  nxt=$((i % 14 + 1))
  printf -- '---\ntype: concept\ntitle: "Cycle %s"\ncreated: %s\npart-of: [concept/c%s]\n---\n\n> 閉路テスト %s。\n' "$i" "$TODAY" "$nxt" "$i" > "$XC/entities/concept/c$i.md"
done
check "X3: 長さ 14 の閉路も検出 (深さ上限撤廃)" 1 "X3 " "$WIKI" lint --all --root "$XC"

LAT="$SB/lattice"
mkdir -p "$LAT/entities/concept"
K=5; L=13
for lv in $(seq 0 $((L - 1))); do
  for n in $(seq 1 $K); do
    if [ "$lv" -lt $((L - 1)) ]; then
      parents="concept/l$((lv + 1))n1"
      for m in $(seq 2 $K); do parents="$parents, concept/l$((lv + 1))n$m"; done
      printf -- '---\ntype: concept\ntitle: "Lat %s %s"\ncreated: %s\npart-of: [%s]\n---\n\n> ラティス %s-%s。\n' "$lv" "$n" "$TODAY" "$parents" "$lv" "$n" > "$LAT/entities/concept/l${lv}n${n}.md"
    else
      printf -- '---\ntype: concept\ntitle: "Lat %s %s"\ncreated: %s\n---\n\n> ラティス %s-%s。\n' "$lv" "$n" "$TODAY" "$lv" "$n" > "$LAT/entities/concept/l${lv}n${n}.md"
    fi
  done
done
t0=$(date +%s)
check_empty "X3: 多重親ラティス 65 枚 (5^12 経路相当) が合法で E/X 0 件" "$WIKI" lint --all --root "$LAT"
t1=$(date +%s)
if [ $((t1 - t0)) -lt 10 ]; then
  ok "X3: ラティス lint が 10 秒未満 (旧実装は 166 秒)"
else
  ng "X3: ラティス lint に $((t1 - t0)) 秒かかった"
fi

echo "=== (c) links / cards / dust (fixtures/ok を --root で読む) ==="
check "links: 4 段の子孫 (kenji-sato) が出る" 0 "person/kenji-sato" "$WIKI" links org/acme-ai --depth 4 --root "$FIX/ok"
check "links: 多重親の合流は既出マークで 1 回だけ辿る" 0 "(既出)" "$WIKI" links org/acme-ai --depth 4 --root "$FIX/ok"
check "links: alias-of 1 段展開で account 経由の記録が出る" 0 "naval-leverage-judgment-3f9c" "$WIKI" links person/naval-ravikant --root "$FIX/ok"
check "links: 無い ID は exit 1" 1 "" "$WIKI" links org/nonexistent --root "$FIX/ok"
check "links: 被リンク記録は一族 union (子孫 community の記録が root の集約に出る)" 0 "dc-agent-builders-tool-retry-8b21" "$WIKI" links org/acme-ai --depth 4 --root "$FIX/ok"
check "links: 一族 union の全件数を明示 (全 3 件)" 0 "全 3 件" "$WIKI" links org/acme-ai --depth 4 --root "$FIX/ok"
np="$("$WIKI" links org/acme-ai --paths --root "$FIX/ok" | wc -l | tr -d ' ')"
if [ "$np" = "3" ] && "$WIKI" links org/acme-ai --paths --root "$FIX/ok" | grep -qv '■'; then
  ok "links --paths: パスのみ全件 (3 行)"
else
  ng "links --paths: 行数 $np != 3"
fi

# save の E ゲート (Bash 書きのすり抜け封鎖)
badp="$WORK/records/2026/08/2026-08-02-bad-format-save-aaaa.md"
printf -- '---\ntype: obs\ntitle: no about\n---\n\nbody\n' > "$badp"
check "save: E のあるファイルは NOT-SAVED exit 1 (E6)" 1 "NOT-SAVED" "$W2" save "$badp"
rm -f "$badp"

check "E18 status 語彙外" 1 "E18 " "$WIKI" lint --root "$FIX/bad/e18-status" "$FIX/bad/e18-status/entities/org/bad-status.md"

check "cards: 日付 │ type │ title │ about の 1 行圧縮" 0 "2026-08-02 │ note │ Building Effective Agents — ツール設計が主戦場 │ org/anthropic" \
  "$WIKI" cards --root "$FIX/ok" "$FIX/ok/records/2026/08/2026-08-02-anthropic-building-effective-agents-9c1a.md"
n_lines="$("$WIKI" cards --root "$FIX/ok" "$FIX/ok/records/2026/08/2026-08-02-anthropic-building-effective-agents-9c1a.md" "$FIX/ok/records/2026/08/2026-08-02-naval-leverage-judgment-3f9c.md" | wc -l | tr -d ' ')"
if [ "$n_lines" = "2" ]; then ok "cards: 1 ファイル = 1 行"; else ng "cards: 行数 $n_lines != 2"; fi

d1="$(CLAUDE_SESSION_ID=fixed-seed "$WIKI" dust -n 1 --root "$FIX/ok")"
d2="$(CLAUDE_SESSION_ID=fixed-seed "$WIKI" dust -n 1 --root "$FIX/ok")"
if [ -n "$d1" ] && [ "$d1" = "$d2" ] && [ -f "$FIX/ok/$d1" ]; then
  ok "dust: 同一 seed で決定的・実在パスを返す"
else
  ng "dust: 決定性 (d1=$d1 d2=$d2)"
fi
n_dust="$("$WIKI" dust -n 2 --root "$FIX/ok" | wc -l | tr -d ' ')"
if [ "$n_dust" = "2" ]; then ok "dust: -n 件数どおり"; else ng "dust: -n 2 で $n_dust 行"; fi

echo "=== --help (全体 + 各動詞) ==="
check "--help 全体" 0 "9 動詞" "$WIKI" --help
for v in new save sync lint find links cards dust; do
  check "--help $v" 0 "wiki" "$WIKI" "$v" --help
done

echo "=== (f) Round 3 の修理回帰: aka 配列 / 0 バイト予約 / push honesty / 被リンクエンティティ ==="
check "E15 aka がスカラー" 1 "E15 " "$WIKI" lint --root "$FIX/bad/e15-aka-scalar" "$FIX/bad/e15-aka-scalar/entities/org/aka-scalar.md"
check "links: 被リンクエンティティ (by の入リンク) が出る" 0 "product/claude-code (by)" "$WIKI" links org/anthropic --root "$FIX/ok"
"$W2" new entity org empty-probe > /dev/null
check "save: 0 バイト予約は NOT-SAVED exit 1" 1 "0 バイト予約" "$W2" save "$WORK/entities/org/empty-probe.md"
X1R="$SB/x1resv"
mkdir -p "$X1R/entities/org" "$X1R/records/2026/08"
: > "$X1R/entities/org/ghost.md"
printf -- '---\ntype: obs\ntitle: ghost 参照\nabout: [org/ghost]\n---\n\n依頼者の言葉:\n\n> ghost。\n' > "$X1R/records/2026/08/2026-08-02-ghost-ref-ab12.md"
check "X1: 参照先が 0 バイト予約のままを明示" 1 "予約のまま" "$WIKI" lint --all --root "$X1R"
check "links: 0 バイト予約の ID は「予約のまま」で exit 1" 1 "予約のまま" "$WIKI" links org/ghost --root "$X1R"
if out=$("$W2" save "$WORK/scripts/wiki" 2>&1); ec=$?; [ $ec -eq 1 ] && ! printf '%s' "$out" | grep -q '保存済み'; then
  ok "save: 全拒否時に「保存済み」の嘘 warn を出さない"
else
  ng "save: push honesty (out=$out)"
fi
rm -f "$WORK/entities/org/empty-probe.md"

echo "=== (g) hook 3 本の回帰 (合成 stdin — 台帳 hash 所有権 / clean・E 分割 / 毒饅頭防止) ==="
HSB="$SB/hooks"
mkdir -p "$HSB/scripts"
cp "$WIKI" "$HSB/scripts/wiki"
cp "$REPO/scripts/hook-boot.sh" "$REPO/scripts/hook-lint.sh" "$REPO/scripts/hook-stop.sh" "$HSB/scripts/"
git init -qb main "$HSB"; git -C "$HSB" config user.email h@e.com; git -C "$HSB" config user.name h
mkdir -p "$HSB/entities/org" "$HSB/records"
git -C "$HSB" add -A; git -C "$HSB" commit -qm init
HS1="llmwiki-testsuite-h1-$$"; HS2="llmwiki-testsuite-h2-$$"
mkj() { printf '{"session_id":"%s","tool_input":{"file_path":"%s"},"stop_hook_active":%s}' "$1" "$2" "$3"; }
hb_out=$(mkj "$HS1" "" false | bash "$HSB/scripts/hook-boot.sh"); hb_rc=$?
if [ $hb_rc -eq 0 ] && printf '%s' "$hb_out" | grep -q 'entities:'; then ok "hook-boot: exit 0 + 現況注入"; else ng "hook-boot (rc=$hb_rc)"; fi
gd="$HSB/entities/org/h-good.md"; bd="$HSB/entities/org/h-bad.md"
printf -- '---\ntype: org\ntitle: HGood\ncreated: %s\n---\n\n> hook 回帰の正常系。\n' "$TODAY" > "$gd"
printf -- '---\ntype: org\ntitle: HBad\n---\n\n> created 無し (E14)。\n' > "$bd"
mkj "$HS1" "$gd" false | bash "$HSB/scripts/hook-lint.sh"; l1=$?
mkj "$HS1" "$bd" false | bash "$HSB/scripts/hook-lint.sh" 2>/dev/null; l2=$?
[ $l1 -eq 0 ] && [ $l2 -eq 2 ] && ok "hook-lint: 正常 0 / E で 2" || ng "hook-lint (l1=$l1 l2=$l2)"
grep -qE '^[0-9a-f]{64} ' "/tmp/llm-wiki-$HS1.paths" && ok "hook-lint: 台帳に hash+パスを記帳" || ng "hook-lint: 台帳形式"
# (stop_hook_active=true の挙動は下の HS3 ブロックで検証 — save はやる・差し戻し (exit 2) はしない)
c0=$(git -C "$HSB" rev-list --count HEAD)
so=$(mkj "$HS1" "" false | bash "$HSB/scripts/hook-stop.sh" 2>&1); s1=$?
c1=$(git -C "$HSB" rev-list --count HEAD)
if [ $s1 -eq 2 ] && [ $((c1 - c0)) -eq 1 ] && printf '%s' "$so" | grep -q 'saved entities/org/h-good.md'; then
  ok "hook-stop: clean は save・E は 1 回目 exit 2 (分割)"
else
  ng "hook-stop: 分割 (s1=$s1 dc=$((c1 - c0)))"
fi
so2=$(mkj "$HS1" "" false | bash "$HSB/scripts/hook-stop.sh" 2>&1); s2=$?
if [ $s2 -eq 0 ] && printf '%s' "$so2" | grep -q '未 commit のまま残す (E あり)'; then
  ok "hook-stop: 2 回目はガードで exit 0 (毒饅頭にしない)"
else
  ng "hook-stop: ガード (s2=$s2)"
fi
fg="$HSB/entities/org/h-foreign.md"
printf -- '---\ntype: org\ntitle: HForeign\ncreated: %s\n---\n\n> 所有権テスト。\n' "$TODAY" > "$fg"
mkj "$HS2" "$fg" false | bash "$HSB/scripts/hook-lint.sh"
printf -- '---\ntype: org\ntitle: HForeign\ncreated: %s\n---\n\n> 別セッションが後から変更した。\n' "$TODAY" > "$fg"
so3=$(mkj "$HS2" "" false | bash "$HSB/scripts/hook-stop.sh" 2>&1); s3=$?
if [ $s3 -eq 0 ] && printf '%s' "$so3" | grep -q '対象外' && [ -n "$(git -C "$HSB" status --porcelain -- entities/org/h-foreign.md)" ]; then
  ok "hook-stop: hash 不一致 (他者の変更) は対象外と明示して不触"
else
  ng "hook-stop: 所有権 (s3=$s3 so3=$so3)"
fi
# HS3: 差し戻し → 修正 → 継続ターン (stop_hook_active=true) で自動 commit されること (fresh レビューの live 実証バグの回帰)
HS3="llmwiki-testsuite-h3-$$"
bf="$HSB/entities/org/h-bounce-fix.md"
printf -- '---\ntype: org\ntitle: HBounceFix\n---\n\n> created 無し (E14)。\n' > "$bf"
mkj "$HS3" "$bf" false | bash "$HSB/scripts/hook-lint.sh" 2>/dev/null
mkj "$HS3" "" true | bash "$HSB/scripts/hook-stop.sh" > /dev/null 2>&1; a1=$?
[ $a1 -eq 0 ] && ok "hook-stop: active=true では E があっても差し戻さない (exit 0)" || ng "hook-stop: active で exit $a1"
printf -- '---\ntype: org\ntitle: HBounceFix\ncreated: %s\n---\n\n> 修正済み。\n' "$TODAY" > "$bf"
mkj "$HS3" "$bf" false | bash "$HSB/scripts/hook-lint.sh"
c2=$(git -C "$HSB" rev-list --count HEAD)
mkj "$HS3" "" true | bash "$HSB/scripts/hook-stop.sh" > /dev/null 2>&1; a2=$?
c3=$(git -C "$HSB" rev-list --count HEAD)
if [ $a2 -eq 0 ] && [ $((c3 - c2)) -eq 1 ] && git -C "$HSB" log --format=%s -1 | grep -q 'h-bounce-fix'; then
  ok "hook-stop: 差し戻し → 修正 → 継続ターンの Stop で自動 commit (置き去りにしない)"
else
  ng "hook-stop: 修正後の active save (rc=$a2 dc=$((c3 - c2)))"
fi
rm -f "/tmp/llm-wiki-$HS1.paths" "/tmp/llm-wiki-$HS2.paths" "/tmp/llm-wiki-$HS3.paths" "/tmp/llm-wiki-stop-$HS1" "/tmp/llm-wiki-stop-$HS2" "/tmp/llm-wiki-stop-$HS3"

echo "=== (h3) depth 無制限 union / カンマ配列 E1 ==="
DP="$SB/deep"
mkdir -p "$DP/entities/org" "$DP/entities/project" "$DP/entities/task" "$DP/records/2026/08"
printf -- '---\ntype: org\ntitle: Root\ncreated: 2026-08-02\n---\n\n> root。\n' > "$DP/entities/org/root.md"
prev="org/root"
for i in 1 2 3 4 5; do
  ty=project; [ "$i" -gt 2 ] && ty=task
  printf -- '---\ntype: %s\ntitle: "L%s"\ncreated: 2026-08-02\npart-of: [%s]\n---\n\n> L%s。\n' "$ty" "$i" "$prev" "$i" > "$DP/entities/$ty/l$i.md"
  prev="$ty/l$i"
done
printf -- '---\ntype: obs\ntitle: "最深の記録"\nabout: [task/l5]\n---\n\n依頼者の言葉:\n\n> 5 段目。\n' > "$DP/records/2026/08/2026-08-02-deepest-note-ab12.md"
check "links: depth 表示打ち切りでも union は深さ無制限 (5 段目の記録が出る)" 0 "deepest-note-ab12" "$WIKI" links org/root --root "$DP"
check "links: 表示打ち切り時にその旨と全ノード数を明示" 0 "…表示打ち切り (子孫は計 5 ノード" "$WIKI" links org/root --root "$DP"
CM="$SB/comma"
mkdir -p "$CM/entities/org"
printf -- '---\ntype: org\ntitle: C\naka: ["Foo, Inc", Bar]\ncreated: 2026-08-02\n---\n\n> c。\n' > "$CM/entities/org/c.md"
check "E1: 配列要素内のカンマ (クォートしても不可)" 1 "配列要素にカンマ" "$WIKI" lint --root "$CM" "$CM/entities/org/c.md"

echo "=== (h2) find (正規化突合) / cards 上限 ==="
check "find: 日本語 aka の正規化一致 (EXACT)" 0 "EXACT account/x-naval" "$WIKI" find "ナヴァル" --root "$FIX/ok"
check "find: 部分一致は NEAR で返る" 0 "NEAR  person/naval-ravikant" "$WIKI" find "ナヴァル" --root "$FIX/ok"
check "find: 0 件は「新規に立ててよい」と明言" 0 "新規に立ててよい" "$WIKI" find "zzz-not-here" --root "$FIX/ok"
check "find: 1 字違いの近接ゆれも NEAR (≈)" 0 "≈" "$WIKI" find "ナグァル" --root "$FIX/ok"
many=$(for i in $(seq 1 70); do printf '%s ' "$FIX/ok/records/2026/08/2026-08-02-naval-leverage-judgment-3f9c.md"; done)
cw=$("$WIKI" cards --root "$FIX/ok" $many 2>/dev/null | tail -1)
if printf '%s' "$cw" | grep -q '60 件で打ち切り'; then ok "cards: 60 件打ち切りを stdout 末尾で明示 (パイプで消えない)"; else ng "cards: 上限 (cw=$cw)"; fi
W10D="$SB/w10"
mkdir -p "$W10D/entities/person" "$W10D/entities/concept" "$W10D/records/2026/08"
printf -- '---\ntype: person\ntitle: W Ten\ncreated: 2026-08-02\n---\n\n> w10。\n' > "$W10D/entities/person/w-ten.md"
printf -- '---\ntype: concept\ntitle: agent design\naka: [エージェント設計]\ncreated: 2026-08-02\n---\n\n> 検査用。\n' > "$W10D/entities/concept/agent-design.md"
printf -- '---\ntype: obs\ntitle: "w10 検査"\nabout: [concept/agent-design]\nby: [person/w-ten]\n---\n\n依頼者の言葉:\n\n> t。\n' > "$W10D/records/2026/08/2026-08-02-w10-check-ab12.md"
check "W10: by の対象が about に無いと警告" 0 "W10 " "$WIKI" lint --all --warn --root "$W10D"

echo "=== (h) Round 4 の修理回帰: A7 TZ / 祖先 / alias 推移閉包・改名連鎖 / ミラー同期ガード ==="
tzp="$(TZ=America/Los_Angeles "$W2" new record obs tz-regression)"
if printf '%s' "$tzp" | grep -qF "$TODAY"; then ok "A7: TZ 偽装でも JST 日付で採番"; else ng "A7: TZ (tzp=$tzp)"; fi
rm -f "$WORK/$tzp"
check "links: 祖先 (part-of 連鎖) が根まで出る" 0 "org/acme-ai" "$WIKI" links community/dc-agent-builders --root "$FIX/ok"

RC="$SB/rename-chain"
mkdir -p "$RC/entities/org" "$RC/entities/project" "$RC/records/2026/08"
printf -- '---\ntype: org\ntitle: Oldest Co\ncreated: 2026-08-02\nalias-of: [org/old-co]\n---\n\n> 最古の旧名 stub。\n' > "$RC/entities/org/oldest-co.md"
printf -- '---\ntype: org\ntitle: Old Co\ncreated: 2026-08-02\nalias-of: [org/new-co]\n---\n\n> 旧名 stub。\n' > "$RC/entities/org/old-co.md"
printf -- '---\ntype: org\ntitle: New Co\ncreated: 2026-08-02\n---\n\n> 現名。\n' > "$RC/entities/org/new-co.md"
printf -- '---\ntype: project\ntitle: RC Child\ncreated: 2026-08-02\npart-of: [org/old-co]\n---\n\n> 旧名を part-of で指したままの子 (張り替え漏れ)。\n' > "$RC/entities/project/rc-child.md"
printf -- '---\ntype: obs\ntitle: "child の記録"\nabout: [project/rc-child]\n---\n\n依頼者の言葉:\n\n> 子の記録。\n' > "$RC/records/2026/08/2026-08-02-rc-child-note-ab12.md"
printf -- '---\ntype: obs\ntitle: "最古名義の記録"\nabout: [org/oldest-co]\n---\n\n依頼者の言葉:\n\n> 最古の記録。\n' > "$RC/records/2026/08/2026-08-02-oldest-era-note-cd34.md"
check "links: 旧名を part-of で指す子も新名の子孫に出る (alias 閉包)" 0 "project/rc-child" "$WIKI" links org/new-co --root "$RC"
check "links: 2 段の改名連鎖でも最古世代の記録が union に入る (推移閉包)" 0 "oldest-era-note-cd34" "$WIKI" links org/new-co --root "$RC"
check "links: 張り替え漏れの子の配下の記録も union に入る" 0 "rc-child-note-ab12" "$WIKI" links org/new-co --root "$RC"

# X1: インラインコード内の [[..]] は引用例 — リンク扱いしない
IC="$SB/inline-code"
mkdir -p "$IC/records/2026/08" "$IC/entities/org"
printf -- '---\ntype: org\ntitle: IC\ncreated: 2026-08-02\n---\n\n> ok。\n' > "$IC/entities/org/ic.md"
printf -- '---\ntype: obs\ntitle: "記法の引用"\nabout: [org/ic]\n---\n\n依頼者の言葉:\n\n> 例えば `[[org/does-not-exist]]` と書く形。\n' > "$IC/records/2026/08/2026-08-02-inline-code-quote-ab12.md"
check_empty "X1: インラインコード内の [[..]] は非検出" "$WIKI" lint --all --root "$IC"

# 逐語ミラーの同期ガード (ずれたらここで割れる — B-F15 の再演防止)
if diff -q <(sed -n '/### 5-2/,/^```$/p' "$REPO/SPEC.md" | sed -n '/```markdown/,/^```$/p' | sed '1d;$d') "$REPO/CLAUDE.md" > /dev/null; then
  ok "ミラー: SPEC §5-2 の CLAUDE.md 写し = 実物 (byte 一致)"
else
  ng "ミラー: SPEC §5-2 と CLAUDE.md がずれている"
fi
spec_r=$(sed -n '/^### 4-3\./,/^```$/p' "$REPO/SPEC.md" | sed -n '/```bash/,/^```$/p' | sed '1d;$d' | grep -v '^$')
ref_r=$(sed -n '/^## 検索レシピ/,/^```$/p' "$REPO/.claude/skills/ref-wiki-schema/SKILL.md" | sed -n '/```bash/,/^```$/p' | sed '1d;$d' | grep -v '^$')
if [ -n "$spec_r" ] && [ "$spec_r" = "$ref_r" ]; then
  ok "ミラー: SPEC §4-3 の R1-R10 = ref-wiki-schema (逐語一致)"
else
  ng "ミラー: R1-R10 が SPEC と ref でずれている"
fi
# D10 行数予算の機械ガード (総量固定制 — ここが割れたら「足すなら削る」の議論をせよ)
budget_ok=1
check_budget() { local f="$1" lim="$2" n; n=$(wc -l < "$REPO/$f" | tr -d ' '); if [ "$n" -gt "$lim" ]; then ng "予算超過: $f = $n 行 > $lim"; budget_ok=0; else :; fi; }
check_budget CLAUDE.md 40
check_budget .claude/skills/ref-wiki-schema/SKILL.md 120
check_budget .claude/skills/run-wiki-capture/SKILL.md 100
check_budget .claude/skills/run-wiki-recall/SKILL.md 100
check_budget .claude/skills/run-wiki-garden/SKILL.md 100
[ "$budget_ok" = 1 ] && ok "D10 規約予算: CLAUDE.md≤40 / ref≤120 / run×3≤100 (全て予算内)"

spec_c=$(sed -n '/capture の必須手順/,/^###/p' "$REPO/SPEC.md" | grep -E '^[0-9]\.' -A2 | grep -v '^#' | tr -d ' \n')
skill_c=$(sed -n '/## 必須手順/,/^## 手順/p' "$REPO/.claude/skills/run-wiki-capture/SKILL.md" | grep -E '^[0-9]\.' -A2 | grep -v '^#' | tr -d ' \n')
if [ -n "$spec_c" ] && [ "$spec_c" = "$skill_c" ]; then
  ok "ミラー: SPEC §5-3 の capture 必須手順 = skill 実物 (正規化一致)"
else
  ng "ミラー: capture 必須手順が SPEC と skill でずれている"
fi

echo
echo "==== 結果: PASS=$PASS FAIL=$FAIL ===="
[ "$FAIL" = 0 ] || exit 1
exit 0
