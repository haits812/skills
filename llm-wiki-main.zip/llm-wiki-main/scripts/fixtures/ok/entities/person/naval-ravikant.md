---
type: person
title: Naval Ravikant
aka: [ナヴァル・ラヴィカント, naval]
created: 2026-08-02
---

> AngelList 創業者・投資家。レバレッジと判断の語彙の供給源。
