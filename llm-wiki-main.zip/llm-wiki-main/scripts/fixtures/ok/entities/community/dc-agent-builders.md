---
type: community
title: Agent Builders (Discord)
aka: [エージェントビルダーズ, agent-builders, AB Discord]
created: 2026-08-02
status: active
part-of: [project/agent-ops-biz, project/dev-rel]
---

> 実装者中心の Discord (約 1,200 人)。事業のリード獲得と現場の詰まりどころの一次観測を兼ねる。

流量が多いのは #tooling。中心的な実装者は [[person/kenji-sato]]。
