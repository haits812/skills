---
type: account
title: "@naval (X)"
aka: [naval, ナヴァル, Naval Ravikant]
created: 2026-08-02
alias-of: [person/naval-ravikant]
---

> X 上の投資家・起業家アカウント。レバレッジ / 判断の語彙を供給してくる観測対象。

まとまった記事を書かない人なので、時系列に obs を積む。刺さった投稿は都度 obs にし
`about` に対応する concept を必ず付ける。
