---
type: concept
title: leverage (レバレッジ)
aka: [レバレッジ, 判断の複製]
created: 2026-08-02
---

> 少ない入力で大きな出力を得る構造。naval の語彙圏。
