---
type: concept
title: tool design (ツール設計)
aka: [ツール設計, tool-dsgn]
created: 2026-08-02
related: [concept/agent-design]
---

> エージェントに渡すツール定義の設計論。agent design の下位トピック。
