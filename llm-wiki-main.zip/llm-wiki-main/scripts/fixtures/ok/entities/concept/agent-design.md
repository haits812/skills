---
type: concept
title: agent design (エージェント設計)
aka: [エージェント設計, agentic design, agent-design]
created: 2026-08-02
---

> どう組むと壊れないかの設計論。この wiki で最も記録が集まる結節点。

## 見取り図 (2026-08 時点)

- 主戦場はプロンプトからツール設計へ → [[2026-08-02-anthropic-building-effective-agents-9c1a]]
- 現場の詰まりは運用側 (権限・再実行・観測) に出る → [[community/dc-agent-builders]] の観測群

## 読む順

1. [[2026-08-02-anthropic-building-effective-agents-9c1a]] — 語彙の土台
2. 以降は時系列。一覧はここに書かない (二重管理) — 導出:
   `rg -Pl 'concept/agent-design(?![a-z0-9-])' records/ | sort -r | head -30`
