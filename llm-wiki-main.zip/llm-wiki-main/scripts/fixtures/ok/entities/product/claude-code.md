---
type: product
title: Claude Code
aka: [クロードコード]
created: 2026-08-02
by: [org/anthropic]
---

> Anthropic のエージェンティックコーディング CLI。エージェント運用の主力ツール。
