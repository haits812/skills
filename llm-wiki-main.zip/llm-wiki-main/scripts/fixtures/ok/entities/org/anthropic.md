---
type: org
title: Anthropic
aka: [アンソロピック, Anthropic PBC]
created: 2026-08-02
---

> Claude を作っている米 AI ラボ。エージェント設計の一次情報源として追っている。

engineering blog の実務密度が高く、[[concept/agent-design]] の語彙はここ発が実質の標準。
提供している製品は [[product/claude-code]] (product 側が `by` で指している)。
