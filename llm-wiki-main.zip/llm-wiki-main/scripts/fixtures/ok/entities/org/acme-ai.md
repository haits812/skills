---
type: org
title: Acme AI
aka: [アクメAI, acme-ai-inc]
created: 2026-08-02
---

> エージェント運用環境のオーナー企業。エージェント運用事業の主体。
