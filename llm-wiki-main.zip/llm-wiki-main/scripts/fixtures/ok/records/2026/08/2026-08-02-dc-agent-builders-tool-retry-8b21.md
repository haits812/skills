---
type: obs
title: "AB Discord: ツールの再試行ループで運用が燃えた報告"
source: https://discord.com/channels/123456789/987654321
about: [community/dc-agent-builders, concept/tool-design, person/kenji-sato]
by: [person/kenji-sato]
confidence: 事実
---

依頼者の言葉:

> #tooling で kenji が「再試行ループの上限を決めずに本番に出して燃えた」と報告していた。

補足 (司書): [[concept/tool-design]] の設計不足が運用側で顕在化する典型例。
