---
type: obs
title: "naval「レバレッジとは判断の複製であって労働の複製ではない」"
source: https://x.com/naval/status/1234567890123456789
about: [account/x-naval, concept/leverage]
by: [account/x-naval]
confidence: 事実
---

依頼者の言葉:

> X で "Leverage is the reproduction of judgment, not of labor." と投稿していた。記録して。

補足 (司書): [[project/agent-ops-biz]] の提案書の「労働の代替」フレームより「判断の複製」の方が
単価の説明がつく — 効きどころとして接続しておく。
