---
type: note
title: "Building Effective Agents — ツール設計が主戦場"
source: https://www.anthropic.com/engineering/building-effective-agents
about: [org/anthropic, concept/agent-design, concept/tool-design]
by: [org/anthropic]
---

依頼者の言葉:

> ツール設計がエージェント設計の主戦場、という指摘が刺さった。失敗の多くはモデルでなく
> ツール定義の曖昧さから来る、は実感と一致する。

補足 (司書): [[project/agent-ops-biz]] で再試行ループに入って燃えた案件と同じ構図
(→ [[2026-08-02-dc-agent-builders-tool-retry-8b21]] の観測とも一致)。
要約は置かない。原文は source を読めばいい。ここに残すのは判断だけ。
