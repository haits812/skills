---
type: concept
title: AI agent design
aka: [agent-design]
created: 2026-08-02
---

> 重複ペアのもう片方 (aka が正規化で agent-design に一致)。
