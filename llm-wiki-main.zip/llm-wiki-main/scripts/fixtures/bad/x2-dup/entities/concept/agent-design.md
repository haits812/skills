---
type: concept
title: Agent Design
aka: [エージェント設計]
created: 2026-08-02
---

> 重複ペアの片方。
