---
type: org
title: BadStatus
aka: [バッドステータス]
created: 2026-08-02
status: 稼働中
---

> status 語彙外 (稼働中) を E18 で捕まえる回帰 — 語彙外は R2 の絞り込みから silent に脱落する。
