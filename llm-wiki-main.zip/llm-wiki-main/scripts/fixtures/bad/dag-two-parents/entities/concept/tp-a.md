---
type: concept
title: TwoParents A
created: 2026-08-02
part-of: [concept/tp-b, concept/tp-c]
---

> 多重親 fixture ノード tp-a。
