---
type: concept
title: TwoParents B
created: 2026-08-02
part-of: [concept/tp-d]
---

> 多重親 fixture ノード tp-b。
