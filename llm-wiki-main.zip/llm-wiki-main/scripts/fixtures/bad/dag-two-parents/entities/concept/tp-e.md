---
type: concept
title: TwoParents Ancestor E
created: 2026-08-02
---

> 多重親 fixture ノード tp-e。
