---
type: concept
title: TwoParents C
created: 2026-08-02
part-of: [concept/tp-e]
---

> 多重親 fixture ノード tp-c。
