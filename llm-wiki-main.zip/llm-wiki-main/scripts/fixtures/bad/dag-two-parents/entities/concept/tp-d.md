---
type: concept
title: TwoParents Ancestor D
created: 2026-08-02
---

> 多重親 fixture ノード tp-d。
