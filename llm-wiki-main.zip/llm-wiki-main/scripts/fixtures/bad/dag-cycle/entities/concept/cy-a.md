---
type: concept
title: Cycle A
created: 2026-08-02
part-of: [concept/cy-b]
---

> 多重親 fixture ノード cy-a。
