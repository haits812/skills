---
type: concept
title: Cycle B
created: 2026-08-02
part-of: [concept/cy-c]
---

> 多重親 fixture ノード cy-b。
