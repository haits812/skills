---
type: concept
title: Cycle C
created: 2026-08-02
part-of: [concept/cy-a]
---

> 多重親 fixture ノード cy-c。
