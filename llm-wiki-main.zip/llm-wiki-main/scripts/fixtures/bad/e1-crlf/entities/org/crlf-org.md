---
type: org
title: CRLF Org
created: 2026-08-02
---

> CRLF 改行の違反サンプル。
