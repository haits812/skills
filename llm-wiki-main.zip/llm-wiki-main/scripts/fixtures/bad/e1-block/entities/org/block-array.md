---
type: org
title: Block Array Org
created: 2026-08-02
aka:
  - foo
  - bar
---

> block 配列の違反サンプル。
