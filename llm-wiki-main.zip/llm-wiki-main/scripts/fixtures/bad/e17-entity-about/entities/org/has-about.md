---
type: org
title: Has About Org
aka: [about-org]
created: 2026-08-02
about: [concept/tool-design]
---

> エンティティに about がある違反サンプル。
