---
type: org
title: X4 Org
created: 2026-08-02
---

> x4-domain の参照先 (X1 を出さないための実在 stub)。
