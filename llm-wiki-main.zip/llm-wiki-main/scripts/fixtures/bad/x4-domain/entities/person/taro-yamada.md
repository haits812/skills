---
type: person
title: Taro Yamada
created: 2026-08-02
part-of: [org/x4-org]
---

> person が part-of を持つ domain 違反サンプル。
