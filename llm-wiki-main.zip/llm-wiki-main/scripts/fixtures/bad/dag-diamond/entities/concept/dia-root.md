---
type: concept
title: Diamond Root
created: 2026-08-02
---

> 多重親 fixture ノード dia-root。
