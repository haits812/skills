---
type: concept
title: Diamond Mid C
created: 2026-08-02
part-of: [concept/dia-root]
---

> 多重親 fixture ノード dia-mid-c。
