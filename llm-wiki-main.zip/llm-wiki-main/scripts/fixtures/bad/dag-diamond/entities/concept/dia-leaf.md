---
type: concept
title: Diamond Leaf
created: 2026-08-02
part-of: [concept/dia-mid-b, concept/dia-mid-c]
---

> 多重親 fixture ノード dia-leaf。
