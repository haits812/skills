---
type: org
title: Fence Org
created: 2026-08-02
---

> code block 内のリンクは検査対象外であることのサンプル (B-F7)。

```
[[org/missing-in-fence]] はリンクとして扱わない
```
