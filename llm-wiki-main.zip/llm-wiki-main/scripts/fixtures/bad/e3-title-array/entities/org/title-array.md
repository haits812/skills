---
type: org
title: [Foo, Bar]
created: 2026-08-02
---

> title が配列化した違反サンプル (B-F16)。
