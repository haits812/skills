---
type: concept
title: Lattice N2B
created: 2026-08-02
part-of: [concept/lat-n3b, concept/lat-n3c]
---

> 多重親 fixture ノード lat-n2b。
