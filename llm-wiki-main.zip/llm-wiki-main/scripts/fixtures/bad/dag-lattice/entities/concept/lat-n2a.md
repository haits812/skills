---
type: concept
title: Lattice N2A
created: 2026-08-02
part-of: [concept/lat-n3a, concept/lat-n3b]
---

> 多重親 fixture ノード lat-n2a。
