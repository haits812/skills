---
type: concept
title: Lattice N4 Root
created: 2026-08-02
---

> 多重親 fixture ノード lat-n4。
