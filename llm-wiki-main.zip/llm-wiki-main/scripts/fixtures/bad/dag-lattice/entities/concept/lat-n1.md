---
type: concept
title: Lattice N1
created: 2026-08-02
part-of: [concept/lat-n2a, concept/lat-n2b]
---

> 多重親 fixture ノード lat-n1。
