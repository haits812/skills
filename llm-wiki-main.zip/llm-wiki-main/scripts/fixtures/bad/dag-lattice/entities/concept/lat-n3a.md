---
type: concept
title: Lattice N3A
created: 2026-08-02
part-of: [concept/lat-n4]
---

> 多重親 fixture ノード lat-n3a。
