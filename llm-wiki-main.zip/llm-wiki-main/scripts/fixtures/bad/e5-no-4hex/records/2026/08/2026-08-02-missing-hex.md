---
type: obs
title: 4hex が無い記録
about: [concept/tool-design]
---

4hex サフィックス欠落の違反サンプル。
