---
type: org
title: Good Org
created: 2026-08-02
---

> 壊れリンクを含む本文のサンプル。

参照: [[org/missing-target]] はどこにも存在しない。
