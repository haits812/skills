---
type: org
title: AkaScalar
aka: エーケーエースカラー
created: 2026-08-02
---

> aka がスカラー (配列でない) を E15 で捕まえる回帰 — スカラーは X2/W8 の材料から silent 脱落する。
