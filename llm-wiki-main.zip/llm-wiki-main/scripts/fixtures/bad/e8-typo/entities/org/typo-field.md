---
type: org
title: Typo Field Org
created: 2026-08-02
tgas: [foo]
---

> tgas タイポの違反サンプル (C-中19)。
