---
type: community
title: Scalar Parent Community
created: 2026-08-02
part-of: org/acme-ai
---

> part-of が配列でない違反サンプル。
