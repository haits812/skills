---
type: obs
title: 述語が記録を指す違反
about: [2026-08-01-some-earlier-note-9f3c]
---

frontmatter の述語が記録 ID を指す違反サンプル。
