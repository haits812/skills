---
type: obs
title: created を持つ記録
about: [concept/tool-design]
created: 2026-08-02
---

記録に created がある違反サンプル。
