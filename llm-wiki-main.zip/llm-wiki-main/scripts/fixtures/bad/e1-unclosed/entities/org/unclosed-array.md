---
type: org
title: Unclosed
aka: [ユンクローズド, unclosed
created: 2026-08-02
---

> インライン配列の閉じ忘れ (] が無い) を E1 で捕まえる回帰。
