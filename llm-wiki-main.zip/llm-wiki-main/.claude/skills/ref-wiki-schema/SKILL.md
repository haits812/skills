---
name: ref-wiki-schema
description: llm-wiki の語彙 (型 10・述語 7)・ID/パス規則・frontmatter 書式・検索レシピ R1-R10 の逐語正本。entities/ records/ に何かを書く前、ID やリンクの書き方で迷った時、記録を grep で引く形を決める時に開く。「wiki の書式」「wiki のレシピ」で発動。
user-invocable: true
kind: docs
---

# llm-wiki スキーマ — 語彙・書式・検索レシピの逐語正本

設計根拠と lint の全項目は SPEC.md (データ契約は SPEC が正本、レシピ・手順は本書が正本)。frontmatter は頭で
組み立てず `.claude/skills/ref-wiki-schema/templates/` の 3 枚 (`entity.md`/`record-note.md`/`record-obs.md`) を写す。

## 型 10 (凍結)

エンティティ 8 = `entities/<type>/<slug>.md`。世界に持続し同一性を持つ名詞。ページは 1 つ・更新はまれ。

| type | 意味 | 例 |
|---|---|---|
| `org` | 会社・法人・組織・チーム | `org/acme-ai` |
| `person` | 人 (実名の人格) | `person/naval-ravikant` |
| `project` | 事業・案件 | `project/agent-ops-biz` |
| `task` | タスクの**記述的記録** — 外の案件 + 自事業のマイルストーンも可。作業**管理** (issue 追跡) はイシュー管理ツールへ | `task/contract-review-acme` |
| `community` | Discord / Slack / フォーラム / 勉強会 = 場 | `community/dc-agent-builders` |
| `account` | プラットフォーム上のアカウント | `account/x-naval` |
| `product` | 製品・サービス・OSS・ツール | `product/claude-code` |
| `concept` | 概念・技術・イベント名。分類の結節点 (MOC) | `concept/agent-design` |

記録 2 = `records/<YYYY>/<MM>/…`。ある時点の観測。**書いたら本文を書き換えない** (訂正は新しい記録で)。

| type | 意味 | 必須 |
|---|---|---|
| `note` | 外部ソース (記事/動画/論文/スレッド) の**構造抽出** — 結論 1-2 文 + 章単位の「要点 + 原文逐語引用 + 元の型」、章見出しに [point 0-5]。評論は書かない | `source` `about` |
| `obs` | 日付を持つ観測・出来事・発言記録 | `about` |

**線引き**: 来月また参照する名前 → エンティティ / 日付を外すと意味が壊れる → 記録 / 両方 YES なら**記録が勝つ**
(記事は「読んだという出来事」= note 1 枚で器にしない。催しの固有名も `concept/…` — event 型は作らない)。
**迷ったら記録** — 記録は後から昇格できるが、中身の無い器は消せず墓場になる。対象を同定できない入力も**断らない**:
`about: [concept/unresolved]` で原文を逐語のまま obs 化し、本文に「未解決: 何が引けないか」を書く (庭師が処理する)。

## ID とパス (純関数・変換表を持たない)

- slug `^[a-z0-9]+(-[a-z0-9]+)*$` (ASCII 固定。日本語は `title`/`aka` へ = NFC/NFD 事故の回避)。`account` はプラットフォーム prefix 必須 `x-` `dc-` `gh-` `yt-` `li-` (例 `account/x-naval`)
- 記録 `records/<YYYY>/<MM>/<YYYY-MM-DD>-<slug>-<4hex>.md` — slug は「誰が/何を」が分かる 3-6 語、4hex は `scripts/wiki new` が採番する (自分で考えない)
- 記録の日付: note = **読んで判断した日** (通常は投入日) / obs = **出来事が起きた日** — `scripts/wiki new record obs <slug> --date YYYY-MM-DD` で指定。不明なら省略して投入日 + 本文に「時期不明」/ **月まで確定なら月初 (YYYY-MM-01) + 本文に「日は不明 (月まで確定)」** — 日を捏造しない。日付・月は全て JST
- ID に `/` があればエンティティ、数字 4 桁始まりなら記録。`id` フィールドは持たない (パスが正本)。同名衝突は修飾語で分ける (`org/apple-inc` / `org/apple-records`) — 曖昧なら長い方

## frontmatter の書式制約 6 (自作パーサの成立条件。違反は lint E1-E3)

1. フラットな `key: value` のみ (**ネスト禁止** — インデントした行は違反)
2. 配列はインライン `[a, b]` 固定 (`- ` の block 記法は違反)
3. コメント (`#`)・複数行スカラ (`|` `>`) 禁止
4. 改行は LF (CRLF は E1)
5. `title` が `[` で始まる / `:` `"` を含む場合は `"` で括る (配列と誤読される)
6. **配列要素にカンマを含めない** (カンマは区切り専用。`Foo, Inc.` は `Foo Inc` と書く)

**フィールド**: 全ノート `type` `title` 必須 / エンティティ `created` 必須・`aka`・`status` (`active`/`paused`/`done`/`dead`) 任意 /
記録 `about` 必須 1 件以上・`source` (note 必須)・`confidence` (`事実`/`印象`/`推測`、obs 任意)。値は必ず配列、空ならキーごと省く。
非 ASCII の `title` を持つなら `aka` に日本語 + 英語 + 略称を必ず書く (日本語からの到達性)。**持たないフィールド**: `updated` `id`
`backlinks` `children` `tags` `date` `schema_version` (更新日は git・ID はパス・backlink は grep・分類は concept リンク・日付はファイル名)。

## 述語 7 (凍結・値の対象はエンティティ限定)

| 述語 | domain | range | 意味 |
|---|---|---|---|
| `part-of` | person 以外のエンティティ | エンティティ | 階層の親。複数可 (多重親 DAG・深さ無制限) |
| `member-of` | person / account | org / community | 所属 |
| `works-on` | person / account | project / task | 担当・関与 |
| `by` | 記録 / product | person / account / org | 著者・発話者・提供元 |
| `about` | 記録 | 任意のエンティティ | 主題 (記録必須。登場する固有名は省略せず全部書く) |
| `alias-of` | エンティティ | エンティティ | 同一実体の正本 (account→person / 旧名→新名) |
| `related` | 任意 | エンティティ | 逃げ道。要素は `<ID>` または `"<自由述語> <ID>"` (例 `"hosted-by org/acme"`)。6 件以上で W1 |

**親は子を指さない。子が親を指す単方向** — 親を編集しないので並行セッションが衝突しない。記録への参照は本文 `[[記録ID]]` のみで、
本文リンクは `[[org/acme-ai]]` / `[[org/acme-ai|アクメ社]]` の **ID 完全形**だけ (短縮解決は無い)。本文の規約は 2 つ:

- **エンティティ**: 最初の非空行は `> ` 始まりの 1 行定義 (`rg '^> ' entities/org/*.md` が名簿になる)
- **記録**: note = 結論 → 骨格 (章単位の構造抽出) → 「依頼者の言葉」(逐語・引用 `> ` 推奨) — 評論は書かない / obs = 「依頼者の言葉」→「補足 (司書):」。
  note の中身は source を読んで書く。依頼に無い判断を依頼者のものとして書くのは禁止。読んでいない記事の内容を作文しない

## 検索レシピ R1-R10 (ID の検索はこの形以外を使わない)

```bash
# R1 エンティティ探索 — まず find (正規化突合・EXACT/NEAR)。rg は補助
scripts/wiki find アクメ acme-ai
rg -in '^(title|aka):.*アクメ' entities/
# R2 型で一覧
ls entities/project/ ; rg -l '^status: active' entities/project/
# R3 下向き 1 段 (子)
rg -Pln '^(part-of|member-of|works-on):.*\borg/acme-ai(?![a-z0-9-])' entities/
# R4 被リンク全部 (backlink) — 記録 ID も同じ型で引ける。source URL 内の文字列にも当たる (過剰側) — 構造リンクだけ数えるなら links
rg -Pl '\borg/acme-ai(?![a-z0-9-])' entities/ records/
rg -Pl '\b2022-09-12-simonw-coins-prompt-injection-daa7(?![a-z0-9-])' entities/ records/
# R5 記録を時系列で (★ 既定は新しい順・30 件上限 — 古い順で読み始めない。同日内は slug 逆順 — 時刻は持たない)
rg -Pl '\bconcept/agent-design(?![a-z0-9-])' records/ | sort -r | head -30
# R6 期間 × テーマ × 型 (R5 と同じく新しい順・上限を外さない)
rg -Pl '\bconcept/agent-design(?![a-z0-9-])' records/2026/07/ | xargs rg -l '^type: note' | sort -r | head -30
# R7 Read 前の当たり付け (★ 必ず cards で 1 件 1 行に圧縮してから選ぶ)
scripts/wiki cards $(rg -Pl '\bconcept/agent-design(?![a-z0-9-])' records/ | sort -r | head -30)
# R8 全文 (ID を知らない自然文検索)
rg -in 'ツール定義' entities/ records/
# R9 alias/一族 union の被リンク (★ person/account/改名/集約は必ずこの経路 — 生 ID の grep は嘘の 0 件、
#    shell での ID 合成は方言 (zsh) で静かに壊れるため禁止。links が唯一の合成器)
scripts/wiki links person/naval-ravikant   # 親 / 子孫 / 被リンクエンティティ (by・related の入リンク) / 被リンク記録 = 一族+alias union・新しい順 head 30
scripts/wiki cards $(scripts/wiki links org/acme-ai --paths | head -8)   # 集約: 一族の記録を圧縮してから Read
# R10 期間で引く — 必ず両軸を 1 セットで打つ (投入日 = git author date / 出来事・判断日 = 日付ディレクトリ)。片方だけだと移行分が黙って落ちる
git log --diff-filter=A --since='2026-07-01 00:00' --until='2026-08-01 00:00' --format='%aI' --name-only -- records/ | rg '^records/'; ls records/2026/07/   # 裸日付は現在時刻が補われ境界日が落ちる (approxidate)
```

`-P` + 否定先読みが無いと `org/acme-ai-labs` に誤爆する (`-w` では防げない)。スコープは常に `entities/ records/` を明示
(`.` にすると SPEC・skill・fixtures の ID 例が混ざる)。rg (PCRE2) は必須依存 — `grep -rE` は否定先読みを表現できない。

## 禁止事項 (破ると静かに壊れる)

1. 導出物 (backlink 一覧・件数・索引・更新日) をファイルに保存しない。毎回 rg で読み時導出する
2. ディレクトリを増やさない・`tags` を作らない・型/述語を勝手に足さない (未整理の置き場は必ず墓場になる。増設条件は SPEC §7-3)
3. 既存パスに素の Write で新規作成しない (`scripts/wiki new` 予約経由のみ — 同時作成の silent overwrite は git にも残らない)
4. 親ファイルを編集して子を登録しない。階層は子側の `part-of` にだけ書く
5. 記録の本文を書き換えない・**ファイルを削除しない** (唯一の例外: W9 の 0 バイト予約死骸は庭師が削除。「消して」は訂正記録で応える。器の退役は alias-of stub 化 — frontmatter の機械的訂正のみ庭師が可)
6. `git add -A` / 素の `git commit` を打たない (commit は `scripts/wiki save` だけ)。`pull --rebase` を伴う同期は庭師の `scripts/wiki sync` だけ
7. **全文の中立要約**と **note への司書の評論**を書かない — note は構造抽出 (結論 + 章単位の要点・逐語引用・元の型 + point) で中身を運ぶ (URL は腐る)
