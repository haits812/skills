---
type: <org|person|project|task|community|account|product|concept>
title: <表示名。日本語可。[ で始まる / : や二重引用符を含むなら全体を二重引用符で括る>
aka: [<日本語名>, <英語名>, <略称・旧名>]
created: <YYYY-MM-DD (JST)>
status: <active|paused|done|dead>
part-of: [<親エンティティ ID>]
member-of: [<所属先 org/community ID>]
works-on: [<関与する project/task ID>]
by: [<提供元 org/person/account ID — product のみ>]
alias-of: [<同一実体の正本エンティティ ID>]
related: [<エンティティ ID>, "<自由述語> <エンティティ ID>"]
---

> <1 行定義。最初の非空行は必ず "> " 始まり。何者で・なぜこの wiki で追っているのかを 1 文で>

<安定した属性と関係を 2-4 行。言及は [[<エンティティ ID>]] / [[<記録 ID>]] で張る (ID の完全形のみ)。
一覧・件数・被リンクは書かない — 読み時に rg で導出するため二重管理になる>

<!-- ↓ ここから下は写さない (写し方) -----------------------------------------
必須は type / title / created と本文の "> " 1 行定義。述語 5 行 + aka + status は任意 —
使わないキーは行ごと消す (空配列を残さない = lint E15)。
新規は `scripts/wiki new entity <type> <slug>` の予約 (0 バイトファイル) を Read してから Write。
account の slug は x- / dc- / gh- / yt- / li- の prefix 付き。
concept は「見取り図」と「読む順」を書ける器だけ作る。一覧はここに列挙せず導出コマンドを 1 行置く。
-->
