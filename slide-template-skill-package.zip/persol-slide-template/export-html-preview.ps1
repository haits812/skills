param(
  [string]$PptxPath,
  [string]$BaseName,
  [switch]$Overwrite
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Get-TimestampToken {
  (Get-Date).ToString("yyyyMMdd-HHmm")
}

function Resolve-RunOutputDir {
  param(
    [string]$OutputRoot,
    [string]$RequestedBaseName
  )

  if (-not (Test-Path $OutputRoot)) {
    New-Item -ItemType Directory -Path $OutputRoot | Out-Null
  }

  $baseFolderName = (Get-TimestampToken) + "-" + $RequestedBaseName
  $candidateDir = Join-Path $OutputRoot $baseFolderName
  $counter = 2
  while (Test-Path $candidateDir) {
    $candidateDir = Join-Path $OutputRoot ($baseFolderName + "-" + $counter.ToString("00"))
    $counter += 1
  }

  New-Item -ItemType Directory -Path $candidateDir | Out-Null
  return $candidateDir
}

function Write-Utf8File {
  param(
    [string]$Path,
    [string]$Content
  )

  $utf8Bom = New-Object System.Text.UTF8Encoding($true)
  [System.IO.File]::WriteAllText($Path, $Content, $utf8Bom)
}

$templateRoot = $PSScriptRoot
$outputRoot = Join-Path $templateRoot "output"

if (-not $PptxPath) {
  $candidate = Get-ChildItem -Path $outputRoot -Recurse -Filter *.pptx -File |
    Sort-Object LastWriteTime -Descending |
    Select-Object -First 1
  if (-not $candidate) {
    throw "No PPTX file found under $outputRoot"
  }
  $PptxPath = $candidate.FullName
}

$pptxItem = Get-Item -LiteralPath $PptxPath
if (-not $BaseName) {
  $BaseName = [System.IO.Path]::GetFileNameWithoutExtension($pptxItem.Name)
}

$pptxParent = Split-Path -Parent $pptxItem.DirectoryName
if (($pptxParent -eq $outputRoot) -and ((Split-Path -Leaf $pptxItem.DirectoryName) -match '^\d{8}-\d{4}-.+')) {
  $outputDir = $pptxItem.DirectoryName
} else {
  $outputDir = Resolve-RunOutputDir -OutputRoot $outputRoot -RequestedBaseName $BaseName
  $copiedPptxPath = Join-Path $outputDir ($BaseName + ".pptx")
  Copy-Item -LiteralPath $pptxItem.FullName -Destination $copiedPptxPath -Force
  $pptxItem = Get-Item -LiteralPath $copiedPptxPath
}

$htmlPath = Join-Path $outputDir ($BaseName + ".html")
$assetDir = Join-Path $outputDir ($BaseName + "-assets")

if ((Test-Path $htmlPath) -and (-not $Overwrite)) {
  throw "HTML preview already exists at $htmlPath. Use -Overwrite to replace it."
}

if (Test-Path $assetDir) {
  Get-ChildItem -Path $assetDir -Force | Remove-Item -Recurse -Force
} else {
  New-Item -ItemType Directory -Path $assetDir | Out-Null
}

$slideRecords = @()
$pp = $null
$pres = $null

try {
  $pp = New-Object -ComObject PowerPoint.Application
  $pp.Visible = -1
  $pres = $pp.Presentations.Open($pptxItem.FullName, $false, $false, $false)

  for ($i = 1; $i -le $pres.Slides.Count; $i++) {
    $fileName = ("slide-{0:D2}.png" -f $i)
    $exportPath = Join-Path $assetDir $fileName
    $pres.Slides.Item($i).Export($exportPath, "PNG", 1600, 900)
    $slideRecords += [PSCustomObject]@{
      Index = $i
      FileName = $fileName
      Label = ("Slide {0:D2}" -f $i)
    }
  }
}
finally {
  if ($pres) {
    $pres.Close()
    [System.Runtime.InteropServices.Marshal]::ReleaseComObject($pres) | Out-Null
  }
  if ($pp) {
    $pp.Quit()
    [System.Runtime.InteropServices.Marshal]::ReleaseComObject($pp) | Out-Null
  }
  [GC]::Collect()
  [GC]::WaitForPendingFinalizers()
}

$slideMarkup = ($slideRecords | ForEach-Object {
@"
        <article class="slide$(if ($_.Index -eq 1) { ' is-active' })" data-title="$($_.Label)">
          <figure class="slide-frame"><img src="./$BaseName-assets/$($_.FileName)" alt="$($_.Label)"></figure>
        </article>
"@
}) -join "`n"

$slideCount = $slideRecords.Count
$deckLabel = [System.IO.Path]::GetFileNameWithoutExtension($pptxItem.Name)

$html = @"
<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>$deckLabel HTML Preview</title>
  <style>
    :root {
      --panel: rgba(255, 255, 255, 0.08);
      --text: #f5f7f7;
      --muted: rgba(245, 247, 247, 0.72);
      --accent: #00bdb2;
      --shadow: 0 24px 80px rgba(0, 0, 0, 0.42);
      --stage-w: min(96vw, calc(92dvh * 1.7777778));
      --stage-h: min(92dvh, calc(96vw / 1.7777778));
    }
    * { box-sizing: border-box; }
    html, body {
      margin: 0;
      width: 100%;
      height: 100%;
      overflow: hidden;
      background:
        radial-gradient(circle at top left, rgba(0, 189, 178, 0.14), transparent 28%),
        radial-gradient(circle at bottom right, rgba(255, 255, 255, 0.08), transparent 22%),
        linear-gradient(180deg, #16181c 0%, #090a0c 100%);
      color: var(--text);
      font-family: "Meiryo", "Hiragino Sans", sans-serif;
    }
    body { min-height: 100vh; min-height: 100dvh; }
    .deck-shell { position: relative; width: 100%; height: 100vh; height: 100dvh; overflow: hidden; isolation: isolate; }
    .deck-shell::before, .deck-shell::after { content: ""; position: absolute; pointer-events: none; z-index: 0; }
    .deck-shell::before {
      top: 6vh; left: 4vw; width: 28vw; height: 28vw;
      border: 1px solid rgba(255, 255, 255, 0.1); opacity: 0.35; transform: rotate(12deg);
    }
    .deck-shell::after {
      right: 5vw; bottom: 8vh; width: 26vw; height: 26vw;
      background: linear-gradient(135deg, rgba(0, 189, 178, 0.18), transparent 70%);
      filter: blur(24px); opacity: 0.55;
    }
    .deck-ui { position: absolute; inset: 0; z-index: 3; pointer-events: none; }
    .deck-header { display: flex; justify-content: space-between; align-items: flex-start; padding: 1rem 1.4rem 0; gap: 1rem; }
    .deck-brand, .deck-meta, .deck-footer {
      backdrop-filter: blur(14px); background: var(--panel); border: 1px solid rgba(255, 255, 255, 0.08);
      border-radius: 999px; box-shadow: 0 10px 28px rgba(0, 0, 0, 0.14);
    }
    .deck-brand { display: inline-flex; align-items: center; gap: 0.8rem; padding: 0.7rem 1rem; }
    .deck-brand strong, .deck-meta strong { display: block; font-size: 0.76rem; letter-spacing: 0.18em; text-transform: uppercase; }
    .deck-brand span, .deck-meta span, .deck-title { color: var(--muted); font-size: 0.84rem; }
    .deck-brand-mark { width: 0.72rem; height: 0.72rem; background: var(--accent); box-shadow: 0 0 0 0.24rem rgba(0, 189, 178, 0.18); }
    .deck-meta { padding: 0.7rem 1rem; text-align: right; }
    .deck-stage { position: relative; z-index: 1; width: 100%; height: 100%; display: grid; place-items: center; padding: 4.5rem 1rem 4rem; }
    .slide-stack { position: relative; width: var(--stage-w); height: var(--stage-h); }
    .slide { position: absolute; inset: 0; margin: auto; opacity: 0; transform: translateY(28px) scale(0.985); transition: opacity 320ms ease, transform 420ms ease; pointer-events: none; }
    .slide.is-active { opacity: 1; transform: translateY(0) scale(1); pointer-events: auto; }
    .slide-frame {
      width: 100%; height: 100%; margin: 0; border-radius: 18px; overflow: hidden;
      box-shadow: var(--shadow); background: rgba(255, 255, 255, 0.06); border: 1px solid rgba(255, 255, 255, 0.1);
    }
    .slide-frame img { display: block; width: 100%; height: 100%; object-fit: contain; background: #fff; }
    .deck-footer {
      position: absolute; left: 50%; bottom: 1rem; transform: translateX(-50%);
      display: flex; align-items: center; gap: 1rem; padding: 0.8rem 1rem; min-width: min(48rem, 88vw); pointer-events: auto;
    }
    .deck-counter { font-size: 0.92rem; font-weight: 700; letter-spacing: 0.08em; white-space: nowrap; }
    .deck-title { flex: 1; min-width: 0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .deck-progress { position: relative; flex: 1.2; height: 0.32rem; border-radius: 999px; overflow: hidden; background: rgba(255,255,255,0.12); }
    .deck-progress > span {
      position: absolute; inset: 0 auto 0 0; width: 0%;
      background: linear-gradient(90deg, rgba(0,189,178,0.7), #00bdb2); transition: width 260ms ease;
    }
    .deck-hint { font-size: 0.78rem; color: var(--muted); white-space: nowrap; }
    .deck-controls { position: absolute; inset: 0; z-index: 2; display: grid; grid-template-columns: 1fr 1fr; }
    .deck-hit { border: 0; background: transparent; cursor: pointer; pointer-events: auto; }
    .deck-hit:focus-visible { outline: 2px solid rgba(0, 189, 178, 0.8); outline-offset: -2px; }
    .visually-hidden {
      position: absolute; width: 1px; height: 1px; padding: 0; margin: -1px; overflow: hidden;
      clip: rect(0, 0, 0, 0); white-space: nowrap; border: 0;
    }
    @media (max-width: 720px) {
      .deck-header { padding: 0.8rem 0.8rem 0; }
      .deck-brand, .deck-meta, .deck-footer { border-radius: 18px; }
      .deck-meta span, .deck-hint { display: none; }
      .deck-footer { min-width: min(96vw, 38rem); gap: 0.7rem; }
      .deck-counter { font-size: 0.82rem; }
    }
    @media (prefers-reduced-motion: reduce) {
      .slide, .deck-progress > span { transition: none; }
    }
  </style>
</head>
<body>
  <main class="deck-shell" aria-label="$deckLabel HTML preview deck">
    <div class="deck-ui">
      <header class="deck-header">
        <div class="deck-brand">
          <span class="deck-brand-mark" aria-hidden="true"></span>
          <div>
            <strong>PERSOL HTML</strong>
            <span>$deckLabel</span>
          </div>
        </div>
        <div class="deck-meta">
          <strong>$slideCount Slides</strong>
          <span>Keyboard, wheel, swipe enabled</span>
        </div>
      </header>
    </div>
    <section class="deck-stage" aria-live="polite">
      <div class="slide-stack">
$slideMarkup
      </div>
    </section>
    <nav class="deck-controls" aria-label="Slide controls">
      <button class="deck-hit" type="button" id="prevButton"><span class="visually-hidden">Previous slide</span></button>
      <button class="deck-hit" type="button" id="nextButton"><span class="visually-hidden">Next slide</span></button>
    </nav>
    <footer class="deck-footer">
      <div class="deck-counter" id="deckCounter">01 / $("{0:D2}" -f $slideCount)</div>
      <div class="deck-title" id="deckTitle">Slide 01</div>
      <div class="deck-progress" aria-hidden="true"><span id="deckProgress"></span></div>
      <div class="deck-hint">&larr; &rarr; / wheel / swipe</div>
    </footer>
  </main>
  <script>
    class PresentationController {
      constructor() {
        this.slides = Array.from(document.querySelectorAll(".slide"));
        this.counter = document.getElementById("deckCounter");
        this.title = document.getElementById("deckTitle");
        this.progress = document.getElementById("deckProgress");
        this.index = 0;
        this.wheelLock = false;
        this.touchStartX = 0;
        this.touchStartY = 0;
        document.getElementById("prevButton").addEventListener("click", () => this.move(-1));
        document.getElementById("nextButton").addEventListener("click", () => this.move(1));
        window.addEventListener("keydown", (event) => this.onKeyDown(event));
        window.addEventListener("wheel", (event) => this.onWheel(event), { passive: false });
        window.addEventListener("touchstart", (event) => this.onTouchStart(event), { passive: true });
        window.addEventListener("touchend", (event) => this.onTouchEnd(event), { passive: true });
        this.render();
      }
      move(delta) {
        const next = Math.max(0, Math.min(this.slides.length - 1, this.index + delta));
        if (next === this.index) return;
        this.index = next;
        this.render();
      }
      render() {
        this.slides.forEach((slide, idx) => {
          slide.classList.toggle("is-active", idx === this.index);
          slide.setAttribute("aria-hidden", idx === this.index ? "false" : "true");
        });
        const current = this.slides[this.index];
        this.counter.textContent = String(this.index + 1).padStart(2, "0") + " / " + String(this.slides.length).padStart(2, "0");
        this.title.textContent = current.dataset.title || ("Slide " + String(this.index + 1).padStart(2, "0"));
        this.progress.style.width = (((this.index + 1) / this.slides.length) * 100) + "%";
      }
      onKeyDown(event) {
        if (["ArrowRight", "PageDown", " ", "j"].includes(event.key)) {
          event.preventDefault();
          this.move(1);
        } else if (["ArrowLeft", "PageUp", "k"].includes(event.key)) {
          event.preventDefault();
          this.move(-1);
        } else if (event.key === "Home") {
          event.preventDefault();
          this.index = 0;
          this.render();
        } else if (event.key === "End") {
          event.preventDefault();
          this.index = this.slides.length - 1;
          this.render();
        }
      }
      onWheel(event) {
        if (Math.abs(event.deltaY) < 18 || this.wheelLock) return;
        event.preventDefault();
        this.wheelLock = true;
        this.move(event.deltaY > 0 ? 1 : -1);
        window.setTimeout(() => { this.wheelLock = false; }, 420);
      }
      onTouchStart(event) {
        const touch = event.changedTouches[0];
        this.touchStartX = touch.clientX;
        this.touchStartY = touch.clientY;
      }
      onTouchEnd(event) {
        const touch = event.changedTouches[0];
        const deltaX = touch.clientX - this.touchStartX;
        const deltaY = touch.clientY - this.touchStartY;
        if (Math.abs(deltaX) < 48 || Math.abs(deltaX) < Math.abs(deltaY)) return;
        this.move(deltaX < 0 ? 1 : -1);
      }
    }
    new PresentationController();
  </script>
</body>
</html>
"@

Write-Utf8File -Path $htmlPath -Content $html
Write-Output $htmlPath
