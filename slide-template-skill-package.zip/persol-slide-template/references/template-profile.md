# PERSOL FY2025 Q3 Template Profile

## Quick Use

- Use `assets/reference/reference-sheet.png` first. It covers the six main slide families.
- Use `assets/reference/archetype-sheet-expanded.png` when you need the extended graph, text-image, topic-list, or disclaimer layouts.
- Use `assets/source/FY2025Q3presentation-template.pdf` as the final visual ground truth.
- Use `assets/logo/persol-logo-lockup.png` and `assets/logo/persol-logo-small.png` for branding. Prefer these PDF-derived assets over redrawing the logo.
- Start from `assets/pptx-starter/persol-theme.js` when building editable decks in JavaScript.

## Theme Tokens

- Canvas: 16:9 wide, 720 x 405 pt source ratio.
- Primary fonts: `Meiryo Bold` for large headings, `Meiryo` for body text and all table-cell content, `Verdana` only for compact numerals or English outside tables, `MS Gothic` only as a fallback.
- Core colors:
  - Aqua accent: `#00BDB2`
  - Aqua tint for highlighted table cells: `#DCE3E3`
  - Secondary aqua tint: `#A2CFCD`
  - Dark navy for positive bridge bars: `#002653`
  - Content gray: `#6A6B6B`
  - Divider gray: `#7F7F7F`
  - Frame gray: `#ABADAD`
  - Light panel gray: `#D7DADA`
  - Rules and grid lines: `#CFCFCF`
- Visual style: flat fills, thin rules, almost no outlines, no shadows, no decorative gradients.

## Persistent Page Furniture

- Keep a thin vertical gray rule on the far-left edge of standard content pages.
- Keep a small brand area at top-right. A wordmark is acceptable when the exact logo asset is unavailable.
- Keep copyright text centered near the bottom edge.
- Keep the page number bottom-right in a muted gray.

## Slide Archetypes

### 1. Cover Slide

- Reference: page 1.
- Structure: large white left panel plus light-gray right panel.
- The right gray area is a single polygon, not an inset rectangle. Its vector path spans `x=5.1489` to `12.2256` with a shallow bevel at the top-right and a matching bevel at the bottom-left.
- Use for: title, date, company name, report subtitle.
- Behavior: keep copy minimal and right-aligned inside the gray panel.
- Logo placement: use the PDF-derived lockup box from `assets/pptx-starter/persol-theme.js` (`x=1.4583`, `y=2.5926`, `w=2.4213`, `h=2.6898` in slide inches). Do not upscale the lockup to fill the left panel.
- Occupancy check: the cover lockup is intentionally modest. It should take about 18.2% of slide width and 35.9% of slide height, leaving the left panel mostly white.
- Verification rule: after rendering, compare the cover slide against PDF page 1. If the logo looks larger, reopen the PDF and recheck the token instead of resizing by feel.

### 2. Highlights Or Agenda Slide

- Reference: page 2.
- Structure: top-left title, vertical aqua timeline on the left, numbered aqua circles, bold headlines with short supporting bullets.
- Use for: highlight lists, executive summary, agenda.
- Behavior: keep each item to one bold line plus one or two bullet lines.

### 3. Section Divider

- Reference: page 3.
- Structure: pale left strip plus dark-gray right block with large white chapter title.
- The right block reuses the same measured polygon footprint as the cover slide, only with dark-gray fill over the light-gray page background.
- Use for: section boundaries.
- Behavior: keep only the chapter title and footer.

### 4. Summary Table

- References: pages 4 and 8.
- Structure: bold slide title, short summary sentence, wide table with thin gray rules.
- Use for: KPI snapshots, progress tables, forecast tables.
- Behavior: highlight the current-year or current-quarter column with aqua header and pale aqua body cells.

### 5. Waterfall Or Bridge Analysis

- Reference: page 5.
- Structure: large title, short lead sentence, central bridge chart, tiny explanatory callout box.
- Use for: EBITDA bridges, variance analysis, gain/loss explanation.
- Behavior: use aqua for start/end totals, navy for positive drivers, gray for cost or negative blocks.

### 6. Two-Panel Analysis

- Reference: page 21.
- Structure: left and right analytical clusters plus dark-gray comment headers and bullet commentary.
- Use for: business-unit comparisons, segment analysis, before/after narratives.
- Behavior: keep each panel visually balanced and reserve the bottom zone for commentary, not data.

### 7. SBU Comparison Bars

- Reference: page 9.
- Structure: title row, compact header, one SBU per row, two horizontal bars for period comparison, then YoY and commentary.
- Use for: business-unit revenue comparisons, KPI league tables with notes, rank-ordered comparisons.
- Behavior: keep row heights tight, bars thin, and comments to one short line per row.

### 8. Outlook Matrix

- Reference: page 25.
- Structure: title and summary sentence, then a multi-column matrix with one descriptive column and three decision columns.
- Use for: next-year outlook, market assessment, action mapping, scenario summaries.
- Behavior: preserve the strong header-band contrast and use aqua columns for outlook/action emphasis.

### 9. Growth Mix Chart

- Reference: page 28.
- Structure: explanatory bullets, small definition box, stacked bars over time, trend lines, and share/callout bubbles near the latest year.
- Use for: mix shift, segment composition, premium-tier growth, contribution split stories.
- Behavior: keep the chart left-heavy and reserve the right edge for CAGR / share callouts.

### 10. Text Plus Image Aside

- Reference: page 31.
- Structure: large title, full-width summary band, text bullets on the left, image/report cover on the right.
- Use for: publication announcements, initiative summaries, case-study callouts, ESG / HR updates.
- Behavior: left side should read like the main narrative; the right-side image is supporting evidence, not the headline.

### 11. Text Plus Summary Bullets

- Reference: derived from page 31.
- Structure: large title, full-width summary band for one main message, then a full-width bullet stack below with no right-side image.
- Use for: announcement slides with one clear takeaway, policy updates, initiative summaries, opening recap pages.
- Behavior: put the single most important sentence in the gray band and demote all other details into short bullets underneath.

### 12. Topic Feed

- Reference: page 33.
- Structure: many horizontal rows, each with a small category pill, one key message, and a lightweight right-edge cue.
- Use for: major topics, press highlights, portfolio news, release digests.
- Behavior: keep each row concise and visually even; use a small card strip at the bottom only when a few items need extra emphasis.

### 13. Dual Financial Tables

- Reference: page 36.
- Structure: one title, a unit label, and two tightly matched tables arranged left and right.
- Use for: balance sheet, cash flow subsets, before/after table comparisons, asset-vs-liability views.
- Behavior: tables must share row rhythm and header treatment; current-period columns should carry the aqua emphasis.

### 14. Multi-Series Trend Line

- Reference: page 42.
- Structure: large line chart, many series, inline legend, right-end value labels, and a short source note.
- Use for: labor-market ratios, long-run KPI tracking, benchmark spreads, time-series comparisons.
- Behavior: highlight only a few important series with stronger weight; let the rest stay secondary.

### 15. Text-Only Notice

- Reference: page 53.
- Structure: title plus two centered body paragraphs with generous whitespace.
- Use for: disclaimer pages, IR caution statements, closing notices, legal or methodological notes.
- Behavior: keep the typography calm and centered; do not add decorative shapes or side content.

## Composition Rules

- Keep titles heavy and left aligned.
- Leave deliberate clearance under the main title before any lead, unit label, bullet block, or table header. Avoid starting the next content band immediately under the title.
- Prefer one dominant visual per slide: one table, one chart, or one paired comparison.
- Use aqua only for emphasis. Most of the slide should stay neutral gray or white.
- Keep copy concise. The source deck relies on large numeric evidence and short explanatory lines.
- In tables and matrices, keep the cell typography consistent in Meiryo even when the contents are mostly numbers.
- Use square bullets, not circular bullets.
- Use the small top-right logo in its measured box (`x=12.2963`, `y=0.2917`, `w=0.5370`, `h=0.5972`).

## Things To Avoid

- Do not introduce colorful card mosaics or dashboard-style tile layouts.
- Do not center-align whole content slides.
- Do not mix many accent colors. Stay inside aqua, navy, gray, white.
- Do not place large logos in body slides unless the user explicitly asks for stronger branding.
