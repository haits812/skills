# CLAUDE.md — この repo で作業する agent へ

toolhint = Claude Code の hook (PreToolUse / UserPromptSubmit) で、きっかけに紐づけた
docs を context 注入するツール群。概要は README.md、導入手順は docs/getting-started.md、
用語は docs/glossary.md。

## レイアウト (どこを触るか)

- `core/toolhint_core.py` — **層への書き込みはここだけ**。読み書き・マージ・dry-run の
  機械操作の単一窓口 (stdout は JSON 1 行。契約は冒頭 docstring で定義)
- `engine/` — 注入 hook (PreToolUse = 操作きっかけ / UserPromptSubmit = ことばきっかけ)。
  plugin として単独動作・fail-open (実行を絶対に止めない)。パーサ・マッチ・層発見の
  実装はここにだけ置く — core は engine から import する (二重実装しない)
- `cli/toolhint` — core の薄い皮 (表示・確認プロンプトのみ。ロジックを持たせない)
- `manager/` — GUI。`server.mjs` (Node 標準 http) + `public/*`。core を子プロセスで叩く

## テスト (6 つ)

```sh
python3 engine/tests/test_toolhint.py            # engine 単体
python3 core/tests/test_core.py                  # core JSON 契約 + engine 発火 e2e
python3 cli/tests/test_cli.py                    # CLI (表示・引数の皮)
python3 manager/fixtures/test_mock_contract.py   # GUI mock と real core の契約一致
python3 manager/fixtures/test_savedoc_e2e.py     # GUI 保存経路の実書き込み縦貫 (node 必要)
cd manager && npm run e2e:layout                 # GUI レイアウト監査 (playwright)
```

e2e:layout は稼働中 server が前提で、env に `TOOLHINT_URL` (server の URL)、
非 loopback bind の server なら `TOOLHINT_TOKEN` も要る (loopback なら token 不要)。

## 守ること

- Python は **stdlib のみ** (pip 依存を足さない)。manager も Node 標準 http のみ
  (`npm install` なしで起動できる状態を維持)
- 層への書き込みは必ず core の `_layer_lock` + `_atomic_write` 経由 —
  直接 open/write を書かない
- GUI の色・フォント・サイズは `manager/public/style.css` の `:root` で定義した
  デザイン tokens のみ使う — コンポーネントに生 hex を書かない
- `manager/fixtures/toolhint_core_mock.py` と real core の契約は
  `test_mock_contract.py` が守っている — core の入出力を変えたら mock と両テストも揃える
- engine (`engine/scripts/` `engine/hooks/`) を変えてリリースする時は
  `engine/.claude-plugin/plugin.json` の version bump 必須 (bump なしでは
  `claude plugin update` が既存インストールを差し替えない)
- README / docs のコマンド例は `cli/tests/test_cli.py` の docs 節が検査する
  (インストールは 2 経路 — GitHub 直接 / clone。README「30 秒で試す」の最初のルールと
  getting-started §3・§5 は実行して出力例と比較、getting-started の相対パスは clone の
  親ディレクトリ基準の `./toolhint/...`、§5 だけは絶対パス)。CLI の引数や出力文言を
  変えたら README の「できること」表と getting-started の該当節を同じ文言に揃える

## 実データを壊さない

- `~/.claude/toolhint/` は、その環境で toolhint を使っている人の本物のデータ — テスト・実験は
  temp HOME + `TOOLHINT_GLOBAL=<一時dir>` で隔離する (例: `manager/fixtures/test_savedoc_e2e.py`)
- toolhint plugin を入れた環境では、この repo での作業中にも hook が発火することがある
  (`[toolhint]` で始まる注入)。それは正常動作
