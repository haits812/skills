#!/usr/bin/env node
// =============================================================================
// manager GUI の e2e レイアウト・意味監査 (playwright / 実 docs 非破壊)
//
// 実行方法:
//   cd manager && npm install          # playwright は devDependency
//   TOOLHINT_URL=http://<host>:<port> TOOLHINT_TOKEN=<token> npm run e2e:layout
//
//   - TOOLHINT_URL   省略時: http://127.0.0.1:4517
//   - TOOLHINT_TOKEN サーバが token 必須 (非 loopback bind) のときは必須。
//                    server.mjs 起動ログの ?token= の値
//   - chromium は playwright の標準 cache を使う。
//     無ければ `npx playwright install chromium`、それも不可なら実機 Chrome
//     (channel: 'chrome') へ自動フォールバックする
//
// 何をするか:
//   A. レイアウト行列 — 幅 [1280,1366,1440,1568,1920] × 高 [800,1080] で
//      (a) topbar 直下の可視要素ペア全組の boundingBox 交差ゼロ
//      (b) topbar 直下の可視要素に width 0 なし・document.scrollWidth ≤ innerWidth
//      (c) #cwd-input: 末尾可視 (scrollWidth ≤ clientWidth または scrollLeft が右端)
//          かつ direction=ltr — rtl は bidi 並べ替えで先頭 "/" が末尾へ移り
//          「相対パス + 末尾スラッシュ」に誤読されるため禁止
//      (d) #search-input に placeholder 文字列を value として注入して
//          scrollWidth ≤ clientWidth (検索 cancel ボタンの予約幅込みで測る方法)
//      (e) 「空き余白があるのに切れている」: topbar-spacer 幅 > 100px かつ
//          いずれかの input で scrollWidth > clientWidth なら FAIL
//   B. 意味の assertion —
//      (f) cwd 無し GET /api/state の cwd が git root と一致し /manager で終わらない
//      (g) 初期 #cwd-input 値 = (f) の値
//      (h) /api/propose を mock (doc_name=prefer-rg.md) → #proposal-name input が
//          存在し、value 変更が /api/apply の mock 捕捉 payload
//          (doc_name と rule.doc の両方) に反映される
//      (i) localStorage 復元: cwd を tmp dir に変更 → reload → input 値が維持
//      (j) 存在しないパス入力 → 警告が可視 (error-bar hidden=false /
//          .target-box.warn 等)
//      (s) 共有層 (layers.d) の doc: 読み取り専用の見た目 + きっかけ 1 件ごとの
//          導線の出し分け (共有のきっかけは操作ボタンなし / 同じ doc を指す手元の
//          きっかけには編集・ON/OFF・削除が出る)。GET を fixture に差し替えて
//          実サーバの層を触らずに再現する
//      (t) 読めない層 (layer_errors / layers[].parse_error) の警告帯、実体の無い
//          doc の言い方 (「参照先の doc が見つからない — 注入されない」)、判定の
//          教育文が判定タブでだけ見えること、新規作成ダイアログの層の選択欄が
//          「保存先」であること。同じく GET を fixture に差し替えて再現する
//      (u) doc を持たないルール (inject の文面だけ) — 一覧にカードで出ること
//          (見出し = ルール id / 「文面だけ」/ 文面)、左上の件数がルール数である
//          こと、詳細が「doc は無く、この文面だけを届ける」+ 文面 + 届く文面
//          (エディタ・保存・届け方は出ない) であること、「届く文面を変える」が
//          既存のきっかけ編集を開くこと、記録が現存する doc 無しルールに
//          「このきっかけは今は無い」を出さないこと。GET を fixture に差し替える
//
// 非破壊の仕組み:
//   - ブラウザからの POST /api/** は page.route で全て mock 応答にする
//     (savedoc / apply / rule/* / propose / dryrun — サーバへ届かない)。
//     GET (読み取り系) だけ実サーバへ通す。server の kill・再起動はしない。
//   - (i) の cwd 変更は「一時 dir を対象に GET するだけ」で、終了時に一時 dir を消す
//   - 再実行可能: ブラウザ context は毎回 fresh / スクショは同名上書き
//
// 出力: 失敗 assert を 1 件ずつ列挙して exit 1 (全 PASS で exit 0)。
//       スクショは manager/screenshots/e2e/ へ。
//
// 注記: B の (f)(h)(i)(j) と A の (c)(e) は「あるべき姿」を仕様として encode している。
// 実装が仕様に追いついていないサーバに対しては該当 assert が fail する —
// それは仕様との差分の検出であり、この監査の正常動作。
// =============================================================================

import { execFileSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const MANAGER_DIR = path.resolve(__dirname, '..');
const REPO = path.resolve(MANAGER_DIR, '..');
const SHOT_DIR = path.join(MANAGER_DIR, 'screenshots', 'e2e');

const BASE = (process.env.TOOLHINT_URL || 'http://127.0.0.1:4517')
  .replace(/\/+$/, '');
const TOKEN = process.env.TOOLHINT_TOKEN || '';

const WIDTHS = [1280, 1366, 1440, 1568, 1920];
const HEIGHTS = [800, 1080];
const EPS = 0.5; // subpixel 誤差 (boundingBox の 0.5px 未満の接触は交差とみなさない)

// ---------------------------------------------------------------------------
// assert 収集
// ---------------------------------------------------------------------------

const results = []; // { id, ok, desc, detail }

function check(id, desc, ok, detail = '') {
  results.push({ id, desc, ok, detail: ok ? '' : String(detail) });
  console.log(`${ok ? '  ok ' : '  FAIL'} [${id}] ${desc}${ok ? '' : ` — ${detail}`}`);
  return ok;
}

function shot(name) { return path.join(SHOT_DIR, name); }

async function waitUntil(fn, { timeout = 10_000, interval = 100, label = 'condition' } = {}) {
  const deadline = Date.now() + timeout;
  while (Date.now() < deadline) {
    const v = await fn();
    if (v) return v;
    await new Promise((r) => setTimeout(r, interval));
  }
  throw new Error(`timeout (${timeout}ms): ${label}`);
}

// ---------------------------------------------------------------------------
// API (読み取り専用) — node 側から直接叩く
// ---------------------------------------------------------------------------

function authHeaders() {
  return TOKEN ? { 'X-Toolhint-Token': TOKEN } : {};
}

async function apiGet(p) {
  const res = await fetch(`${BASE}${p}`, { headers: authHeaders() });
  let body = null;
  try { body = await res.json(); } catch { /* 非 JSON */ }
  return { status: res.status, body };
}

// ---------------------------------------------------------------------------
// 書き込み API の全 mock (page.route) — サーバへ一切書かせない
// ---------------------------------------------------------------------------

const MOCK_PROPOSAL = {
  rule: {
    id: 'prefer-rg-e2e', tool: 'Bash', match: '\\bgrep\\b',
    doc: 'docs/prefer-rg.md', every: 'session',
  },
  doc_name: 'prefer-rg.md',
  doc_content: '# rg を使う\n\ngrep より rg (ripgrep) を優先する。\n(e2e mock — 実サーバには保存されない)\n',
  sample_input: '{"command": "grep -r foo ."}',
  rationale: 'grep 実行前に rg を勧める (layout-audit の mock 起案)',
  layer: 'project',
  engine: 'sdk',
};

// ことばきっかけ (kind: kw) の起案 mock — 操作きっかけと同じ形で event: prompt を返す
const MOCK_PROPOSAL_KW = {
  rule: {
    id: 'deploy-kw-e2e', event: 'prompt', keywords: 'デプロイ, deploy',
    doc: 'docs/deploy.md', inject: 'この話題の docs: {doc} — デプロイ手順 ({id})',
    every: 'session',
  },
  doc_name: 'deploy.md',
  doc_content: '# デプロイ\n\nデプロイの作り方は docs を読む。\n(e2e mock — 実サーバには保存されない)\n',
  sample_prompt: 'デプロイを作りたい',
  rationale: 'デプロイの話題で docs を渡す (layout-audit の mock 起案)',
  layer: 'project',
  kind: 'kw',
  engine: 'sdk',
};

// ---------------------------------------------------------------------------
// 共有層 (layers.d) の fixture — 読み取り系 GET を差し替えて決まった形を出す。
// 実サーバの層を触らずに「共有 doc + それを指す手元のきっかけ」を再現する
// (core は layer を「最初に参照したルールの層」で返すため、この混在が
//  「手元のきっかけの編集導線まで消える」回帰の温床になる)。
// ---------------------------------------------------------------------------

const FIX_GLOBAL = '/tmp/toolhint-e2e-fixture/global';
const FIX_TEAM = `${FIX_GLOBAL}/layers.d/team`;
const FIX_PROJ = '/tmp/toolhint-e2e-fixture/proj/.claude/toolhint';
const FIX_SHARED_DOC = `${FIX_TEAM}/docs/team-search.md`;
const FIX_OWN_DOC = `${FIX_GLOBAL}/docs/mine.md`;

const FIX_TRIGGERS = {
  // 共有層のきっかけ (この画面からは書き換えない)
  shared: {
    id: 'team-grep', tool: 'Bash', match: '\\bgrep\\b', every: 'session',
    mode: 'pointer', enabled: true, event: 'tool', keywords: null,
    find: null, case: null, layer: 'layers.d/team',
  },
  // 手元 (全体層) のきっかけが同じ共有 doc を指している — 導線は出るべき
  mine: {
    id: 'mine-extra', tool: 'Bash', match: '\\brg\\b', every: 'session',
    mode: 'pointer', enabled: true, event: 'tool', keywords: null,
    find: null, case: null, layer: 'global',
  },
  own: {
    id: 'my-rule', tool: 'Bash', match: '\\bls\\b', every: 'session',
    mode: 'pointer', enabled: true, event: 'tool', keywords: null,
    find: null, case: null, layer: 'global',
  },
};

function fixtureState(cwd) {
  const rule = (t, doc) => ({
    ...t, doc, inject: null, overridden: false,
    doc_abs: doc, doc_exists: true,
  });
  return {
    cwd, cwd_exists: true, core: 'real',
    engine: { connected: true, source: `${FIX_GLOBAL}/settings.json`, route: 'plugin' },
    layers: [
      { name: 'layers.d/team', dir: FIX_TEAM, exists: true },
      { name: 'global', dir: FIX_GLOBAL, exists: true },
      { name: 'project', dir: FIX_PROJ, exists: false },
    ],
    rules: [
      rule(FIX_TRIGGERS.shared, FIX_SHARED_DOC),
      rule(FIX_TRIGGERS.mine, FIX_SHARED_DOC),
      rule(FIX_TRIGGERS.own, FIX_OWN_DOC),
    ],
  };
}

function fixtureDocs(cwd) {
  return {
    cwd, core: 'real',
    docs: [
      {
        name: 'team-search.md', path_abs: FIX_SHARED_DOC, layer: 'layers.d/team',
        exists: true, body_excerpt: '# team search', inject_count_7d: 0,
        triggers: [FIX_TRIGGERS.shared, FIX_TRIGGERS.mine],
      },
      {
        name: 'mine.md', path_abs: FIX_OWN_DOC, layer: 'global',
        exists: true, body_excerpt: '# mine', inject_count_7d: 0,
        triggers: [FIX_TRIGGERS.own],
      },
    ],
  };
}

/** 読み取り系 GET を fixture に差し替える (POST は既存の write mock へ委ねる)。 */
async function installSharedLayerFixture(page) {
  await page.route('**/api/**', async (route) => {
    const req = route.request();
    if (req.method() !== 'GET') return route.fallback();
    const url = new URL(req.url());
    const p = url.pathname;
    const cwd = url.searchParams.get('cwd') || '/tmp/toolhint-e2e-fixture/proj';
    const json = (obj) => route.fulfill({
      status: 200, contentType: 'application/json', body: JSON.stringify(obj),
    });
    if (p === '/api/state') return json(fixtureState(cwd));
    if (p === '/api/docs') return json(fixtureDocs(cwd));
    if (p === '/api/log') return json({ cwd, core: 'real', entries: [] });
    if (p === '/api/doc') {
      const dp = url.searchParams.get('path') || '';
      const body = dp === FIX_SHARED_DOC
        ? '# team search\n共有ルールの本文\n' : '# mine\n自分のルールの本文\n';
      return json({ path: dp, content: body });
    }
    return route.fallback();
  });
}

// ---------------------------------------------------------------------------
// 読めない層 + 実体の無い doc の fixture — GET を差し替えて次の状態を作る:
//   ・追加層 layers.d/broken の rules.yaml が engine のパーサで読めない
//     (/api/state の layer_errors と layers[].parse_error に載る)。その層の docs/ に
//     ある doc は、参照するルールが読めないので triggers: [] で一覧に出る
//   ・全体層のきっかけが指す doc の実体が無い (exists: false)
// ---------------------------------------------------------------------------

const FIX_BROKEN = `${FIX_GLOBAL}/layers.d/broken`;
const FIX_BROKEN_RULES = `${FIX_BROKEN}/rules.yaml`;
const FIX_BROKEN_ERROR = "line 8: 構文外の値: '[unquoted-bracket]'";
const FIX_BROKEN_DOC = `${FIX_BROKEN}/docs/orphan-in-broken.md`;
const FIX_MISSING_DOC = `${FIX_GLOBAL}/docs/gone.md`;

function fixtureStateBroken(cwd) {
  const st = fixtureState(cwd);
  const own = { ...FIX_TRIGGERS.own, id: 'points-to-gone', match: '\\bcat\\b' };
  return {
    ...st,
    layers: [
      { name: 'layers.d/broken', dir: FIX_BROKEN, exists: true, parse_error: FIX_BROKEN_ERROR },
      ...st.layers.map((l) => ({ ...l, parse_error: null })),
    ],
    rules: [
      ...st.rules,
      { ...own, doc: 'docs/gone.md', inject: null, overridden: false, doc_abs: FIX_MISSING_DOC, doc_exists: false },
    ],
    layer_errors: [
      { layer: 'layers.d/broken', file: FIX_BROKEN_RULES, error: FIX_BROKEN_ERROR },
    ],
  };
}

function fixtureDocsBroken(cwd) {
  const d = fixtureDocs(cwd);
  const own = { ...FIX_TRIGGERS.own, id: 'points-to-gone', match: '\\bcat\\b' };
  return {
    ...d,
    docs: [
      ...d.docs,
      {
        name: 'orphan-in-broken.md', path_abs: FIX_BROKEN_DOC, layer: 'layers.d/broken',
        exists: true, body_excerpt: '# orphan in broken layer', inject_count_7d: 0,
        triggers: [],
      },
      {
        name: 'gone.md', path_abs: FIX_MISSING_DOC, layer: 'global',
        exists: false, body_excerpt: null, inject_count_7d: 0,
        triggers: [own],
      },
    ],
  };
}

async function installBrokenLayerFixture(page) {
  await page.route('**/api/**', async (route) => {
    const req = route.request();
    if (req.method() !== 'GET') return route.fallback();
    const url = new URL(req.url());
    const p = url.pathname;
    const cwd = url.searchParams.get('cwd') || '/tmp/toolhint-e2e-fixture/proj';
    const json = (obj) => route.fulfill({
      status: 200, contentType: 'application/json', body: JSON.stringify(obj),
    });
    if (p === '/api/state') return json(fixtureStateBroken(cwd));
    if (p === '/api/docs') return json(fixtureDocsBroken(cwd));
    if (p === '/api/log') return json({ cwd, core: 'real', entries: [] });
    if (p === '/api/doc') {
      const dp = url.searchParams.get('path') || '';
      return json({ path: dp, content: `# ${dp.split('/').pop()}\n本文\n` });
    }
    return route.fallback();
  });
}

// ---------------------------------------------------------------------------
// doc を持たないルール (inject の文面だけを届ける) の fixture — GET を差し替えて
// 次の状態を作る:
//   ・全体層に doc 無しのことばきっかけ ship-warn (文面あり) と、doc も文面も無い
//     操作きっかけ no-payload — /api/docs には inject_only: true のエントリで載る
//   ・記録に ship-warn (現存) と kiery (どのルールにも無い) の 2 行
// ---------------------------------------------------------------------------

const FIX_IO_TRIGGERS = {
  shipWarn: {
    id: 'ship-warn', tool: null, match: null, every: 'session',
    mode: 'pointer', enabled: true, event: 'prompt', keywords: 'リリース, release',
    find: null, case: null, layer: 'global',
  },
  noPayload: {
    id: 'no-payload', tool: 'Bash', match: '\\bcat\\b', every: 'session',
    mode: 'pointer', enabled: true, event: 'tool', keywords: null,
    find: null, case: null, layer: 'global',
  },
};
const FIX_IO_INJECT = 'リリース手順は先に確認 ({id})';

function fixtureStateInjectOnly(cwd) {
  const st = fixtureState(cwd);
  return {
    ...st,
    rules: [
      ...st.rules,
      { ...FIX_IO_TRIGGERS.shipWarn, doc: null, inject: FIX_IO_INJECT, overridden: false, doc_abs: null, doc_exists: false },
      { ...FIX_IO_TRIGGERS.noPayload, doc: null, inject: null, overridden: false, doc_abs: null, doc_exists: false },
    ],
  };
}

function fixtureDocsInjectOnly(cwd) {
  const d = fixtureDocs(cwd);
  return {
    ...d,
    docs: [
      ...d.docs.map((x) => ({ ...x, inject_only: false })),
      {
        name: null, path_abs: null, layer: 'global', exists: false, inject_only: true,
        body_excerpt: FIX_IO_INJECT, inject_count_7d: 1,
        triggers: [FIX_IO_TRIGGERS.shipWarn],
      },
      {
        name: null, path_abs: null, layer: 'global', exists: false, inject_only: true,
        body_excerpt: null, inject_count_7d: 0,
        triggers: [FIX_IO_TRIGGERS.noPayload],
      },
    ],
  };
}

function fixtureLogInjectOnly(cwd) {
  const ts = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z');
  const row = (rule_id, tool_name, input) => ({
    ts, session_id: 's-e2e', cwd, tool_name, rule_id, layer: 'global', doc: null,
    mode: 'pointer', every: 'session', input_excerpt: input, tool_use_id: null,
  });
  return {
    cwd, core: 'real',
    entries: [row('ship-warn', 'prompt', 'そろそろリリースしたい'), row('kiery', 'Bash', 'kiery cmd')],
  };
}

async function installInjectOnlyFixture(page) {
  await page.route('**/api/**', async (route) => {
    const req = route.request();
    if (req.method() !== 'GET') return route.fallback();
    const url = new URL(req.url());
    const p = url.pathname;
    const cwd = url.searchParams.get('cwd') || '/tmp/toolhint-e2e-fixture/proj';
    const json = (obj) => route.fulfill({
      status: 200, contentType: 'application/json', body: JSON.stringify(obj),
    });
    if (p === '/api/state') return json(fixtureStateInjectOnly(cwd));
    if (p === '/api/docs') return json(fixtureDocsInjectOnly(cwd));
    if (p === '/api/log') return json(fixtureLogInjectOnly(cwd));
    if (p === '/api/doc') {
      const dp = url.searchParams.get('path') || '';
      return json({ path: dp, content: `# ${dp.split('/').pop()}\n本文\n` });
    }
    return route.fallback();
  });
}

/** POST /api/** を全て捕捉して mock 応答。captured に {path, body} を積む。 */
async function installWriteMocks(page, captured) {
  await page.route('**/api/**', async (route) => {
    const req = route.request();
    if (req.method() !== 'POST') return route.continue();
    const p = new URL(req.url()).pathname;
    let body = {};
    try { body = JSON.parse(req.postData() || '{}'); } catch { /* 非 JSON body */ }
    captured.push({ path: p, body });
    if (p === '/api/propose') {
      // 起案の種別は payload の kind で分岐 (server と同じ既定 = 操作きっかけ)
      const proposal = body.kind === 'kw' ? MOCK_PROPOSAL_KW : MOCK_PROPOSAL;
      return route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(proposal) });
    }
    if (p === '/api/dryrun') {
      return route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({ ok: true, matches: [], core: 'real' }) });
    }
    // 書き込み系 (savedoc / apply / rule/*) — 成功 mock。実サーバへは届かない
    return route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({ ok: true, core: 'real' }) });
  });
}

// ---------------------------------------------------------------------------
// ページ側の計測 (viewport ごとに 1 回 evaluate)
// ---------------------------------------------------------------------------

async function measureTopbar() {
  const vis = (el) => {
    const cs = getComputedStyle(el);
    return cs.display !== 'none' && cs.visibility !== 'hidden';
  };
  const nameOf = (el) => el.id ? `#${el.id}`
    : (el.className && typeof el.className === 'string'
      ? `.${el.className.trim().split(/\s+/).join('.')}` : el.tagName.toLowerCase());
  if (document.activeElement && document.activeElement.blur) document.activeElement.blur();
  // blur 後の末尾スクロール回復は rAF 遅延 (app.js) — 2 フレーム待ってから計測
  await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));

  const kids = [...document.querySelectorAll('.topbar > *')].filter(vis);
  const rects = kids.map((el) => {
    const r = el.getBoundingClientRect();
    return { name: nameOf(el), x: r.x, y: r.y, w: r.width, h: r.height };
  });

  const cwd = document.getElementById('cwd-input');
  const cwdM = {
    value: cwd.value,
    scrollWidth: cwd.scrollWidth,
    clientWidth: cwd.clientWidth,
    scrollLeft: cwd.scrollLeft,
    direction: getComputedStyle(cwd).direction,
  };

  // (d) placeholder を value として注入 → cancel ボタン込みで幅を測る → 復元
  const s = document.getElementById('search-input');
  const prevValue = s.value;
  s.value = s.placeholder || '';
  s.dispatchEvent(new Event('input', { bubbles: true }));
  const searchM = {
    placeholder: s.placeholder || '',
    scrollWidth: s.scrollWidth,
    clientWidth: s.clientWidth,
  };
  s.value = prevValue;
  s.dispatchEvent(new Event('input', { bubbles: true }));

  const spacer = document.querySelector('.topbar-spacer');
  return {
    rects,
    cwd: cwdM,
    search: searchM,
    spacerWidth: spacer ? spacer.getBoundingClientRect().width : 0,
    docScrollWidth: Math.max(
      document.documentElement.scrollWidth, document.body.scrollWidth),
    innerWidth: window.innerWidth,
  };
}

function overlapPairs(rects, eps) {
  const bad = [];
  for (let i = 0; i < rects.length; i++) {
    for (let j = i + 1; j < rects.length; j++) {
      const a = rects[i];
      const b = rects[j];
      const ix = Math.min(a.x + a.w, b.x + b.w) - Math.max(a.x, b.x);
      const iy = Math.min(a.y + a.h, b.y + b.h) - Math.max(a.y, b.y);
      if (ix > eps && iy > eps) {
        bad.push(`${a.name} × ${b.name} (交差 ${ix.toFixed(1)}×${iy.toFixed(1)}px)`);
      }
    }
  }
  return bad;
}

// ---------------------------------------------------------------------------
// main
// ---------------------------------------------------------------------------

async function launchBrowser() {
  const { chromium } = await import('playwright');
  try {
    return await chromium.launch();
  } catch (e) {
    console.error(`[e2e] bundled chromium 起動失敗 → 実機 Chrome へフォールバック: ${e.message.split('\n')[0]}`);
    return chromium.launch({ channel: 'chrome' });
  }
}

async function waitAppLoaded(page, { timeout = 20_000 } = {}) {
  await page.waitForFunction(() => {
    const cwd = document.getElementById('cwd-input');
    const count = document.getElementById('doc-count');
    return cwd && cwd.value !== '' && count && count.textContent !== '–';
  }, undefined, { timeout });
}

async function main() {
  // スクショ dir は毎回作り直す — 前回 run の残骸が今回の結果に混ざらない (再実行可能性)
  fs.rmSync(SHOT_DIR, { recursive: true, force: true });
  fs.mkdirSync(SHOT_DIR, { recursive: true });

  // 前提: サーバ到達性 + git root
  const gitRoot = execFileSync('git', ['-C', REPO, 'rev-parse', '--show-toplevel'],
    { encoding: 'utf-8' }).trim();
  const probe = await apiGet('/api/state').catch((e) => ({ status: -1, body: { error: e.message } }));
  if (probe.status !== 200) {
    console.error(`[e2e] サーバに到達できない: ${BASE}/api/state → ${probe.status} ${JSON.stringify(probe.body)}`);
    console.error('[e2e] TOOLHINT_URL / TOOLHINT_TOKEN を env で指定する (ファイル冒頭の実行方法を参照)');
    process.exit(2);
  }
  const stateNoCwd = probe.body;
  console.log(`[e2e] server: ${BASE} (core=${stateNoCwd.core}) / git root: ${gitRoot}`);

  const browser = await launchBrowser();
  const context = await browser.newContext({ viewport: { width: WIDTHS[0], height: HEIGHTS[0] } });
  const page = await context.newPage();
  const pageErrors = [];
  page.on('pageerror', (e) => pageErrors.push(String(e && e.message || e)));
  const captured = [];
  await installWriteMocks(page, captured);

  const openUrl = TOKEN ? `${BASE}/?token=${encodeURIComponent(TOKEN)}` : `${BASE}/`;
  await page.goto(openUrl, { waitUntil: 'load' });
  await waitAppLoaded(page);

  // -------------------------------------------------------------------------
  // B-f / B-g — cwd の既定と初期表示 (A の前に初期状態のまま検証する)
  // -------------------------------------------------------------------------
  check('B-f', 'cwd 無し /api/state の cwd が git root (…/manager で終わらない)',
    stateNoCwd.cwd === gitRoot && !/\/manager\/?$/.test(String(stateNoCwd.cwd)),
    `api cwd=${JSON.stringify(stateNoCwd.cwd)} / git root=${JSON.stringify(gitRoot)}`);

  const initialCwd = await page.locator('#cwd-input').inputValue();
  check('B-g', '初期 #cwd-input 値 = cwd 無し /api/state の cwd',
    initialCwd === stateNoCwd.cwd,
    `input=${JSON.stringify(initialCwd)} / api=${JSON.stringify(stateNoCwd.cwd)}`);
  if (!results.at(-1).ok || !results.at(-2).ok) {
    await page.screenshot({ path: shot('b-fg-initial-cwd.png') });
  }

  // -------------------------------------------------------------------------
  // A — レイアウト行列
  // -------------------------------------------------------------------------
  for (const width of WIDTHS) {
    for (const height of HEIGHTS) {
      const vp = `${width}x${height}`;
      await page.setViewportSize({ width, height });
      await page.waitForTimeout(120); // reflow 待ち
      const m = await page.evaluate(measureTopbar);

      const failsBefore = results.filter((r) => !r.ok).length;

      const overlaps = overlapPairs(m.rects, EPS);
      check(`A-a@${vp}`, 'topbar 直下の可視要素ペア全組: boundingBox 交差ゼロ',
        overlaps.length === 0, overlaps.join(' / '));

      const zero = m.rects.filter((r) => r.w < EPS).map((r) => r.name);
      check(`A-b@${vp}`, 'topbar 直下の可視要素に width 0 なし + 横 overflow なし (scrollWidth ≤ innerWidth)',
        zero.length === 0 && m.docScrollWidth <= m.innerWidth,
        `width0=[${zero.join(',')}] docScrollWidth=${m.docScrollWidth} innerWidth=${m.innerWidth}`);

      const cwdTailVisible = m.cwd.scrollWidth <= m.cwd.clientWidth
        || m.cwd.scrollLeft >= m.cwd.scrollWidth - m.cwd.clientWidth - 1;
      check(`A-c@${vp}`, '#cwd-input: 末尾可視 (収まる or scrollLeft 右端) かつ direction=ltr (rtl は先頭 "/" 誤読で禁止)',
        cwdTailVisible && m.cwd.direction !== 'rtl',
        `scrollWidth=${m.cwd.scrollWidth} clientWidth=${m.cwd.clientWidth} scrollLeft=${m.cwd.scrollLeft} direction=${m.cwd.direction} value=${JSON.stringify(m.cwd.value)}`);

      check(`A-d@${vp}`, '#search-input: placeholder を value 注入して scrollWidth ≤ clientWidth (cancel ボタン予約込み)',
        m.search.scrollWidth <= m.search.clientWidth,
        `scrollWidth=${m.search.scrollWidth} clientWidth=${m.search.clientWidth} placeholder=${JSON.stringify(m.search.placeholder)}`);

      const anyClipped = (m.cwd.scrollWidth > m.cwd.clientWidth)
        || (m.search.scrollWidth > m.search.clientWidth);
      check(`A-e@${vp}`, '空き余白があるのに切れていない (spacer > 100px なら input の clip 禁止)',
        !(m.spacerWidth > 100 && anyClipped),
        `spacerWidth=${m.spacerWidth.toFixed(1)} cwdClip=${m.cwd.scrollWidth > m.cwd.clientWidth} searchClip=${m.search.scrollWidth > m.search.clientWidth}`);

      if (results.filter((r) => !r.ok).length > failsBefore) {
        // 失敗した viewport は証拠スクショ (placeholder 注入状態も再現して撮る)
        await page.evaluate(() => {
          const s = document.getElementById('search-input');
          s.value = s.placeholder || '';
          s.dispatchEvent(new Event('input', { bubbles: true }));
        });
        await page.screenshot({ path: shot(`layout-${vp}.png`) });
        await page.evaluate(() => {
          const s = document.getElementById('search-input');
          s.value = '';
          s.dispatchEvent(new Event('input', { bubbles: true }));
        });
      }
    }
  }
  await page.setViewportSize({ width: 1440, height: 900 });

  // -------------------------------------------------------------------------
  // B-h — propose (mock) → #proposal-name の rename が apply payload に届く
  // -------------------------------------------------------------------------
  try {
    await page.click('#new-doc-btn');
    await page.fill('#ask-input', '(e2e) grep を打とうとしたら rg を勧めて');
    await page.click('#ask-btn');
    await page.waitForSelector('#proposal:not([hidden])', { timeout: 10_000 });

    const nameInput = page.locator('input#proposal-name');
    const exists = await nameInput.count() > 0;
    const prefill = exists ? await nameInput.inputValue() : null;
    check('B-h1', '#proposal-name input が存在し起案の doc_name が入っている',
      exists && prefill === MOCK_PROPOSAL.doc_name,
      exists ? `value=${JSON.stringify(prefill)} (期待 ${MOCK_PROPOSAL.doc_name})`
        : '#proposal-name (input) が存在しない — 起案 doc 名の編集 UI 未実装 (期待仕様)');

    if (exists) {
      const RENAMED = 'renamed-by-e2e.md';
      await nameInput.fill(RENAMED);
      await page.click('#apply-btn');
      const applyCall = await waitUntil(
        () => captured.find((c) => c.path === '/api/apply'),
        { label: '/api/apply の mock 捕捉' });
      const got = { doc_name: applyCall.body.doc_name, ruleDoc: applyCall.body.rule && applyCall.body.rule.doc };
      check('B-h2', '#proposal-name の変更が /api/apply payload の doc_name と rule.doc 両方に反映',
        got.doc_name === RENAMED && got.ruleDoc === `docs/${RENAMED}`,
        `payload doc_name=${JSON.stringify(got.doc_name)} rule.doc=${JSON.stringify(got.ruleDoc)} (期待 ${RENAMED} / docs/${RENAMED})`);
    } else {
      check('B-h2', '#proposal-name の変更が /api/apply payload の doc_name と rule.doc 両方に反映',
        false, 'B-h1 不成立 (input なし) のため検証不能 (期待仕様)');
    }
  } catch (e) {
    check('B-h1', '#proposal-name input が存在し起案の doc_name が入っている', false, `フロー失敗: ${e.message}`);
    check('B-h2', '#proposal-name の変更が /api/apply payload の doc_name と rule.doc 両方に反映', false, `フロー失敗: ${e.message}`);
  }
  await page.screenshot({ path: shot('b-h-proposal.png') });
  // モーダルが開いたままなら閉じる (apply 成功 mock なら自動で閉じている)
  await page.evaluate(() => {
    const m = document.getElementById('modal');
    if (m && !m.hidden) m.hidden = true;
  });

  // -------------------------------------------------------------------------
  // B-k — ask ペインのきっかけ種別セグメント (操作 / ことば) と kw 起案の確認
  // -------------------------------------------------------------------------
  try {
    await page.click('#new-doc-btn');
    const pressed = () => page.evaluate(() => ({
      op: document.getElementById('ask-kind-op').getAttribute('aria-pressed'),
      kw: document.getElementById('ask-kind-kw').getAttribute('aria-pressed'),
      legacy: !!document.getElementById('ask-kw-manual-btn'),
    }));
    const before = await pressed();
    check('B-k1', 'ask ペインに種別セグメントがあり既定は「操作に反応」(未対応の逃げ行は無い)',
      before.op === 'true' && before.kw === 'false' && !before.legacy,
      `op=${before.op} kw=${before.kw} 旧「手動で作る」導線=${before.legacy}`);

    await page.click('#ask-kind-kw');
    const after = await pressed();
    check('B-k2', '「ことばに反応」を押すと種別が切り替わる (aria-pressed)',
      after.op === 'false' && after.kw === 'true', `op=${after.op} kw=${after.kw}`);

    await page.fill('#ask-input', '(e2e) デプロイの話が出たらデプロイの作り方 docs を渡して');
    await page.click('#ask-btn');
    await page.waitForSelector('#proposal:not([hidden])', { timeout: 10_000 });
    const proposeCall = [...captured].reverse().find((c) => c.path === '/api/propose');
    check('B-k3', '/api/propose の payload に kind: "kw" が乗る',
      !!proposeCall && proposeCall.body.kind === 'kw',
      `payload kind=${JSON.stringify(proposeCall && proposeCall.body.kind)}`);

    const pv = await page.evaluate(() => ({
      kwChip: document.querySelectorAll('#proposal-cond .tool-chip.kind-kw').length,
      pattern: (document.querySelector('#proposal-cond .condition-pattern') || {}).textContent || '',
      meta: (document.querySelector('#proposal-cond .condition-meta') || {}).textContent || '',
      delHidden: document.getElementById('proposal-delivery').hidden,
      delText: document.getElementById('proposal-delivery-text').textContent || '',
    }));
    check('B-k4', 'kw 起案のプレビューが ことばチップ + keywords + 一致条件の注記を出す',
      pv.kwChip === 1 && pv.pattern.includes('デプロイ') && pv.meta.includes('初回'),
      `chip=${pv.kwChip} pattern=${JSON.stringify(pv.pattern)} meta=${JSON.stringify(pv.meta)}`);
    // {doc} が空文字に潰れても通らないよう、実パス片 (/docs/<name>.md) の混入まで見る
    check('B-k5', 'kw 起案の「実際に届く文面」が起案の inject を展開して出る ({doc} が実パスになる)',
      !pv.delHidden && pv.delText.startsWith('[toolhint] ')
      && pv.delText.includes('デプロイ手順 (deploy-kw-e2e)')
      && pv.delText.includes(`/${MOCK_PROPOSAL_KW.rule.doc}`)
      && !pv.delText.includes('{doc}') && !pv.delText.includes('{id}'),
      `hidden=${pv.delHidden} text=${JSON.stringify(pv.delText)}`);
    await page.screenshot({ path: shot('b-k-proposal-kw.png') });
    await page.click('#discard-btn'); // 保存はしない (mock でも apply を撃たない)

    // 既存 doc への追加 (attach_to) × inline は起案に本文が無い —
    // 空の本文を「届く文面」として描かず、その場所を注記で埋める
    const attachText = await page.evaluate(() => {
      proposal = {
        rule: { id: 'attach-kw-e2e', event: 'prompt', keywords: 'デプロイ', doc: 'docs/deploy.md', mode: 'inline' },
        doc_name: 'deploy.md', doc_content: '', attach_to: 'docs/deploy.md', layer: 'project',
      };
      document.getElementById('proposal-name').value = 'deploy.md';
      renderProposalDelivery();
      const t = document.getElementById('proposal-delivery-text').textContent;
      proposal = null; // 後続の流れに持ち越さない
      renderProposalDelivery();
      return t;
    });
    check('B-k6', 'attach_to × inline の起案は本文の場所を注記で埋める (空文面を出さない)',
      attachText.includes('既存 doc の本文がここに入る'), `text=${JSON.stringify(attachText)}`);
  } catch (e) {
    for (const id of ['B-k1', 'B-k2', 'B-k3', 'B-k4', 'B-k5', 'B-k6']) {
      check(id, 'ask ペインの種別セグメント / kw 起案プレビュー', false, `フロー失敗: ${e.message}`);
    }
    await page.screenshot({ path: shot('b-k-proposal-kw.png') });
  }

  // -------------------------------------------------------------------------
  // B-l — 届く文面 (inject) の編集面: 手動作成 / きっかけ追加 / きっかけ編集
  // -------------------------------------------------------------------------
  try {
    // 手動タブ — 種別を切り替えても欄は消えず、空のときの標準文面だけ入れ替わる
    await page.click('#tab-manual');
    const tpl = await page.evaluate(() => ({ op: POINTER_TEMPLATE, kw: POINTER_TEMPLATE_PROMPT }));
    const manualPh = async () => page.locator('#manual-inject').getAttribute('placeholder');
    await page.click('#manual-kind-op');
    const mOp = await manualPh();
    await page.click('#manual-kind-kw');
    const mKw = await manualPh();
    check('B-l1', '手動作成フォームに「届く文面」欄があり placeholder が種別ごとの標準文面',
      mOp === tpl.op && mKw === tpl.kw,
      `操作=${JSON.stringify(mOp)} ことば=${JSON.stringify(mKw)}`);
    await page.screenshot({ path: shot('b-l-manual-inject.png') });
    await page.click('#modal-close-btn');
  } catch (e) {
    check('B-l1', '手動作成フォームに「届く文面」欄があり placeholder が種別ごとの標準文面',
      false, `フロー失敗: ${e.message}`);
    await page.evaluate(() => {
      const m = document.getElementById('modal');
      if (m && !m.hidden) m.hidden = true;
    });
  }

  try {
    // きっかけ追加フォーム — 開く導線は件数で出し分かれるので関数を直接呼ぶ
    const tpl = await page.evaluate(() => ({ op: POINTER_TEMPLATE, kw: POINTER_TEMPLATE_PROMPT }));
    const condPh = async (kind) => page.evaluate((k) => {
      openCondForm(k);
      return document.getElementById('cond-inject').placeholder;
    }, kind);
    const cOp = await condPh('op');
    const cKw = await condPh('kw');
    check('B-l2', 'きっかけ追加フォームに「届く文面」欄があり placeholder が種別ごとの標準文面',
      cOp === tpl.op && cKw === tpl.kw,
      `操作=${JSON.stringify(cOp)} ことば=${JSON.stringify(cKw)}`);
    await page.evaluate(() => setCondFormOpen(false));

    // きっかけ編集フォーム — 両種別の HTML を関数から直接得る (実データに依存しない)
    const edit = await page.evaluate((t) => {
      const op = ruleEditFormHtml({ id: 'e2e-op', layer: 'global', tool: 'Bash', match: '\\bgrep\\b' });
      const kw = ruleEditFormHtml({ id: 'e2e-kw', layer: 'global', event: 'prompt', keywords: 'デプロイ' });
      const has = (html, ph) => html.includes('name="inject"') && html.includes(ph);
      return { op: has(op, t.op), kw: has(kw, t.kw) };
    }, tpl);
    check('B-l3', 'きっかけ編集フォーム (操作 / ことば 両方) に「届く文面」欄がある',
      edit.op && edit.kw, `操作=${edit.op} ことば=${edit.kw}`);

    // 実データがあるときは DOM でも確認する (編集ボタン → フォーム内に欄がある)。
    // 対象は doc を持つルールのカード — doc を持たないルール (inject_only) の
    // 文面は空にできない (B-l6 の「空 = 標準文面へ戻す」が成り立たない) ので、
    // 自動選択がそちらに落ちていても doc 付きのカードを明示的に選び直す
    const docKey = await page.evaluate(() => {
      const d = state.docs.find((x) => !x.inject_only && x.exists !== false
        && x.triggers.some((t) => t.enabled !== false && !isSharedLayer(t.layer)));
      return d ? keyOf(d) : null;
    });
    if (docKey) {
      await page.click(`#doc-list a[data-key="${docKey}"]`);
      await page.waitForFunction(
        (k) => document.querySelector(`#doc-list a[data-key="${k}"][aria-current="true"]`)
          && document.querySelector('#cond-list .rule-act[data-act=edit]'),
        docKey, { timeout: 10_000 });
    }
    const editBtn = page.locator('#cond-list .rule-act[data-act=edit]').first();
    if (await editBtn.count()) {
      await editBtn.click();
      await page.waitForSelector('#cond-list form.rule-edit-form', { timeout: 5_000 });
      const domOk = await page.evaluate(() =>
        !!document.querySelector('#cond-list form.rule-edit-form [name=inject]'));
      check('B-l4', '編集ボタンで開くフォームの DOM に「届く文面」欄が実在する',
        domOk, `[name=inject] 有無=${domOk}`);
      await page.screenshot({ path: shot('b-l-edit-inject.png') });

      // 欄に書いて保存 → patch.inject に載る / 空にして保存 → patch.inject: null
      // (POST は mock なので実サーバのルールは変わらない)
      const TEXT = 'この操作の docs: {doc} — 先に読む ({id})';
      const submitEdit = async () => {
        const before = captured.filter((c) => c.path === '/api/rule/update').length;
        await page.click('#cond-list form.rule-edit-form button[type=submit]');
        const call = await waitUntil(() => {
          const all = captured.filter((c) => c.path === '/api/rule/update');
          return all.length > before ? all[all.length - 1] : null;
        }, { label: '/api/rule/update の mock 捕捉' });
        // captured は「送信時点」で積まれる — 応答後の再読み込み (loadAll) が
        // 終わるまで待たないと、後続の cwd 切り替えと読み込み順が競る。
        // 編集フォームが消える = 再読み込み後の再描画まで済んだ合図
        await page.waitForFunction(
          () => !document.querySelector('#cond-list form.rule-edit-form'),
          undefined, { timeout: 15_000 });
        return call.body.patch;
      };
      await page.fill('#cond-list form.rule-edit-form [name=inject]', TEXT);
      const patchSet = await submitEdit();
      check('B-l5', '「届く文面」に書いて保存すると patch.inject に載る',
        patchSet && patchSet.inject === TEXT, `patch=${JSON.stringify(patchSet)}`);

      await page.locator('#cond-list .rule-act[data-act=edit]').first().click();
      await page.waitForSelector('#cond-list form.rule-edit-form [name=inject]', { timeout: 5_000 });
      await page.fill('#cond-list form.rule-edit-form [name=inject]', '');
      const patchCleared = await submitEdit();
      check('B-l6', '「届く文面」を空にして保存すると patch.inject: null (標準文面へ戻す)',
        patchCleared && patchCleared.inject === null, `patch=${JSON.stringify(patchCleared)}`);
    } else {
      console.log('  skip [B-l4..6] きっかけを持つ doc が対象 cwd に無いため DOM 確認を省略');
    }
  } catch (e) {
    check('B-l2', 'きっかけ追加 / 編集フォームの「届く文面」欄', false, `フロー失敗: ${e.message}`);
  }

  // -------------------------------------------------------------------------
  // B-m — 「実際に届く文面」の帯そのもので inject を編集できる (発見可能性の回帰)。
  //       以前は編集機能が鉛筆フォームの中にしか無く、帯を見ている人には
  //       「文面を変えられない」ように見えた。B-m1 がその回帰。
  // -------------------------------------------------------------------------

  // B-m0 — deliveryText の期待リテラル固定 (純関数直呼び / 実データ非依存)
  try {
    const DOC = '/tmp/e2e-toolhint/docs/x.md';
    const cases = await page.evaluate((doc) => {
      const base = { id: 'r1', docAbs: doc, docExists: true, kind: 'op', mode: 'pointer', inject: null };
      const call = (over, body) => deliveryText({ ...base, ...over }, body);
      return {
        pointerOp: call({}),
        pointerKw: call({ kind: 'kw' }),
        pointerInject: call({ inject: 'A {doc} B {id}' }),
        inlineOp: call({ mode: 'inline' }, '本文\n\n'),
        inlineKw: call({ mode: 'inline', kind: 'kw' }, '本文\n\n'),
        inlineInject: call({ mode: 'inline', inject: 'まず読む: {id}' }, '本文\n'),
        noDoc: call({ docExists: false }),
      };
    }, DOC);
    const want = {
      pointerOp: `[toolhint] この操作の docs: ${DOC} — 必要なら読む`,
      pointerKw: `[toolhint] この話題の docs: ${DOC} — 必要なら読む`,
      pointerInject: `[toolhint] A ${DOC} B r1`,
      inlineOp: '[toolhint] この操作の docs (r1):\n本文',
      inlineKw: '[toolhint] 本文',
      inlineInject: '[toolhint] まず読む: r1\nこの操作の docs (r1):\n本文',
      noDoc: null,
    };
    const bad = Object.keys(want).filter((k) => cases[k] !== want[k]);
    check('B-m0', 'deliveryText が engine の build_text と同じ文面を返す (期待リテラル固定)',
      bad.length === 0,
      bad.map((k) => `${k}: got=${JSON.stringify(cases[k])} want=${JSON.stringify(want[k])}`).join(' / '));
  } catch (e) {
    check('B-m0', 'deliveryText が engine の build_text と同じ文面を返す (期待リテラル固定)',
      false, `フロー失敗: ${e.message}`);
  }

  // B-m6 — deliveryTargets の保存先の決め方 (同一文面のきっかけだけを巻き込む)
  try {
    const g = await page.evaluate(() => {
      const base = { docAbs: '/tmp/e2e/x.md', docExists: true, kind: 'op', mode: 'pointer', inject: null };
      const v = (id, over) => ({ ...base, id, layer: 'global', ...over });
      const same = deliveryTargets([v('a'), v('b')], '');
      const diff = deliveryTargets([v('a'), v('b', { inject: 'ちがう文面 {doc}' })], '');
      // inject: null と「標準文面リテラル」は展開結果が同じ = 同じ 1 通に畳まれる
      const styled = deliveryTargets(
        [v('a'), v('b', { inject: 'この操作の docs: {doc} — 必要なら読む' })], '');
      const ids = (r) => r.targets.map((x) => x.id);
      return {
        same: { texts: same.texts.length, ids: ids(same) },
        diff: { texts: diff.texts.length, ids: ids(diff) },
        styled: {
          texts: styled.texts.length,
          ids: ids(styled),
          styles: new Set(styled.targets.map((x) => x.inject || '')).size,
        },
      };
    });
    check('B-m6', 'deliveryTargets: 同一文面のきっかけだけを保存先にし、書き方の違いを数えられる',
      g.same.texts === 1 && g.same.ids.join(',') === 'a,b'
      && g.diff.texts === 2 && g.diff.ids.join(',') === 'a'
      && g.styled.texts === 1 && g.styled.ids.join(',') === 'a,b' && g.styled.styles === 2,
      JSON.stringify(g));
  } catch (e) {
    check('B-m6', 'deliveryTargets: 同一文面のきっかけだけを保存先にし、書き方の違いを数えられる',
      false, `フロー失敗: ${e.message}`);
  }

  // B-m1..m5 / m7..m9 — 実データ (きっかけを持ち文面が出る doc) が要る DOM フロー
  const pick = await page.evaluate(() => {
    const cands = [];
    for (const d of state.docs) {
      if (d.exists === false) continue;
      const views = d.triggers.filter((t) => t.enabled !== false)
        .map((t) => viewTrigger(t, { docAbs: d.path_abs, docExists: true }));
      const { head } = deliveryTargets(views, '');
      if (head) {
        cands.push({
          key: keyOf(d), name: d.name, abs: d.path_abs,
          // kind は placeholder の期待値を決める (標準文面は操作 / ことばで違う)
          mode: head.mode, kind: head.kind, id: head.id, layer: head.layer,
        });
      }
    }
    return cands.find((c) => c.mode === 'pointer') || cands[0] || null;
  });

  if (!pick) {
    console.log('  skip [B-m1..m5,m7..m9] 文面が出る doc が対象 cwd に無いため DOM フローを省略');
  } else {
    try {
      await page.evaluate((k) => selectDoc(k), pick.key);
      await page.waitForFunction(() => {
        const b = document.getElementById('delivery-edit-btn');
        const t = document.getElementById('delivery-text');
        return b && !b.hidden && t && t.textContent !== '読み込み中…';
      }, undefined, { timeout: 15_000 });

      const btn = page.locator('#delivery-edit-btn');
      check('B-m1', '「実際に届く文面」の帯に編集の導線が可視 (編集の入口が見つからない問題の回帰)',
        await btn.isVisible() && (await btn.textContent()).trim() === '文面を変える',
        `text=${JSON.stringify(await btn.textContent())}`);

      // B-m2 — 開くと生テンプレートが入る (展開後の文字列ではない)
      const savedInject = await page.evaluate((p) => {
        const r = (state.info.rules || []).find((x) => x.id === p.id && x.layer === p.layer);
        return (r && r.inject) || '';
      }, pick);
      await btn.click();
      await page.waitForSelector('#delivery-edit:not([hidden])', { timeout: 5_000 });
      const opened = await page.evaluate(() => ({
        value: document.getElementById('delivery-inject').value,
        placeholder: document.getElementById('delivery-inject').placeholder,
        btn: document.getElementById('delivery-edit-btn').textContent.trim(),
        expanded: document.getElementById('delivery-edit-btn').getAttribute('aria-expanded'),
        help: document.getElementById('delivery-inject-help').textContent,
      }));
      // 期待 placeholder は届き方 (mode) と種別 (kind) の両方で決まる — 標準文面は
      // 操作きっかけ (この操作の docs) とことばきっかけ (この話題の docs) で違う。
      // mode だけで決め打つと、先に pick された doc がことばきっかけの環境で偽 FAIL する
      const wantPh = pick.mode === 'inline' ? '(前置きなし — 本文がそのまま届く)'
        : (await page.evaluate((kind) => (kind === 'kw' ? POINTER_TEMPLATE_PROMPT : POINTER_TEMPLATE),
          pick.kind));
      check('B-m2', '帯の編集を開くと inject の生テンプレートが入り、空なら標準文面が placeholder',
        opened.value === savedInject && opened.btn === '閉じる' && opened.expanded === 'true'
        && (savedInject !== '' || opened.placeholder === wantPh)
        && opened.help.includes('{doc}'),
        `value=${JSON.stringify(opened.value)} 保存値=${JSON.stringify(savedInject)} placeholder=${JSON.stringify(opened.placeholder)} btn=${opened.btn}`);

      // B-m3 — 打つと帯が {doc}/{id} 展開後の姿へ即時更新 + 未保存の予告
      const TEXT = 'よく読む: {doc} ({id})';
      await page.fill('#delivery-inject', TEXT);
      const wantHead = `[toolhint] よく読む: ${pick.abs} (${pick.id})`;
      await waitUntil(async () => (await page.locator('#delivery-text').textContent()).startsWith(wantHead),
        { label: '帯の予告更新' }).catch(() => null);
      const live = await page.evaluate(() => ({
        text: document.getElementById('delivery-text').textContent,
        note: document.getElementById('delivery-note').textContent,
      }));
      check('B-m3', '帯で打つと {doc}/{id} が展開された姿に即時更新し「未保存」と言う',
        live.text.startsWith(wantHead)
        && !live.text.slice(0, wantHead.length + 8).includes('{doc}')
        && live.note.includes('未保存 — 保存すると届く文面'),
        `text=${JSON.stringify(live.text.slice(0, 120))} note=${JSON.stringify(live.note)}`);

      // B-m4 — 保存は生テンプレートを送る (展開後を送らない) / パネルは開いたまま。
      // 保存先は「いま帯に見えている文面を出しているきっかけ」全部 = 複数の POST が出る
      const updates = () => captured.filter((c) => c.path === '/api/rule/update');
      const nTargets = await page.evaluate(() => state.injectTargets.length);
      const before4 = updates().length;
      await page.click('#delivery-edit button[type=submit]');
      await waitUntil(() => updates().length >= before4 + nTargets,
        { label: '/api/rule/update (帯の保存) の mock 捕捉' });
      const sent4 = updates().slice(before4);
      await waitUntil(async () => /^保存した/.test(
        await page.locator('#delivery-inject-note').textContent()),
      { label: '保存結果の表示' }).catch(() => null);
      const after4 = await page.evaluate(() => ({
        open: !document.getElementById('delivery-edit').hidden,
        note: document.getElementById('delivery-inject-note').textContent,
      }));
      check('B-m4', '帯の保存は patch.inject に生テンプレートを送り、パネルは開いたまま結果を返す',
        sent4.length === nTargets
        && sent4.every((c) => c.body.patch && c.body.patch.inject === TEXT && c.body.layer)
        && sent4[0].body.id === pick.id && sent4[0].body.layer === pick.layer
        && after4.open && /^保存した/.test(after4.note),
        `送信 ${sent4.length}/${nTargets} 件 patch=${JSON.stringify(sent4.map((c) => c.body.patch))} id=${JSON.stringify(sent4.map((c) => c.body.id))} open=${after4.open} note=${JSON.stringify(after4.note)}`);

      // B-m5 — 「標準に戻す」は patch.inject: null (キー削除 → 標準文面)
      const before5 = updates().length;
      await page.click('#delivery-inject-reset');
      await waitUntil(() => updates().length >= before5 + nTargets,
        { label: '/api/rule/update (標準に戻す) の mock 捕捉' });
      const sent5 = updates().slice(before5);
      await waitUntil(async () => (await page.locator('#delivery-inject-note').textContent()) === '標準文面に戻した',
        { label: '標準復帰の表示' }).catch(() => null);
      check('B-m5', '「標準に戻す」は patch.inject: null を送る (キー削除で標準文面へ)',
        sent5.length === nTargets && sent5.every((c) => c.body.patch && c.body.patch.inject === null),
        `patch=${JSON.stringify(sent5.map((c) => c.body.patch))} note=${JSON.stringify(await page.locator('#delivery-inject-note').textContent())}`);
      await page.screenshot({ path: shot('b-m-delivery-edit.png') });

      // B-m7 — filled ガード: 本文の打鍵 (renderDelivery が毎回走る経路) で入力が消えない
      await page.fill('#delivery-inject', '下書き {doc}');
      const guard = await page.evaluate(() => {
        const ed = document.getElementById('editor-body');
        const before = document.getElementById('delivery-inject').value;
        const orig = ed.value;
        ed.value = `${orig}\ne2e 打鍵`;
        ed.dispatchEvent(new Event('input', { bubbles: true }));
        const after = document.getElementById('delivery-inject').value;
        const dirty = state.dirty;
        return { before, after, dirty };
      });
      check('B-m7', '本文を打っても帯の入力欄の下書きが消えない (renderDelivery の再描画に耐える)',
        guard.before === guard.after && guard.after === '下書き {doc}' && guard.dirty === true,
        `before=${JSON.stringify(guard.before)} after=${JSON.stringify(guard.after)} dirty=${guard.dirty}`);
      await page.click('#body-discard-btn'); // 本文は元へ (この監査は非破壊)
      await waitUntil(async () => page.evaluate(() => state.dirty === false),
        { label: '本文の取り消し' }).catch(() => null);

      // B-m8 — accent 不変条件: 画面の青い主ボタンは常に 1 つ以下
      const primaries = await page.evaluate(() => [...document.querySelectorAll('.btn-primary')]
        .filter((el) => el.offsetParent !== null)
        .map((el) => el.id || el.textContent.trim()));
      check('B-m8', '帯の編集パネルを開いている間、可視の主ボタン (.btn-primary) は 1 つ以下',
        primaries.length <= 1, `可視 btn-primary=${JSON.stringify(primaries)}`);

      // B-m9 — パネル開状態のレイアウト (兄弟の交差ゼロ + 横 overflow なし)
      const lay = await page.evaluate(() => {
        const vis = (el) => {
          const cs = getComputedStyle(el);
          const r = el.getBoundingClientRect();
          return cs.display !== 'none' && cs.visibility !== 'hidden' && r.width > 0 && r.height > 0;
        };
        const rectsOf = (sel) => [...document.querySelectorAll(`${sel} > *`)].filter(vis).map((el) => {
          const r = el.getBoundingClientRect();
          return { name: `${sel}>${el.id || el.className}`, x: r.x, y: r.y, w: r.width, h: r.height };
        });
        return {
          delivery: rectsOf('#delivery'),
          form: rectsOf('#delivery-edit'),
          head: rectsOf('.editor-card .delivery-head'),
          docScrollWidth: Math.max(document.documentElement.scrollWidth, document.body.scrollWidth),
          innerWidth: window.innerWidth,
        };
      });
      const overlaps = [...overlapPairs(lay.delivery, EPS), ...overlapPairs(lay.form, EPS),
        ...overlapPairs(lay.head, EPS)];
      check('B-m9', '帯の編集パネル開: 兄弟要素の交差ゼロ + 横 overflow なし',
        overlaps.length === 0 && lay.docScrollWidth <= lay.innerWidth,
        `${overlaps.join(' / ')} docScrollWidth=${lay.docScrollWidth} innerWidth=${lay.innerWidth}`);

      // B-m10 — 保存が失敗しても打った下書きを消さない (押し直すだけで再送できる)。
      // 失敗時に保存値へ書き戻すと、書けなかった文面が黙って消える
      const failRoute = (route) => route.fulfill({
        status: 500,
        contentType: 'application/json',
        body: JSON.stringify({ error: 'e2e 強制失敗 (rule/update)' }),
      });
      await page.route('**/api/rule/update', failRoute);
      const DRAFT = 'のこるはず {doc} — 長い下書き';
      await page.fill('#delivery-inject', DRAFT);
      await page.click('#delivery-edit button[type=submit]');
      await waitUntil(async () => /^失敗/.test(
        await page.locator('#delivery-inject-note').textContent()),
      { label: '保存失敗の表示' }).catch(() => null);
      const failed = await page.evaluate(() => ({
        value: document.getElementById('delivery-inject').value,
        draft: state.draftInject,
        open: !document.getElementById('delivery-edit').hidden,
        note: document.getElementById('delivery-inject-note').textContent,
        err: document.getElementById('delivery-inject-note').classList.contains('err'),
      }));
      await page.unroute('**/api/rule/update', failRoute);
      check('B-m10', '保存に失敗しても下書きが残り、パネルは開いたまま失敗と言う (再送できる)',
        failed.value === DRAFT && failed.draft === DRAFT && failed.open
        && /^失敗/.test(failed.note) && failed.err,
        `value=${JSON.stringify(failed.value)} draft=${JSON.stringify(failed.draft)} open=${failed.open} note=${JSON.stringify(failed.note)} err=${failed.err}`);

      // B-m11 — 鉛筆フォーム → 帯の編集を開くと鉛筆は畳まれる (同じ inject の編集面は 1 つ)。
      // 2 つ開くと、帯で保存した値を鉛筆フォームの保存が黙って巻き戻す
      await page.click('#delivery-edit-btn'); // いったん帯を閉じる
      await page.waitForSelector('#delivery-edit', { state: 'hidden', timeout: 5_000 });
      const pencil = page.locator('#cond-list .rule-act[data-act=edit]').first();
      if (await pencil.count()) {
        await pencil.click();
        await page.waitForSelector('#cond-list form.rule-edit-form', { timeout: 5_000 });
        await page.click('#delivery-edit-btn');
        await page.waitForSelector('#delivery-edit:not([hidden])', { timeout: 5_000 });
        const both = await page.evaluate(() => ({
          pencilOpen: !!document.querySelector('#cond-list form.rule-edit-form'),
          bandOpen: !document.getElementById('delivery-edit').hidden,
          editingRuleId: state.editingRuleId,
          primaries: [...document.querySelectorAll('.btn-primary')]
            .filter((el) => el.offsetParent !== null).map((el) => el.id || el.textContent.trim()),
        }));
        check('B-m11', '鉛筆フォームを開いたまま帯の編集を開くと、鉛筆が畳まれ主ボタンは 1 つ以下',
          !both.pencilOpen && both.bandOpen && both.editingRuleId === null
          && both.primaries.length <= 1,
          `鉛筆=${both.pencilOpen} 帯=${both.bandOpen} editingRuleId=${JSON.stringify(both.editingRuleId)} 可視 btn-primary=${JSON.stringify(both.primaries)}`);
      } else {
        await page.click('#delivery-edit-btn'); // 鉛筆が無い環境でも帯は開き直して次へ
        await page.waitForSelector('#delivery-edit:not([hidden])', { timeout: 5_000 });
        console.log('  skip [B-m11] きっかけの編集ボタンが対象 cwd に無いため省略');
      }

      // B-m12 — 対象プロジェクト (cwd) が変わったら下書きは畳む。selectDoc を通らない
      // 再選択 (cwd 切替・doc 消滅) でパネルが生き残ると、前の doc の下書きが
      // 別プロジェクトのきっかけへ 1 クリックで書けてしまう
      const origCwd = await page.evaluate(() => state.cwd);
      const foldTmp = fs.mkdtempSync(path.join(os.tmpdir(), 'toolhint-e2e-fold-'));
      try {
        await page.fill('#delivery-inject', '汚染するはずの下書き {doc}');
        await page.evaluate((c) => loadAll(c), foldTmp);
        await waitUntil(async () => page.evaluate((c) => state.cwd === c, foldTmp),
          { label: 'cwd 切替後の読み込み' });
        const folded = await page.evaluate(() => ({
          editing: state.editingDelivery,
          open: !document.getElementById('delivery-edit').hidden,
          value: document.getElementById('delivery-inject').value,
          draft: state.draftInject,
        }));
        check('B-m12', 'cwd を切り替えると帯の編集は畳まれ、前の doc の下書きが残らない',
          folded.editing === false && !folded.open && folded.value === '' && folded.draft === null,
          `editing=${folded.editing} open=${folded.open} value=${JSON.stringify(folded.value)} draft=${JSON.stringify(folded.draft)}`);
      } finally {
        await page.evaluate((c) => loadAll(c), origCwd);
        await waitUntil(async () => page.evaluate((c) => state.cwd === c, origCwd),
          { label: 'cwd の復帰' }).catch(() => null);
        fs.rmSync(foldTmp, { recursive: true, force: true });
      }

      // 後片付け — 開いたまま次の検査 (cwd 切替) へ持ち越さない
      if (await page.evaluate(() => !document.getElementById('delivery-edit').hidden)) {
        await page.click('#delivery-edit-btn');
        await page.waitForSelector('#delivery-edit', { state: 'hidden', timeout: 5_000 });
      }
    } catch (e) {
      for (const id of ['B-m1', 'B-m2', 'B-m3', 'B-m4', 'B-m5', 'B-m7', 'B-m8', 'B-m9',
        'B-m10', 'B-m11', 'B-m12']) {
        if (!results.some((r) => r.id === id)) {
          check(id, '帯 (実際に届く文面) の中での inject 編集', false, `フロー失敗: ${e.message}`);
        }
      }
      await page.screenshot({ path: shot('b-m-delivery-edit.png') });
    }
  }

  // -------------------------------------------------------------------------
  // B-s — 共有層 (layers.d) の doc: 読み取り専用の見た目と、層ごとの導線の出し分け
  //   fixture (GET 差し替え) で「共有 doc を、共有のきっかけと手元のきっかけが
  //   両方指している」状態を作る。実サーバの層は一切触らない
  // -------------------------------------------------------------------------
  try {
    const sp = await context.newPage();
    sp.on('pageerror', (e) => pageErrors.push(String(e && e.message || e)));
    await installWriteMocks(sp, captured);
    await installSharedLayerFixture(sp); // 後勝ち — GET だけ fixture、POST は write mock へ
    await sp.goto(openUrl, { waitUntil: 'load' });
    await waitAppLoaded(sp);

    const shelf = await sp.evaluate(() => {
      const card = document.querySelector('#doc-list a[data-key^="layers.d/"]');
      return {
        found: !!card,
        chip: !!(card && card.querySelector('.shared-chip')),
        dot: !!(card && card.querySelector('.doc-scope.layer-shared')),
        toggle: !!(card && card.querySelector('button.doc-toggle')),
      };
    });
    check('B-s1', '棚: 共有層の doc に「共有」のしるし (チップ + 層ドット) が出る',
      shelf.found && shelf.chip && shelf.dot, JSON.stringify(shelf));

    await sp.click('#doc-list a[data-key^="layers.d/"]');
    await sp.waitForTimeout(500);
    const detail = await sp.evaluate(() => {
      const visible = (sel) => {
        const el = document.querySelector(sel);
        if (!el) return false;
        const r = el.getBoundingClientRect();
        return r.width > 0 && r.height > 0;
      };
      const row = (id) => document.querySelector(`#cond-list .condition-rule[data-id="${id}"]`);
      const sharedRow = row('team-grep');
      const mineRow = row('mine-extra');
      // 「見えているボタン」だけを数える — DOM にあっても display:none で畳まれて
      // いれば人には無い (旧実装は共有 doc の行を CSS でまとめて畳んでいた)
      const acts = (el) => [...(el ? el.querySelectorAll('button[data-act]') : [])]
        .filter((b) => { const r = b.getBoundingClientRect(); return r.width > 0 && r.height > 0; })
        .map((b) => b.dataset.act).sort();
      return {
        readonlyClass: !!document.querySelector('.detail.readonly-layer'),
        scope: (document.getElementById('detail-scope') || {}).textContent || '',
        editorReadOnly: !!(document.getElementById('editor-body') || {}).readOnly,
        saveVisible: visible('#save-btn'),
        condAddVisible: visible('#cond-add-mini'),
        deliverRowVisible: visible('#deliver-row'),
        sharedRowFound: !!sharedRow,
        sharedRowActs: acts(sharedRow),
        sharedRowChip: !!(sharedRow && sharedRow.querySelector('.shared-chip')),
        mineRowFound: !!mineRow,
        mineRowActs: acts(mineRow),
        deliveryText: (document.getElementById('delivery-text') || {}).textContent || '',
        docScrollWidth: Math.max(document.documentElement.scrollWidth, document.body.scrollWidth),
        innerWidth: window.innerWidth,
      };
    });
    check('B-s2', '共有 doc は読み取り専用 (保存・きっかけ追加・届け方の導線が出ない / 本文編集不可)',
      detail.readonlyClass && detail.editorReadOnly && !detail.saveVisible
      && !detail.condAddVisible && !detail.deliverRowVisible
      && detail.scope.includes('読み取り専用'),
      JSON.stringify(detail));
    check('B-s3', '共有のきっかけ行: 操作ボタンなし + 「共有」のしるしあり',
      detail.sharedRowFound && detail.sharedRowActs.length === 0 && detail.sharedRowChip,
      JSON.stringify({ found: detail.sharedRowFound, acts: detail.sharedRowActs, chip: detail.sharedRowChip }));
    check('B-s4', '同じ doc を指す手元 (全体層) のきっかけ行: 編集・ON/OFF・削除の導線が出る',
      detail.mineRowFound
      && ['del', 'edit', 'toggle'].every((a) => detail.mineRowActs.includes(a)),
      JSON.stringify({ found: detail.mineRowFound, acts: detail.mineRowActs }));
    check('B-s5', '共有 doc でも「実際に届く文面」は読める (engine の文面が出ている)',
      detail.deliveryText.includes('[toolhint]') && detail.deliveryText.includes('team-search.md'),
      JSON.stringify(detail.deliveryText.slice(0, 160)));
    check('B-s6', '共有 doc 表示中も横 overflow なし',
      detail.docScrollWidth <= detail.innerWidth,
      `docScrollWidth=${detail.docScrollWidth} innerWidth=${detail.innerWidth}`);
    await sp.screenshot({ path: shot('b-s-shared-layer.png') });

    // 手元の doc へ切り替えると導線が戻る (readonly の固着がない)
    await sp.click('#doc-list a[data-key^="global "]');
    await sp.waitForTimeout(500);
    const own = await sp.evaluate(() => {
      const visible = (sel) => {
        const el = document.querySelector(sel);
        if (!el) return false;
        const r = el.getBoundingClientRect();
        return r.width > 0 && r.height > 0;
      };
      return {
        readonlyClass: !!document.querySelector('.detail.readonly-layer'),
        editorReadOnly: !!(document.getElementById('editor-body') || {}).readOnly,
        saveArea: visible('.detail-actions'),
        condAdd: visible('#cond-add-mini'),
      };
    });
    check('B-s7', '手元の doc へ戻すと読み取り専用が解ける (保存・追加の導線が戻る)',
      !own.readonlyClass && !own.editorReadOnly && own.saveArea && own.condAdd,
      JSON.stringify(own));
    if (!results.at(-1).ok) await sp.screenshot({ path: shot('b-s-own-layer.png') });
    await sp.close();
  } catch (e) {
    for (const id of ['B-s1', 'B-s2', 'B-s3', 'B-s4', 'B-s5', 'B-s6', 'B-s7']) {
      if (!results.some((r) => r.id === id)) {
        check(id, '共有層 (layers.d) の表示と導線', false, `フロー失敗: ${e.message}`);
      }
    }
  }

  // -------------------------------------------------------------------------
  // B-t — 読めない層の警告帯 / 実体の無い doc の言い方 / 判定の教育文の出しどころ /
  //   新規作成ダイアログの「保存先」— fixture (GET 差し替え) で状態を作る
  // -------------------------------------------------------------------------
  const BT_IDS = ['B-t1', 'B-t2', 'B-t3', 'B-t4', 'B-t5', 'B-t6', 'B-t7'];
  try {
    const tp = await context.newPage();
    tp.on('pageerror', (e) => pageErrors.push(String(e && e.message || e)));
    await installWriteMocks(tp, captured);
    await installBrokenLayerFixture(tp); // 後勝ち — GET だけ fixture、POST は write mock へ
    await tp.goto(openUrl, { waitUntil: 'load' });
    await waitAppLoaded(tp);

    const bar = await tp.evaluate(() => {
      const el = document.getElementById('layer-error-bar');
      const r = el ? el.getBoundingClientRect() : null;
      return {
        found: !!el,
        visible: !!el && !el.hidden && !!r && r.width > 0 && r.height > 0,
        text: el ? el.textContent.replace(/\s+/g, ' ').trim() : '',
        lines: el ? el.querySelectorAll('.layer-error-line').length : 0,
        docScrollWidth: Math.max(document.documentElement.scrollWidth, document.body.scrollWidth),
        innerWidth: window.innerWidth,
      };
    });
    check('B-t1', '読めない層があると上部に警告帯が可視で、事実 (読み飛ばし) + ファイル + 理由を言う',
      bar.visible && bar.lines === 1
      && bar.text.includes('rules.yaml が読めないため読み飛ばされています')
      && bar.text.includes('layers.d/broken/rules.yaml')
      && bar.text.includes(FIX_BROKEN_ERROR)
      && bar.text.includes('共有: broken'),
      JSON.stringify(bar));
    check('B-t2', '警告帯を出しても横 overflow なし',
      bar.docScrollWidth <= bar.innerWidth,
      `docScrollWidth=${bar.docScrollWidth} innerWidth=${bar.innerWidth}`);

    const cards = await tp.evaluate(() => {
      const textOf = (sel) => {
        const a = document.querySelector(sel);
        return a ? a.textContent.replace(/\s+/g, ' ').trim() : null;
      };
      return {
        broken: textOf('#doc-list a[data-key="layers.d/broken orphan-in-broken.md"]'),
        gone: textOf('#doc-list a[data-key="global gone.md"]'),
        goneSummary: textOf('#doc-list a[data-key="global gone.md"] .doc-summary'),
      };
    });
    check('B-t3', '読めない層の doc は「きっかけ未設定」ではなく「きっかけ不明 (層が読めない)」',
      !!cards.broken && cards.broken.includes('きっかけ不明 (層が読めない)')
      && !cards.broken.includes('きっかけ未設定'),
      JSON.stringify(cards.broken));
    check('B-t4', '実体の無い doc は「(ファイル未作成)」ではなく「参照先の doc が見つからない — 注入されない」',
      !!cards.goneSummary && cards.goneSummary.includes('参照先の doc が見つからない')
      && cards.goneSummary.includes('注入されない')
      && !cards.gone.includes('ファイル未作成'),
      JSON.stringify(cards));

    // 実体の無い doc を開く — 詳細の「実際に届く文面」の脇注も同じ事実を言う
    await tp.click('#doc-list a[data-key="global gone.md"]');
    await tp.waitForTimeout(400);
    const goneDetail = await tp.evaluate(() => ({
      note: (document.getElementById('delivery-note') || {}).textContent || '',
      editorState: (document.getElementById('editor-state') || {}).textContent || '',
    }));
    check('B-t5', '実体の無い doc の詳細: 脇注とエディタの状態が「注入されない」と言い、「未作成」と言わない',
      goneDetail.note.includes('参照先の doc が見つからない') && goneDetail.note.includes('注入されない')
      && goneDetail.editorState.includes('注入されない') && !goneDetail.editorState.includes('未作成'),
      JSON.stringify(goneDetail));

    // 判定の教育文 — 判定を 1 回実行して開示 → 記録タブへ移ると畳まれ → 判定へ戻すと戻る
    await tp.click('#dock-tab-try');
    await tp.fill('#test-input', 'cat foo');
    await tp.click('#test-run-btn');
    await tp.waitForFunction(() => {
      const box = document.getElementById('test-result');
      return box && !box.hidden && box.textContent.trim() !== '' && box.textContent.trim() !== '確認中…';
    }, undefined, { timeout: 10_000 });
    const helpVisible = () => tp.evaluate(() => {
      const th = document.querySelector('.test-help');
      if (!th || th.hidden) return false;
      const r = th.getBoundingClientRect();
      return r.width > 0 && r.height > 0;
    });
    const afterTest = await helpVisible();
    await tp.click('#dock-tab-log');
    await tp.waitForTimeout(150);
    const onLog = await helpVisible();
    await tp.click('#dock-tab-try');
    await tp.waitForTimeout(150);
    const backOnTry = await helpVisible();
    check('B-t6', '判定の教育文は判定タブでだけ見える (判定後に可視 → 記録タブで消える → 判定へ戻すと戻る)',
      afterTest && !onLog && backOnTry,
      `afterTest=${afterTest} onLog=${onLog} backOnTry=${backOnTry}`);
    if (!results.at(-1).ok) await tp.screenshot({ path: shot('b-t-test-help.png') });
    await tp.screenshot({ path: shot('b-t-broken-layer.png') });

    // 新規作成ダイアログ — 層の選択欄の見出しは「保存先」(「適用範囲」は scope の語)
    await tp.click('#new-doc-btn');
    await tp.waitForSelector('#modal:not([hidden])', { timeout: 5_000 });
    const modal = await tp.evaluate(() => {
      const labels = [...document.querySelectorAll('.layer-choice .field-label')]
        .map((el) => el.textContent.trim());
      const bodyText = document.body.innerText || document.body.textContent || '';
      return { labels, hasScopeWord: bodyText.includes('適用範囲') };
    });
    check('B-t7', '新規作成ダイアログの層の選択欄は「保存先」で、画面に「適用範囲」の語が無い',
      modal.labels.length === 2 && modal.labels.every((t) => t === '保存先') && !modal.hasScopeWord,
      JSON.stringify(modal));
    await tp.screenshot({ path: shot('b-t-new-modal.png') });
    await tp.close();
  } catch (e) {
    for (const id of BT_IDS) {
      if (!results.some((r) => r.id === id)) {
        check(id, '読めない層の警告帯 / 実体の無い doc / 判定の教育文 / 保存先ラベル', false, `フロー失敗: ${e.message}`);
      }
    }
  }

  // -------------------------------------------------------------------------
  // B-u — doc を持たないルール (inject の文面だけ) が一覧・詳細・記録で扱えること —
  //   fixture (GET 差し替え) で状態を作る。一覧に出ない / 記録が「今は無い」と言う
  //   回帰を止める
  // -------------------------------------------------------------------------
  const BU_IDS = ['B-u1', 'B-u2', 'B-u3', 'B-u4', 'B-u5', 'B-u6', 'B-u7'];
  try {
    const up = await context.newPage();
    up.on('pageerror', (e) => pageErrors.push(String(e && e.message || e)));
    await installWriteMocks(up, captured);
    await installInjectOnlyFixture(up); // 後勝ち — GET だけ fixture、POST は write mock へ
    await up.goto(openUrl, { waitUntil: 'load' });
    await waitAppLoaded(up);

    const shelf = await up.evaluate(() => {
      const textOf = (sel) => {
        const a = document.querySelector(sel);
        return a ? a.textContent.replace(/\s+/g, ' ').trim() : null;
      };
      return {
        count: (document.getElementById('doc-count') || {}).textContent,
        cardName: textOf('#doc-list a[data-key="global rule:ship-warn"] .doc-name'),
        cardChip: textOf('#doc-list a[data-key="global rule:ship-warn"] .inject-only-chip'),
        cardSummary: textOf('#doc-list a[data-key="global rule:ship-warn"] .doc-summary'),
        cardTrigger: textOf('#doc-list a[data-key="global rule:ship-warn"] .trigger'),
        emptySummary: textOf('#doc-list a[data-key="global rule:no-payload"] .doc-summary'),
        docScrollWidth: Math.max(document.documentElement.scrollWidth, document.body.scrollWidth),
        innerWidth: window.innerWidth,
      };
    });
    check('B-u1', '棚: doc 無しルールがカードで出る (見出し = ルール id / 「文面だけ」のしるし / 本文欄に文面 / 種別チップ)',
      shelf.cardName === 'ship-warn' && shelf.cardChip === '文面だけ'
      && !!shelf.cardSummary && shelf.cardSummary.includes(FIX_IO_INJECT)
      && !!shelf.cardTrigger && shelf.cardTrigger.includes('ことば'),
      JSON.stringify(shelf));
    // fixture のルールは doc 付き 3 + doc 無し 2 = 5 — 左上の件数は doc 数 (2) ではなくルール数
    check('B-u2', '左上の件数は「ルール N」= /api/state の rules 総数 (doc 数ではない)',
      shelf.count === '5', `count=${JSON.stringify(shelf.count)} (期待 5)`);
    check('B-u3', 'doc も文面も無いルールは「(届く文面が無い — 注入されない)」と言う',
      !!shelf.emptySummary && shelf.emptySummary.includes('届く文面が無い') && shelf.emptySummary.includes('注入されない'),
      JSON.stringify(shelf.emptySummary));

    await up.click('#doc-list a[data-key="global rule:ship-warn"]');
    await up.waitForTimeout(400);
    const detail = await up.evaluate(() => {
      const vis = (el) => {
        if (!el || el.hidden) return false;
        const cs = getComputedStyle(el);
        if (cs.display === 'none' || cs.visibility === 'hidden') return false;
        const r = el.getBoundingClientRect();
        return r.width > 0 && r.height > 0;
      };
      return {
        title: (document.getElementById('detail-title') || {}).textContent,
        path: (document.getElementById('detail-path') || {}).textContent,
        boxVisible: vis(document.getElementById('inject-only-box')),
        lead: (document.getElementById('inject-only-lead') || {}).textContent,
        text: (document.getElementById('inject-only-text') || {}).textContent,
        editBtnVisible: vis(document.getElementById('inject-only-edit-btn')),
        editorVisible: vis(document.getElementById('editor-body')),
        saveVisible: vis(document.getElementById('save-btn')),
        deliverRowVisible: vis(document.getElementById('deliver-row')),
        addMiniVisible: vis(document.getElementById('cond-add-mini')),
        addRowVisible: vis(document.getElementById('cond-add-row')),
        delivery: (document.getElementById('delivery-text') || {}).textContent,
        deliveryVisible: vis(document.getElementById('delivery-text')),
        condIds: [...document.querySelectorAll('#cond-list .condition-rule')].map((el) => el.dataset.id),
        docScrollWidth: Math.max(document.documentElement.scrollWidth, document.body.scrollWidth),
        innerWidth: window.innerWidth,
      };
    });
    check('B-u4', '詳細: 見出しはルール id、パス欄は「doc なし」、本文欄は「doc は無く、この文面だけを届ける」+ 文面 (エディタ・保存・届け方・きっかけ追加は出ない)',
      detail.title === 'ship-warn' && detail.path === 'doc なし'
      && detail.boxVisible && detail.lead === 'doc は無く、この文面だけを届ける'
      && detail.text === FIX_IO_INJECT && detail.editBtnVisible
      && !detail.editorVisible && !detail.saveVisible && !detail.deliverRowVisible
      && !detail.addMiniVisible && !detail.addRowVisible
      && detail.condIds.length === 1 && detail.condIds[0] === 'ship-warn',
      JSON.stringify(detail));
    check('B-u5', '詳細: 「実際に届く文面」は {id} 展開後の文面 1 行 ([toolhint] 前置き)',
      detail.deliveryVisible && detail.delivery === '[toolhint] リリース手順は先に確認 (ship-warn)',
      JSON.stringify(detail.delivery));
    await up.screenshot({ path: shot('b-u-inject-only.png') });

    // 「届く文面を変える」→ 既存のきっかけ編集フォーム (届く文面の欄) が開き、そこへ focus
    await up.click('#inject-only-edit-btn');
    await up.waitForSelector('#cond-list form.rule-edit-form [name=inject]', { timeout: 5_000 });
    const edit = await up.evaluate(() => {
      const form = document.querySelector('#cond-list form.rule-edit-form');
      const inp = form && form.querySelector('[name=inject]');
      const label = inp && inp.closest('.field') && inp.closest('.field').querySelector('.field-label');
      return {
        id: form && form.dataset.id,
        focused: document.activeElement === inp,
        value: inp && inp.value,
        label: label && label.textContent,
      };
    });
    check('B-u6', '「届く文面を変える」は既存のきっかけ編集フォームを開き、届く文面の欄 (doc 無しの語) へ focus する',
      edit.id === 'ship-warn' && edit.focused && edit.value === FIX_IO_INJECT
      && !!edit.label && edit.label.includes('doc が無い') && !edit.label.includes('空 = 標準'),
      JSON.stringify(edit));
    await up.screenshot({ path: shot('b-u-inject-only-edit.png') });

    // 記録タブ — 現存する doc 無しルールの行には「このきっかけは今は無い」を出さない。
    // どのルールにも無い id (kiery) の行にだけ出す
    await up.click('#dock-tab-log');
    await up.waitForTimeout(200);
    const log = await up.evaluate(() => [...document.querySelectorAll('#log-table .log-row')].map((r) => ({
      main: (r.querySelector('.log-main') || {}).textContent,
      gone: !!r.querySelector('.log-gone'),
    })));
    const shipRow = log.find((r) => (r.main || '').includes('ship-warn'));
    const kieryRow = log.find((r) => (r.main || '').includes('kiery'));
    check('B-u7', '記録: 現存する doc 無しルールに「このきっかけは今は無い」を出さず、どのルールにも無い id にだけ出す',
      !!shipRow && !shipRow.gone && !!kieryRow && kieryRow.gone
      && shelf.docScrollWidth <= shelf.innerWidth && detail.docScrollWidth <= detail.innerWidth,
      JSON.stringify({ log, overflow: [shelf.docScrollWidth, shelf.innerWidth, detail.docScrollWidth, detail.innerWidth] }));
    await up.screenshot({ path: shot('b-u-inject-only-log.png') });
    await up.close();
  } catch (e) {
    for (const id of BU_IDS) {
      if (!results.some((r) => r.id === id)) {
        check(id, 'doc を持たないルールの一覧・詳細・記録', false, `フロー失敗: ${e.message}`);
      }
    }
  }

  // -------------------------------------------------------------------------
  // B-i — localStorage 復元: cwd を tmp dir へ → reload → 値が維持される
  // -------------------------------------------------------------------------
  const tmpCwd = fs.mkdtempSync(path.join(os.tmpdir(), 'toolhint-e2e-'));
  try {
    // 注意: fill 直後は value が既に tmpCwd なので「value 一致」で完了を待てない
    // (loadAll 完了前に reload すると localStorage 書き込み前に頁が消える race)。
    // 新 cwd での 3 GET (state/docs/log) の応答を完了シグナルにする
    const enc = encodeURIComponent(tmpCwd);
    const loaded = Promise.all(['/api/state', '/api/docs', '/api/log'].map((ep) =>
      page.waitForResponse((r) => r.url().includes(ep) && r.url().includes(enc),
        { timeout: 15_000 })));
    await page.fill('#cwd-input', tmpCwd);
    await page.press('#cwd-input', 'Enter');
    await loaded;
    await page.waitForTimeout(400); // 応答受領後の反映 (json parse → 永続化) の settle
    await page.reload({ waitUntil: 'load' });
    await waitAppLoaded(page);
    const after = await page.locator('#cwd-input').inputValue();
    check('B-i', 'cwd を変更 → reload → #cwd-input 値が維持 (localStorage 復元)',
      after === tmpCwd, `reload 後=${JSON.stringify(after)} (期待 ${tmpCwd})`);
    if (after !== tmpCwd) await page.screenshot({ path: shot('b-i-restore.png') });
  } catch (e) {
    check('B-i', 'cwd を変更 → reload → #cwd-input 値が維持 (localStorage 復元)', false, `フロー失敗: ${e.message}`);
    await page.screenshot({ path: shot('b-i-restore.png') });
  } finally {
    fs.rmSync(tmpCwd, { recursive: true, force: true });
  }

  // -------------------------------------------------------------------------
  // B-j — 存在しないパス入力 → 警告が可視
  // -------------------------------------------------------------------------
  try {
    const bogus = '/nonexistent-toolhint-e2e-path-xyz';
    await page.fill('#cwd-input', bogus);
    await page.press('#cwd-input', 'Enter');
    // 挙動レベルで待つ: 警告 (error-bar か .target-box.warn) の出現。出なければ timeout → FAIL
    let warned = false;
    try {
      await page.waitForFunction(() => {
        const bar = document.getElementById('error-bar');
        return (!!bar && !bar.hidden && bar.textContent.trim() !== '')
          || !!document.querySelector('.target-box.warn');
      }, undefined, { timeout: 10_000 });
      warned = true;
    } catch { /* timeout = 警告なし */ }
    const warn = await page.evaluate(() => {
      const bar = document.getElementById('error-bar');
      return {
        barVisible: !!bar && !bar.hidden && bar.textContent.trim() !== '',
        boxWarn: !!document.querySelector('.target-box.warn'),
        barText: bar ? bar.textContent.trim() : '',
      };
    });
    check('B-j', '存在しないパス入力で警告が可視 (error-bar か .target-box.warn)',
      warned, `error-bar visible=${warn.barVisible} target-box.warn=${warn.boxWarn} text=${JSON.stringify(warn.barText.slice(0, 80))}`);
    if (!warned) await page.screenshot({ path: shot('b-j-warn.png') });
  } catch (e) {
    check('B-j', '存在しないパス入力で警告が可視 (error-bar か .target-box.warn)', false, `フロー失敗: ${e.message}`);
    await page.screenshot({ path: shot('b-j-warn.png') });
  }

  await page.screenshot({ path: shot('final-state.png') });
  await browser.close();

  // -------------------------------------------------------------------------
  // 非破壊の自己検証 + まとめ
  // -------------------------------------------------------------------------
  const writes = captured.map((c) => c.path);
  console.log(`\n[e2e] mock で捕捉した POST (実サーバへは届いていない): ${writes.length ? writes.join(', ') : '(なし)'}`);
  if (pageErrors.length) {
    console.log(`[e2e] page の JS エラー (参考): ${pageErrors.slice(0, 5).join(' / ')}`);
  }

  const fails = results.filter((r) => !r.ok);
  console.log(`\n===== 結果: ${results.length - fails.length}/${results.length} PASS =====`);
  if (fails.length) {
    console.log('失敗 assert (1 件ずつ):');
    for (const f of fails) console.log(`  FAIL [${f.id}] ${f.desc} — ${f.detail}`);
    console.log(`\nスクショ: ${SHOT_DIR}`);
    process.exit(1);
  }
  console.log('全 assert PASS');
  process.exit(0);
}

main().catch((e) => {
  console.error(`[e2e] 監査ハーネス自体の失敗: ${e.stack || e}`);
  process.exit(2);
});
