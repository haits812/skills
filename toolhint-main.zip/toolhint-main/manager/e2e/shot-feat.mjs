#!/usr/bin/env node
// =============================================================================
// 追加機能 (届く文面の編集 / ことばきっかけの AI 起案) の確認スクショ
// (playwright / 実 docs 非破壊 — 保存系のボタンは 1 つも押さない)
//
// 実行方法:
//   cd manager && TOOLHINT_URL=http://<host>:<port> [TOOLHINT_TOKEN=<token>] \
//     node e2e/shot-feat.mjs [outdir]
//
// 出力 (既定 screenshots/density/):
//   feat-edit-inject.png    きっかけ編集フォームの「届く文面」欄
//   feat-manual-inject.png  手動作成フォームの「届く文面」欄 (ことば種別)
//   feat-ask-kind.png       ask ペインのきっかけ種別セグメント
//   feat-propose-kw.png     ことばきっかけの実起案 (LLM を 1 回だけ呼ぶ) の確認画面
//
// 注意: propose は実サーバ経由で claude を呼ぶ (読み取りのみ)。起案結果は
// 保存しない (apply を押さないまま撮る)。
// =============================================================================
import { chromium } from 'playwright';
import { mkdirSync } from 'node:fs';
import path from 'node:path';

const BASE = (process.env.TOOLHINT_URL || 'http://127.0.0.1:4517').replace(/\/+$/, '');
const TOKEN = process.env.TOOLHINT_TOKEN || '';
const outdir = process.argv[2] || 'screenshots/density';
mkdirSync(outdir, { recursive: true });

const KW_REQUEST = '「デプロイ」の話題が出たら、デプロイ前チェックリストの docs を渡して';

let browser;
try { browser = await chromium.launch(); }
catch { browser = await chromium.launch({ channel: 'chrome' }); }

const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 } });
const page = await ctx.newPage();
const shot = async (name) => {
  const file = path.join(outdir, name);
  await page.screenshot({ path: file });
  console.log(file);
};

await page.goto(TOKEN ? `${BASE}/?token=${TOKEN}` : `${BASE}/`, { waitUntil: 'networkidle' });
await page.waitForTimeout(800); // フォント読み込み・初期描画の落ち着き待ち

// 1) きっかけ編集フォーム — 先頭のきっかけを編集で開く (保存はしない)
const editBtn = page.locator('#cond-list .rule-act[data-act=edit]').first();
if (await editBtn.count()) {
  await editBtn.click();
  await page.waitForSelector('#cond-list form.rule-edit-form [name=inject]');
  await page.focus('#cond-list form.rule-edit-form [name=inject]'); // help を出した状態で撮る
  await page.waitForTimeout(200);
  await shot('feat-edit-inject.png');
  await page.evaluate(() => {
    const b = document.querySelector('#cond-list form.rule-edit-form [data-act=edit-cancel]');
    if (b) b.click();
  });
} else {
  console.log('skip: きっかけを持つ doc が無いため feat-edit-inject.png は撮らない');
}

// 2) 手動作成フォーム (ことば種別) の届く文面欄
await page.click('#new-doc-btn');
await page.click('#tab-manual');
await page.click('#manual-kind-kw');
await page.focus('#manual-inject');
await page.waitForTimeout(200);
await shot('feat-manual-inject.png');

// 3) ask ペインの種別セグメント (ことばに反応を選んだ状態)
await page.click('#tab-ask');
await page.click('#ask-kind-kw');
await page.fill('#ask-input', KW_REQUEST);
await page.waitForTimeout(200);
await shot('feat-ask-kind.png');

// 4) 実起案 (claude を 1 回呼ぶ) → 確認画面。保存はしない
await page.click('#ask-btn');
try {
  await page.waitForSelector('#proposal:not([hidden])', { timeout: 240_000 });
  await page.waitForTimeout(300);
  await shot('feat-propose-kw.png');
} catch (e) {
  console.error(`起案に失敗 (スクショだけ残す): ${e.message}`);
  await shot('feat-propose-kw.png');
}

await ctx.close();
await browser.close();
