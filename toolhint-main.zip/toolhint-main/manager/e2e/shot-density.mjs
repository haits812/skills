#!/usr/bin/env node
// =============================================================================
// manager GUI の密度確認用スクショ (playwright / 実 docs 非破壊・読み取りのみ)
//
// 実行方法:
//   cd manager && TOOLHINT_URL=http://<host>:<port> TOOLHINT_TOKEN=<token> \
//     node e2e/shot-density.mjs <outdir> [prefix]
//
// 幅 1440×900 / 1920×1080 の 2 枚 (viewport のみ、フルページなし) を
// <outdir>/<prefix>-1440.png, <prefix>-1920.png へ保存する。
// =============================================================================
import { chromium } from 'playwright';
import { mkdirSync } from 'node:fs';
import path from 'node:path';

const BASE = process.env.TOOLHINT_URL || 'http://127.0.0.1:4517';
const TOKEN = process.env.TOOLHINT_TOKEN || '';
const outdir = process.argv[2] || 'screenshots/density';
const prefix = process.argv[3] || 'shot';
mkdirSync(outdir, { recursive: true });

const SIZES = [
  { w: 1440, h: 900 },
  { w: 1920, h: 1080 },
];

let browser;
try { browser = await chromium.launch(); }
catch { browser = await chromium.launch({ channel: 'chrome' }); }

for (const { w, h } of SIZES) {
  const ctx = await browser.newContext({ viewport: { width: w, height: h } });
  const page = await ctx.newPage();
  const url = TOKEN ? `${BASE}/?token=${TOKEN}` : `${BASE}/`;
  await page.goto(url, { waitUntil: 'networkidle' });
  await page.waitForTimeout(800); // フォント読み込み・初期描画の落ち着き待ち
  const file = path.join(outdir, `${prefix}-${w}.png`);
  await page.screenshot({ path: file });
  console.log(file);
  await ctx.close();
}
await browser.close();
