#!/usr/bin/env python3
"""toolhint core 契約モック (manager 開発用フィクスチャ)。

core/toolhint_core.py と同一の CLI / JSON 契約を実装する (manager 単体の開発・テスト用)。
manager の統合コード (server.mjs) は契約だけに依存し、core/toolhint_core.py が
存在すれば server が自動でそちらを使う (このモックは使われなくなる)。

契約:
  list     --cwd <path>
      → {"layers":[{"name","dir","exists","parse_error"}],
         "rules":[{"id","tool","match","doc","inject","mode","every","enabled",
                   "event","keywords","find","case",
                   "layer","overridden","doc_abs","doc_exists"}],
         "layer_errors":[{"layer","file","error"}]}
      (event は正規化 "tool"|"prompt"、keywords/find/case は生値透過 —
       real core と同じ。layer は "global"|"project"|"layers.d/<名前>" で、
       並びは読み順 layers.d/* → global → project、overridden は
       「後の層 (より手元) に同 id がある」。適用範囲つきのルールだけ
       "scope" キーが増える — 無いルールでは省略、これも real core と同じ。
       parse_error は層のルールファイルが engine パーサで読めない理由
       ("<ファイル名>: line N: ..."、健全なら null)、layer_errors は同じ
       情報のファイル単位一覧 (正常時 []) — engine が層ごと読み飛ばして
       rules が 0 件になる状態を、ルールが無い状態と区別するためのキー)
  dry-run  --cwd <path> --tool <name> --input <str> [--event tool|prompt]
      → {"matches":[{"id","layer","text"}]}
      (real core と同じく {"command": <input>} を JSON 文字列化した対象に match。
       --tool 経路は event: tool のルールのみ。--event=prompt は <input> を
       ユーザー発言として event: prompt のルールのみ判定。scope 付きルールは
       --cwd がそのパターンに一致するときだけ発火)
  add-rule --layer <l> --cwd <path> --rule <json> [--doc-content <str>]
      → {"ok":true,"rules_path":...,"doc_path":...} | {"ok":false,"error"}
      (--doc-content 省略時は doc を書かない = 既存 doc へのきっかけ追加。
       doc の無いルールは inject 必須 ({doc} 参照不可・--doc-content 不可) で
       doc_path は null — real core と同じ。
       書き込み先は scope の有無で決まる — 下記「層のルールファイル」)

層のルールファイルは 2 本: rules.yaml と rules-scoped.yaml (この順に読み、
同 id は後勝ち)。書式も扱いも同じで、適用範囲 (scope) 付きのルールを後者へ
置き分ける — この形式を知らない古い版の engine は rules.yaml しか読まないので、
scope 付きルールが「適用範囲を無視してどこでも発火する」事故が起きない。
  docs     --cwd <path>
      → {"docs":[{"name","path_abs","layer":"global|project|layers.d/<名前>","exists",
                  "inject_only":false,
                  "body_excerpt","triggers":[{"id","tool","match","every",
                  "mode","layer"}],"inject_count_7d"}]}
      (doc を持たないルール (inject の文面だけ) もルール 1 件 = 1 エントリで
       含める — {"name":null,"path_abs":null,"layer","exists":false,
       "inject_only":true,"body_excerpt":<inject の先頭 120 字>,
       "triggers":[<そのルール 1 件>],"inject_count_7d"}。その注入回数は
       doc 無しの記録を rule_id + 層で数え、project 層は記録の cwd がその
       プロジェクトの中にあるものだけ — real core と同じ)
  log      --cwd <path> --limit N
      → {"entries":[{"ts","session_id","cwd","tool_name","rule_id",
                     "layer","doc"}]}
      (新しい順。engine が書く <global>/log/injections.jsonl。
       ts は ISO8601 UTC "…Z"、doc は絶対パス — real core と同じ)
  save-doc --cwd <path> --layer <l> --doc-name <name.md> --content <str>
      → {"ok":true,"doc_path":...} | {"ok":false,"error"}
      (real core と同じく上書き前に .bak 退避)

依存: python3 標準ライブラリのみ。
"""

import argparse
import datetime
import fnmatch
import json
import os
import re
import shutil
import sys
import time

DEFAULT_POINTER_TEMPLATE = "この操作の docs: {doc} — 必要なら読む"

DEFAULT_POINTER_TEMPLATE_PROMPT = "この話題の docs: {doc} — 必要なら読む"

VALID_FINDS = ("substring", "word", "regex")


def _rule_event(rule):
    """engine の rule_event と同じ判別: `event: prompt` のみ prompt rule。
    キー無し = tool rule (後方互換)、それ以外の値は tool に倒す。"""
    v = rule.get("event")
    if v is None:
        return "tool"
    return "prompt" if str(v).strip() == "prompt" else "tool"


def _rule_enabled(rule):
    """engine の rule_enabled と同じ: `enabled: "false"` のみ無効 (既定は有効)。"""
    v = rule.get("enabled")
    if v is None:
        return True
    return str(v).strip().lower() != "false"


def _rule_find(rule):
    """prompt rule の find 正規化 (engine と同じ): 不正値は substring に倒す。"""
    v = rule.get("find")
    if v is None:
        return "substring"
    v = str(v).strip()
    return v if v in VALID_FINDS else "substring"


def split_prompt_keywords(keywords):
    """engine と同じ分割: `,` `、` `，` (全角カンマ) で分割 → trim → 空要素を除去。"""
    return [p.strip() for p in re.split(r"[,、，]", str(keywords)) if p.strip()]


def rule_in_scope(rule, cwd):
    """engine の rule_in_scope と同じ判定 — scope (作業ディレクトリの glob
    パターン) 付きのルールは cwd が一致するときだけ発火。scope 無しは常に True、
    cwd 不明・パターン不正は False (場所が分からないなら出さない)。"""
    scope = rule.get("scope")
    if scope is None:
        return True
    try:
        if not cwd:
            return False
        return fnmatch.fnmatch(os.path.abspath(os.path.expanduser(cwd)),
                               str(scope))
    except Exception:
        return False


# ---------------------------------------------------------------------------
# rules.yaml の読み書き (engine と同じ strict subset。構文外は MiniYamlError —
# 文言も engine と同じにして、list の parse_error / layer_errors を同形にする)
# ---------------------------------------------------------------------------

class MiniYamlError(ValueError):
    pass


_SINGLE_RE = re.compile(r"^'((?:[^']|'')*)'\s*(?:#.*)?$")
_DOUBLE_RE = re.compile(r'^"((?:[^"\\]|\\.)*)"\s*(?:#.*)?$')
_KV_RE = re.compile(r"^([A-Za-z0-9_\-]+):(?:\s+(.*))?$")
_RULES_RE = re.compile(r"^rules:\s*(?:#.*)?$")


def _unescape_double(s):
    """"double" クォート値の最小限の unescape (\\n \\t \\" \\\\)。
    未知のエスケープはそのまま残す (engine と同じ lenient 仕様)。"""
    out = []
    i = 0
    known = {"n": "\n", "t": "\t", '"': '"', "\\": "\\"}
    while i < len(s):
        c = s[i]
        if c == "\\" and i + 1 < len(s):
            n = s[i + 1]
            out.append(known.get(n, "\\" + n))
            i += 2
        else:
            out.append(c)
            i += 1
    return "".join(out)


def _parse_value(raw, lineno):
    raw = raw.strip()
    if raw.startswith("'"):
        m = _SINGLE_RE.match(raw)
        if not m:
            raise MiniYamlError("line %d: 不正な single quote 値" % lineno)
        return m.group(1).replace("''", "'")
    if raw.startswith('"'):
        m = _DOUBLE_RE.match(raw)
        if not m:
            raise MiniYamlError("line %d: 不正な double quote 値" % lineno)
        return _unescape_double(m.group(1))
    m = re.search(r"\s#", raw)  # プレーンスカラの行末コメント
    if m:
        raw = raw[: m.start()].rstrip()
    if raw == "":
        raise MiniYamlError("line %d: 値が空 (ネスト構造?)" % lineno)
    if raw[0] in "|>[{&*":
        raise MiniYamlError("line %d: 構文外の値: %r" % (lineno, raw))
    return raw


def _split_kv(s, lineno):
    m = _KV_RE.match(s)
    if not m:
        raise MiniYamlError("line %d: 'key: value' 形式でない: %r" % (lineno, s))
    if m.group(2) is None or m.group(2).strip() == "":
        raise MiniYamlError(
            "line %d: キー %r の値が空 (ネスト dict は構文外)" % (lineno, m.group(1)))
    return m.group(1), _parse_value(m.group(2), lineno)


def parse_rules_yaml(text):
    """strict subset をパースしてルール dict のリストを返す (engine と同じ規則・
    同じ文言)。構文外は MiniYamlError。"""
    rules = []
    current = None
    seen_rules_key = False
    effective_lines = 0
    for lineno, line in enumerate(text.splitlines(), 1):
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        effective_lines += 1
        indent = len(line) - len(line.lstrip(" \t"))
        if indent == 0:
            if _RULES_RE.match(stripped):
                if seen_rules_key:
                    raise MiniYamlError("line %d: rules: が重複" % lineno)
                seen_rules_key = True
                continue
            raise MiniYamlError("line %d: 構文外のトップレベル行: %r" % (lineno, stripped))
        if not seen_rules_key:
            raise MiniYamlError("line %d: rules: より前にインデント行" % lineno)
        if stripped == "-":
            current = {}
            rules.append(current)
        elif stripped.startswith("- "):
            current = {}
            rules.append(current)
            key, val = _split_kv(stripped[2:].strip(), lineno)
            current[key] = val
        else:
            if current is None:
                raise MiniYamlError("line %d: リスト要素の外に mapping 行" % lineno)
            key, val = _split_kv(stripped, lineno)
            current[key] = val
    if effective_lines == 0:
        return []
    if not seen_rules_key:
        raise MiniYamlError("トップレベル rules: キーがない")
    return rules


def parse_rules(text):
    """パース + 必須キーの選別 (engine の load_rules と同じ):
    tool rule → tool 必須 / prompt rule → keywords 必須
    (find が regex 以外は分割後の有効要素 1+ も必要)。構文外は MiniYamlError。"""
    out = []
    for r in parse_rules_yaml(text):
        if not r.get("id"):
            continue
        if _rule_event(r) == "prompt":
            if not r.get("keywords"):
                continue
            if _rule_find(r) != "regex" and not split_prompt_keywords(r["keywords"]):
                continue
        elif not r.get("tool"):
            continue
        out.append(r)
    return out


RULES_FILENAME = "rules.yaml"
SCOPED_RULES_FILENAME = "rules-scoped.yaml"
RULES_FILENAMES = (RULES_FILENAME, SCOPED_RULES_FILENAME)


def rules_filename(rule):
    """ルールを置くファイル名 — scope 付きは rules-scoped.yaml (real core と同じ)。"""
    return SCOPED_RULES_FILENAME if rule.get("scope") else RULES_FILENAME


def load_layer_rules(layer_dir):
    """層のルールファイル (rules.yaml → rules-scoped.yaml) をこの順に読む。
    どちらか 1 本でも読めなければ層全体を [] にする (engine と同じ)。"""
    out = []
    for name in RULES_FILENAMES:
        path = os.path.join(layer_dir, name)
        if not os.path.isfile(path):
            continue
        try:
            with open(path, "r", encoding="utf-8") as f:
                out += parse_rules(f.read())
        except Exception:
            return []
    return out


def layer_parse_errors(layer_dir):
    """層のルールファイルのうち engine パーサで読めないものを
    [(絶対パス, 理由), ...] で返す (real core と同じ形。健全なら [])。"""
    out = []
    for name in RULES_FILENAMES:
        path = os.path.join(os.path.abspath(layer_dir), name)
        if not os.path.isfile(path):
            continue
        try:
            with open(path, "r", encoding="utf-8") as f:
                parse_rules_yaml(f.read())
        except Exception as e:
            out.append((path, str(e)))
    return out


# real core (toolhint_core.py) の serialize_rule と同じ安全契約:
# 改行系の制御文字 (str.splitlines の行境界) は拒否、\n は \\n にエスケープした
# double quote 値で emit する — engine パーサと往復一致し rules.yaml を汚さない。
RULE_KEYS = ("id", "tool", "match", "doc", "inject", "mode", "every",
             "event", "keywords", "find", "case", "scope")
_FORBIDDEN_CHARS = "\r\x0b\x0c\x1c\x1d\x1e\x85\u2028\u2029"


def _yaml_quote(value, key):
    value = str(value)
    for ch in _FORBIDDEN_CHARS:
        if ch in value:
            raise ValueError(
                "キー %r の値に使用できない改行系文字 %r が含まれる" % (key, ch))
    escaped = (value.replace("\\", "\\\\").replace('"', '\\"')
               .replace("\n", "\\n").replace("\t", "\\t"))
    return '"%s"' % escaped


def emit_rule_block(rule):
    lines = []
    for key in RULE_KEYS:
        if not rule.get(key):
            continue
        prefix = "  - " if not lines else "    "
        lines.append("%s%s: %s" % (prefix, key, _yaml_quote(rule[key], key)))
    return "\n".join(lines) + "\n"


# ---------------------------------------------------------------------------
# 層の発見 (engine の find_global_dir / find_project_dir と同じ規則)
# ---------------------------------------------------------------------------

def global_dir():
    p = os.environ.get("TOOLHINT_GLOBAL")
    if p:
        return os.path.abspath(os.path.expanduser(p))
    return os.path.join(os.path.expanduser("~"), ".claude", "toolhint")


def extra_layers(gdir):
    """`<global層>/layers.d/<名前>/` の追加層を名前の辞書順で返す
    (engine の find_extra_layers と同じ規則)。返り値: [(表示名, dir), ...]。"""
    root = os.path.join(gdir, "layers.d")
    try:
        names = sorted(os.listdir(root))
    except OSError:
        return []
    out = []
    for name in names:
        if name.startswith("."):
            continue
        d = os.path.join(root, name)
        try:
            if not os.path.isdir(d):
                continue
        except OSError:
            continue
        out.append(("layers.d/%s" % name, d))
    return out


def ordered_layers(cwd, gdir):
    """読み順 layers.d/* → global → project の [(表示名, dir, exists), ...]
    (real core の read_layers と同じ)。"""
    p, p_exists = project_dir(cwd, gdir)
    layers = [(name, d, True) for name, d in extra_layers(gdir)]
    layers.append(("global", gdir, os.path.isdir(gdir)))
    layers.append(("project", p, p_exists))
    return layers


def project_dir(cwd, gdir):
    """cwd から上方向へ辿り最初の .claude/toolhint を探す。
    返り値: (dir, exists)。見つからなければ (<cwd>/.claude/toolhint, False)。
    解決済み global 層と同一の dir・既定 global 置き場 (~/.claude/toolhint) は
    project 層候補から除外する (engine の find_project_dir と同じ規則)。"""
    d = os.path.abspath(os.path.expanduser(cwd or os.getcwd()))
    default = os.path.join(d, ".claude", "toolhint")
    home = os.path.expanduser("~")
    excluded = {
        os.path.realpath(gdir),
        os.path.realpath(os.path.join(home, ".claude", "toolhint")),
    }
    try:  # HOME を差し替えたテスト環境でも、OS アカウント本来の home の既定置き場は除外
        import pwd
        account_home = pwd.getpwuid(os.getuid()).pw_dir
        if account_home:
            excluded.add(os.path.realpath(
                os.path.join(account_home, ".claude", "toolhint")))
    except Exception:
        pass  # 非 Unix 等 pwd が無い環境は HOME ベースの除外のみ
    cur = d
    while True:
        cand = os.path.join(cur, ".claude", "toolhint")
        if os.path.isdir(cand) and os.path.realpath(cand) not in excluded:
            return cand, True
        if cur == home:
            return default, False
        parent = os.path.dirname(cur)
        if parent == cur:
            return default, False
        cur = parent


# ---------------------------------------------------------------------------
# コマンド
# ---------------------------------------------------------------------------

def cmd_list(cwd):
    g = global_dir()
    ordered = ordered_layers(cwd, g)
    layers = []
    layer_errors = []
    for name, d, exists in ordered:
        errs = layer_parse_errors(d) if exists else []
        layers.append({
            "name": name, "dir": d, "exists": exists,
            "parse_error": "; ".join("%s: %s" % (os.path.basename(p), e)
                                     for p, e in errs) or None,
        })
        for p, e in errs:
            layer_errors.append({"layer": name, "file": p, "error": e})
    loaded = [(name, d, load_layer_rules(d) if exists else [])
              for name, d, exists in ordered]
    out = []
    for i, (layer_name, ldir, rlist) in enumerate(loaded):
        later_ids = set()
        for _n, _d, later in loaded[i + 1:]:
            later_ids.update(r["id"] for r in later)
        for r in rlist:
            doc = r.get("doc")
            doc_abs = os.path.abspath(os.path.join(ldir, doc)) if doc else None
            entry = {
                "id": r["id"],
                "tool": r.get("tool"),
                "match": r.get("match"),
                "doc": doc,
                "inject": r.get("inject"),
                "mode": r.get("mode", "pointer"),
                "every": r.get("every", "session"),
                "enabled": _rule_enabled(r),
                "event": _rule_event(r),
                "keywords": r.get("keywords"),
                "find": r.get("find"),
                "case": r.get("case"),
                "layer": layer_name,
                "overridden": r["id"] in later_ids,  # 後の層 (より手元) が勝つ
                "doc_abs": doc_abs,
                "doc_exists": bool(doc_abs and os.path.isfile(doc_abs)),
            }
            if r.get("scope"):  # 適用範囲つきのルールだけキーが増える
                entry["scope"] = r["scope"]
            out.append(entry)
    return {"layers": layers, "rules": out, "layer_errors": layer_errors}


def doc_within_layer(doc_path, layer_dir):
    """engine の doc_within_layer と同じ包含判定 (両辺 realpath)。"""
    layer_real = os.path.realpath(layer_dir)
    doc_real = os.path.realpath(doc_path)
    return doc_real == layer_real or doc_real.startswith(layer_real + os.sep)


def build_text(rule, layer_dir, restrict_doc=False):
    """engine の build_text と同じ規則で注入文面を作る。

    文面は event 別 (engine と同じ): prompt inline はヘッダ無しで本文
    そのまま、prompt の既定ポインタは「この話題の docs」。
    restrict_doc=True (追加層 layers.d のルール) は層 dir の外を指す doc を
    注入しない (engine と同じ制限)。"""
    rid = rule.get("id", "")
    doc = rule.get("doc")
    inject = rule.get("inject")
    mode = rule.get("mode", "pointer")
    is_prompt = _rule_event(rule) == "prompt"
    doc_abs = os.path.abspath(os.path.join(layer_dir, doc)) if doc else None
    if doc_abs and restrict_doc and not doc_within_layer(doc_abs, layer_dir):
        return None

    def expand(t):
        return t.replace("{doc}", doc_abs or "").replace("{id}", rid)

    if mode == "inline":
        if doc_abs and os.path.isfile(doc_abs):
            try:
                with open(doc_abs, "r", encoding="utf-8") as f:
                    body = f.read().rstrip("\n")
            except Exception:
                return None
            text = body if is_prompt \
                else "この操作の docs (%s):\n%s" % (rid, body)
            return (expand(inject) + "\n" + text) if inject else text
        if inject and "{doc}" not in inject:
            return expand(inject)
        return None
    if inject:
        if "{doc}" in inject and not (doc_abs and os.path.isfile(doc_abs)):
            return None
        return expand(inject)
    if doc_abs and os.path.isfile(doc_abs):
        return expand(DEFAULT_POINTER_TEMPLATE_PROMPT if is_prompt
                      else DEFAULT_POINTER_TEMPLATE)
    return None


def match_prompt(rule, prompt):
    """engine の rule_matches_prompt と同じ判定 (substring / word / regex,
    case: sensitive)。時間予算は mock では省略。"""
    keywords = rule.get("keywords")
    if not keywords or not isinstance(prompt, str) or prompt == "":
        return False
    find = _rule_find(rule)
    case_sensitive = str(rule.get("case") or "").strip() == "sensitive"
    try:
        if find == "regex":
            flags = 0 if case_sensitive else re.IGNORECASE
            return re.search(keywords, prompt, flags) is not None
        kws = split_prompt_keywords(keywords)
        if not kws:
            return False
        if find == "word":
            flags = 0 if case_sensitive else re.IGNORECASE
            return any(
                re.search(r"(?<![A-Za-z0-9_])%s(?![A-Za-z0-9_])" % re.escape(kw),
                          prompt, flags)
                for kw in kws)
        hay = prompt if case_sensitive else prompt.lower()
        return any((kw if case_sensitive else kw.lower()) in hay for kw in kws)
    except re.error:
        return False


def cmd_dry_run(cwd, tool, input_str, event="tool"):
    g = global_dir()
    # real core / engine と同じ意味論:
    #   tool は tool_name への fullmatch、match は {"command": <input>} を
    #   JSON 文字列化した flat への re.search (^ アンカー等の食い違いを作らない)
    #   --event=prompt は input_str をユーザー発言として prompt ルールのみ判定
    flat = json.dumps({"command": input_str}, ensure_ascii=False)
    # id → (rule, layer_name, layer_dir)。読み順 layers.d/* → global → project で
    # 後勝ち (= より手元の層が勝つ) — engine の merge_layers と同じ
    merged = {}
    for layer_name, ldir, ok in ordered_layers(cwd, g):
        if not ok:
            continue
        for r in load_layer_rules(ldir):
            merged[r["id"]] = (r, layer_name, ldir)
    matches = []
    for rid, (rule, layer_name, ldir) in merged.items():
        if not _rule_enabled(rule):
            continue  # enabled: false は engine 同様マッチ対象外 (マージ後に判定)
        if not rule_in_scope(rule, cwd):
            continue  # 適用範囲つきのルールは cwd が一致する場所でだけ発火
        if _rule_event(rule) != event:
            continue  # event フィルタ — rule["tool"] 直参照より前に絞る
        if event == "prompt":
            if not match_prompt(rule, input_str):
                continue
        else:
            try:
                if not re.fullmatch(rule["tool"], tool):
                    continue
                pat = rule.get("match")
                if pat is not None and not re.search(pat, flat):
                    continue
            except re.error:
                continue
        # 追加層のルールは層 dir 配下の doc のみ (engine / real core と同じ制限)
        text = build_text(rule, ldir,
                          restrict_doc=layer_name.startswith("layers.d/"))
        if text is None:
            continue
        matches.append({"id": rid, "layer": layer_name,
                        "text": "[toolhint] " + text})
    return {"matches": matches}


# ---------------------------------------------------------------------------
# docs / log / save-doc (新契約)
# ---------------------------------------------------------------------------

_DOC_NAME_RE = re.compile(r"^[A-Za-z0-9._\-]+\.md$")


def _excerpt(path, limit=120):
    """本文 1 行抜粋: 最初の非見出し非空行。無ければ見出しの # を剥がした行。"""
    try:
        with open(path, "r", encoding="utf-8") as f:
            text = f.read(4096)
    except Exception:
        return ""
    heading = ""
    for line in text.splitlines():
        s = line.strip()
        if not s:
            continue
        if s.startswith("#"):
            if not heading:
                heading = s.lstrip("#").strip()
            continue
        return s[:limit]
    return heading[:limit]


def _parse_ts(ts):
    if isinstance(ts, (int, float)):
        return float(ts)
    if isinstance(ts, str):
        try:
            return datetime.datetime.fromisoformat(
                ts.replace("Z", "+00:00")).timestamp()
        except ValueError:
            return 0.0
    return 0.0


def read_log(gdir):
    path = os.path.join(gdir, "log", "injections.jsonl")
    entries = []
    if not os.path.isfile(path):
        return entries
    try:
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    e = json.loads(line)
                except ValueError:
                    continue
                if isinstance(e, dict):
                    entries.append(e)
    except Exception:
        pass
    return entries


def _trigger_entry(r, layer_name):
    return {
        "id": r["id"],
        "tool": r.get("tool"),
        "match": r.get("match"),
        "every": r.get("every", "session"),
        "mode": r.get("mode", "pointer"),
        "enabled": _rule_enabled(r),
        "event": _rule_event(r),
        "keywords": r.get("keywords"),
        "find": r.get("find"),
        "case": r.get("case"),
        "layer": layer_name,
    }


def _inject_only_count(recent, rule_id, layer_name, ldir):
    """doc を持たないルールの注入回数 — doc 無しの記録を rule_id + 層で数える。
    project 層は記録の cwd がそのプロジェクト (層 dir の root) の中にあるものだけ
    (real core と同じ)。"""
    root = None
    if layer_name == "project":
        root = os.path.abspath(os.path.join(ldir, os.pardir, os.pardir))
    n = 0
    for e in recent:
        if e.get("doc") or e.get("rule_id") != rule_id \
                or e.get("layer") != layer_name:
            continue
        if root is not None:
            cwd = e.get("cwd")
            if not isinstance(cwd, str) or not cwd:
                continue
            cwd_abs = os.path.abspath(cwd)
            if cwd_abs != root and not cwd_abs.startswith(root + os.sep):
                continue
        n += 1
    return n


def cmd_docs(cwd):
    g = global_dir()
    week_ago = time.time() - 7 * 86400
    recent = [e for e in read_log(g) if _parse_ts(e.get("ts")) >= week_ago]
    docs = []
    inject_only = []  # doc を持たないルール (ルール 1 件 = 1 エントリ)
    seen = set()  # 同じ doc を複数層のルールが指す場合は先に読んだ層の 1 件だけ
    for layer_name, ldir, ok in ordered_layers(cwd, g):  # 追加層 (layers.d/*) も含む
        if not ok:
            continue
        # doc は層 dir からの相対パスとして解決する (real core と同じ — basename では
        # サブディレクトリや層外を指す doc の場所を取り違える)
        by_path = {}
        for r in load_layer_rules(ldir):
            doc = r.get("doc")
            if not doc:
                # inject の文面だけを届けるルール — 同じ文面でも id が違えば別の 1 件
                inject = r.get("inject")
                inject_only.append({
                    "name": None,
                    "path_abs": None,
                    "layer": layer_name,
                    "exists": False,
                    "inject_only": True,
                    "body_excerpt": str(inject)[:120] if inject else None,
                    "triggers": [_trigger_entry(r, layer_name)],
                    "inject_count_7d": _inject_only_count(
                        recent, r["id"], layer_name, ldir),
                })
                continue
            by_path.setdefault(
                os.path.abspath(os.path.join(ldir, doc)), []).append(r)
        paths = set(by_path)
        ddir = os.path.join(ldir, "docs")
        if os.path.isdir(ddir):  # どのルールからも参照されない doc も一覧に出す
            for fn in os.listdir(ddir):
                if fn.endswith(".md"):
                    paths.add(os.path.abspath(os.path.join(ddir, fn)))
        for path_abs in sorted(paths):
            if path_abs in seen:
                continue
            seen.add(path_abs)
            exists = os.path.isfile(path_abs)
            triggers = [_trigger_entry(r, layer_name)
                        for r in by_path.get(path_abs, [])]
            count = 0  # 注入回数は doc の絶対パス一致で数える (real core と同じ)
            for e in recent:
                if e.get("doc") == path_abs:
                    count += 1
            docs.append({
                "name": os.path.basename(path_abs),
                "path_abs": path_abs,
                "layer": layer_name,
                "exists": exists,
                "inject_only": False,
                "body_excerpt": _excerpt(path_abs) if exists else "",
                "triggers": triggers,
                "inject_count_7d": count,
            })
    return {"docs": docs + inject_only}


def cmd_log(cwd, limit):
    entries = read_log(global_dir())
    entries.sort(key=lambda e: _parse_ts(e.get("ts")), reverse=True)
    return {"entries": entries[:max(0, limit)]}


def cmd_save_doc(cwd, layer, doc_name, content):
    if not _DOC_NAME_RE.match(doc_name or "") or ".." in doc_name:
        return {"ok": False, "error": "doc-name が不正 (docs/ 直下の *.md のみ): %r" % doc_name}
    g = global_dir()
    if layer == "global":
        ldir = g
    elif layer == "project":
        ldir, _ = project_dir(cwd, g)
    else:
        return {"ok": False, "error": "layer は global | project: %r" % layer}
    ddir = os.path.join(ldir, "docs")
    path = os.path.abspath(os.path.join(ddir, doc_name))
    ddir_abs = os.path.abspath(ddir)
    if os.path.dirname(path) != ddir_abs:
        return {"ok": False, "error": "doc パスが docs/ の外: %r" % doc_name}
    os.makedirs(ddir_abs, exist_ok=True)
    if os.path.isfile(path):
        shutil.copy2(path, path + ".bak")  # real core と同じく旧内容を退避
    with open(path, "w", encoding="utf-8") as f:
        f.write(content if content.endswith("\n") else content + "\n")
    return {"ok": True, "doc_path": path, "layer": layer, "mock": True}


def cmd_add_rule(layer, cwd, rule_json, doc_content):
    try:
        rule = json.loads(rule_json)
    except Exception as e:
        return {"ok": False, "error": "rule JSON をパースできない: %s" % e}
    if not isinstance(rule, dict) or not rule.get("id"):
        return {"ok": False, "error": "rule に id が必要"}
    # 必須は event 別 (real core の validate_event_keys 相当の入口だけ再現)
    if _rule_event(rule) == "prompt":
        if not rule.get("keywords"):
            return {"ok": False, "error": "event: prompt の rule に keywords が必要"}
    elif not rule.get("tool"):
        return {"ok": False, "error": "rule に id / tool が必要"}
    # doc の無いルールは inject 必須 ({doc} 参照不可)・--doc-content 不可 (real core と同じ)
    if not rule.get("doc"):
        if not rule.get("inject"):
            return {"ok": False,
                    "error": "rule に doc も inject もない — マッチしても注入するものが無い"}
        if "{doc}" in str(rule.get("inject")):
            return {"ok": False,
                    "error": "doc が無いのに inject が {doc} を参照している"}
        if doc_content:
            return {"ok": False,
                    "error": "doc の無いルールに --doc-content は使えない"}
    g = global_dir()
    if layer == "global":
        ldir = g
    elif layer == "project":
        ldir, _ = project_dir(cwd, g)
    else:
        return {"ok": False, "error": "layer は global | project: %r" % layer}

    existing = load_layer_rules(ldir)
    if any(r["id"] == rule["id"] for r in existing):
        return {"ok": False,
                "error": "id %r は %s 層に既に存在する" % (rule["id"], layer)}

    try:
        block = emit_rule_block(rule)  # 改行系の禁止文字は書き込み前に ValueError
    except ValueError as e:
        return {"ok": False, "error": str(e)}

    os.makedirs(ldir, exist_ok=True)
    ldir_real = os.path.realpath(ldir)

    doc_path = None
    if rule.get("doc") and doc_content:
        doc_path = os.path.abspath(os.path.join(ldir, rule["doc"]))
        parent_real = os.path.realpath(os.path.dirname(doc_path))
        if not (parent_real == ldir_real or
                parent_real.startswith(ldir_real + os.sep)):
            return {"ok": False, "error": "doc パスが層ディレクトリの外: %r" % rule["doc"]}
        os.makedirs(os.path.dirname(doc_path), exist_ok=True)
        with open(doc_path, "w", encoding="utf-8") as f:
            f.write(doc_content if doc_content.endswith("\n") else doc_content + "\n")

    # 置き先は scope の有無で決まる (real core と同じ)
    ry = os.path.join(ldir, rules_filename(rule))
    if os.path.isfile(ry):
        with open(ry, "r", encoding="utf-8") as f:
            cur = f.read()
        if cur.strip() == "":
            cur = "rules:\n"
        elif not cur.endswith("\n"):
            cur += "\n"
        with open(ry, "w", encoding="utf-8") as f:
            f.write(cur + "\n" + block)
    else:
        with open(ry, "w", encoding="utf-8") as f:
            f.write("rules:\n" + block)
    return {"ok": True, "layer": layer, "layer_dir": ldir,
            "rules_path": ry, "doc_path": doc_path, "mock": True}


def main():
    ap = argparse.ArgumentParser(prog="toolhint_core_mock")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p1 = sub.add_parser("list")
    p1.add_argument("--cwd", default=os.getcwd())
    p2 = sub.add_parser("dry-run")
    p2.add_argument("--cwd", default=os.getcwd())
    p2.add_argument("--event", default="tool", choices=["tool", "prompt"])
    p2.add_argument("--tool", default="")
    p2.add_argument("--input", required=True)
    p3 = sub.add_parser("add-rule")
    p3.add_argument("--layer", required=True)
    p3.add_argument("--cwd", default=os.getcwd())
    p3.add_argument("--rule", required=True)
    p3.add_argument("--doc-content", default="")
    p4 = sub.add_parser("docs")
    p4.add_argument("--cwd", default=os.getcwd())
    p5 = sub.add_parser("log")
    p5.add_argument("--cwd", default=os.getcwd())
    p5.add_argument("--limit", type=int, default=50)
    p6 = sub.add_parser("save-doc")
    p6.add_argument("--cwd", default=os.getcwd())
    p6.add_argument("--layer", required=True)
    p6.add_argument("--doc-name", required=True)
    p6.add_argument("--content", required=True)
    a = ap.parse_args()
    if a.cmd == "list":
        out = cmd_list(a.cwd)
    elif a.cmd == "dry-run":
        out = cmd_dry_run(a.cwd, a.tool, a.input, a.event)
    elif a.cmd == "docs":
        out = cmd_docs(a.cwd)
    elif a.cmd == "log":
        out = cmd_log(a.cwd, a.limit)
    elif a.cmd == "save-doc":
        out = cmd_save_doc(a.cwd, a.layer, a.doc_name, a.content)
    else:
        out = cmd_add_rule(a.layer, a.cwd, a.rule, a.doc_content)
    sys.stdout.write(json.dumps(out, ensure_ascii=False) + "\n")


if __name__ == "__main__":
    main()
