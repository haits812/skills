#!/usr/bin/env python3
"""manager 保存経路の実書き込み e2e テスト。

GUI の保存 (public/app.js が POST /api/savedoc へ送る {cwd, layer, doc_name,
content} と同一形のリクエスト) → server.mjs → real core (core/toolhint_core.py
save-doc) → 実ファイル、の縦貫を検証する:

  1. ファイル内容一致  — 保存した content が層の docs/<name>.md に byte 一致で届く
  2. .bak 生成         — 上書き時に旧内容が docs/<name>.md.bak へ退避される
  3. atomic            — 書き込み後に tmp 残骸 (.<name>.*.tmp) が残らない
  4. auto-commit       — backup-init 済み層への保存で git commit が積まれる
  5. 届く文面 (inject) — GUI の「届く文面」欄が送る形 (apply の inject /
     rule/update の patch inject: null) で rules.yaml に入り・消え、
     dry-run の実文面 (engine build_text) がそのとおりに変わる
  6. ことばきっかけ    — event: prompt + inject の apply → dry-run --event=prompt。
     doc を持たないルール (inject の文面だけ) が /api/docs に inject_only の
     エントリとして 1 件載り、きっかけの総数が /api/state の rules 総数と一致
     すること (一覧の「ルール N」の根拠)。文面を空にする patch は 409
  7. AI 起案 (kind=kw) — /api/propose の LLM 出力を env スタブに差し替え、
     ことばきっかけの起案 JSON 検証・自己検証 (発火しない起案の retry)・
     既存ルールとの overlap 検査が実際に働くことを LLM 抜きで確認する
  8. AI 起案の attach_to — 既存 doc への「きっかけ追加」の縦貫 (起案 → GUI と
     同形の apply → 実書き込み)。実在しない doc への attach_to (幻覚) は retry
     で自己修正 or 502 で人の承認前に止まり、本文なし apply × 実在しない doc は
     人が読める 400 になること (保存失敗を人の手前で止める)。keywords の区切りは
     engine と同じ 3 種 (`,` `、` `，`) — 全角カンマだけは「区切り文字だけ」で
     弾かれ、全角カンマ区切りは 2 語に割れて発火すること
  9. 追加層 (layers.d)  — <global層>/layers.d/<名前>/ が state / docs に層名
     付きで載り、そこへの書き込み (savedoc / apply / rule 操作) は 400 で断られ
     ファイルが無傷であること (読み取り専用の配布物)
 10. 読めない層の告知    — ルールファイルが engine のパーサで読めない層は
     GET /api/state の layer_errors ([{layer, file, error}]) と
     layers[].parse_error に載り、GUI (app.js renderLayerErrors) の警告帯まで
     届くこと。core の実出力と、TOOLHINT_CORE 差し替え (server が中身を
     加工せず通すか) の 2 経路で見る (別 scenario / 別 server)
  他: 応答の core が "real" (mock へ落ちていない) / 層 dir が env 差し替え先 /
      project 層への保存先 / doc_name traversal の 403 / 実データ無汚染

実データを汚さない仕組み: server.mjs の子プロセス (python3 core) は server の
env を継承するため、server を TOOLHINT_GLOBAL=<一時dir> (engine の
find_global_dir が参照) + HOME=<一時dir> で起動すると、global 層 / project 層 /
engine 検知の全読み書きが一時 dir に閉じる。テスト末尾で実 global 層に
テスト doc が存在しないことも確認する。

実行: python3 manager/fixtures/test_savedoc_e2e.py
前提: node (server.mjs 起動用) / python3。git 不在時は auto-commit 検証のみ skip。
"""

import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(os.path.dirname(HERE))
SERVER = os.path.join(os.path.dirname(HERE), "server.mjs")
REAL_CORE = os.path.join(REPO, "core", "toolhint_core.py")

FAILURES = []


def check(name, cond, detail=""):
    if cond:
        print("  ok: %s" % name)
    else:
        print("  NG: %s %s" % (name, detail))
        FAILURES.append(name)


def http_json(method, url, body=None):
    """(status, parsed_json) を返す。4xx/5xx も JSON body を読む。"""
    data = json.dumps(body).encode("utf-8") if body is not None else None
    req = urllib.request.Request(
        url, data=data, method=method,
        headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return r.status, json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        raw = e.read().decode("utf-8", "replace")
        try:
            return e.code, json.loads(raw)
        except ValueError:
            return e.code, {"_raw": raw}


def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


def wait_ready(base, cwd, proc, timeout_s=20):
    """server が /api/state に応答するまで待つ (real core probe 込み)。"""
    deadline = time.time() + timeout_s
    last = None
    while time.time() < deadline:
        if proc.poll() is not None:
            return None
        try:
            status, obj = http_json(
                "GET", "%s/api/state?cwd=%s" % (base, urllib.request.quote(cwd)))
            if status == 200:
                return obj
            last = (status, obj)
        except (urllib.error.URLError, OSError, ValueError) as e:
            last = e
        time.sleep(0.2)
    print("  server が起動しない: %r" % (last,))
    return None


def run_core(args, env):
    p = subprocess.run([sys.executable, REAL_CORE] + args,
                       capture_output=True, text=True, env=env, timeout=60)
    try:
        return json.loads(p.stdout)
    except ValueError:
        return {"_no_json": True, "stdout": p.stdout, "stderr": p.stderr}


def git_out(gdir, args):
    p = subprocess.run(["git", "-C", gdir] + args,
                       capture_output=True, text=True, timeout=30)
    return p.returncode, p.stdout.strip()


def read_file(path):
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def tmp_residue(docs_dir):
    """atomic write の tmp 残骸 (dot 始まり *.tmp) と未知ファイルの一覧。"""
    if not os.path.isdir(docs_dir):
        return []
    return [f for f in os.listdir(docs_dir)
            if f.endswith(".tmp") or f.startswith(".")]


def find_rule(env, proj, rule_id):
    """core list から 1 ルールを引く (無ければ None)。"""
    out = run_core(["list", "--cwd=%s" % proj], env)
    return next((r for r in out.get("rules", []) if r.get("id") == rule_id), None)


# dry-run が返す text は engine が注入する完成品 (先頭に注入マーカーが付く)
INJECT_PREFIX = "[toolhint] "


def dryrun_text(env, proj, rule_id, *args):
    """core dry-run で rule_id の実文面 (engine build_text の結果) を取る。"""
    out = run_core(["dry-run", "--cwd=%s" % proj] + list(args), env)
    m = next((x for x in out.get("matches", []) if x.get("id") == rule_id), None)
    return m.get("text") if m else None


# /api/propose の LLM 出力スタブ (TOOLHINT_AGENT_STUB) — 1 リクエスト最大 2 試行なので
# 4 個並べて 2 リクエストぶんを仕込む:
#   1,2 個目 = sample_prompt 欠落 (自己検証の入力が無い) → 2 試行とも拒否されて 502
#   3 個目   = sample_prompt が keywords に一致しない「発火しない起案」→ retry
#   4 個目   = 正しい起案 → 200 (返る sample_prompt は 4 個目のもの)
STUB_KW_BAD = {
    "rule": {"id": "e2e-propose-kw", "event": "prompt", "keywords": "デプロイ, deploy",
             "doc": "docs/e2e-propose-kw.md",
             "inject": "この話題の docs: {doc} — デプロイ手順 ({id})"},
    "doc_name": "e2e-propose-kw.md",
    "doc_content": "# デプロイ\n\nデプロイの作り方は docs を読む。\n",
    "sample_prompt": "まったく関係のない依頼文",
    "rationale": "(stub) 発火しない起案 — 自己検証で弾かれるはず",
}
STUB_KW_GOOD = dict(STUB_KW_BAD, sample_prompt="デプロイを作りたい")
STUB_KW_NOSAMPLE = {k: v for k, v in STUB_KW_BAD.items() if k != "sample_prompt"}
# 全角カンマ `，` (U+FF0C) は `,` / `、` と同じ区切り — server の起案検証も engine と
# 同じ 3 種で割る。`，` だけの keywords は「区切り文字だけ」で弾き、
# 「本番，ほんばん」は 2 語として通る (sample_prompt に「本番」で発火)
STUB_KW_FW_EMPTY = {
    "rule": {"id": "e2e-fw-empty", "event": "prompt", "keywords": "，，"},
    "doc_name": "e2e-fw-empty.md", "doc_content": "# 全角カンマだけ\n",
    "sample_prompt": "本番に出す",
    "rationale": "(stub) 全角カンマだけの keywords — 区切り文字だけで弾かれるはず",
}
STUB_KW_FW_OK = {
    "rule": {"id": "e2e-fw-ok", "event": "prompt", "keywords": "本番，ほんばん"},
    "doc_name": "e2e-fw-ok.md", "doc_content": "# 本番\n\n本番に出す前の確認。\n",
    "sample_prompt": "本番に出す",
    "rationale": "(stub) 全角カンマ区切り — 2 語に割れて発火するはず",
}


def stub_attach(rid, target):
    """attach_to 起案 (既存 doc へのきっかけ追加) のスタブ — 本文を持たない。"""
    return {"rule": {"id": rid, "event": "prompt", "keywords": "リリース, release",
                     "inject": "この話題の docs: {doc} — リリース手順"},
            "attach_to": target,
            "sample_prompt": "リリースをまとめたい",
            "rationale": "(stub) 既存 doc へのきっかけ追加"}


def scenario(td):
    gdir = os.path.join(td, "global")
    home = os.path.join(td, "home")
    proj = os.path.join(td, "proj")
    os.makedirs(home)
    os.makedirs(os.path.join(proj, ".claude", "toolhint"))

    # 追加層 (読み取り専用の共有ルール) — 一覧に出るが書き込みは拒否されること
    team = os.path.join(gdir, "layers.d", "team")
    os.makedirs(os.path.join(team, "docs"))
    with open(os.path.join(team, "docs", "team.md"), "w", encoding="utf-8") as f:
        f.write("# team\n共有ルールの本文\n")
    with open(os.path.join(team, "rules.yaml"), "w", encoding="utf-8") as f:
        f.write("rules:\n  - id: e2e-team\n    tool: Bash\n    match: teamcmd\n"
                "    doc: docs/team.md\n")

    # 8) attach_to 起案の紐づけ先 (5 で apply が作る doc)。stub は server 起動前に
    # 確定させる必要があるため、doc 名だけ先に決めておく
    doc2 = "e2e-inject-%d.md" % os.getpid()
    attach_ok = "docs/%s" % doc2
    ghost = "docs/e2e-ghost.md"

    # server 起動 — 子プロセス (python3 core) へ env が継承され層 dir が差し替わる
    # スタブは 1 リクエスト最大 2 試行ぶんを呼び出し順に消費する (下の 7 と 8 の
    # リクエスト順と 1:1 — 途中に /api/propose を足すときは並びも直すこと)
    port = free_port()
    base = "http://127.0.0.1:%d" % port
    env = dict(os.environ, TOOLHINT_GLOBAL=gdir, HOME=home,
               PORT=str(port), HOST="127.0.0.1",
               TOOLHINT_AGENT_STUB="\x1e".join(
                   json.dumps(x, ensure_ascii=False) for x in
                   [STUB_KW_NOSAMPLE, STUB_KW_NOSAMPLE,          # 7: 502
                    STUB_KW_BAD, STUB_KW_GOOD,                   # 7: retry → 200
                    stub_attach("e2e-attach-a", attach_ok),      # 8a: 一発 200
                    stub_attach("e2e-attach-b", ghost),          # 8b: 幻覚 → retry
                    stub_attach("e2e-attach-b", attach_ok),      # 8b: 修正 → 200
                    stub_attach("e2e-attach-c", ghost),          # 8c: 幻覚 ×2
                    stub_attach("e2e-attach-c", ghost),          # 8c: → 502
                    {"rule": {"id": "e2e-attach-d", "event": "prompt",
                              "keywords": "リリース, release"},
                     "doc_name": doc2, "doc_content": "# 別内容\n",
                     "sample_prompt": "リリースをまとめたい",
                     "rationale": "(stub) 既存名の新規 doc — 弾かれるはず"},  # 8d: 衝突 → retry
                    stub_attach("e2e-attach-d", attach_ok),      # 8d: attach へ矯正 → 200
                    {"rule": {"id": "e2e-attach-e", "event": "prompt",
                              "keywords": "リリース, release", "doc": ghost},
                     "doc_name": "e2e-newdoc.md", "doc_content": "# 新規\n",
                     "sample_prompt": "リリースをまとめたい",
                     "rationale": "(stub) doc_name と rule.doc の食い違い"},  # 8e: 正規化 → 200
                    # 8g: 全角カンマ `，` だけの keywords — 区切り文字のみとして 2 回とも拒否 → 502
                    STUB_KW_FW_EMPTY, STUB_KW_FW_EMPTY,
                    # 8h: 全角カンマ区切り「本番，ほんばん」— 2 語に割れて sample に発火 → 200
                    STUB_KW_FW_OK]))
    env.pop("TOOLHINT_CORE", None)  # probe 経由で real core が選ばれる経路を検証
    proc = subprocess.Popen(
        ["node", SERVER], env=env, cwd=REPO,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

    doc = "e2e-savedoc-%d.md" % os.getpid()
    v1 = "# e2e doc v1\n日本語と \"quote\" と 'single'\nline3 🚀\n"
    v2 = "# e2e doc v2\n上書き後の内容\n"
    v3 = "# e2e doc v3\nauto-commit 検証用\n"
    doc_abs = os.path.join(gdir, "docs", doc)
    docs_dir = os.path.join(gdir, "docs")

    try:
        state = wait_ready(base, proj, proc)
        check("server が起動して /api/state 応答", state is not None)
        if state is None:
            return
        check("api/state: core が real (mock へ落ちていない)",
              state.get("core") == "real", state.get("core"))
        gl = next((l for l in state.get("layers", [])
                   if l.get("name") == "global"), {})
        check("api/state: global 層 dir が TOOLHINT_GLOBAL の一時 dir",
              os.path.realpath(gl.get("dir") or "") == os.path.realpath(gdir),
              gl)

        # --- 0) 追加層 (layers.d) — 読めるが書けない -----------------------
        tl = next((l for l in state.get("layers", [])
                   if l.get("name") == "layers.d/team"), {})
        check("api/state: 追加層が layers.d/<名前> として載る",
              os.path.realpath(tl.get("dir") or "") == os.path.realpath(team), tl)
        trule = next((r for r in state.get("rules", [])
                      if r.get("id") == "e2e-team"), {})
        check("api/state: 追加層のルールの層名が layers.d/team",
              trule.get("layer") == "layers.d/team", trule)
        status, dl = http_json(
            "GET", "%s/api/docs?cwd=%s" % (base, urllib.request.quote(proj)))
        tdoc = next((d for d in dl.get("docs", [])
                     if d.get("path_abs") == os.path.join(team, "docs", "team.md")),
                    {})
        check("api/docs: 追加層の doc が層名付きで載る",
              tdoc.get("layer") == "layers.d/team"
              and [t["id"] for t in tdoc.get("triggers", [])] == ["e2e-team"], tdoc)
        team_before = read_file(os.path.join(team, "docs", "team.md"))
        status, out = http_json("POST", base + "/api/savedoc",
                                {"cwd": proj, "layer": "layers.d/team",
                                 "doc_name": "team.md", "content": "上書き"})
        check("savedoc: 追加層への保存は 400 (読み取り専用)", status == 400, (status, out))
        status, out = http_json("POST", base + "/api/apply",
                                {"cwd": proj, "layer": "layers.d/team",
                                 "rule": {"id": "e2e-team-2", "tool": "Bash",
                                          "doc": "docs/team.md"},
                                 "doc_content": "x\n"})
        check("apply: 追加層への追加は 400 (読み取り専用)", status == 400, (status, out))
        status, out = http_json("POST", base + "/api/rule/toggle",
                                {"cwd": proj, "id": "e2e-team",
                                 "layer": "layers.d/team", "enabled": False})
        check("rule/toggle: 追加層の層指定は 400", status == 400, (status, out))
        check("追加層のファイルは無傷",
              read_file(os.path.join(team, "docs", "team.md")) == team_before
              and not os.path.exists(os.path.join(team, "docs", "team.md.bak")))

        # --- 1) 新規保存 (global): 内容一致 -------------------------------
        status, out = http_json("POST", base + "/api/savedoc",
                                {"cwd": proj, "layer": "global",
                                 "doc_name": doc, "content": v1})
        check("savedoc(新規): 200 + ok:true",
              status == 200 and out.get("ok") is True, (status, out))
        check("savedoc(新規): core が real", out.get("core") == "real", out)
        check("savedoc(新規): doc_path が一時 global 層内",
              os.path.realpath(out.get("doc_path") or "")
              == os.path.realpath(doc_abs), out)
        check("savedoc(新規): ファイル内容一致 (改行・日本語・引用符込み)",
              os.path.isfile(doc_abs) and read_file(doc_abs) == v1,
              doc_abs)
        check("savedoc(新規): 新規なので .bak なし",
              not os.path.exists(doc_abs + ".bak"), os.listdir(docs_dir))

        # --- 2) 上書き: .bak 退避 + 内容一致 -------------------------------
        status, out = http_json("POST", base + "/api/savedoc",
                                {"cwd": proj, "layer": "global",
                                 "doc_name": doc, "content": v2})
        check("savedoc(上書き): 200 + ok:true",
              status == 200 and out.get("ok") is True, (status, out))
        check("savedoc(上書き): ファイル内容が新内容",
              read_file(doc_abs) == v2, repr(read_file(doc_abs)))
        check("savedoc(上書き): .bak に旧内容が退避",
              os.path.isfile(doc_abs + ".bak")
              and read_file(doc_abs + ".bak") == v1,
              os.listdir(docs_dir))

        # --- 3) atomic: tmp 残骸なし --------------------------------------
        residue = tmp_residue(docs_dir)
        check("atomic: docs/ に tmp 残骸 (.* / *.tmp) なし", not residue, residue)
        check("atomic: docs/ は期待ファイルのみ",
              sorted(os.listdir(docs_dir)) == sorted([doc, doc + ".bak"]),
              os.listdir(docs_dir))

        # --- traversal は server が 403 で拒否 (実ファイルも作られない) -----
        status, out = http_json("POST", base + "/api/savedoc",
                                {"cwd": proj, "layer": "global",
                                 "doc_name": "../evil.md", "content": "x"})
        check("savedoc(traversal): 403", status == 403, (status, out))
        check("savedoc(traversal): 層 dir 直下に evil.md が作られない",
              not os.path.exists(os.path.join(gdir, "evil.md")),
              os.listdir(gdir))

        # --- project 層への保存 -------------------------------------------
        status, out = http_json("POST", base + "/api/savedoc",
                                {"cwd": proj, "layer": "project",
                                 "doc_name": doc, "content": v1})
        proj_doc = os.path.join(proj, ".claude", "toolhint", "docs", doc)
        check("savedoc(project): 200 + ok:true",
              status == 200 and out.get("ok") is True, (status, out))
        check("savedoc(project): <cwd>/.claude/toolhint/docs/ に内容一致",
              os.path.isfile(proj_doc) and read_file(proj_doc) == v1,
              out.get("doc_path"))

        # --- 4) backup-init 済み層への保存で auto-commit ------------------
        if shutil.which("git") is None:
            print("  skip: git 不在のため auto-commit 検証を省略")
        else:
            out = run_core(["backup-init", "--cwd=%s" % proj, "--layer=global"],
                           env)
            check("backup-init: ok:true (initialized)",
                  out.get("ok") is True and out.get("initialized") is True, out)
            rc, n0 = git_out(gdir, ["rev-list", "--count", "HEAD"])
            check("backup-init: 初回 commit が 1 件", rc == 0 and n0 == "1",
                  (rc, n0))
            status, out = http_json("POST", base + "/api/savedoc",
                                    {"cwd": proj, "layer": "global",
                                     "doc_name": doc, "content": v3})
            check("savedoc(backup後): 200 + ok:true",
                  status == 200 and out.get("ok") is True, (status, out))
            rc, n1 = git_out(gdir, ["rev-list", "--count", "HEAD"])
            check("auto-commit: 保存で commit が積まれる (1→2)",
                  rc == 0 and n1 == "2", (rc, n1))
            rc, subj = git_out(gdir, ["log", "-n1", "--format=%s"])
            check("auto-commit: メッセージが save-doc の対象を指す",
                  rc == 0 and subj == "toolhint save-doc: docs/%s" % doc,
                  subj)
            rc, porcelain = git_out(gdir, ["status", "--porcelain"])
            check("auto-commit: 層 dir に未追跡の残骸なし (bak/.lock は ignore)",
                  rc == 0 and porcelain == "", porcelain)

        # --- 5) 届く文面 (inject) — GUI の欄が送る形で書き込み → 削除 -------
        # doc は別名 doc2 を使う (上の atomic / auto-commit 検査の期待ファイル一覧を
        # 汚さない)。doc2 の名前自体は stub の都合で scenario 冒頭で確定済み
        doc2_abs = os.path.join(gdir, "docs", doc2)
        op_id = "e2e-inject-op"
        op_inject = "この操作の docs: {doc} — {id} の注意"
        status, out = http_json("POST", base + "/api/apply", {
            "cwd": proj, "layer": "global",
            "rule": {"id": op_id, "tool": "Bash", "match": r"\bgrep\b",
                     "doc": "docs/%s" % doc2, "inject": op_inject},
            "doc_name": doc2, "doc_content": "# inject 検証用\n本文。\n"})
        check("apply(inject 付き): 200 + ok:true",
              status == 200 and out.get("ok") is True, (status, out))
        rules_text = read_file(os.path.join(gdir, "rules.yaml"))
        check("apply(inject 付き): rules.yaml に inject が入る",
              ('inject: "%s"' % op_inject) in rules_text, rules_text)
        r = find_rule(env, proj, op_id)
        check("apply(inject 付き): core list の inject が一致",
              r is not None and r.get("inject") == op_inject, r)
        expanded = INJECT_PREFIX + op_inject.replace("{doc}", doc2_abs).replace("{id}", op_id)
        check("apply(inject 付き): dry-run の実文面が inject の展開結果",
              dryrun_text(env, proj, op_id, "--tool=Bash", "--input=grep -r foo .")
              == expanded, dryrun_text(env, proj, op_id, "--tool=Bash",
                                       "--input=grep -r foo ."))

        # 欄を空にして保存 = patch inject: null (キー削除 → 標準文面へ戻る)
        status, out = http_json("POST", base + "/api/rule/update", {
            "cwd": proj, "id": op_id, "layer": "global",
            "patch": {"tool": "Bash", "match": r"\bgrep\b", "every": None,
                      "inject": None}})
        check("rule/update(inject 空): 200 + ok:true",
              status == 200 and out.get("ok") is True, (status, out))
        rules_text = read_file(os.path.join(gdir, "rules.yaml"))
        check("rule/update(inject 空): rules.yaml から inject キーが消える",
              "inject:" not in rules_text, rules_text)
        r = find_rule(env, proj, op_id)
        check("rule/update(inject 空): core list の inject が null",
              r is not None and r.get("inject") is None, r)
        check("rule/update(inject 空): dry-run の実文面が標準文面へ戻る",
              dryrun_text(env, proj, op_id, "--tool=Bash", "--input=grep -r foo .")
              == INJECT_PREFIX + "この操作の docs: %s — 必要なら読む" % doc2_abs,
              dryrun_text(env, proj, op_id, "--tool=Bash", "--input=grep -r foo ."))

        # --- 5b) inject 単独 patch — 帯 (実際に届く文面) の編集が送る形 ---------
        # 上の 5) は複合 patch (tool/match/every/inject)。帯の編集面は inject だけを
        # 送るので、「他のキーを巻き添えにしない」ことを契約として固定する
        band_inject = "よく読む: {doc} ({id})"
        status, out = http_json("POST", base + "/api/rule/update", {
            "cwd": proj, "id": op_id, "layer": "global",
            "patch": {"inject": band_inject}})
        check("rule/update(inject 単独): 200 + ok:true",
              status == 200 and out.get("ok") is True, (status, out))
        r = find_rule(env, proj, op_id)
        check("rule/update(inject 単独): inject だけが変わり tool / match は保持",
              r is not None and r.get("inject") == band_inject
              and r.get("tool") == "Bash" and r.get("match") == r"\bgrep\b", r)
        check("rule/update(inject 単独): dry-run の実文面が新 inject の展開結果",
              dryrun_text(env, proj, op_id, "--tool=Bash", "--input=grep -r foo .")
              == INJECT_PREFIX + band_inject.replace("{doc}", doc2_abs).replace("{id}", op_id),
              dryrun_text(env, proj, op_id, "--tool=Bash", "--input=grep -r foo ."))

        # --- 5c) inject 単独 null — 帯の「標準に戻す」が送る形 -----------------
        status, out = http_json("POST", base + "/api/rule/update", {
            "cwd": proj, "id": op_id, "layer": "global",
            "patch": {"inject": None}})
        check("rule/update(inject 単独 null): 200 + ok:true",
              status == 200 and out.get("ok") is True, (status, out))
        rules_text = read_file(os.path.join(gdir, "rules.yaml"))
        check("rule/update(inject 単独 null): rules.yaml から inject キーが消える",
              "inject:" not in rules_text, rules_text)
        r = find_rule(env, proj, op_id)
        check("rule/update(inject 単独 null): tool / match は保持されたまま",
              r is not None and r.get("inject") is None
              and r.get("tool") == "Bash" and r.get("match") == r"\bgrep\b", r)
        check("rule/update(inject 単独 null): dry-run の実文面が標準文面へ戻る",
              dryrun_text(env, proj, op_id, "--tool=Bash", "--input=grep -r foo .")
              == INJECT_PREFIX + "この操作の docs: %s — 必要なら読む" % doc2_abs,
              dryrun_text(env, proj, op_id, "--tool=Bash", "--input=grep -r foo ."))

        # --- 5d) 同じ doc の 2 きっかけへ帯が同じテンプレートを書く経路 ---------
        # 帯の保存は「同じ文面を出しているきっかけ」全部へ 1 件ずつ POST する。
        # {id} 入りのテンプレートは rule ごとに違う値へ展開される = 書いた瞬間に
        # 文面が 2 通りへ割れる (GUI は保存結果の 1 行で、保存後に読み直した状態から言う)。
        # 「標準に戻す」も両方へ送らないと片方に残る — 書き込み側の事実をここで固定する
        op2_id = "e2e-inject-op2"
        status, out = http_json("POST", base + "/api/apply", {
            "cwd": proj, "layer": "global",
            "rule": {"id": op2_id, "tool": "Bash", "match": r"\bfind\b",
                     "doc": "docs/%s" % doc2}})
        check("apply(同じ doc の 2 きっかけ目): 200 + ok:true",
              status == 200 and out.get("ok") is True, (status, out))
        for rid in (op_id, op2_id):
            status, out = http_json("POST", base + "/api/rule/update", {
                "cwd": proj, "id": rid, "layer": "global",
                "patch": {"inject": band_inject}})
            check("rule/update(2 件へ同じ文面): %s が 200 + ok:true" % rid,
                  status == 200 and out.get("ok") is True, (status, out))
        texts = {
            op_id: dryrun_text(env, proj, op_id, "--tool=Bash", "--input=grep -r foo ."),
            op2_id: dryrun_text(env, proj, op2_id, "--tool=Bash", "--input=find . -name x"),
        }
        want = {rid: INJECT_PREFIX + band_inject.replace("{doc}", doc2_abs).replace("{id}", rid)
                for rid in (op_id, op2_id)}
        check("2 件へ同じ {id} テンプレート: 実文面は rule ごとに違う 2 通りになる",
              texts == want and texts[op_id] != texts[op2_id], (texts, want))
        for rid in (op_id, op2_id):
            status, out = http_json("POST", base + "/api/rule/update", {
                "cwd": proj, "id": rid, "layer": "global", "patch": {"inject": None}})
            check("rule/update(2 件を標準へ戻す): %s が 200 + ok:true" % rid,
                  status == 200 and out.get("ok") is True, (status, out))
        rules_text = read_file(os.path.join(gdir, "rules.yaml"))
        check("2 件を標準へ戻す: rules.yaml に inject が 1 つも残らない",
              "inject:" not in rules_text, rules_text)

        # --- 6) ことばきっかけ (event: prompt) + inject の apply 経路 -------
        kw_id = "e2e-inject-kw"
        kw_inject = "この話題の docs: {doc} — デプロイ手順"
        status, out = http_json("POST", base + "/api/apply", {
            "cwd": proj, "layer": "global",
            "rule": {"id": kw_id, "event": "prompt", "keywords": "デプロイ, deploy",
                     "doc": "docs/%s" % doc2, "inject": kw_inject}})
        # doc_content 省略 = 既存 doc へのきっかけ追加 (GUI のことばきっかけ追加と同形)
        check("apply(event: prompt + inject): 200 + ok:true",
              status == 200 and out.get("ok") is True, (status, out))
        r = find_rule(env, proj, kw_id)
        check("apply(event: prompt + inject): core list が prompt ルールとして返す",
              r is not None and r.get("event") == "prompt"
              and r.get("keywords") == "デプロイ, deploy"
              and r.get("inject") == kw_inject, r)
        check("apply(event: prompt + inject): dry-run --event=prompt で発火し文面が一致",
              dryrun_text(env, proj, kw_id, "--event=prompt", "--input=デプロイを作りたい")
              == INJECT_PREFIX + kw_inject.replace("{doc}", doc2_abs),
              dryrun_text(env, proj, kw_id, "--event=prompt", "--input=デプロイを作りたい"))

        # --- 6b) doc を持たないルール (inject の文面だけ) が /api/docs に出る ------
        # GUI の一覧は /api/docs を並べる — doc 無しのルールがここに載らないと
        # 「注入はされるのに一覧に無い」になる。apply (doc も本文も無し) で作り、
        # inject_only のエントリとして 1 件載ること・inject を空にできないことまで
        io_id = "e2e-inject-only"
        io_inject = "リリース手順は先に確認 ({id})"
        status, out = http_json("POST", base + "/api/apply", {
            "cwd": proj, "layer": "global",
            "rule": {"id": io_id, "event": "prompt", "keywords": "リリース, release",
                     "inject": io_inject}})
        check("apply(doc 無し・inject のみ): 200 + ok:true + doc_path null",
              status == 200 and out.get("ok") is True and out.get("doc_path") is None,
              (status, out))
        status, dl = http_json(
            "GET", "%s/api/docs?cwd=%s" % (base, urllib.request.quote(proj)))
        io_entries = [d for d in dl.get("docs", []) if d.get("inject_only")]
        io = next((d for d in io_entries
                   if [t.get("id") for t in d.get("triggers", [])] == [io_id]), None)
        check("api/docs: doc 無しルールが inject_only のエントリとして 1 件載る",
              io is not None and len([d for d in io_entries
                                      if [t.get("id") for t in d["triggers"]] == [io_id]]) == 1,
              io_entries)
        check("api/docs: inject_only は name/path_abs null・exists false・"
              "body_excerpt が inject の文面・層が global",
              io is not None and io.get("name") is None and io.get("path_abs") is None
              and io.get("exists") is False and io.get("body_excerpt") == io_inject
              and io.get("layer") == "global" and io.get("inject_count_7d") == 0, io)
        check("api/docs: doc のエントリは inject_only false",
              all(d.get("inject_only") is False for d in dl.get("docs", [])
                  if d.get("path_abs")), dl.get("docs"))
        status, st = http_json(
            "GET", "%s/api/state?cwd=%s" % (base, urllib.request.quote(proj)))
        check("api/docs: きっかけの総数 = api/state の rules 総数 (一覧の「ルール N」の根拠)",
              sum(len(d.get("triggers", [])) for d in dl.get("docs", []))
              == len(st.get("rules", [])),
              (sum(len(d.get("triggers", [])) for d in dl.get("docs", [])),
               len(st.get("rules", []))))
        check("dry-run --event=prompt: doc 無しルールは inject の文面で発火",
              dryrun_text(env, proj, io_id, "--event=prompt", "--input=リリースする")
              == INJECT_PREFIX + io_inject.replace("{id}", io_id),
              dryrun_text(env, proj, io_id, "--event=prompt", "--input=リリースする"))
        # 文面を空にする patch (帯の「標準に戻す」と同形) は、doc が無いので拒まれる
        rules_before = read_file(os.path.join(gdir, "rules.yaml"))
        status, out = http_json("POST", base + "/api/rule/update", {
            "cwd": proj, "id": io_id, "layer": "global", "patch": {"inject": None}})
        check("rule/update(doc 無し × inject 空): 409 で拒否・rules.yaml 無変更",
              status == 409 and out.get("ok") is False
              and read_file(os.path.join(gdir, "rules.yaml")) == rules_before,
              (status, out))

        # --- 7) AI 起案 (kind=kw) — LLM は env スタブ (claude を呼ばない) ----
        # 自己検証の入力が無い起案は通さない (無検証のまま人の承認画面へ出さない)
        status, out = http_json("POST", base + "/api/propose", {
            "cwd": proj, "layer": "global", "kind": "kw",
            "request": "デプロイの話が出たらデプロイの作り方 docs を渡して"})
        check("propose(kind=kw): sample_prompt 欠落の起案は 502 で通さない",
              status == 502 and "sample_prompt" in str(out.get("error")),
              (status, out))

        status, out = http_json("POST", base + "/api/propose", {
            "cwd": proj, "layer": "global", "kind": "kw",
            "request": "デプロイの話が出たらデプロイの作り方 docs を渡して"})
        check("propose(kind=kw): 200", status == 200, (status, out))
        pr = out.get("rule") or {}
        check("propose(kind=kw): rule が event: prompt + keywords",
              pr.get("event") == "prompt" and pr.get("keywords") == "デプロイ, deploy",
              pr)
        check("propose(kind=kw): tool / match を持たない (混在キー拒否)",
              "tool" not in pr and "match" not in pr, pr)
        check("propose(kind=kw): inject が起案どおり返る",
              pr.get("inject") == STUB_KW_BAD["rule"]["inject"], pr)
        check("propose(kind=kw): 発火しない起案 (sample_prompt 不一致) は retry へ回る",
              out.get("sample_prompt") == "デプロイを作りたい", out.get("sample_prompt"))
        check("propose(kind=kw): 既存の ことばルールを overlap で返す "
              "(dry-run --event=prompt)",
              [o.get("id") for o in (out.get("overlap") or [])] == [kw_id],
              out.get("overlap"))

        # --- 8) AI 起案の attach_to (既存 doc へのきっかけ追加) ------------
        # 起案が実在しない doc への「きっかけ追加」を
        # 出しても人の承認画面には届かない (retry で自己修正 or 502)。承認された
        # 起案は GUI の保存ボタンと同形の apply で必ず保存できることまで縦貫で固定
        ask_attach = {"cwd": proj, "layer": "global", "kind": "kw",
                      "request": "リリースの話が出たらリリースの docs を渡して"}

        # 8a) 実在 doc への attach_to — 起案 → GUI と同形の apply → 実書き込み
        doc2_before = read_file(doc2_abs)
        status, out = http_json("POST", base + "/api/propose", ask_attach)
        check("propose(attach_to): 200", status == 200, (status, out))
        check("propose(attach_to): attach_to / doc_name が既存 doc を指す",
              out.get("attach_to") == attach_ok and out.get("doc_name") == doc2,
              out)
        check("propose(attach_to): doc_content は空 (本文は既存 doc のもの)",
              out.get("doc_content") == "", repr(out.get("doc_content")))
        status, aout = http_json("POST", base + "/api/apply", {
            "cwd": proj, "layer": "global", "rule": out.get("rule"),
            "doc_name": out.get("doc_name"),
            "doc_content": out.get("doc_content")})
        check("apply(attach_to): 200 + ok:true",
              status == 200 and aout.get("ok") is True, (status, aout))
        r = find_rule(env, proj, "e2e-attach-a")
        check("apply(attach_to): ルールが層に入り既存 doc を指す",
              r is not None and r.get("doc") == attach_ok, r)
        check("apply(attach_to): 既存 doc の本文は無傷",
              read_file(doc2_abs) == doc2_before)

        # 8b) 実在しない doc への attach_to (幻覚) は retry で自己修正されて 200
        # (rule.id も見る — stub の消費順がずれると別リクエストの出力で偽 green
        #  になり得るため、どの stub が返ったかまで固定する。以下 8d も同じ)
        status, out = http_json("POST", base + "/api/propose", ask_attach)
        check("propose(attach_to 幻覚→修正): retry で実在 doc に落ち着き 200",
              status == 200 and out.get("attach_to") == attach_ok
              and (out.get("rule") or {}).get("id") == "e2e-attach-b",
              (status, out))

        # 8c) 2 回とも幻覚 → 502 (保存で初めて割れる事故を人の承認前で止める)
        status, out = http_json("POST", base + "/api/propose", ask_attach)
        check("propose(attach_to 幻覚×2): 502 で通さない", status == 502,
              (status, out))
        check("propose(attach_to 幻覚×2): エラーが幻覚 doc 名と実在一覧を言う",
              "実在しない" in str(out.get("error"))
              and "e2e-ghost.md" in str(out.get("error"))
              and attach_ok in str(out.get("error")), out.get("error"))

        # 8d) 既存 doc と同名の新規 doc (内容違い) も apply では必ず死ぬ形 —
        #     起案検証が弾き、retry で attach_to へ矯正される
        status, out = http_json("POST", base + "/api/propose", ask_attach)
        check("propose(既存名の新規 doc): retry で attach_to へ矯正され 200",
              status == 200 and out.get("attach_to") == attach_ok
              and (out.get("rule") or {}).get("id") == "e2e-attach-d",
              (status, out))

        # 8e) 新規 doc 起案で rule.doc が doc_name と別の doc (実在しない) を
        #     指してくる形 — rule.doc は doc_name から組み直され、承認画面の名前と
        #     保存される参照が食い違わない
        status, out = http_json("POST", base + "/api/propose", ask_attach)
        check("propose(rule.doc 食い違い): rule.doc が doc_name へ正規化され 200",
              status == 200
              and (out.get("rule") or {}).get("id") == "e2e-attach-e"
              and (out.get("rule") or {}).get("doc") == "docs/e2e-newdoc.md"
              and "attach_to" not in out,
              (status, out))

        # 8f) apply 直叩き: 本文なし × 実在しない doc は人が読める 400
        #     (起案後に doc 名を書き換えた等の経路。core の CLI フラグ語彙
        #      「--doc-content 省略時は…」を GUI へ素通ししない)
        rules_before = read_file(os.path.join(gdir, "rules.yaml"))
        status, out = http_json("POST", base + "/api/apply", {
            "cwd": proj, "layer": "global",
            "rule": {"id": "e2e-apply-ghost", "event": "prompt",
                     "keywords": "幽霊", "doc": ghost},
            "doc_name": "e2e-ghost.md", "doc_content": ""})
        check("apply(本文なし×実在しない doc): 400", status == 400, (status, out))
        check("apply(本文なし×実在しない doc): エラーが人の言葉 (CLI フラグ語彙なし)",
              "--doc-content" not in str(out.get("error"))
              and ghost in str(out.get("error")), out.get("error"))
        check("apply(本文なし×実在しない doc): rules.yaml は無変更",
              read_file(os.path.join(gdir, "rules.yaml")) == rules_before)
        check("apply(本文なし×実在しない doc): ghost doc が作られない",
              not os.path.exists(os.path.join(gdir, "docs", "e2e-ghost.md")),
              os.listdir(os.path.join(gdir, "docs")))

        # 8g) 全角カンマ `，` だけの keywords — server の起案検証が engine と同じ
        #     3 種 (`,` `、` `，`) で割り「区切り文字だけ」として弾く (2 回とも → 502)。
        #     割らずに 1 語として通すと、拒否理由が「sample_prompt に一致しない」に
        #     すり替わる — 理由の文言まで固定する
        ask_fw = {"cwd": proj, "layer": "global", "kind": "kw",
                  "request": "本番の話が出たら本番前の確認を渡して"}
        status, out = http_json("POST", base + "/api/propose", ask_fw)
        check("propose(全角カンマだけ): 502 で通さない", status == 502, (status, out))
        check("propose(全角カンマだけ): 拒否理由が「有効な要素がない (区切り文字だけ)」",
              "有効な要素がない" in str(out.get("error"))
              and "sample_prompt に一致しない" not in str(out.get("error")),
              out.get("error"))
        # 8h) 全角カンマ区切り「本番，ほんばん」— 2 語に割れて sample_prompt「本番に出す」で
        #     発火し 200。keywords は書かれたまま (正規化しない) で返る
        status, out = http_json("POST", base + "/api/propose", ask_fw)
        check("propose(全角カンマ区切り): 200", status == 200, (status, out))
        check("propose(全角カンマ区切り): keywords が書かれたまま返る",
              (out.get("rule") or {}).get("keywords") == "本番，ほんばん", out.get("rule"))

        # --- 実データ無汚染: 実 global 層にテスト doc が存在しない ---------
        real_global = os.environ.get("TOOLHINT_GLOBAL") or os.path.join(
            os.path.expanduser("~"), ".claude", "toolhint")
        check("実データ無汚染: 実 global 層にテスト doc なし",
              not os.path.exists(os.path.join(real_global, "docs", doc)),
              real_global)
    finally:
        proc.terminate()
        try:
            _, errs = proc.communicate(timeout=10)
        except subprocess.TimeoutExpired:
            proc.kill()
            _, errs = proc.communicate()
        if FAILURES and errs:
            print("--- server stderr (失敗時のみ) ---")
            print(errs[-2000:])


def start_server(env, extra_env=None):
    """server.mjs を空きポートで起動して (proc, base_url, env) を返す。"""
    port = free_port()
    base = "http://127.0.0.1:%d" % port
    env = dict(env, PORT=str(port), HOST="127.0.0.1")
    if extra_env:
        env.update(extra_env)
    proc = subprocess.Popen(
        ["node", SERVER], env=env, cwd=REPO,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    return proc, base, env


def stop_server(proc):
    proc.terminate()
    try:
        _, errs = proc.communicate(timeout=10)
    except subprocess.TimeoutExpired:
        proc.kill()
        _, errs = proc.communicate()
    if FAILURES and errs:
        print("--- server stderr (失敗時のみ) ---")
        print(errs[-2000:])


# rules.yaml を engine のパーサが読めなくする 1 行 — 未クォートの `[` 始まりの値
BROKEN_RULES_YAML = (
    "rules:\n"
    "  - id: good\n    tool: Bash\n    match: foo\n    doc: docs/a.md\n"
    "  - id: bad\n    tool: Bash\n    match: [unquoted-bracket]\n    doc: docs/a.md\n"
)

# TOOLHINT_CORE 差し替え用の最小 core — list の出力を固定して返す。
# server が state を加工せず GUI へ通すかだけを見る (core の実装とは独立)
STUB_CORE = r'''#!/usr/bin/env python3
import json, sys
FIXED = json.loads(%s)
args = sys.argv[1:]
cmd = args[0] if args else ""
if cmd == "--help" or cmd == "-h":
    print("usage: stub {list,dry-run,add-rule,docs,log,save-doc}")
    sys.exit(0)
if cmd == "list":
    print(json.dumps(FIXED, ensure_ascii=False))
    sys.exit(0)
if cmd == "docs":
    print(json.dumps({"docs": []}))
    sys.exit(0)
if cmd == "log":
    print(json.dumps({"entries": []}))
    sys.exit(0)
print(json.dumps({"ok": False, "error": "stub: %%s は未対応" %% cmd}))
sys.exit(1)
'''


def scenario_layer_errors(td):
    """10) 読めない層 → /api/state の layer_errors / layers[].parse_error。"""
    gdir = os.path.join(td, "global")
    home = os.path.join(td, "home")
    proj = os.path.join(td, "proj")
    os.makedirs(home)
    os.makedirs(os.path.join(proj, ".claude", "toolhint"))
    os.makedirs(os.path.join(gdir, "docs"))
    # 読める層 (global) — 1 ルール
    with open(os.path.join(gdir, "docs", "ok.md"), "w", encoding="utf-8") as f:
        f.write("# ok\n")
    with open(os.path.join(gdir, "rules.yaml"), "w", encoding="utf-8") as f:
        f.write("rules:\n  - id: e2e-ok\n    tool: Bash\n    match: okcmd\n"
                "    doc: docs/ok.md\n")
    # 読めない層 (追加層) — rules.yaml の 1 行がパーサ外
    broken = os.path.join(gdir, "layers.d", "zz-broken")
    os.makedirs(os.path.join(broken, "docs"))
    with open(os.path.join(broken, "docs", "a.md"), "w", encoding="utf-8") as f:
        f.write("# a\n")
    broken_rules = os.path.join(broken, "rules.yaml")
    with open(broken_rules, "w", encoding="utf-8") as f:
        f.write(BROKEN_RULES_YAML)

    base_env = dict(os.environ, TOOLHINT_GLOBAL=gdir, HOME=home)
    base_env.pop("TOOLHINT_CORE", None)

    # --- (a) real core: 壊れた層が layer_errors / parse_error に載る -------
    proc, base, env = start_server(base_env)
    try:
        state = wait_ready(base, proj, proc)
        check("layer_errors: server が起動して /api/state 応答", state is not None)
        if state is not None:
            check("layer_errors: core が real", state.get("core") == "real",
                  state.get("core"))
            errs = state.get("layer_errors")
            check("layer_errors: /api/state に layer_errors (list) が載る",
                  isinstance(errs, list), repr(errs)[:200])
            errs = errs if isinstance(errs, list) else []
            hit = next((e for e in errs
                        if isinstance(e, dict)
                        and e.get("layer") == "layers.d/zz-broken"), None)
            check("layer_errors: 壊れた層 (layers.d/zz-broken) が 1 件載る",
                  hit is not None and len(errs) == 1, errs)
            check("layer_errors: file が壊れた rules.yaml の絶対パス",
                  hit is not None and os.path.isabs(str(hit.get("file") or ""))
                  and os.path.realpath(str(hit.get("file") or ""))
                  == os.path.realpath(broken_rules), hit)
            check("layer_errors: error に行番号 (line N) が入る",
                  hit is not None and "line" in str(hit.get("error") or ""), hit)
            layers = {l.get("name"): l for l in state.get("layers", [])
                      if isinstance(l, dict)}
            bl = layers.get("layers.d/zz-broken", {})
            check("layers[].parse_error: 壊れた層は理由の文字列",
                  isinstance(bl.get("parse_error"), str) and bl.get("parse_error"),
                  bl)
            check("layers[].parse_error: 読める層 (global) は null",
                  "parse_error" in layers.get("global", {})
                  and layers.get("global", {}).get("parse_error") is None,
                  layers.get("global"))
            check("layer_errors: 読める層はどれも載らない",
                  all(e.get("layer") == "layers.d/zz-broken" for e in errs), errs)
            ids = [r.get("id") for r in state.get("rules", [])]
            check("layer_errors: 壊れた層のルールは一覧に出ない (層ごと読み飛ばし) "
                  "+ 読める層のルールは出る",
                  "good" not in ids and "bad" not in ids and "e2e-ok" in ids, ids)
            # 壊れた層への書き込みは従来どおり断られ、ファイルは無傷 (読み取り専用の層)
            before = read_file(broken_rules)
            status, out = http_json("POST", base + "/api/apply",
                                    {"cwd": proj, "layer": "layers.d/zz-broken",
                                     "rule": {"id": "x", "tool": "Bash",
                                              "doc": "docs/a.md"},
                                     "doc_content": "x\n"})
            check("layer_errors: 壊れた層への apply は 400 でファイル無傷",
                  status == 400 and read_file(broken_rules) == before,
                  (status, out))
    finally:
        stop_server(proc)

    # --- (b) TOOLHINT_CORE 差し替え: server が state を加工せず通す ----------
    fixed = {
        "layers": [
            {"name": "global", "dir": gdir, "exists": True,
             "parse_error": "line 8: 構文外の値: '[unquoted-bracket]'"},
            {"name": "project", "dir": os.path.join(proj, ".claude", "toolhint"),
             "exists": True, "parse_error": None},
        ],
        "rules": [],
        "layer_errors": [
            {"layer": "global", "file": os.path.join(gdir, "rules.yaml"),
             "error": "line 8: 構文外の値: '[unquoted-bracket]'"},
        ],
    }
    stub = os.path.join(td, "stub_core.py")
    with open(stub, "w", encoding="utf-8") as f:
        f.write(STUB_CORE % repr(json.dumps(fixed, ensure_ascii=False)))
    proc, base, env = start_server(base_env, {"TOOLHINT_CORE": stub})
    try:
        state = wait_ready(base, proj, proc)
        check("passthrough: 差し替え core で /api/state 応答", state is not None)
        if state is not None:
            check("passthrough: core が custom (差し替え先)",
                  state.get("core") == "custom", state.get("core"))
            check("passthrough: layer_errors が core の出力そのまま",
                  state.get("layer_errors") == fixed["layer_errors"],
                  state.get("layer_errors"))
            got = [(l.get("name"), l.get("parse_error"))
                   for l in state.get("layers", [])]
            want = [(l["name"], l["parse_error"]) for l in fixed["layers"]]
            check("passthrough: layers[].parse_error が core の出力そのまま",
                  got == want, got)
    finally:
        stop_server(proc)


def main():
    print("[savedoc e2e] GUI 保存リクエスト → server → real core → 実ファイル")
    with tempfile.TemporaryDirectory(prefix="toolhint-savedoc-e2e-") as td:
        scenario(td)
    print("[savedoc e2e] 読めない層 → /api/state の layer_errors / parse_error")
    with tempfile.TemporaryDirectory(prefix="toolhint-layererr-e2e-") as td:
        scenario_layer_errors(td)
    if FAILURES:
        print("FAIL: %d 件" % len(FAILURES))
        return 1
    print("OK: 保存経路の縦貫 (内容一致 / .bak / atomic / auto-commit) を確認")
    return 0


if __name__ == "__main__":
    sys.exit(main())
