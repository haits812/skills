#!/usr/bin/env python3
"""mock (fixtures/toolhint_core_mock.py) と real core (core/toolhint_core.py) の
契約突き合わせテスト。

mock が real core の安全契約から乖離すると、probe フォールバック窓で
実データ破壊 (改行入り rules.yaml / .bak なし上書き) や dry-run の嘘が
起きるため、両者を同じシナリオで実行して突き合わせる:
  - add-rule: 改行入り inject が engine パーサで読み戻せる形で書かれること
  - add-rule: 応答キー rules_path / doc_path
  - add-rule: 改行系の禁止文字 (\\r) は ok:false で拒否されること
  - add-rule: doc の無いルールは inject 必須 ({doc} 参照・--doc-content は拒否)、
              通れば doc_path null で docs/ に何も増えず、dry-run は inject の文面
  - dry-run: {"command": <input>} への match (^ アンカーは不一致) /
             tool は fullmatch / text は "[toolhint] " 前置き
  - save-doc: 上書き前に .bak 退避 / 応答キー doc_path
  - 先頭 '-' の値も = 連結形式で受理されること
  - prompt rule (event: prompt) 入り層での list / dry-run --tool /
    dry-run --event=prompt (パス正規化した出力の real vs mock 直接突き合わせ)
  - 追加層 (<global層>/layers.d/<名前>/) 入り層での list / dry-run / docs —
    層名・読み順・後勝ち・手元の enabled:false による停止・層外 doc の不発
    (docs は並びと本文抜粋を除く主要キーで突き合わせる)
  - 適用範囲 (scope) 入り層での list / dry-run (範囲内・範囲外 × 操作/ことば) と
    add-rule の置き先 (scope 付き = rules-scoped.yaml / 無し = rules.yaml)
  - engine パーサで読めないルールファイルを持つ層での list — layers[].parse_error
    (理由・行番号) と layer_errors (ファイル単位) が同形で、その層の rules は 0 件、
    健全な層は影響を受けないこと
  - doc を持たないルール (inject の文面だけ) 入り層での docs — ルール 1 件 =
    1 エントリ (inject_only: true / name・path_abs null / body_excerpt = inject の
    先頭) で載り、同じ文面でも id が違えば別エントリ、list に doc 無しで載る id の
    集合と一致すること。inject_count_7d は doc 無しの記録を rule_id + 層で数え、
    project 層は記録の cwd がそのプロジェクトの中にあるものだけであること

実行: python3 manager/fixtures/test_mock_contract.py  (すべて subprocess・/tmp 内)
"""

import datetime

import json
import os
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(os.path.dirname(HERE))
MOCK = os.path.join(HERE, "toolhint_core_mock.py")
REAL = os.path.join(REPO, "core", "toolhint_core.py")

sys.path.insert(0, os.path.join(REPO, "engine", "scripts"))
import toolhint  # noqa: E402  (engine パーサで read-back 検証)

FAILURES = []


def check(name, cond, detail=""):
    if cond:
        print("  ok: %s" % name)
    else:
        print("  NG: %s %s" % (name, detail))
        FAILURES.append(name)


def run(core, args, gdir, cwd):
    env = dict(os.environ, TOOLHINT_GLOBAL=gdir)
    p = subprocess.run([sys.executable, core] + args,
                       capture_output=True, text=True, env=env, cwd=cwd)
    try:
        return json.loads(p.stdout)
    except ValueError:
        return {"_no_json": True, "stdout": p.stdout, "stderr": p.stderr}


def scenario(core):
    label = os.path.basename(core)
    print("[%s]" % label)
    with tempfile.TemporaryDirectory(prefix="toolhint-contract-") as td:
        gdir = os.path.join(td, "global")
        cwd = os.path.join(td, "proj")
        os.makedirs(cwd)

        # 1) 改行入り inject の add-rule → engine パーサで読み戻せること
        rule = {"id": "t-nl", "tool": "Bash", "match": r"\bgrep\b",
                "doc": "docs/a.md", "inject": "line1\nline2"}
        out = run(core, ["add-rule", "--layer=global", "--cwd=%s" % cwd,
                         "--rule=%s" % json.dumps(rule, ensure_ascii=False),
                         "--doc-content=hint body"], gdir, td)
        check("add-rule (改行入り inject) ok:true", out.get("ok") is True, out)
        check("add-rule 応答キー rules_path/doc_path",
              "rules_path" in out and "doc_path" in out, sorted(out))
        ry = os.path.join(gdir, "rules.yaml")
        try:
            parsed = toolhint.parse_rules_yaml(open(ry, encoding="utf-8").read())
            check("rules.yaml が engine パーサで読める", True)
            check("inject の改行が往復一致",
                  parsed and parsed[-1].get("inject") == "line1\nline2",
                  parsed)
        except Exception as e:
            check("rules.yaml が engine パーサで読める", False, str(e))

        # 2) ^ アンカーの match は flat ({"command": ...}) に不一致
        rule2 = {"id": "t-anchor", "tool": "Bash", "match": r"^git\s",
                 "doc": "docs/a.md"}
        out = run(core, ["add-rule", "--layer=global", "--cwd=%s" % cwd,
                         "--rule=%s" % json.dumps(rule2)], gdir, td)
        check("add-rule (--doc-content 省略, 既存 doc)", out.get("ok") is True, out)

        dr = run(core, ["dry-run", "--cwd=%s" % cwd, "--tool=Bash",
                        "--input=grep -r foo ."], gdir, td)
        ids = {m["id"] for m in dr.get("matches", [])}
        check("dry-run: match は flat への search (t-nl が発火)", "t-nl" in ids, dr)
        texts = [m["text"] for m in dr.get("matches", [])]
        check("dry-run: text は '[toolhint] ' 前置き",
              all(t.startswith("[toolhint] ") for t in texts), texts)

        dr = run(core, ["dry-run", "--cwd=%s" % cwd, "--tool=Bash",
                        "--input=git push --force"], gdir, td)
        ids = {m["id"] for m in dr.get("matches", [])}
        check("dry-run: ^ アンカーは flat に不一致 (t-anchor 不発)",
              "t-anchor" not in ids, dr)

        # 3) tool は fullmatch (Bash ルールは BashOutput に発火しない)
        dr = run(core, ["dry-run", "--cwd=%s" % cwd, "--tool=BashOutput",
                        "--input=grep -r foo ."], gdir, td)
        check("dry-run: tool は fullmatch (BashOutput に不発)",
              not dr.get("matches"), dr)

        # 4) 先頭 '-' の値も = 連結形式で受理
        dr = run(core, ["dry-run", "--cwd=%s" % cwd, "--tool=Bash",
                        "--input=-r"], gdir, td)
        check("dry-run: '-r' 入力を = 形式で受理", "matches" in dr, dr)

        # 5) save-doc: .bak 退避 + doc_path キー
        out = run(core, ["save-doc", "--cwd=%s" % cwd, "--layer=global",
                         "--doc-name=a.md", "--content=v2"], gdir, td)
        check("save-doc ok:true + doc_path",
              out.get("ok") is True and "doc_path" in out, out)
        check("save-doc: 上書き前に .bak 退避",
              os.path.isfile(os.path.join(gdir, "docs", "a.md.bak")),
              os.listdir(os.path.join(gdir, "docs")))

        # 6) 改行系の禁止文字 (\r) は拒否
        bad = {"id": "t-bad", "tool": "Bash", "match": "x",
               "doc": "docs/a.md", "inject": "a\rb"}
        out = run(core, ["add-rule", "--layer=global", "--cwd=%s" % cwd,
                         "--rule=%s" % json.dumps(bad)], gdir, td)
        check("add-rule: \\r 入り値は ok:false", out.get("ok") is False, out)
        try:
            parsed = toolhint.parse_rules_yaml(open(ry, encoding="utf-8").read())
            check("拒否後も rules.yaml は無傷", len(parsed) == 2, parsed)
        except Exception as e:
            check("拒否後も rules.yaml は無傷", False, str(e))

        # 7) doc の無いルール (inject の文面だけ): inject 必須 ({doc} 参照不可・
        #    --doc-content 不可)、通れば doc_path は null で docs/ に何も増えない
        for name, rule, dc in [
                ("doc も inject も無い", {"id": "nd-1", "tool": "Bash", "match": "x"}, None),
                ("inject が {doc} を参照", {"id": "nd-2", "tool": "Bash", "match": "x",
                                          "inject": "see {doc}"}, None),
                ("--doc-content 付き", {"id": "nd-3", "tool": "Bash", "match": "x",
                                       "inject": "plain"}, "body"),
        ]:
            args = ["add-rule", "--layer=global", "--cwd=%s" % cwd,
                    "--rule=%s" % json.dumps(rule)]
            if dc is not None:
                args.append("--doc-content=%s" % dc)
            out = run(core, args, gdir, td)
            check("add-rule (doc 無し, %s) は ok:false" % name,
                  out.get("ok") is False, out)
        docs_before = sorted(os.listdir(os.path.join(gdir, "docs")))
        rule_nd = {"id": "nd-ok", "event": "prompt", "keywords": "リリース",
                   "inject": "手順を確認 ({id})"}
        out = run(core, ["add-rule", "--layer=global", "--cwd=%s" % cwd,
                         "--rule=%s" % json.dumps(rule_nd, ensure_ascii=False)],
                  gdir, td)
        check("add-rule (doc 無し, inject あり) ok:true + doc_path null",
              out.get("ok") is True and out.get("doc_path") is None, out)
        check("add-rule (doc 無し): docs/ に何も増えない",
              sorted(os.listdir(os.path.join(gdir, "docs"))) == docs_before,
              os.listdir(os.path.join(gdir, "docs")))
        try:
            parsed = toolhint.parse_rules_yaml(open(ry, encoding="utf-8").read())
            check("add-rule (doc 無し): engine パーサと往復一致",
                  parsed and parsed[-1] == rule_nd, parsed)
        except Exception as e:
            check("add-rule (doc 無し): engine パーサと往復一致", False, str(e))
        dp = run(core, ["dry-run", "--cwd=%s" % cwd, "--event=prompt",
                        "--input=リリースする"], gdir, td)
        check("dry-run --event=prompt: doc 無しルールは inject の文面そのもの",
              [(m["id"], m["text"]) for m in dp.get("matches", [])]
              == [("nd-ok", "[toolhint] 手順を確認 (nd-ok)")], dp)


def scenario_prompt(core):
    """prompt rule (event: prompt) 入り層での list / dry-run --tool /
    dry-run --event=prompt。返り値はパス正規化済みの出力 —
    main() が mock vs real を直接突き合わせる。"""
    label = os.path.basename(core)
    print("[%s prompt-rules]" % label)
    collected = {}
    with tempfile.TemporaryDirectory(prefix="toolhint-contract-p-") as td:
        gdir = os.path.join(td, "global")
        cwd = os.path.join(td, "proj")
        os.makedirs(cwd)
        os.makedirs(os.path.join(gdir, "docs"))
        with open(os.path.join(gdir, "docs", "a.md"), "w", encoding="utf-8") as f:
            f.write("hint body\n")
        with open(os.path.join(gdir, "rules.yaml"), "w", encoding="utf-8") as f:
            f.write(
                "rules:\n"
                "  - id: t1\n    tool: Bash\n    match: grep\n    doc: docs/a.md\n"
                "  - id: kw1\n    event: prompt\n"
                "    keywords: \"deploy, デプロイ\"\n"
                "    doc: docs/a.md\n    mode: inline\n"
                "  - id: kw2\n    event: prompt\n"
                "    keywords: \"(?:デプロイ)|(?:catalog)\"\n"
                "    find: regex\n    doc: docs/a.md\n"
                "  - id: broken\n    event: prompt\n    keywords: \"、,\"\n"
                "    doc: docs/a.md\n")

        # list — event / keywords / find / case が透過し、壊れ prompt rule は skip
        lst = run(core, ["list", "--cwd=%s" % cwd], gdir, td)
        proj = sorted(
            [{k: r.get(k) for k in ("id", "layer", "event", "keywords",
                                    "find", "case", "tool", "match", "doc")}
             for r in lst.get("rules", [])],
            key=lambda r: (r["layer"] or "", r["id"] or ""))
        ids = [r["id"] for r in proj]
        check("list: prompt rule が載る", "kw1" in ids and "kw2" in ids, ids)
        check("list: 壊れ prompt rule (区切りのみ keywords) は skip",
              "broken" not in ids, ids)
        by_id = {r["id"]: r for r in proj}
        check("list: event 判別 (kw1=prompt / t1=tool)",
              by_id.get("kw1", {}).get("event") == "prompt"
              and by_id.get("t1", {}).get("event") == "tool", proj)
        check("list: keywords / find が生値透過",
              by_id.get("kw1", {}).get("keywords") == "deploy, デプロイ"
              and by_id.get("kw2", {}).get("find") == "regex", proj)
        collected["list"] = proj

        # dry-run --tool: keyword を含む入力でも prompt rule は不発 (event フィルタ)
        dr = run(core, ["dry-run", "--cwd=%s" % cwd, "--tool=Bash",
                        "--input=grep デプロイ catalog"], gdir, td)
        check("dry-run --tool: tool rule のみ (prompt 不発)",
              {m["id"] for m in dr.get("matches", [])} == {"t1"}, dr)
        collected["dry_tool"] = dr

        # dry-run --event=prompt: prompt rule のみ・inline はヘッダ無し
        dp = run(core, ["dry-run", "--cwd=%s" % cwd, "--event=prompt",
                        "--input=デプロイを見たい"], gdir, td)
        check("dry-run --event=prompt: kw1+kw2 発火・tool 不発",
              {m["id"] for m in dp.get("matches", [])} == {"kw1", "kw2"}, dp)
        texts = {m["id"]: m["text"] for m in dp.get("matches", [])}
        check("prompt inline はヘッダ無しで本文そのまま",
              texts.get("kw1") == "[toolhint] hint body", texts)
        abs_doc = os.path.join(gdir, "docs", "a.md")
        check("prompt pointer は「この話題の docs」",
              texts.get("kw2")
              == "[toolhint] この話題の docs: %s — 必要なら読む" % abs_doc, texts)
        collected["dry_prompt"] = dp

        # substring は大小無視
        dp2 = run(core, ["dry-run", "--cwd=%s" % cwd, "--event=prompt",
                         "--input=DEPloy please"], gdir, td)
        check("dry-run --event=prompt: substring は大小無視",
              {m["id"] for m in dp2.get("matches", [])} == {"kw1"}, dp2)
        collected["dry_prompt_ci"] = dp2

        # 一時 dir のパスを正規化して mock vs real を直接比較できる形に
        blob = json.dumps(collected, ensure_ascii=False, sort_keys=True)
        blob = blob.replace(gdir, "<GDIR>").replace(cwd, "<CWD>")
    return json.loads(blob)


def scenario_extra_layers(core):
    """追加層 (<global層>/layers.d/<名前>/) 入りの層での list / dry-run。
    返り値はパス正規化済み — main() が mock vs real を直接突き合わせる。"""
    label = os.path.basename(core)
    print("[%s layers.d]" % label)
    collected = {}
    with tempfile.TemporaryDirectory(prefix="toolhint-contract-l-") as td:
        gdir = os.path.join(td, "global")
        cwd = os.path.join(td, "proj")
        os.makedirs(cwd)
        team = os.path.join(gdir, "layers.d", "team")
        os.makedirs(os.path.join(team, "docs"))
        with open(os.path.join(team, "docs", "t.md"), "w", encoding="utf-8") as f:
            f.write("team body\n")
        with open(os.path.join(team, "rules.yaml"), "w", encoding="utf-8") as f:
            f.write(
                "rules:\n"
                "  - id: t-doc\n    tool: Bash\n    match: grep\n    doc: docs/t.md\n"
                "  - id: t-over\n    tool: Bash\n    match: grep\n    inject: TEAM\n"
                "  - id: t-stop\n    tool: Bash\n    match: grep\n    inject: STOP\n"
                # 層外 doc — 追加層のルールは層 dir 配下しか参照できない (発火しない)
                "  - id: t-escape\n    tool: Bash\n    match: grep\n"
                "    doc: ../../../outside.md\n    mode: inline\n")
        with open(os.path.join(td, "outside.md"), "w", encoding="utf-8") as f:
            f.write("OUTSIDE BODY\n")
        os.makedirs(gdir, exist_ok=True)
        with open(os.path.join(gdir, "rules.yaml"), "w", encoding="utf-8") as f:
            f.write(  # 手元の層で 1 件を上書き・1 件を停止
                "rules:\n"
                "  - id: t-over\n    tool: Bash\n    match: grep\n    inject: LOCAL\n"
                "  - id: t-stop\n    tool: Bash\n    enabled: \"false\"\n")

        lst = run(core, ["list", "--cwd=%s" % cwd], gdir, td)
        names = [l.get("name") for l in lst.get("layers", [])]
        check("list: 層の並びは layers.d/* → global → project",
              names == ["layers.d/team", "global", "project"], names)
        rows = sorted(
            [{k: r.get(k) for k in ("id", "layer", "overridden", "enabled",
                                    "doc", "inject")}
             for r in lst.get("rules", [])],
            key=lambda r: ((r["layer"] or ""), (r["id"] or "")))
        by = {(r["layer"], r["id"]): r for r in rows}
        check("list: 追加層のルールが layers.d/<名前> として載る",
              ("layers.d/team", "t-doc") in by, rows)
        check("list: 手元の層に同 id があれば追加層の行は overridden",
              by.get(("layers.d/team", "t-over"), {}).get("overridden") is True, rows)
        check("list: 停止用の行は enabled:false で載る",
              by.get(("global", "t-stop"), {}).get("enabled") is False, rows)
        collected["list"] = rows
        collected["layers"] = names

        dr = run(core, ["dry-run", "--cwd=%s" % cwd, "--tool=Bash",
                        "--input=grep -r foo ."], gdir, td)
        got = {m["id"]: (m["layer"], m["text"]) for m in dr.get("matches", [])}
        check("dry-run: 追加層のルールが層名付きで発火",
              got.get("t-doc", ("", ""))[0] == "layers.d/team", dr)
        check("dry-run: 同 id は手元の層が勝つ",
              got.get("t-over", ("", ""))[1] == "[toolhint] LOCAL", dr)
        check("dry-run: 手元の enabled:false で追加層のルールが止まる",
              "t-stop" not in got, dr)
        check("dry-run: 追加層の層外 doc (../) は発火しない",
              "t-escape" not in got, dr)
        collected["dry_run"] = dr

        dl = run(core, ["docs", "--cwd=%s" % cwd], gdir, td)
        # docs — 追加層の doc が層名付きで載り、きっかけが紐づくこと。
        # 比較は「並び」と「本文抜粋」を除く主要キー (real は注入回数順・mock は層順、
        # body_excerpt の作り方も違う — どちらも今回の対象ではない)
        docs = sorted(
            [{"name": d.get("name"), "path_abs": d.get("path_abs"),
              "layer": d.get("layer"), "exists": d.get("exists"),
              "inject_count_7d": d.get("inject_count_7d"),
              "triggers": sorted(
                  [{k: t.get(k) for k in ("id", "layer", "every", "mode",
                                          "enabled", "event")}
                   for t in d.get("triggers", [])],
                  key=lambda t: t["id"] or "")}
             for d in dl.get("docs", [])],
            # doc 無しルールのエントリは path_abs が無い — id と層で並べる
            key=lambda d: (d["path_abs"] or "",
                           d["triggers"][0]["id"] if d["triggers"] else "",
                           d["layer"] or ""))
        by_path = {d["path_abs"]: d for d in docs if d["path_abs"]}
        team_doc = os.path.join(team, "docs", "t.md")
        check("docs: 追加層の doc が layers.d/<名前> の層で載る",
              by_path.get(team_doc, {}).get("layer") == "layers.d/team", docs)
        check("docs: 追加層の doc にきっかけが紐づく",
              [t["id"] for t in by_path.get(team_doc, {}).get("triggers", [])]
              == ["t-doc"], docs)
        collected["docs"] = docs

        blob = json.dumps(collected, ensure_ascii=False, sort_keys=True)
        # 層外 doc (<td>/outside.md) も出力に載るので一時 dir 自体も正規化する
        blob = blob.replace(gdir, "<GDIR>").replace(cwd, "<CWD>").replace(td, "<TD>")
    return json.loads(blob)


def scenario_scope(core):
    """適用範囲 (scope) 入りの層での list / dry-run と、add-rule の置き先。
    返り値はパス正規化済み — main() が mock vs real を直接突き合わせる。"""
    label = os.path.basename(core)
    print("[%s scope]" % label)
    collected = {}
    with tempfile.TemporaryDirectory(prefix="toolhint-contract-s-") as td:
        gdir = os.path.join(td, "global")
        inside = os.path.join(td, "work", "alpha", "sub")
        outside = os.path.join(td, "work", "beta")
        os.makedirs(inside)
        os.makedirs(outside)
        os.makedirs(os.path.join(gdir, "docs"))
        with open(os.path.join(gdir, "docs", "a.md"), "w", encoding="utf-8") as f:
            f.write("hint body\n")
        with open(os.path.join(gdir, "rules.yaml"), "w", encoding="utf-8") as f:
            f.write(
                "rules:\n"
                "  - id: anywhere\n    tool: Bash\n    match: grep\n"
                "    doc: docs/a.md\n    inject: ANYWHERE\n")
        with open(os.path.join(gdir, "rules-scoped.yaml"), "w",
                  encoding="utf-8") as f:
            f.write(  # 2 本目のファイルも同じ層のルールとして読まれる
                "rules:\n"
                "  - id: scoped\n    tool: Bash\n    match: grep\n"
                "    doc: docs/a.md\n    inject: SCOPED\n"
                "    scope: \"*/work/alpha*\"\n"
                "  - id: kw-scoped\n    event: prompt\n    keywords: deploy\n"
                "    doc: docs/a.md\n    inject: KW_SCOPED\n"
                "    scope: \"*/work/alpha*\"\n")

        lst = run(core, ["list", "--cwd=%s" % inside], gdir, td)
        rows = sorted(
            [{k: r.get(k) for k in ("id", "layer", "scope", "inject", "event")}
             for r in lst.get("rules", [])], key=lambda r: r["id"] or "")
        by_id = {r["id"]: r for r in rows}
        check("list: rules-scoped.yaml のルールも同じ層として載る",
              by_id.get("scoped", {}).get("layer") == "global", rows)
        check("list: 適用範囲つきだけ scope キーが増える",
              by_id.get("scoped", {}).get("scope") == "*/work/alpha*"
              and "scope" not in
              {k: v for k, v in by_id.get("anywhere", {}).items() if v is not None},
              rows)
        collected["list"] = rows

        dr_in = run(core, ["dry-run", "--cwd=%s" % inside, "--tool=Bash",
                           "--input=grep -r foo ."], gdir, td)
        check("dry-run: 範囲内では scope 付きも発火",
              {m["id"] for m in dr_in.get("matches", [])} == {"anywhere", "scoped"},
              dr_in)
        dr_out = run(core, ["dry-run", "--cwd=%s" % outside, "--tool=Bash",
                            "--input=grep -r foo ."], gdir, td)
        check("dry-run: 範囲外では scope 付きだけ消える",
              {m["id"] for m in dr_out.get("matches", [])} == {"anywhere"}, dr_out)
        dp_in = run(core, ["dry-run", "--cwd=%s" % inside, "--event=prompt",
                           "--input=deploy して"], gdir, td)
        dp_out = run(core, ["dry-run", "--cwd=%s" % outside, "--event=prompt",
                            "--input=deploy して"], gdir, td)
        check("dry-run --event=prompt: ことばきっかけにも scope が効く",
              {m["id"] for m in dp_in.get("matches", [])} == {"kw-scoped"}
              and dp_out.get("matches") == [], (dp_in, dp_out))
        collected["dry_in"] = dr_in
        collected["dry_out"] = dr_out
        collected["dry_prompt_in"] = dp_in
        collected["dry_prompt_out"] = dp_out

        # add-rule の置き先: scope 付き = rules-scoped.yaml / 無し = rules.yaml
        new_scoped = {"id": "added-scoped", "tool": "Bash", "match": "ls",
                      "doc": "docs/b.md", "inject": "ADDED", "scope": "*/work*"}
        out = run(core, ["add-rule", "--layer=global", "--cwd=%s" % inside,
                         "--rule=%s" % json.dumps(new_scoped),
                         "--doc-content=B"], gdir, td)
        check("add-rule (scope 付き) ok:true", out.get("ok") is True, out)
        check("add-rule: scope 付きは rules-scoped.yaml へ",
              out.get("rules_path") == os.path.join(gdir, "rules-scoped.yaml"),
              out)
        new_plain = {"id": "added-plain", "tool": "Bash", "match": "ls",
                     "doc": "docs/b.md", "inject": "ADDED2"}
        out2 = run(core, ["add-rule", "--layer=global", "--cwd=%s" % inside,
                          "--rule=%s" % json.dumps(new_plain),
                          "--doc-content=B"], gdir, td)
        check("add-rule: scope 無しは rules.yaml へ",
              out2.get("rules_path") == os.path.join(gdir, "rules.yaml"), out2)
        try:
            for name in ("rules.yaml", "rules-scoped.yaml"):
                path = os.path.join(gdir, name)
                parsed = toolhint.parse_rules_yaml(open(path, encoding="utf-8").read())
                collected["file:" + name] = [r.get("id") for r in parsed]
            check("追記後も両ファイルが engine パーサで読める", True)
        except Exception as e:
            check("追記後も両ファイルが engine パーサで読める", False, str(e))

        blob = json.dumps(collected, ensure_ascii=False, sort_keys=True)
        blob = blob.replace(gdir, "<GDIR>").replace(td, "<TD>")
    return json.loads(blob)


def scenario_broken_layer(core):
    """engine パーサで読めないルールファイルを持つ層での list。
    返り値はパス正規化済み — main() が mock vs real を直接突き合わせる。"""
    label = os.path.basename(core)
    print("[%s broken-layer]" % label)
    collected = {}
    with tempfile.TemporaryDirectory(prefix="toolhint-contract-b-") as td:
        gdir = os.path.join(td, "global")
        proj_root = os.path.join(td, "proj")
        proj = os.path.join(proj_root, ".claude", "toolhint")
        team = os.path.join(gdir, "layers.d", "team")
        for d in (gdir, proj, team):
            os.makedirs(os.path.join(d, "docs"))
            with open(os.path.join(d, "docs", "a.md"), "w", encoding="utf-8") as f:
                f.write("hint body\n")
        # global: rules.yaml は健全、rules-scoped.yaml がネスト dict で壊れている
        with open(os.path.join(gdir, "rules.yaml"), "w", encoding="utf-8") as f:
            f.write("rules:\n  - id: g-ok\n    tool: Bash\n    match: grep\n"
                    "    doc: docs/a.md\n")
        with open(os.path.join(gdir, "rules-scoped.yaml"), "w",
                  encoding="utf-8") as f:
            f.write("rules:\n  - id: g-scoped\n    tool: Bash\n"
                    "    scope:\n      glob: \"*/proj*\"\n    doc: docs/a.md\n")
        # project: rules.yaml がクォート漏れの flow collection で壊れている
        with open(os.path.join(proj, "rules.yaml"), "w", encoding="utf-8") as f:
            f.write("rules:\n  - id: good\n    tool: Bash\n    match: foo\n"
                    "    doc: docs/a.md\n  - id: bad\n    tool: Bash\n"
                    "    match: [unquoted-bracket]\n    doc: docs/a.md\n")
        # 追加層: 健全 (壊れた層の影響を受けない)
        with open(os.path.join(team, "rules.yaml"), "w", encoding="utf-8") as f:
            f.write("rules:\n  - id: t-ok\n    tool: Bash\n    match: grep\n"
                    "    doc: docs/a.md\n")

        lst = run(core, ["list", "--cwd=%s" % proj_root], gdir, td)
        layers = {l.get("name"): l for l in lst.get("layers", [])}
        check("list: 壊れた層に parse_error (ファイル名 + 行番号つき理由)",
              layers.get("project", {}).get("parse_error")
              == "rules.yaml: line 8: 構文外の値: '[unquoted-bracket]'", layers)
        check("list: rules-scoped.yaml だけ壊れた層も parse_error",
              (layers.get("global", {}).get("parse_error") or "")
              .startswith("rules-scoped.yaml: line 4:"), layers)
        check("list: 健全な層の parse_error は null",
              "parse_error" in layers.get("layers.d/team", {})
              and layers["layers.d/team"]["parse_error"] is None, layers)
        rule_layers = sorted({r.get("layer") for r in lst.get("rules", [])})
        check("list: 壊れた層のルールは 0 件・健全な層は残る",
              rule_layers == ["layers.d/team"], lst.get("rules"))
        errs = lst.get("layer_errors")
        check("list: layer_errors はファイル単位 (layer / file / error)",
              isinstance(errs, list) and len(errs) == 2
              and all(set(e) == {"layer", "file", "error"} for e in errs), errs)
        collected["layers"] = [
            {k: l.get(k) for k in ("name", "dir", "exists", "parse_error")}
            for l in lst.get("layers", [])]
        collected["rules"] = sorted(
            [{k: r.get(k) for k in ("id", "layer", "doc")}
             for r in lst.get("rules", [])], key=lambda r: r["id"] or "")
        collected["layer_errors"] = errs

        # 直した後は parse_error / layer_errors が消える
        with open(os.path.join(proj, "rules.yaml"), "w", encoding="utf-8") as f:
            f.write("rules:\n  - id: good\n    tool: Bash\n    match: foo\n"
                    "    doc: docs/a.md\n")
        os.remove(os.path.join(gdir, "rules-scoped.yaml"))
        lst2 = run(core, ["list", "--cwd=%s" % proj_root], gdir, td)
        check("list: 直せば parse_error は全層 null・layer_errors は []",
              all(l.get("parse_error") is None for l in lst2.get("layers", []))
              and lst2.get("layer_errors") == [], lst2)
        collected["after_fix_layers"] = [
            {k: l.get(k) for k in ("name", "parse_error")}
            for l in lst2.get("layers", [])]
        collected["after_fix_errors"] = lst2.get("layer_errors")

        blob = json.dumps(collected, ensure_ascii=False, sort_keys=True)
        blob = blob.replace(gdir, "<GDIR>").replace(proj_root, "<PROJ>")
    return json.loads(blob)


def _iso_days_ago(days):
    dt = (datetime.datetime.now(datetime.timezone.utc)
          - datetime.timedelta(days=days))
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")


def _docs_rows(dl):
    """docs の出力を mock vs real で直接比べられる形に — 並びと doc の
    body_excerpt (作り方が違う・今回の対象外) を落とし、inject_only エントリは
    body_excerpt (inject の先頭) まで含めて比べる。"""
    rows = []
    for d in dl.get("docs", []):
        row = {k: d.get(k) for k in ("name", "path_abs", "layer", "exists",
                                     "inject_only", "inject_count_7d")}
        if d.get("inject_only"):
            row["body_excerpt"] = d.get("body_excerpt")
        row["triggers"] = sorted(
            [{k: t.get(k) for k in ("id", "layer", "every", "mode", "enabled",
                                    "event", "keywords", "tool", "match")}
             for t in d.get("triggers", [])],
            key=lambda t: t["id"] or "")
        rows.append(row)
    rows.sort(key=lambda r: (r["path_abs"] or "",
                             r["triggers"][0]["id"] if r["triggers"] else "",
                             r["layer"] or ""))
    return rows


def scenario_inject_only(core):
    """doc を持たないルール (inject の文面だけ) 入りの層での docs。
    返り値はパス正規化済み — main() が mock vs real を直接突き合わせる。"""
    label = os.path.basename(core)
    print("[%s inject-only]" % label)
    collected = {}
    with tempfile.TemporaryDirectory(prefix="toolhint-contract-i-") as td:
        gdir = os.path.join(td, "global")
        proj_root = os.path.join(td, "proj")
        proj = os.path.join(proj_root, ".claude", "toolhint")
        proj_sub = os.path.join(proj_root, "sub")
        other_root = os.path.join(td, "other")
        other = os.path.join(other_root, ".claude", "toolhint")
        os.makedirs(os.path.join(gdir, "docs"))
        os.makedirs(proj_sub)
        os.makedirs(proj)
        os.makedirs(other)
        doc_abs = os.path.join(gdir, "docs", "a.md")
        with open(doc_abs, "w", encoding="utf-8") as f:
            f.write("hint body\n")
        with open(os.path.join(gdir, "rules.yaml"), "w", encoding="utf-8") as f:
            f.write(
                "rules:\n"
                "  - id: t-doc\n    tool: Bash\n    match: grep\n    doc: docs/a.md\n"
                # 同じ文面の doc 無しルール 2 件 — id が違うので別エントリ
                "  - id: t-text\n    tool: Bash\n    match: grep\n"
                "    inject: TEXT ONLY\n"
                "  - id: t-text2\n    tool: Bash\n    match: ls\n"
                "    inject: TEXT ONLY\n    every: always\n"
                "  - id: kw-text\n    event: prompt\n    keywords: リリース\n"
                "    inject: \"手順を確認 ({id})\"\n"
                # doc も inject も無い (engine は何も注入しない) — それでも一覧には載る
                "  - id: no-payload\n    tool: Bash\n    match: cat\n")
        # 2 つのプロジェクト層に同 id の doc 無しルール — 記録の cwd で数え分ける
        for d in (proj, other):
            with open(os.path.join(d, "rules.yaml"), "w", encoding="utf-8") as f:
                f.write("rules:\n  - id: p-text\n    event: prompt\n"
                        "    keywords: デプロイ\n    inject: P TEXT\n")
        os.makedirs(os.path.join(gdir, "log"))
        with open(os.path.join(gdir, "log", "injections.jsonl"), "w",
                  encoding="utf-8") as f:
            def line(days, rid, layer, cwd, doc=None, tool="Bash"):
                f.write(json.dumps({
                    "ts": _iso_days_ago(days), "session_id": "s", "cwd": cwd,
                    "tool_name": tool, "rule_id": rid, "layer": layer,
                    "doc": doc, "mode": "pointer", "every": "session",
                    "input_excerpt": "x", "tool_use_id": None},
                    ensure_ascii=False) + "\n")
            line(1, "t-doc", "global", proj_root, doc=doc_abs)
            line(1, "t-text", "global", proj_root)
            line(2, "t-text", "global", other_root)
            line(8, "t-text", "global", proj_root)          # 7 日より古い → 数えない
            line(0, "t-text2", "global", proj_root)
            line(0, "kw-text", "global", proj_root, tool="prompt")
            line(1, "p-text", "project", proj_sub, tool="prompt")  # proj の中 (サブ dir)
            line(1, "p-text", "project", proj_root, tool="prompt")
            line(1, "p-text", "project", other_root, tool="prompt")  # 別プロジェクト
            # doc 付きの記録は rule_id が同じでも doc 無しルールには数えない
            line(1, "t-text", "global", proj_root, doc=doc_abs)

        dl = run(core, ["docs", "--cwd=%s" % proj_sub], gdir, td)
        rows = _docs_rows(dl)
        io_rows = [r for r in rows if r["inject_only"]]
        by_id = {r["triggers"][0]["id"]: r for r in io_rows}
        check("docs: doc 無しルールがルール 1 件 = 1 エントリで載る (同じ文面でも別)",
              sorted(by_id) == ["kw-text", "no-payload", "p-text", "t-text", "t-text2"],
              sorted(by_id))
        check("docs: inject_only エントリは name/path_abs null・exists false・triggers 1 件",
              all(r["name"] is None and r["path_abs"] is None
                  and r["exists"] is False and len(r["triggers"]) == 1
                  for r in io_rows), io_rows)
        check("docs: inject_only の body_excerpt は inject の文面 (無ければ null)",
              by_id.get("t-text", {}).get("body_excerpt") == "TEXT ONLY"
              and by_id.get("kw-text", {}).get("body_excerpt") == "手順を確認 ({id})"
              and by_id.get("no-payload", {}).get("body_excerpt") is None, io_rows)
        check("docs: doc のエントリは inject_only false",
              all(r["inject_only"] is False for r in rows if r["path_abs"]), rows)
        counts = {rid: r["inject_count_7d"] for rid, r in by_id.items()}
        check("docs: inject_only の注入回数は doc 無しの記録を rule_id + 層で数える "
              "(7 日より古い・doc 付きは数えない)",
              counts.get("t-text") == 2 and counts.get("t-text2") == 1
              and counts.get("kw-text") == 1 and counts.get("no-payload") == 0, counts)
        check("docs: project 層の doc 無しルールは記録の cwd がそのプロジェクトの中のものだけ",
              counts.get("p-text") == 2, counts)
        doc_row = next((r for r in rows if r["path_abs"] == doc_abs), {})
        check("docs: doc の注入回数は doc の絶対パス一致 (doc 無しルールの記録は混ざらない)",
              doc_row.get("inject_count_7d") == 2, doc_row)
        # list に doc 無しで載る id の集合 = docs の inject_only の id 集合
        lst = run(core, ["list", "--cwd=%s" % proj_sub], gdir, td)
        docless = sorted(r["id"] for r in lst.get("rules", []) if not r.get("doc"))
        check("docs: list の doc 無しルールが 1 件残らず inject_only として載る",
              docless == sorted(by_id), (docless, sorted(by_id)))
        collected["docs"] = rows

        # 別プロジェクトから見ると、そのプロジェクトの記録だけが数えられる
        dl2 = run(core, ["docs", "--cwd=%s" % other_root], gdir, td)
        rows2 = _docs_rows(dl2)
        p_other = next((r for r in rows2 if r["inject_only"]
                        and r["triggers"][0]["id"] == "p-text"), {})
        check("docs: 別プロジェクトの同 id は、その cwd の記録 (1 件) だけを数える",
              p_other.get("inject_count_7d") == 1, p_other)
        collected["docs_other"] = rows2

        blob = json.dumps(collected, ensure_ascii=False, sort_keys=True)
        blob = blob.replace(gdir, "<GDIR>").replace(td, "<TD>")
    return json.loads(blob)


def main():
    prompt_results = {}
    extra_results = {}
    scope_results = {}
    broken_results = {}
    inject_only_results = {}
    for core in (MOCK, REAL):
        scenario(core)
        prompt_results[core] = scenario_prompt(core)
        extra_results[core] = scenario_extra_layers(core)
        scope_results[core] = scenario_scope(core)
        broken_results[core] = scenario_broken_layer(core)
        inject_only_results[core] = scenario_inject_only(core)
    check("prompt シナリオ: mock と real の出力一致 (パス正規化後)",
          prompt_results[MOCK] == prompt_results[REAL],
          json.dumps(prompt_results, ensure_ascii=False)[:600])
    check("layers.d シナリオ: mock と real の出力一致 (パス正規化後)",
          extra_results[MOCK] == extra_results[REAL],
          json.dumps(extra_results, ensure_ascii=False)[:600])
    check("scope シナリオ: mock と real の出力一致 (パス正規化後)",
          scope_results[MOCK] == scope_results[REAL],
          json.dumps(scope_results, ensure_ascii=False)[:600])
    check("壊れた層シナリオ: mock と real の出力一致 (パス正規化後)",
          broken_results[MOCK] == broken_results[REAL],
          json.dumps(broken_results, ensure_ascii=False)[:600])
    check("doc 無しルールシナリオ: mock と real の docs 出力一致 (パス正規化後)",
          inject_only_results[MOCK] == inject_only_results[REAL],
          json.dumps(inject_only_results, ensure_ascii=False)[:600])
    if FAILURES:
        print("FAIL: %d 件" % len(FAILURES))
        return 1
    print("OK: mock と real core の契約が一致")
    return 0


if __name__ == "__main__":
    sys.exit(main())
