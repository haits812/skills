// toolhint manager — docs 起点のクライアント
// 左 = docs の棚 / 右 = 選択 doc の詳細 (本文・注入のきっかけ・最近の注入)

'use strict';

const $ = (id) => document.getElementById(id);

const state = {
  cwd: '',
  defaultCwd: null,  // cwd 指定なしで server が解決した対象 (表示モードの既定)
  info: null,        // /api/state (layers, engine, core, ui)
  docs: [],          // /api/docs (表示モードで畳んだあとの一覧 = 画面が扱う全部)
  allDocs: [],       // 畳む前の全件 — id の衝突判定・記録の照合など「実体の事実」用
  log: [],           // /api/log
  selectedKey: null, // `${layer} ${name}`
  filter: 'all',
  search: '',
  dirty: false,
  loadedBody: '',
  editingRuleId: null, // 編集フォームを開いているきっかけ (rule) の id
  dockTab: 'try',      // 下ドック「確かめる」の開いているタブ (try | log)
  testMode: 'tool',    // ドック「試す」の入力の意味 ('tool' = 操作で / 'prompt' = 発言で)
  testHelpOpen: false, // 判定の教育文を開示済みか (結果が出た瞬間に開き、doc を移ると畳む。見えるのは判定タブの間だけ)
  editorExpanded: false, // 本文エディタを上限 (行数 token) を超えて全文まで開いているか
  flashRuleId: null,   // 直前の編集で変わったきっかけ — 次の描画で一瞬だけ指す
  flashTone: 'ok',     // その変更の向き ('ok' = 届くようになる / 'warn' = 届かなくなる)
  editingDelivery: false, // 「実際に届く文面」の帯の中の編集フォームを開いているか
  draftInject: null,      // 編集中のテンプレート下書き — 帯の予告表示にだけ使う
  injectTargets: [],      // 保存先 [{id, layer}] — renderDelivery のたび保存値から再計算
  deliveryEditKey: null,  // その下書きが「どの対象プロジェクト・どの doc のものか」
  injectWrote: [],        // 直前にこの帯から書いた先 — 「標準に戻す」で必ず全部戻すため
};

// ---------------------------------------------------------------------------
// util
// ---------------------------------------------------------------------------

function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, (c) => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

/** 棚の 1 行 (= /api/docs のエントリ) の鍵。doc のエントリは層 + doc 名。
    doc を持たないルール (inject_only — doc は無く、文面だけを届けるルール 1 件 =
    1 エントリ) は層 + "rule:" + ルール id (doc 名は英数字と . _ - の *.md なので
    衝突しない)。 */
function keyOf(d) {
  return d.inject_only ? `${d.layer} rule:${ruleIdOf(d)}` : `${d.layer} ${d.name}`;
}

/** inject_only エントリのルール id (きっかけはそのルール 1 件だけ)。 */
function ruleIdOf(d) {
  const t = d && d.triggers && d.triggers[0];
  return (t && t.id) || '';
}

/** 棚・見出しに出す名前 — doc なら doc 名、doc を持たないルールならルール id。 */
function docLabel(d) { return d.inject_only ? ruleIdOf(d) : String(d.name ?? ''); }

/** 棚の並び — 注入回数 (7 日) 降順 → 名前昇順 (docLabel)。 */
function shelfOrder(a, b) {
  return (b.inject_count_7d - a.inject_count_7d) || docLabel(a).localeCompare(docLabel(b));
}

/** 「doc は無く、この文面だけを届ける」— inject_only の語彙はここ 1 箇所で決める。 */
const INJECT_ONLY_LEAD = 'doc は無く、この文面だけを届ける';
const INJECT_ONLY_TITLE = 'このルールは doc を持たない — 一致したとき agent へ届くのは、きっかけに書いた文面だけ';
// inject も無い doc 無しルール — engine は一致しても何も注入せずスキップする
const INJECT_ONLY_EMPTY_SHORT = '(届く文面が無い — 注入されない)';
const INJECT_ONLY_EMPTY_TITLE = 'doc も届く文面も無い — 一致しても何も注入されない。きっかけの編集で届く文面を書くと注入されるようになる';

// 追加層 (core/engine の layers.d/<名前>) — 外から配られる共有ルールの層。
// この画面からは書き換えない (core の書き込み経路も 全体 / このプロジェクト だけ) ので、
// 読み取り専用として出す。止めたいときは同じ id のきっかけを手元の層に置いて無効にする。
function isSharedLayer(layer) {
  return typeof layer === 'string' && layer.startsWith('layers.d/');
}

function sharedLayerName(layer) { return String(layer || '').slice('layers.d/'.length); }

/** doc の実体がどの層の中にあるか — /api/state の層 dir との最長一致で決める
    (追加層 layers.d/* は全体層 dir の内側にあるので「最長一致」が要る)。
    core の docs が返す layer は「最初に参照したルールの層」なので、手元のルールが
    共有層の doc を指しているときは実体の場所と食い違う。本文をどこへ保存するかは
    実体の場所で決まるため、書ける/書けないの判定はこちらを使う。 */
function docFileLayer(d) {
  const layers = (state.info && state.info.layers) || [];
  const p = String((d && d.path_abs) || '');
  let best = null;
  for (const l of layers) {
    if (!l.dir) continue;
    const dir = String(l.dir).replace(/\/+$/, '');
    if (p === dir || p.startsWith(dir + '/')) {
      if (!best || dir.length > best.dir.length) best = { name: l.name, dir };
    }
  }
  return best ? best.name : (d && d.layer);
}

/** この doc の本文をこの画面から保存できないか (実体が共有層の中にある)。 */
function docIsReadonly(d) { return isSharedLayer(docFileLayer(d)); }

/** きっかけ (rule) 単位の書ける/書けない — doc が共有層にあっても、手元の層の
    ルールがそれを指していれば、そのきっかけは編集・有効無効を切り替えられる。 */
function writableTriggers(d) {
  return (d.triggers || []).filter((t) => !isSharedLayer(t.layer));
}

function scopeLabel(layer) {
  if (isSharedLayer(layer)) return `共有: ${sharedLayerName(layer)}`;
  if (layer === 'global') return globalOnly() ? globalOnlyLabel() : '全体';
  return 'このプロジェクト';
}

function scopeTitle(layer) {
  if (isSharedLayer(layer)) {
    // 逃げ道は「この画面で書ける層」を名指しする — 扱う層が 1 つだけのモードでは
    // その層 (呼び名も差し替わる) だけが実行可能な選択肢
    const where = globalOnly()
      ? `「${scopeLabel('global')}」` : '「全体」か「このプロジェクト」';
    return `置き場所: 共有 (${layer}) — 外から配られたルール。この画面からは変更できない`
      + ` (止めたいときは同じ id のきっかけを${where}に作って無効にする)`;
  }
  // 層の呼び名は scopeLabel が唯一の出どころ (表示モードで差し替わる) — ここで書かない
  return layer === 'global'
    ? `置き場所: ${scopeLabel('global')} (~/.claude/toolhint/) — どのプロジェクトの操作でも注入の対象`
    : '置き場所: このプロジェクト (.claude/toolhint/) — 対象プロジェクトの操作だけ注入の対象';
}

/** 棚カード・見出しの層ドットの色クラス (style.css の --layer-* と対応)。 */
function layerDotClass(layer) {
  if (isSharedLayer(layer)) return 'layer-shared';
  return layer === 'global' ? 'layer-global' : 'layer-project';
}

function everyLabel(every) { return every === 'always' ? '頻度: 毎回' : '頻度: セッション初回'; }

function everyWord(every) { return every === 'always' ? '毎回' : 'セッション初回だけ'; }

/** engine (PreToolUse hook) がこのパソコンに配線されているか。
    未配線なら注入はいっさい起きない — 画面が現在形で「届く」と言ってよいかの唯一の判定。 */
function engineWired() {
  return !!(state.info && state.info.engine && state.info.engine.connected);
}

/** 画面が「このパソコンは未配線」と語ってよいか。
    配線の検知はこのサーバが動く 1 台ぶんの事実なので、全体層モード (共有ルール層の
    編集面) では稼働表示と同じ理由でいっさい語らない — 語らないときは配線済みと同じ
    素の文 (層の中身だけを述べる言い方) を使う。 */
function tellUnwired() { return !engineWired() && !globalOnly(); }

// ---------------------------------------------------------------------------
// 表示モード (/api/state の ui) — server の起動オプションで決まる。
//
// 全体層モード = この画面を「共有ルール層の編集面」として別の UI に埋め込むときの姿。
// 扱う層は全体層だけになり、対象プロジェクトの切り替え・プロジェクト層・engine の
// 検知表示 (このサーバが動く 1 台の事実) を出さない。判断はここでしない —
// server が ui を返すかどうかが唯一の分岐で、以下はその反映だけ。
// ---------------------------------------------------------------------------

function globalOnly() {
  return !!(state.info && state.info.ui && state.info.ui.global_only);
}

/** 対象欄の代わりに出す固定の表示ラベル (server の起動オプション)。 */
function globalOnlyLabel() {
  return (state.info && state.info.ui && state.info.ui.global_label) || '全体';
}

/** モードを DOM へ写す (毎回の読み込みで呼ぶ・冪等)。既定では何も畳まない。 */
function applyUiMode() {
  const on = globalOnly();
  // モード専用の見た目 (任意ラベルの長さ対策など) を CSS 側で足すための目印。
  // 既定モードではこのクラスが付かない = 既定の CSS は 1 つも変わらない
  document.body.classList.toggle('global-only', on);
  const targetBox = document.querySelector('.target-box');
  if (targetBox) targetBox.hidden = on;      // 対象プロジェクト (cwd) の切替
  $('target-chip').hidden = !on;             // その代わりの固定の表示ラベル
  $('engine-status').hidden = on;            // 注入の稼働表示 (1 台ぶんの検知)
  $('wire-bar').hidden = on;                 // その直し方の行 (同じ検知の続き)
  for (const el of document.querySelectorAll('.layer-choice')) el.hidden = on;
  if (!on) return;
  const label = globalOnlyLabel();
  $('target-chip-label').textContent = label;
  $('target-chip').title = `保存先は「${label}」の層 — この画面はこの層だけを扱う`;
  // 保存先の選択欄は畳むので、読み取られる値も全体層へ揃えておく
  $('ask-layer').value = 'global';
  $('manual-layer').value = 'global';
}

/** 新規作成・起案の保存先の層 — 全体層モードでは選ばせず global 固定。 */
function pickLayer(sel) { return globalOnly() ? 'global' : sel.value; }

/** 表示モードで一覧に出す doc だけに畳む。全体層モードでは全体層の doc と、
    全体層のきっかけだけを残す (プロジェクト層は画面から消える = 保存先にも選べない)。
    doc の layer は core では「最初に参照したルールの層」なので、本文の実体が全体層に
    あってもプロジェクト層のルールが先に指していれば 'project' になる — このモードでは
    それが保存先になってしまうため、残す doc は実体の層 (global) で揃える。 */
function visibleDocs(docs) {
  if (!globalOnly()) return docs;
  return docs
    // 残すのは「全体層が実体を持つ doc」と「全体層のきっかけが指している doc」。
    // 後者を落とすと、外から配られた doc を手元のきっかけで使っている全体層の
    // ルールが、編集できるのに画面から消える
    .filter((d) => docFileLayer(d) === 'global'
      || (d.triggers || []).some((t) => t.layer === 'global'))
    .map((d) => ({
      ...d,
      // 実体が全体層にある doc だけ保存先を全体層で確定させる。実体が別の層に
      // ある doc は読み取り専用のまま (判定は実体の場所を見る docIsReadonly)
      ...(docFileLayer(d) === 'global' ? { layer: 'global' } : {}),
      triggers: (d.triggers || []).filter((t) => t.layer === 'global'),
    }));
}

// ---------------------------------------------------------------------------
// きっかけ 1 件の語彙 — 画面のどこでも同じ語・同じ順で言うための唯一の出どころ。
//
// engine の既定は pointer で、agent に渡るのは本文ではなく「doc の絶対パス 1 行」。
// 本文がそのまま渡るのは mode: inline のときだけ。さらに engine の build_text は
// 「無効なきっかけ」「doc の実体が無いきっかけ」を注入しない — この 2 つを現在形で
// 「渡す」と言うと、画面が嘘をつく。この 3 つの事実をここ 1 箇所だけで言葉にする。
// ---------------------------------------------------------------------------

// engine/scripts/toolhint.py の DEFAULT_POINTER_TEMPLATE(_PROMPT) と同一
const POINTER_TEMPLATE = 'この操作の docs: {doc} — 必要なら読む';
const POINTER_TEMPLATE_PROMPT = 'この話題の docs: {doc} — 必要なら読む';

// 実体の無い doc の語彙 — きっかけが参照しているのにファイルが無い状態。engine は
// 一致しても注入せずスキップする。棚 (短文) と詳細・エディタ (全文) で同じ事実を言う
const MISSING_DOC_SHORT = '(参照先の doc が見つからない — 注入されない)';
const MISSING_DOC_TITLE = 'きっかけはこの doc を指しているが、ファイルが無い — 一致しても注入されずスキップされる。本文を保存するとファイルができ、注入されるようになる';

// 届く文面 (inject) の入力欄で「空にすると何が届くか」を placeholder で見せる。
// 標準文面は種別で違う (engine の build_text と同じ分岐) — 欄を出す側が kind を渡す。
// inline では inject が空でも標準文面は出ない (本文の前置きが無くなるだけ) —
// mode が分かる呼び出し元は渡す (省略時は従来どおり pointer の標準文面)。
function injectPlaceholder(kind, mode) {
  if (mode === 'inline') return '(前置きなし — 本文がそのまま届く)';
  return kind === 'kw' ? POINTER_TEMPLATE_PROMPT : POINTER_TEMPLATE;
}

// 届く文面の欄に添える説明 (index.html の静的フォームと同一文 — 語彙を割らない)。
// 「空にすると何が起きるか」は届き方で違う (pointer = 標準文面 / inline = 前置きが
// 無くなるだけ) ので、展開の説明と空のときの話を分けて持つ
const INJECT_HELP_VARS = '{doc} は doc の絶対パス、{id} はルール id に展開';
const INJECT_HELP = `${INJECT_HELP_VARS}。空にすると標準文面`;
const INJECT_HELP_INLINE = `${INJECT_HELP_VARS}。空にすると前置きなし`;

// ---------------------------------------------------------------------------
// きっかけの種別 (kind) — 'op' = 操作きっかけ (tool の実行直前) /
// 'kw' = ことばきっかけ (ユーザー発言 event: prompt)。判別は core/engine の
// rule_event と同じ「event: prompt のみ prompt」。画面の種別語もここで 1 度だけ決める。
// ---------------------------------------------------------------------------

const KIND_WORD = { op: '操作', kw: 'ことば' };

function triggerKind(t) { return t && t.event === 'prompt' ? 'kw' : 'op'; }

/** keywords の分割 — engine の split_prompt_keywords と同じ「, 、 ， (全角カンマ) の
    区切り + trim + 空除去」。 */
function splitKeywords(keywords) {
  return String(keywords || '').split(/[,、，]/).map((s) => s.trim()).filter(Boolean);
}

// ---------------------------------------------------------------------------
// きっかけが「構造的に決して一致しない」書き方かの静的判定 — 画面で唯一の出どころ。
//
// engine (toolhint.py) の照合対象は flatten_tool_input = json.dumps(tool_input) —
// 必ず `{` で始まり `}` で終わる JSON 1 行で、実改行も `\n` の 2 文字になる。
// そこへ re.search をかけるので、`^` の直後がリテラル `{` 以外 / `$` の直前が
// リテラル `}` 以外 の枝は、何を打っても一致しない。
//
// 誤警告は「画面が実挙動と食い違う」ものなので、断定できる時だけ断定する:
//   ・`.` `[` `(` `\s` `\d` 量指定子など、`{` を含みうる/判断できない形は死と言わない
//   ・トップレベルの `|` で割った全枝が死のときだけ「決して一致しない」と言う
//   ・一部の枝だけ死 (`^claude\b|\bclaude\s`) は partial — 一覧では黙り、書く場所でだけ注記
// ---------------------------------------------------------------------------

/** 正規表現をトップレベルの `|` で枝へ割る。`\` は次の 1 文字を巻き取り、
    文字クラス `[...]` とグループ `(...)` の中の `|` は区切りにしない。 */
function splitAlternation(re) {
  const out = [];
  let cur = '';
  let depth = 0;        // ( ) のネスト段数
  let inClass = false;  // [ ] の中か
  for (let i = 0; i < re.length; i++) {
    const c = re[i];
    if (c === '\\') { cur += c + (re[i + 1] || ''); i++; continue; }
    if (inClass) { cur += c; if (c === ']') inClass = false; continue; }
    if (c === '[') { inClass = true; cur += c; continue; }
    if (c === '(') { depth++; cur += c; continue; }
    if (c === ')') { if (depth > 0) depth--; cur += c; continue; }
    if (c === '|' && depth === 0) { out.push(cur); cur = ''; continue; }
    cur += c;
  }
  out.push(cur);
  return out;
}

/** 枝を「1 手ずつ」のトークンへ。エスケープと文字クラスは 1 トークンに巻き取るので、
    先頭・末尾のトークンを見れば `^` / `$` が生 (未エスケープ) かが分かる。 */
function reTokens(branch) {
  const out = [];
  for (let i = 0; i < branch.length; i++) {
    const c = branch[i];
    if (c === '\\') { out.push(branch.slice(i, i + 2)); i++; continue; }
    if (c === '[') {
      let j = i + 1;
      if (branch[j] === '^') j++;
      if (branch[j] === ']') j++;
      while (j < branch.length && branch[j] !== ']') { if (branch[j] === '\\') j++; j++; }
      out.push(branch.slice(i, Math.min(j + 1, branch.length)));
      i = j;
      continue;
    }
    out.push(c);
  }
  return out;
}

/** 正規表現の意味を持たない「ただの 1 文字」か。`{` `}` は量指定子の記号でもあるため
    ここでは除く — つまり `^{` `}$` を死と言うことは無い (どちらも実際に一致しうる)。 */
function isPlainLiteral(tok) {
  return typeof tok === 'string' && tok.length === 1 && !'.^$*+?()[]{}|\\'.includes(tok);
}

/** 続くトークンが「0 回でもよい」量指定子か (`a*` `a?` `a{0,2}`)。
    その場合、直前の 1 文字は必須ではないので死と断定できない。 */
function isLooseQuant(tok) { return tok === '*' || tok === '?' || tok === '{'; }

/** 枝 1 本の死因を返す ({head, tail} のどちらかが true なら決して一致しない)。 */
function branchDeath(branch) {
  const tk = reTokens(branch);
  const death = { head: false, tail: false };
  if (tk.length >= 2 && tk[0] === '^') {
    const next = tk[1];
    if (!isLooseQuant(tk[2]) && (next === '\\b' || isPlainLiteral(next))) death.head = true;
  }
  if (tk.length >= 2 && tk[tk.length - 1] === '$') {
    const prev = tk[tk.length - 2];
    if (prev === '\\b' || isPlainLiteral(prev)) death.tail = true;
  }
  return death;
}

/** どのアンカーが効かないかを engine の事実で言う (入力欄の静的ヘルプと同じ語彙)。 */
function anchorWhy(head, tail) {
  const target = '対象は {"command": …} の JSON 1 行で';
  if (head && tail) return `${target}、先頭が {" なので ^ は、末尾が "} なので $ は一致しない`;
  if (head) return `${target}、先頭が {" なので ^ は一致しない`;
  return `${target}、末尾が "} なので $ は一致しない`;
}

/** match 1 本の判定。null = 判定なし /
    {kind:'dead'} = 全枝が死 (何を打っても一致しない) /
    {kind:'partial'} = 一部の枝だけ死 (残りの枝でなら一致しうる)。 */
function deadMatchReason(match) {
  const src = String(match || '').trim();
  if (!src) return null; // match 無し = この tool のすべての操作 — 判定するものが無い
  const branches = splitAlternation(src);
  const dead = [];
  const live = [];
  let head = false;
  let tail = false;
  for (const b of branches) {
    const d = branchDeath(b);
    if (d.head || d.tail) { dead.push(b); head = head || d.head; tail = tail || d.tail; }
    else live.push(b);
  }
  if (!dead.length) return null;
  const why = anchorWhy(head, tail);
  if (!live.length) {
    return { kind: 'dead', why, text: `このきっかけは決して一致しない — ${why}` };
  }
  return {
    kind: 'partial',
    why,
    text: `${dead.join(' / ')} の部分は一致しない — 一致は ${live.join(' / ')} の方だけで起きる`,
  };
}

/** 一覧・hero で使う短い述語 — partial は誤警告になるので数えない。 */
function isDeadMatch(match) {
  const r = deadMatchReason(match);
  return !!(r && r.kind === 'dead');
}

/** /api/state の rules[] から、このきっかけの完全な定義 (mode / inject / doc 実在) を引く。
    /api/docs の triggers には inject と doc の実在が無いため、ここで補う。 */
function ruleOf(t) {
  const rules = (state.info && state.info.rules) || [];
  return rules.find((r) => r.id === t.id && r.layer === t.layer) || null;
}

/** きっかけ 1 件を表示用の正準形にそろえる。/api/docs の trigger でも、
    起案 (proposal) の rule でもここを通せば同じ語彙が使える。
    opts.rule = 参照先の rule を明示 (起案はまだ /api/state に無い) /
    opts.docAbs・opts.docExists・opts.hasDoc = rule から引けないときの控え。
    hasDoc = ルールが doc を持つか — 持たないルール (inject の文面だけを届ける) では
    doc の実在・届き方 (pointer/inline) の話をしない。 */
function viewTrigger(t, opts) {
  const o = opts || {};
  const r = (o.rule !== undefined) ? o.rule : ruleOf(t);
  const findRaw = t.find || (r && r.find) || '';
  // 分からないときは「doc を持つ」に倒す (doc の無いルールだけが例外) — rule も控えも
  // 無い呼び出し (起案の確認・部品の単体検査) が doc 無し扱いに落ちないようにする
  const hasDoc = r ? !!r.doc
    : (o.hasDoc !== undefined ? !!o.hasDoc : (t.doc !== undefined ? !!t.doc : true));
  return {
    hasDoc,
    id: t.id,
    // 保存先の層 — /api/rule/update に必要。起案 (proposal) 経路では null
    // (起案はまだ層に無い — 帯の編集 UI は起案では使わない)
    layer: t.layer || (r && r.layer) || null,
    kind: (t.event === 'prompt' || (r && r.event === 'prompt')) ? 'kw' : 'op',
    tool: t.tool,
    match: t.match || '',
    keywords: String(t.keywords ?? (r && r.keywords) ?? ''),
    find: (findRaw === 'word' || findRaw === 'regex') ? findRaw : 'substring',
    caseSensitive: (t.case ?? (r && r.case)) === 'sensitive',
    every: t.every === 'always' ? 'always' : 'session',
    mode: (((r && r.mode) || t.mode || 'pointer') === 'inline') ? 'inline' : 'pointer',
    inject: (r && r.inject) || t.inject || null,
    enabled: t.enabled !== false,
    docExists: (r && r.doc_exists !== undefined) ? r.doc_exists !== false
      : (o.docExists !== undefined ? o.docExists : true),
    docAbs: (r && r.doc_abs) || o.docAbs || null,
  };
}

/** 届き方を 1 語で (このきっかけが生きているときに何を渡すか)。 */
function deliveryWord(v) {
  if (v.hasDoc === false) return '決めた一文を渡す'; // doc の無いルールは文面だけ (届き方の別は無い)
  if (v.mode === 'inline') return '本文を渡す';
  return v.inject ? '決めた一文を渡す' : '場所を渡す';
}

/** 脇テキスト用 — いま実際に起きること。engine が注入しない条件では「渡す」と言わない。 */
function deliveryPhrase(v) {
  if (!v.enabled) return 'いまは何も渡さない';
  // 一致しない書き方は doc の有無より手前の話 — engine はここで止まり doc を見に行かない
  // (静的な死判定は操作きっかけの match 専用 — ことばきっかけには掛からない)
  if (v.kind === 'op' && isDeadMatch(v.match)) return 'この書き方では一致しない';
  // doc を持たないルールは文面 (inject) が無ければ engine は何も注入しない
  if (v.hasDoc === false) return v.inject ? deliveryWord(v) : '届く文面が無いので渡せない';
  if (!v.docExists) return 'doc ファイルが無いので渡せない';
  return deliveryWord(v);
}

/** ことばきっかけの一致条件の注記 (既定 = 含む・大小無視のときは何も言わない)。 */
function kwMetaNotes(v) {
  if (v.kind !== 'kw') return [];
  const out = [];
  if (v.find === 'word') out.push('語の単位で一致');
  if (v.find === 'regex') out.push('正規表現で一致');
  if (v.caseSensitive) out.push('大文字小文字を区別');
  return out;
}

/** 届くものを文中の名詞で (「…が agent へ届く」の主語)。 */
function deliveryNoun(v) {
  if (v.hasDoc === false) return 'きっかけに書いた一文';
  if (v.mode === 'inline') return 'このルールの本文';
  return v.inject ? 'きっかけに書いた一文' : 'この doc ファイルの場所';
}

function deliveryTitle(v) {
  const base = v.hasDoc === false
    ? `届き方: 文面だけ — ${INJECT_ONLY_LEAD} (doc の場所も本文も無い)`
    : v.mode === 'inline'
      ? '届き方: inline — このルールの本文をそのまま流し込む'
      : '届き方: pointer — doc ファイルの場所 (絶対パス) を知らせ、agent が必要なら読む';
  if (!v.enabled) return `無効 — 一致しても注入しない (設定は残る)。有効にすると ${base}`;
  const dm = v.kind === 'op' ? deadMatchReason(v.match) : null;
  if (dm && dm.kind === 'dead') return `${dm.text} — 書き方を直すと ${base}`;
  if (v.hasDoc === false) {
    return v.inject ? base : `${INJECT_ONLY_EMPTY_TITLE}`;
  }
  if (!v.docExists) return `doc の実体がまだ無い — 一致しても注入されない。実体ができると ${base}`;
  return base;
}

/** tool 正規表現がラベルと同じ (Bash / Grep 等) なら二度言わない。
    mcp__.* → 「MCP」のようにラベルへ丸められた時だけ生の正規表現を添える。
    ことばきっかけに tool は無い — 何も添えない。 */
function rawToolNote(v) {
  if (v.kind === 'kw') return '';
  return toolLabel(v.tool) === String(v.tool) ? '' : `tool 正規表現: ${v.tool}`;
}

/** きっかけ 1 件の可視の脇テキストを組む唯一の場所 — 本体の一覧も起案の確認も必ずここを通す。
    順は重要度の降順 (頻度 → 届き方 → id → tool 正規表現)。幅が足りないときは
    後ろの識別子から削れる (フレックスの縮み優先度は CSS 側の .meta-id が持つ)。
    可視は圧縮形: 頻度はチップ 1 語 (初回/毎回)、既定の「場所を渡す」は言わない
    (title・届く文面帯・hero に同内容が常時可視)、id は値のみ。
    警告 (何も渡さない / 一致しない / doc 無し) だけは可視に残す — 全文は title (triggerMetaText)。 */
function triggerMetaParts(v, opts) {
  const parts = [{ k: 'freq', t: v.every === 'always' ? '毎回' : '初回' }];
  // 行にバッジで同じことが書いてあるときは 2 度言わない — 重複すると幅を食い合い、
  // どちらも ellipsis で切れて両方読めなくなる
  if (!(opts && opts.omitDelivery)) {
    const phrase = deliveryPhrase(v);
    if (phrase !== '場所を渡す') parts.push({ k: 'strong', t: phrase });
  }
  for (const n of kwMetaNotes(v)) parts.push({ k: 'strong', t: n });
  parts.push({ k: 'id', t: v.id });
  const raw = rawToolNote(v);
  if (raw) parts.push({ k: 'id', t: raw });
  return parts;
}

/** hover (title) 用の完全文 — 可視の圧縮形と違い、頻度・届き方・id を省略しない。 */
function triggerMetaText(v) {
  const parts = [everyLabel(v.every), deliveryPhrase(v), ...kwMetaNotes(v), `id: ${v.id}`];
  const raw = rawToolNote(v);
  if (raw) parts.push(raw);
  return parts.join(' · ');
}

function triggerMetaHtml(v, opts) {
  // 芯 (頻度・届き方) と識別子 (id・tool 正規表現) を群にまとめ、群の境界だけは
  // 「·」を置かない — 幅が足りないと群ごと次の行へ落ちるので、記号が行頭・行末に
  // 孤立しない (群の中の「·」は必ず同じ行に残る)。CSS 側は .meta-group
  const parts = triggerMetaParts(v, opts);
  const inner = ['freq', 'strong', 'id']
    .map((k) => parts.filter((p) => p.k === k))
    .filter((g) => g.length)
    .map((g) => `<span class="meta-group meta-group-${g[0].k}">${
      g.map((p) => `<span class="meta-${p.k}">${esc(p.t)}</span>`)
        .join('<span class="meta-dot" aria-hidden="true">·</span>')
    }</span>`)
    .join('');
  // title は省略しない — 見えている脇テキストから何を削っても、全文はここから辿れる
  return `<div class="condition-meta" title="${esc(`${triggerMetaText(v)} — ${deliveryTitle(v)}`)}">${inner}</div>`;
}

/** engine の build_text を写して「実際に届く文面」を組む。
    engine が発火できない条件 (doc の実体が無い) では null — engine も None でスキップする。 */
function deliveryText(v, body) {
  const expand = (tpl) => String(tpl).split('{doc}').join(v.docAbs || '').split('{id}').join(v.id);
  if (v.hasDoc === false) {
    // doc を持たないルール — 届くのは inject の文面だけ。inject が無い / {doc} を
    // 参照している (展開先が無い) ときは engine が注入せずスキップする
    if (!v.inject || String(v.inject).includes('{doc}')) return null;
    return `[toolhint] ${expand(v.inject)}`;
  }
  if (!v.docExists) return null;
  if (v.mode === 'inline') {
    // ことばきっかけの inline はヘッダ無しで本文そのまま (engine の build_text と同一)
    let text = v.kind === 'kw'
      ? String(body ?? '').replace(/\n+$/, '')
      : `この操作の docs (${v.id}):\n${String(body ?? '').replace(/\n+$/, '')}`;
    if (v.inject) text = `${expand(v.inject)}\n${text}`;
    return `[toolhint] ${text}`;
  }
  if (v.inject) return `[toolhint] ${expand(v.inject)}`;
  return `[toolhint] ${expand(v.kind === 'kw' ? POINTER_TEMPLATE_PROMPT : POINTER_TEMPLATE)}`;
}

/** 帯に出す文面の集計 — texts (重複除去済み・保存値ベース) と、texts[0] を出している
    きっかけ (= 帯の編集フォームの保存先) を返す。
    注意: 同一の展開結果 ≠ 同一の inject テンプレート (inject: null と標準文面リテラル、
    {doc} とパス直書きは同じ文字列になる) — 揃えて書く前に呼び出し側が警告する。 */
function deliveryTargets(views, body) {
  const texts = [];
  const targets = [];
  for (const v of views) {
    const x = deliveryText(v, body);
    if (!x) continue;
    if (!texts.includes(x)) texts.push(x);
    if (x === texts[0]) targets.push(v);
  }
  return { texts, targets, head: targets[0] || null };
}

/** ことばきっかけの「いつ」の句 — 一致のしかた (find) で言い分ける。 */
function kwWherePhrase(v) {
  const q = shorten(v.keywords, 44);
  if (v.find === 'regex') return `発言が正規表現『${q}』に一致するとき`;
  if (v.find === 'word') return `発言に語『${q}』が現れるとき`;
  return `発言に『${q}』を含むとき`;
}

/** きっかけ 1 件を「いつ・何が届くか」の平文 1 文に (編集結果の行で使う)。 */
function triggerSentence(v) {
  if (v.kind === 'kw') {
    const kwWhere = kwWherePhrase(v);
    if (tellUnwired()) {
      return `配線すると、${kwWhere}、${deliveryNoun(v)}が届く (${everyWord(v.every)})`;
    }
    return `${kwWhere}、${deliveryNoun(v)}が届く (${everyWord(v.every)})`;
  }
  // 保存した直後の 1 行 = 「書く場所」で返る唯一の結果。決して一致しない書き方を
  // 「届く」と祝うとこの行が嘘になる — 判定は一覧・入力欄とまったく同じ出どころで言う
  const dm = deadMatchReason(v.match);
  if (dm && dm.kind === 'dead') {
    return `${toolLabel(v.tool)} の ${v.match} に一致する操作は無い — ${dm.why}`;
  }
  const where = v.match
    ? `${toolLabel(v.tool)} の ${v.match} に一致する操作`
    : `${toolLabel(v.tool)} のすべての操作`;
  // 未配線なら注入はいっさい起きない — 無条件の現在形「届く」はここでも言わない。
  // toggle / update / add の結果行はぜんぶこの 1 文を使うので、条件はここで 1 度だけ付ける
  if (tellUnwired()) {
    return `配線すると、${where}の直前に${deliveryNoun(v)}が届く (${everyWord(v.every)})`;
  }
  return `${where}の直前に、${deliveryNoun(v)}が届く (${everyWord(v.every)})`;
}

function toolLabel(tool) {
  const t = String(tool || '');
  if (/^mcp/i.test(t)) return 'MCP';
  if (/skill/i.test(t)) return 'Skill';
  const m = t.match(/[A-Za-z0-9_]+/);
  return m ? m[0] : t || '?';
}

function shorten(s, n) {
  const t = String(s ?? '');
  return t.length > n ? t.slice(0, n - 1) + '…' : t;
}

/** markdown の装飾記号を落として平文の 1 行にする。 */
function stripMd(line) {
  return String(line)
    .replace(/^#{1,6}\s*/, '')            // 見出し記号
    .replace(/^[-*+]\s+/, '')             // 箇条書き記号
    .replace(/^\d+[.)]\s+/, '')           // 番号付きリスト
    .replace(/^>\s*/, '')                 // 引用
    .replace(/\*\*([^*]+)\*\*/g, '$1')    // 強調
    .replace(/`([^`]*)`/g, '$1')          // インラインコード
    .replace(/\[([^\]]+)\]\([^)]*\)/g, '$1') // リンク
    .trim();
}

/** body_excerpt (生の先頭数行) から整った 1 行説明を作る。
    見出しは doc が自称する一行説明なので最優先。無ければ最初の本文行を平文化。 */
function cleanExcerpt(s) {
  const lines = String(s || '').split('\n').map((l) => l.trim()).filter(Boolean);
  if (!lines.length) return '';
  const heading = lines.find((l) => /^#{1,6}\s/.test(l));
  return stripMd(heading || lines[0]);
}

function abbrHome(p) {
  const s = String(p || '');
  const m = s.match(/^\/(?:Users|home)\/[^/]+(\/.*)?$/);
  return m ? '~' + (m[1] || '') : s;
}

function parseTs(ts) {
  if (typeof ts === 'number') return ts * 1000;
  if (typeof ts === 'string') {
    const d = new Date(ts);
    if (!Number.isNaN(d.getTime())) return d.getTime();
    const n = Number(ts);
    if (Number.isFinite(n)) return n * 1000;
  }
  return 0;
}

function relTime(ts) {
  const ms = parseTs(ts);
  if (!ms) return '—';
  const d = new Date(ms);
  const now = new Date();
  const hm = `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  const day = (x) => `${x.getFullYear()}-${x.getMonth()}-${x.getDate()}`;
  const yest = new Date(now.getTime() - 86400_000);
  if (day(d) === day(now)) return `今日 ${hm}`;
  if (day(d) === day(yest)) return `昨日 ${hm}`;
  return `${d.getMonth() + 1}/${d.getDate()} ${hm}`;
}

// 認証 token — 非 loopback bind のサーバは /api に token を要求する (server.mjs)。
// 起動ログの ?token= 付き URL から受け取り、sessionStorage に保持して
// アドレスバーからは消す (共有・スクショで漏らさない)
const AUTH_TOKEN = (() => {
  let t = null;
  try {
    const u = new URL(location.href);
    t = u.searchParams.get('token');
    if (t) {
      sessionStorage.setItem('toolhint_token', t);
      u.searchParams.delete('token');
      history.replaceState(null, '', u.pathname + (u.searchParams.toString() ? `?${u.searchParams}` : '') + u.hash);
    } else {
      t = sessionStorage.getItem('toolhint_token');
    }
  } catch { /* sessionStorage 不可などは token なしで続行 */ }
  return t || '';
})();

/** "/api/..." を今開いているページ基準の相対 URL に解決する。
    サブパス配下 (プレフィックスを剥がして転送するリバースプロキシの下) に置いても
    そのまま届くよう、URL の組み立てはこの 1 箇所に集約する。
    ルート直下ではこれまでと同じ絶対パスに解決される。 */
function apiUrl(path) {
  return new URL(String(path).replace(/^\/+/, ''), document.baseURI).toString();
}

async function api(path, opts) {
  if (AUTH_TOKEN) {
    opts = { ...(opts || {}) };
    opts.headers = { ...(opts.headers || {}), 'X-Toolhint-Token': AUTH_TOKEN };
  }
  const res = await fetch(apiUrl(path), opts);
  let body = null;
  try { body = await res.json(); } catch { /* 非 JSON */ }
  if (!res.ok) {
    const msg = body && body.error ? body.error : `${res.status} ${res.statusText}`;
    const err = new Error(msg);
    err.status = res.status;
    throw err;
  }
  return body;
}

function postJson(path, body) {
  return api(path, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
}

function showError(msg) {
  const bar = $('error-bar');
  if (!msg) { bar.hidden = true; return; }
  bar.textContent = msg;
  bar.hidden = false;
}

// ---------------------------------------------------------------------------
// ルールファイルが読めない層 — engine はその層を丸ごと読み飛ばす (fail-open) ので、
// 一覧に出ないルールがあり、注入も起きない。/api/state の layer_errors
// ([{layer, file, error}]) と layers[].parse_error が出どころ。
// ---------------------------------------------------------------------------

/** 読めない層の一覧 [{layer, file, error}]。layer_errors を正とし、layers[].parse_error
    だけが立っている層 (file が分からない) は層 dir を file の代わりに載せる。 */
function layerErrors() {
  const info = state.info || {};
  const out = [];
  const seen = new Set();
  for (const e of Array.isArray(info.layer_errors) ? info.layer_errors : []) {
    if (!e || typeof e !== 'object') continue;
    const layer = String(e.layer || '');
    const file = String(e.file || '');
    const key = `${layer}\n${file}`;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push({ layer, file, error: String(e.error || '') });
  }
  for (const l of info.layers || []) {
    if (!l || !l.parse_error) continue;
    if (out.some((e) => e.layer === l.name)) continue;
    out.push({ layer: String(l.name || ''), file: String(l.dir || ''), error: String(l.parse_error) });
  }
  return out;
}

/** その層のルールファイルが読めていないなら理由の文字列、読めていれば null。 */
function layerParseError(layer) {
  const hit = layerErrors().find((e) => e.layer === layer);
  return hit ? (hit.error || hit.file || '読めない') : null;
}

/** 画面上部の警告帯 — 読めない層が 1 つでもあれば出す (読み込みのたびに描き直す)。
    操作の失敗を出す error-bar とは別の帯で、操作の成否で消えない。 */
function renderLayerErrors() {
  const bar = $('layer-error-bar');
  if (!bar) return;
  // 扱う層が 1 つだけのモードでは、画面に出していないプロジェクト層の話はしない
  const errs = layerErrors().filter((e) => !globalOnly() || e.layer !== 'project');
  if (!errs.length) { bar.hidden = true; bar.innerHTML = ''; return; }
  bar.innerHTML = errs.map((e) => {
    const base = e.file.split('/').pop() || '';
    const fileWord = /\.ya?ml$/.test(base) ? base : 'ルールファイル';
    return `<div class="layer-error-line">
      <span class="layer-error-layer layer-key ${layerDotClass(e.layer)}" title="${esc(scopeTitle(e.layer))}">${esc(scopeLabel(e.layer))}</span>
      <span class="layer-error-text">この層の ${esc(fileWord)} が読めないため読み飛ばされています: <code class="layer-error-file" title="${esc(e.file)}">${esc(abbrHome(e.file))}</code>: ${esc(e.error)}</span>
    </div>`;
  }).join('');
  bar.title = 'ファイルを直すまで、この層のルールは 1 件も注入されず、この画面からこの層への保存も断られる';
  bar.hidden = false;
}

// ---------------------------------------------------------------------------
// SVG アイコン (きっかけ行の操作 — 線画・丸端ストローク)
// ---------------------------------------------------------------------------

const ICON_EDIT = '<svg viewBox="0 0 16 16" fill="none"><path d="m11.1 2.6 2.3 2.3-7.7 7.7-3 .7.7-3zM9.6 4.1l2.3 2.3" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg>';
const ICON_POWER = '<svg viewBox="0 0 16 16" fill="none"><path d="M8 2.2v5.1M4.5 4.7a5 5 0 1 0 7 0" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg>';
const ICON_TRASH = '<svg viewBox="0 0 16 16" fill="none"><path d="M2.8 4.5h10.4M6.4 4.5V3h3.2v1.5M4.3 4.5l.6 8.3a1 1 0 0 0 1 .9h4.2a1 1 0 0 0 1-.9l.6-8.3M6.6 7v4M9.4 7v4" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/></svg>';

// ---------------------------------------------------------------------------
// データ読み込み
// ---------------------------------------------------------------------------

let loadSeq = 0;             // 世代トークン — 後着した古い応答を捨てる
let lastRequestedCwd = null; // Enter 直後の blur による同一 cwd の二重発火を抑止

async function loadAll(cwd) {
  const seq = ++loadSeq;
  lastRequestedCwd = cwd || null;
  showError('');
  try {
    const q = cwd ? `?cwd=${encodeURIComponent(cwd)}` : '';
    const [info, docsRes, logRes] = await Promise.all([
      api(`/api/state${q}`),
      api(`/api/docs${q}`),
      api(`/api/log${q ? q + '&' : '?'}limit=100`),
    ]);
    if (seq !== loadSeq) return; // 後から別の読み込みが始まった — この応答は古い
    state.cwd = info.cwd;
    state.info = info;
    applyUiMode();
    renderLayerErrors(); // 読めない層の警告帯 — 一覧より先に (一覧に出ないルールがある前提を先に言う)
    // server の既定の対象 = cwd を指定せずに解決された値。全体層モードではこれ以外
    // (URL の ?cwd= や前回値) を使わないので、来ていたら既定で読み直す。
    // 読み直しの promise をそのまま返す — 保存後の `await loadAll(...)` が
    // 読み直しの完了まで待てないと、呼び出し元が古い一覧を見て選択に失敗する
    if (!cwd) state.defaultCwd = info.cwd;
    if (globalOnly() && cwd && cwd !== state.defaultCwd) return loadAll('');
    state.allDocs = docsRes.docs || [];
    state.docs = visibleDocs(state.allDocs);
    state.log = logRes.entries || [];
    // 最後に使った対象を覚えて次回起動で復元する。存在しないパス (typo) は永続化しない。
    // localStorage 不可環境 (file:// 等) は黙って素通し。モード時は復元しないので書かない
    if (info.cwd_exists !== false && !globalOnly()) {
      try { localStorage.setItem('toolhint.last-cwd', info.cwd); } catch { /* 不可環境 */ }
    }
    // 入力途中の値を上書きしない — 未フォーカス時だけサーバ解決値へ同期
    if (document.activeElement !== $('cwd-input')) $('cwd-input').value = info.cwd;
    $('cwd-input').title = info.cwd; // 省略表示でもフルパスを hover で確認できる
    fitCwdBox(); // box を必要幅へ + 末尾 (project 名) 優先で可視化 — rtl は使わない
    // 存在しないディレクトリ (typo) の明示 — 次回 loadAll 冒頭の showError('') で自然に消える
    const targetBox = document.querySelector('.target-box');
    if (info.cwd_exists === false) {
      showError(`対象が存在しないディレクトリ: ${info.cwd} — パスの typo を確認`);
      if (targetBox) targetBox.classList.add('warn');
    } else if (targetBox) {
      targetBox.classList.remove('warn');
    }
    if (state.selectedKey && !state.docs.some((d) => keyOf(d) === state.selectedKey)) {
      state.selectedKey = null;
    }
    // 未選択なら先頭 doc (注入回数 7 日の 1 位) を自動選択 — 空状態は docs 0 件の時だけ
    let autoSelected = false;
    if (!state.selectedKey && state.docs.length) {
      const top = [...state.docs].sort(shelfOrder)[0];
      state.selectedKey = keyOf(top);
      autoSelected = true;
    }
    renderShelf();
    renderStatusbar(docsRes.core);
    renderDockLog();
    if (state.selectedKey) renderDetail(autoSelected);
    else renderDetailEmpty();
  } catch (e) {
    if (seq !== loadSeq) return;
    showError(`読み込みに失敗: ${e.message}`);
  }
}

// ---------------------------------------------------------------------------
// 左ペイン: docs の棚
// ---------------------------------------------------------------------------

// 絞り込みはきっかけの種別 (kind) の閉集合 — 'all' | 'op' (操作) | 'kw' (ことば)
const FILTER_KINDS = ['all', 'op', 'kw'];

/** 一覧のエントリ群が持つルール (きっかけ) の数 — 左上の件数は「ルール N」なので、
    doc の数ではなくルールの数を数える (doc 1 枚に 3 きっかけなら 3、doc を持たない
    ルールは 1 エントリ = 1、どのルールからも参照されない doc は 0)。 */
function ruleCount(docs) {
  return docs.reduce((a, d) => a + (d.triggers ? d.triggers.length : 0), 0);
}

/** その kind のきっかけ (ルール) の数 (チップの N)。 */
function kindCount(kind) {
  return state.docs.reduce(
    (a, d) => a + d.triggers.filter((t) => triggerKind(t) === kind).length, 0);
}

function docMatchesFilter(d) {
  if (state.filter !== 'all'
      && !d.triggers.some((t) => triggerKind(t) === state.filter)) return false;
  if (state.search) {
    const s = state.search.toLowerCase();
    const hay = [docLabel(d), d.body_excerpt || '',
      ...d.triggers.flatMap((t) => [t.id, t.tool || '', t.match || '', t.keywords || ''])]
      .join('\n').toLowerCase();
    if (!hay.includes(s)) return false;
  }
  return true;
}

// 押下中 (pointerdown〜up) に棚を innerHTML で作り直すと、押していたノードが
// DOM から外れて click イベント自体が発火しない (クリックが無音で消える)。
// pointer が down の間は棚の再描画を保留し、click の処理後に流す。
let pointerHeld = false;
let shelfRenderPending = false;
function flushShelfRender() {
  if (pointerHeld || !shelfRenderPending) return;
  shelfRenderPending = false;
  renderShelf();
}
document.addEventListener('pointerdown', () => { pointerHeld = true; }, true);
for (const t of ['pointerup', 'pointercancel']) {
  document.addEventListener(t, () => {
    pointerHeld = false;
    setTimeout(flushShelfRender, 0); // click の発火後に保留分を描く
  }, true);
}

function renderShelf() {
  if (pointerHeld) { shelfRenderPending = true; return; }
  shelfRenderPending = false;
  // フィルタチップ — きっかけの種別 (操作 / ことば) の閉集合。N は種別を持つルール数
  if (!FILTER_KINDS.includes(state.filter)) state.filter = 'all';
  const chip = (f, label, title) =>
    `<button class="filter-chip${state.filter === f ? ' active' : ''}" data-f="${f}"${
      title ? ` title="${esc(title)}"` : ''}>${esc(label)}</button>`;
  $('filter-row').innerHTML = [
    chip('all', 'すべて'),
    chip('op', `操作 ${kindCount('op')}`, '操作きっかけ (tool の実行直前) を持つルール'),
    chip('kw', `ことば ${kindCount('kw')}`, 'ことばきっかけ (ユーザーの発言) を持つルール'),
  ].join('');

  const shown = state.docs.filter(docMatchesFilter).sort(shelfOrder);
  // バッジはコンパクトな数字 — 件数が実際に減っている時だけ「表示数/総数」
  // (フィルタ・検索が全件に一致している間は総数のみ — 「6/6」を出さない)。
  // 数えるのはルール (きっかけ) の数 — 一覧の見出しが「ルール」なので、doc の数ではなく
  // /api/state の rules と同じ総数を言う (doc 1 枚に 3 きっかけなら 3、
  // doc を持たないルールも 1、どのルールからも参照されない doc は 0)
  const total = ruleCount(state.docs);
  const shownRules = ruleCount(shown);
  const narrowed = shownRules !== total;
  $('doc-count').textContent = narrowed ? `${shownRules}/${total}` : String(total);
  $('doc-count').title = narrowed
    ? `絞り込みに合うルール ${shownRules} 件 / 全 ${total} 件`
    : `ルール ${total} 件`;

  const empty = $('shelf-empty');
  if (!shown.length) {
    if (state.docs.length) {
      // 「何に合わなかったか」を文中で名指しし、そのままクリアできる導線を添える —
      // 0 件の行き止まりで検索欄・チップまで視線を往復させない
      const bits = [];
      if (state.search) bits.push(`検索「${esc(state.search)}」`);
      // 絞り込み名は画面の表示語 (操作 / ことば) で言う — 内部値 'op'/'kw' を出さない
      if (state.filter !== 'all') bits.push(`絞り込み「${esc(KIND_WORD[state.filter] || state.filter)}」`);
      empty.innerHTML = `<p>${bits.join(' と ')}に合うルールが無い。</p>
        <div class="shelf-empty-actions">
          ${state.search ? '<button type="button" class="btn" data-clear="search">検索をクリア</button>' : ''}
          ${state.filter !== 'all' ? '<button type="button" class="btn" data-clear="filter">すべて表示</button>' : ''}
        </div>`;
    } else {
      empty.innerHTML = '<p>ルールはまだ無い。「+ 新規」から作る。</p>';
    }
    empty.hidden = false;
  } else {
    empty.hidden = true;
  }

  // project 層 0 件の気づき (「並んでいる docs は全体層」の誤読防止) は、棚見出しの
  // 「このプロジェクト 0」の hover (renderStatusbar) に吸収 — 常時のピル行は置かない

  // 選択中の doc が絞り込みに合わなくても棚から消さない — 「開いている doc が
  // 一覧に無い」不一致を作らないよう、末尾に「絞り込み対象外」として薄く残す
  const selDoc = state.docs.find((d) => keyOf(d) === state.selectedKey);
  const pinned = (selDoc && !shown.some((d) => keyOf(d) === state.selectedKey)) ? selDoc : null;

  // 層 (置き場所) の色ドットは「層が混ざっているとき」だけ意味を持つ — いま並んでいる
  // カードが全部同じ層なら、全行に同じ色の点が反復するだけのノイズになる。
  // 層ごとの内訳は棚見出しの .layer-key (全体 N · このプロジェクト N) が常時言っている
  const visible = pinned ? [...shown, pinned] : shown;
  const mixedLayers = new Set(visible.map((d) => docFileLayer(d))).size > 1;

  $('doc-list').innerHTML = shown.map((d) => docCardHtml(d, false, mixedLayers)).join('')
    + (pinned ? docCardHtml(pinned, true, mixedLayers) : '');
  // 0 件のときリストを伸ばすと、下の「合う docs が無い」だけが棚の底へ離れて孤立する
  // (pinned カードが残っていると :empty も効かない) — 伸ばさず直下に続かせる
  $('doc-list').classList.toggle('no-results', !shown.length);
}

/** 棚のカード 1 枚。filteredOut = 選択中だが検索・絞り込みに一致しない pinned 表示
    (selected ハイライトと a[data-key] の構造は通常カードと共通 — click 委譲を壊さない)。
    showScope = 表示中のカードに層が 2 つ以上あるか (renderShelf が判定) — 単一層なら
    層ドットは出さない (全行同色の点は情報を足さない反復ノイズ)。 */
function docCardHtml(d, filteredOut, showScope) {
  const key = keyOf(d);
  const sel = key === state.selectedKey ? ' selected' : '';
  // 有効なきっかけを優先表示。全部 disable 中の doc は信号を消灯 + 「無効」表示
  const enabledTriggers = d.triggers.filter((x) => x.enabled !== false);
  const t = enabledTriggers[0] || d.triggers[0];
  const allOff = d.triggers.length > 0 && !enabledTriggers.length;
  // 畳んだ側に「決して一致しない」書き方が沈んでいるときは件数の title で言う —
  // 棚レベルで完全死の存在が判別できないまま doc を開くまで黙らない (理由は開いた先のバッジが持つ)。
  // 死判定は操作きっかけ専用 — ことばきっかけには掛けない
  const folded = t ? d.triggers.filter((x) => x !== t) : [];
  const foldedDead = folded.filter((x) => x.enabled !== false
    && triggerKind(x) === 'op' && isDeadMatch(x.match)).length;
  const more = folded.length
    ? `<span class="trigger-more" title="ほかに ${folded.length} 件のきっかけ${foldedDead ? ` — うち ${foldedDead} 件は決して一致しない書き方 (開くと理由が見える)` : ''}">+${folded.length}</span>` : '';
  // きっかけ = 種別語チップ (操作 / ことば) + 内容。長い内容は shorten + ellipsis で
  // 切れる — title で必ず全文へ到達できるようにする
  // きっかけ 0 件でも、実体のある層のルールファイルが読めていないなら「未設定」ではなく
  // 「分からない」— 読めるようになれば出てくるきっかけを、無いものとして言わない
  const brokenLayer = !d.triggers.length ? layerParseError(docFileLayer(d)) : null;
  let trig = brokenLayer
    ? `<span class="trigger-none" title="${esc(`この層のルールファイルが読めないため、きっかけを表示できない: ${brokenLayer}`)}">きっかけ不明 (層が読めない)</span>`
    : '<span class="trigger-none">きっかけ未設定</span>';
  if (t && triggerKind(t) === 'kw') {
    const kw = String(t.keywords || '');
    const kwTitle = (t.find === 'regex' ? '正規表現: ' : '発言にどれかを含むと一致: ') + kw;
    trig = `${allOff ? '<span class="disabled-chip">無効</span>' : ''}`
      + '<span class="kind-chip kind-kw" title="ことばきっかけ — ユーザーの発言に反応する">ことば</span>'
      + `<span class="regex" title="${esc(kwTitle)}">${esc(shorten(kw, 30))}</span>${more}`;
  } else if (t) {
    const rawMatch = t.match ? t.match : 'すべて';
    trig = `${allOff ? '<span class="disabled-chip">無効</span>' : ''}`
      + '<span class="kind-chip kind-op" title="操作きっかけ — tool の実行直前に反応する">操作</span>'
      + `<span class="tool-label" title="tool: ${esc(t.tool)}">${esc(toolLabel(t.tool))}</span><span aria-hidden="true">·</span><span class="regex" title="${esc(rawMatch)}">${esc(shorten(rawMatch, 30))}</span>${more}`;
  }
  let summary;
  if (d.inject_only) {
    // doc を持たないルール — 本文欄に相当する行には、届く文面 (inject) そのものを出す。
    // 文面も無ければ engine は何も注入しない — その事実を「本文が空」と言わない
    const inject = String(d.body_excerpt || '').replace(/\s*\n\s*/g, ' ⏎ ').trim();
    summary = inject
      ? `<div class="doc-summary inject-only" title="${esc(`${INJECT_ONLY_LEAD}: ${inject}`)}">${esc(inject)}</div>`
      : `<div class="doc-summary empty missing" title="${esc(INJECT_ONLY_EMPTY_TITLE)}">${INJECT_ONLY_EMPTY_SHORT}</div>`;
  } else {
    const excerpt = cleanExcerpt(d.body_excerpt);
    // 実体の無い doc は「きっかけが参照しているのにファイルが無い」状態 (一覧に載る理由が
    // 参照だけ) — engine は一致しても注入せずスキップするので、新規のように読める
    // 「未作成」ではなく、参照先が無いことと注入されないことを言う
    summary = excerpt
      ? `<div class="doc-summary">${esc(excerpt)}</div>`
      : (d.exists
        ? '<div class="doc-summary empty">(本文が空)</div>'
        : `<div class="doc-summary empty missing" title="${esc(MISSING_DOC_TITLE)}">${MISSING_DOC_SHORT}</div>`);
  }
  // 注入回数は数字のみ — 単位と期間は hover が持つ。0 回 (= まだ発火していない) だけ状態色
  const n = d.inject_count_7d || 0;
  const count = n
    ? `<span class="doc-count" title="7 日間の注入 ${n} 回"><strong>${n}</strong></span>`
    : '<span class="doc-count zero" title="直近 7 日の注入は 0 回 (それ以前の注入は数えていない)"><strong>0</strong></span>';
  // ON/OFF トグル (name 行右端) — 触れるのは手元の層のきっかけだけ (共有のきっかけは
  // この画面から書かない)。表示・状態もその触れる範囲で言う。手元のきっかけが
  // 1 つも無ければボタン自体を出さない
  const fileLayer = docFileLayer(d);
  const shared = isSharedLayer(fileLayer);
  const writable = writableTriggers(d);
  const sharedCount = d.triggers.length - writable.length;
  const onCount = writable.filter((x) => x.enabled !== false).length;
  const anyOn = onCount > 0;
  const mixed = anyOn && onCount < writable.length;
  const sharedNote = sharedCount
    ? ` (共有の ${sharedCount} 件はここでは変えられない)` : '';
  const togTitle = (mixed
    ? `${onCount}/${writable.length} 件が有効 — 押すと止める (設定は残る)`
    : anyOn ? '注入 ON — 押すと止まる (設定は残る)' : '注入 OFF — 押すと再開する')
    + sharedNote;
  const label = docLabel(d);
  const toggle = writable.length
    ? `<button type="button" class="doc-toggle${anyOn ? ' on' : ''}" data-toggle="${esc(key)}" role="switch" aria-checked="${anyOn}" title="${esc(togTitle)}" aria-label="ルール ${esc(label)} の注入を${anyOn ? '止める' : '再開する'}"></button>`
    : '';
  const sharedChip = shared
    ? `<span class="shared-chip" title="${esc(scopeTitle(fileLayer))}">共有</span>` : '';
  // doc を持たないルールのしるし — 見出しはルール id (doc 名が無い) なので、
  // 「これは doc ではなく文面だけのルール」と行の中で 1 語言う
  const injectOnlyChip = d.inject_only
    ? `<span class="inject-only-chip" title="${esc(INJECT_ONLY_TITLE)}">文面だけ</span>` : '';
  const chip = filteredOut
    ? '<span class="filtered-out-chip" title="いまの検索・絞り込みには一致しないが、選択中なので棚に残している">絞り込み対象外</span>'
    : '';
  const nameTitle = d.inject_only ? `ルール id: ${label} — ${INJECT_ONLY_LEAD}` : label;
  return `<li class="doc-card${sel}${filteredOut ? ' filtered-out' : ''}${d.inject_only ? ' inject-only' : ''}"><a href="#" data-key="${esc(key)}"${sel ? ' aria-current="true"' : ''}>
      ${chip}
      <div class="doc-title-line">
        <span class="doc-name" title="${esc(nameTitle)}">${esc(label)}</span>
        ${injectOnlyChip}
        ${sharedChip}
        ${count}
        ${toggle}
      </div>
      ${summary}
      <div class="doc-meta">
        <span class="trigger${allOff ? ' off' : ''}">${trig}</span>
        ${(showScope || shared) ? `<span class="doc-scope ${layerDotClass(fileLayer)}" title="${esc(scopeTitle(fileLayer))}" aria-label="${esc(scopeLabel(fileLayer))}"></span>` : ''}
      </div></a></li>`;
}

// クリックはコンテナへの委譲で受ける — innerHTML 再構築で子ノードが差し替わっても
// リスナーが揮発しない (自動操作の参照安定性も上がる)
$('filter-row').addEventListener('click', (ev) => {
  const b = ev.target.closest('button[data-f]');
  if (!b) return;
  state.filter = b.dataset.f;
  renderShelf();
});
// 0 件の行き止まりからのクリア導線 (shelf-empty は innerHTML 再構築されるので委譲で受ける)
$('shelf-empty').addEventListener('click', (ev) => {
  const b = ev.target.closest('button[data-clear]');
  if (!b) return;
  if (b.dataset.clear === 'search') {
    state.search = '';
    $('search-input').value = '';
  } else {
    state.filter = 'all';
  }
  renderShelf();
});
/** カード右端のトグル — この doc の全きっかけの enabled をまとめて切り替える。
    表示は「いずれか有効なら ON」なので、ON からの押下は全 OFF / 全 OFF からは全 ON。
    途中失敗は即中断して loadAll (サーバの実際の状態へ戻す) + showError — 楽観状態を画面に残さない。 */
async function toggleDocRules(key, btn) {
  const d = state.docs.find((x) => keyOf(x) === key);
  if (!d || !d.triggers.length) return;
  // 共有 (追加層) のきっかけへは書きに行かない — 手元の層のきっかけだけまとめて切り替える
  const targets = writableTriggers(d);
  if (!targets.length) return;
  const enabled = !targets.some((t) => t.enabled !== false);
  btn.disabled = true;
  try {
    for (const t of targets) {
      await postJson('/api/rule/toggle', { cwd: state.cwd, id: t.id, layer: t.layer, enabled });
    }
    await loadAll(state.cwd);
    markTestStale('きっかけを変えた');
  } catch (e) {
    await loadAll(state.cwd); // 途中まで変わった可能性 — 表示は必ずサーバの実際の状態へ戻す
    showError(`ルール「${docLabel(d)}」の${enabled ? '有効化' : '無効化'}に失敗 (途中で中断): ${e.message}`);
  }
  // loadAll が棚ごと作り直すので btn の disabled 解除は不要 (要素ごと消える)
}

$('doc-list').addEventListener('click', (ev) => {
  // ボタン (トグル) はアンカーより先に拾って return — doc 選択に化けさせない
  const tg = ev.target.closest('button.doc-toggle');
  if (tg) {
    ev.preventDefault();
    toggleDocRules(tg.dataset.toggle, tg);
    return;
  }
  const a = ev.target.closest('a[data-key]');
  if (!a) return;
  ev.preventDefault();
  selectDoc(a.dataset.key);
});

// ---------------------------------------------------------------------------
// 右ペイン: doc 詳細
// ---------------------------------------------------------------------------

function selectedDoc() {
  return state.docs.find((d) => keyOf(d) === state.selectedKey) || null;
}

function confirmDiscardDirty() {
  return !state.dirty || window.confirm('本文に未保存の変更がある。破棄して移動する?');
}

function selectDoc(key) {
  // 同一 key の再クリックでも dirty なら confirm を通す (renderDetail(true) が
  // 本文をサーバから再読込するため、素通しすると未保存編集が無警告で消える)。
  // 非 dirty の同一 key 再選択 (apply 後の再読込 903/940 行) は confirm 無しで従来どおり。
  if (!confirmDiscardDirty()) return;
  state.dirty = false;
  state.editingRuleId = null; // doc を移ったら編集フォームは畳む
  foldDeliveryEdit(); // 帯の中の文面編集も畳む (前 doc の下書きを次の doc へ持ち越さない)
  state.editorExpanded = false; // 本文の展開も doc ごとに戻す (次の doc の fold を守る)
  state.selectedKey = key;
  renderShelf();
  renderDetail(true);
  // 切替の着地は必ず詳細の最上部 (hero: doc 名・パス・保存ボタン行) から。
  // 前 doc で下までスクロールした位置を持ち越すと、別 doc の途中に着地して迷う
  document.querySelector('.detail').scrollTop = 0;
  revealSelection();
}

/** 選択項目が画面外に残らないようにする — 棚は selected 項目へ、1 カラム時は詳細へ送る。 */
function revealSelection() {
  const sel = document.querySelector('.doc-card.selected a');
  if (sel) sel.scrollIntoView({ block: 'nearest' });
  if (window.matchMedia('(max-width: 860px)').matches) {
    const detail = document.querySelector('.detail');
    if (detail) detail.scrollIntoView({ block: 'start', behavior: 'smooth' });
  }
}

// 配線コマンド (2 段) — ステータスバーの title と同内容を、未配線 + docs 0 の
// オンボーディングでは常時表示 + コピー可能にする
const WIRE_CMDS = [
  'claude plugin marketplace add AI-Driven-R-D-Dept/toolhint',
  'claude plugin install toolhint@toolhint',
];

function renderDetailEmpty() {
  // 詳細が空 = 保存先の doc が無い。帯の編集を開いたままにすると、次に選んだ doc の
  // きっかけへ前の下書きが載る (renderDelivery を通らない唯一の経路なのでここで畳む)
  if (state.editingDelivery) foldDeliveryEdit();
  const el = $('detail-empty');
  // 未配線 + docs 0 件 = 初回セットアップ — 3 手順のオンボーディングに差し替える。
  // 全体層モードでは配線も対象プロジェクトも画面の外の話なので出さない
  const onboarding = !globalOnly() && state.info && state.info.engine
    && state.info.engine.connected === false && state.docs.length === 0;
  if (onboarding) {
    el.innerHTML = `<div class="onboarding">
      <p class="onboarding-title">はじめかた — 3 手順</p>
      <p class="onboarding-lead">この 3 つを済ませると、Claude Code が tool を使う直前に、ここで書いた docs が agent へ届くようになる。</p>
      <ol class="onboarding-steps">
        <li>
          <span class="onboarding-step-title">配線する</span>
          <span class="onboarding-step-sub">この 2 コマンドで、操作の直前に docs が届くようになる (手元に clone して使うなら 1 行目は claude plugin marketplace add &lt;clone した repo のパス 例 ./toolhint&gt;)</span>
          ${WIRE_CMDS.map((c) => `<div class="onboarding-cmd"><code>${esc(c)}</code><button type="button" class="btn onboarding-copy" data-cmd="${esc(c)}">コピー</button></div>`).join('')}
        </li>
        <li><span class="onboarding-step-title">対象プロジェクトのパスを上の「対象プロジェクト」に入れる</span></li>
        <li><span class="onboarding-step-title">「+ 新規」で最初のルールを作る</span></li>
      </ol>
    </div>`;
  } else {
    el.innerHTML = '<p>左の一覧からルールを選ぶと、本文と注入のきっかけをここで編集できる。</p>'
      + '<p class="detail-empty-sub">まだルールが無ければ「+ 新規」から。</p>';
  }
  el.hidden = false;
  $('detail-scroll').hidden = true;
}

/** クリップボードへコピー — 非 https (リモートの http) では clipboard API が
    使えないため textarea + execCommand へフォールバックする。 */
function copyText(t) {
  if (navigator.clipboard && window.isSecureContext) return navigator.clipboard.writeText(t);
  return new Promise((resolve, reject) => {
    const ta = document.createElement('textarea');
    ta.value = t;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    try {
      if (document.execCommand('copy')) resolve();
      else reject(new Error('copy failed'));
    } catch (e) { reject(e); } finally { ta.remove(); }
  });
}

$('detail-empty').addEventListener('click', async (ev) => {
  const b = ev.target.closest('button.onboarding-copy');
  if (!b) return;
  try {
    await copyText(b.dataset.cmd);
    b.textContent = 'コピーした';
  } catch {
    b.textContent = 'コピー不可 — 手で選択';
  }
  setTimeout(() => { b.textContent = 'コピー'; }, 1800);
});

/** 帯の下書きが「どの対象の何に対するものか」を表す鍵 (対象プロジェクト + doc)。
    doc の選択は selectDoc だけでは変わらない (cwd 切替・doc 消滅時の自動再選択も動く) —
    鍵が変わったら必ず畳んで、前の doc の下書きを別のきっかけへ書けないようにする。 */
function deliveryEditKeyOf(d) { return d ? `${state.cwd} ${keyOf(d)}` : null; }

/** 帯の中の文面編集を畳む — 状態・入力欄・結果表示・accent をまとめて元へ戻す。
    (状態だけ倒して入力欄に前の下書きを残すと、次に開いた doc へ持ち越される) */
function foldDeliveryEdit() {
  state.editingDelivery = false;
  state.draftInject = null;
  state.deliveryEditKey = null;
  state.injectWrote = [];
  $('delivery-edit').hidden = true;
  $('delivery-inject').value = '';
  const note = $('delivery-inject-note');
  note.textContent = '';
  note.classList.remove('err');
  updateAccentFocus(); // 主ボタンが 1 つ消えた — accent の行き先を戻す
}

/** 「実際に届く文面」— 本文カードの下に、engine が流し込む文字列そのものを出す。
    pointer では本文ではなくパス 1 行が届くため、ここが画面で唯一の正しい答えになる。
    本文カードの見出し脇 (#body-hint) も届き方に合わせて書き換える。 */
function renderDelivery(d) {
  // 開いたときと違う対象を描くなら、まず畳む。selectDoc 以外にも対象は変わる
  // (cwd 切替・doc 消滅による loadAll の自動再選択) — その経路で開いたままにすると、
  // 前の doc の下書きが別プロジェクトのきっかけへ 1 クリックで書けてしまう
  if (state.editingDelivery && state.deliveryEditKey !== deliveryEditKeyOf(d)) foldDeliveryEdit();
  const box = $('delivery');
  const noteEl = $('delivery-note');
  const textEl = $('delivery-text');
  const readEl = $('delivery-read');
  const hint = $('body-hint');
  const live = d.triggers.filter((t) => t.enabled !== false);
  const views = live.map((t) => viewTrigger(t, {
    docAbs: d.path_abs, docExists: d.exists !== false, hasDoc: !d.inject_only,
  }));
  const modes = new Set(views.map((v) => v.mode));

  // pointer 既定の説明は本文カード見出しの hover (title) へ — 正直さに効く 3 分岐
  // (inline / 混在 / きっかけ無し) だけを可視で言う。doc を持たないルールでは
  // 本文欄そのものが「doc は無く、この文面だけを届ける」の箱になる (renderInjectOnlyBody)
  hint.textContent = d.inject_only ? ''
    : !live.length ? '届くきっかけがいま無い'
      : modes.size > 1 ? 'きっかけごとに届き方が違う'
        : modes.has('inline') ? 'この本文がそのまま agent へ届く'
          : '';
  hint.title = hint.textContent;
  const bodyHead = hint.closest('.surface-head');
  if (bodyHead) {
    bodyHead.title = d.inject_only ? INJECT_ONLY_TITLE
      : (!hint.textContent && live.length) ? 'agent はこのファイルを読みに来る' : '';
  }

  // 脇注は可視 (textContent)・hover (title)・見出し行 (title) の 3 点を必ず同時に更新する
  const headEl = noteEl.closest('.delivery-head');
  const setNote = (text, title) => {
    noteEl.textContent = text;
    noteEl.title = title || text;
    if (headEl) headEl.title = title || text;
  };

  // 届け方の切替セグ — 全きっかけの mode の実際の値から状態を作る (楽観更新はしない)。
  // 混在 (きっかけごとに違う) はどちらも押されていない状態 — 押すと全部が揃う。
  // doc を持たないルールに届け方の別は無い (本文も場所も無い) — セグ自体を出さない
  const segRow = $('deliver-row');
  segRow.hidden = !d.triggers.length || !!d.inject_only;
  $('deliver-inline').setAttribute('aria-pressed', String(modes.size === 1 && modes.has('inline')));
  $('deliver-pointer').setAttribute('aria-pressed', String(modes.size === 1 && modes.has('pointer')));

  box.hidden = false;
  readEl.hidden = true;
  // 編集 UI は既定で畳んでおく — 出せる条件 (doc 実体あり・届く文面あり) を
  // 満たしたときだけ末尾の syncDeliveryEdit が開く
  $('delivery-edit-btn').hidden = true;
  $('delivery-edit').hidden = true;
  textEl.removeAttribute('data-editable');
  textEl.title = '';
  state.injectTargets = [];
  // 出せない状態へ落ちたら (きっかけの削除・無効化・doc 消滅)、開いていた編集も畳む —
  // 保存先が消えたまま入力欄だけ残さない
  const foldEdit = () => { if (state.editingDelivery) foldDeliveryEdit(); };
  if (!d.exists && !d.inject_only) {
    // 参照先が無い = 一致しても注入されない (engine のスキップ) — 「まだ無い」の
    // 新規の顔をさせず、いま届かない事実を先に言う
    setNote('参照先の doc が見つからない — 一致しても注入されない。本文を保存すると作られる', MISSING_DOC_TITLE);
    textEl.hidden = true;
    foldEdit();
    return;
  }
  if (!live.length) {
    // 扱う層が 1 つだけのモードでは「何も届かない」と全体を断定できない —
    // 画面が見ている層の話として言う
    setNote(globalOnly()
      ? 'この層に有効なきっかけが無い — この層からは何も届かない'
      : '有効なきっかけが無いので、いまは何も届かない');
    textEl.hidden = true;
    foldEdit();
    return;
  }
  // engine は同じ文面になる複数ルールを 1 回にまとめる — 数える単位も「文面の種類」。
  // head = 下に出す 1 通を作ったきっかけ (脇の語もこの 1 件で言う) /
  // targets = その 1 通を出しているきっかけ全部 (帯で編集したときの保存先)
  const body = $('editor-body').value;
  const { texts, targets, head } = deliveryTargets(views, body);
  if (!head) {
    // doc を持たないルールで文面も無い = engine は何も注入しない — その事実で言う
    setNote(d.inject_only ? INJECT_ONLY_EMPTY_SHORT.replace(/^\(|\)$/g, '') : 'いま届く文面が無い',
      d.inject_only ? INJECT_ONLY_EMPTY_TITLE : undefined);
    textEl.hidden = true;
    foldEdit();
    return;
  }
  // 帯だけが予告、集計は実際の値から — texts のグループ数・「ほかに N 通り」・保存先の算定は
  // 必ず保存値から。draft は帯の文字列生成にしか通さない
  const draftNorm = state.editingDelivery ? String(state.draftInject ?? '').trim() : null;
  const draftDirty = state.editingDelivery && (draftNorm || null) !== (head.inject || null);
  const parts = [deliveryWord(head)];
  // この帯が語る時制は 2 つの条件で変わる。両方を並べると 1 行に収まらないので、
  // 手前で止まる方 (一致しない = 配線しても届かない) を優先して 1 つだけ言う
  if (views.every((v) => v.kind === 'op' && isDeadMatch(v.match))) {
    parts.unshift('いまのきっかけでは一致しない — 一致すればこの文面');
  } else if (tellUnwired()) {
    parts.unshift('未配線 — 配線後に届く文面');
  }
  if (draftDirty) parts.unshift('未保存 — 保存すると届く文面');
  if (texts.length > 1) parts.push(`ほかに ${texts.length - 1} 通りの文面`);
  // 「未保存」を 1 行に 2 度言わない (帯の予告が出ているときは本文側の注記は畳む)
  if (!draftDirty && state.dirty && head.mode === 'inline') parts.push('未保存 — 保存後はこの内容');
  const joined = parts.join(' · ');
  // 素の未配線 pointer (警告も件数の注記も無い) だけは hover のみに畳む —
  // 未配線はバナー、届き方 (場所を渡す) は hero と下の [toolhint] 行に常時可視。
  // 「一致しない」「ほかに N 通り」「未保存」などの各文は可視のまま
  // (配線を語らないモードでは、そもそもこの文が組み立てられない)
  const plainUnwired = joined === '未配線 — 配線後に届く文面 · 場所を渡す';
  setNote(plainUnwired ? '' : joined, `${joined} — ${deliveryTitle(head)}`);
  textEl.hidden = false;
  // 編集中で下書きが保存値と違うときだけ、帯を「保存したらこうなる」の予告に差し替える。
  // {doc}/{id} 展開後の姿で出す = 打った文字が何になるかを挙動で教える
  textEl.textContent = draftDirty
    ? deliveryText({ ...head, inject: draftNorm || null }, body)
    : texts[0];
  // pointer で届くのはパス 1 行 — その先で agent が読む中身は「本文を編集している間だけ」
  // ここに添える (保存でどうなるかの予告)。クリーン時は直上の #editor-body に同一内容が
  // 常時見えているため出さない — 同じ中身を 2 度置かない。
  // 本文を書き換えるとここが動く = 本文編集の結果がこの帯で見える (inline は上の
  // 文面そのものが本文なので出さない)。
  // 先頭 2 行で切ると 3 行目以降を直しても画面が動かない (編集の結果が見えない) — 全文を出し、
  // 縦に伸びすぎないぶんは CSS の max-height + スクロールで受ける
  if (head.mode === 'pointer' && state.dirty) {
    const lines = body.split('\n').map((l) => l.trimEnd()).filter((l) => l.trim());
    // 見出しの素の文は data-base に残す — 行数の注記 (syncReadCap) を足しても
    // 前回の注記を二重に付けない
    $('delivery-read-label').dataset.base = state.dirty
      ? '保存すると、agent がこのパスを開いて読む中身はこうなる'
      : 'agent がこのパスを開いて読む中身';
    $('delivery-read-text').textContent = lines.length ? lines.join('\n') : '(本文が空)';
    // 注記で言う行数は doc の実際の行数 (末尾の改行 1 つを除いた改行数 + 1 = wc -l と同数)。
    // 折り返し後の視覚行を数えると、同じファイルがウィンドウ幅ごとに違う行数に見える
    $('delivery-read-text').dataset.lines = String(
      body.trim() ? body.replace(/\n+$/, '').split('\n').length : 0);
    readEl.hidden = false;
    syncReadCap(); // 5 行で切れているなら「続きがある」と脇の見出しで言う
  }
  syncDeliveryEdit(head, targets, texts);
}

/** 帯の中の編集 UI を、いまの実際の値 (head / targets / texts) へ合わせる。
    入力欄の value にはここでは触らない — renderDelivery は本文の毎打鍵でも走るので、
    書き戻すと打鍵が消える (書き戻すのは「開くとき」と「保存後の食い違い」だけ)。 */
function syncDeliveryEdit(head, targets, texts) {
  const btn = $('delivery-edit-btn');
  const form = $('delivery-edit');
  const textEl = $('delivery-text');
  state.injectTargets = targets.map((v) => ({ id: v.id, layer: v.layer }));
  btn.hidden = false;
  btn.textContent = state.editingDelivery ? '閉じる' : '文面を変える';
  btn.setAttribute('aria-expanded', String(state.editingDelivery));
  textEl.dataset.editable = '1';
  textEl.title = 'クリックすると、この文面を変えられる';
  if (!state.editingDelivery) return;
  form.hidden = false;
  const n = targets.length;
  // doc を持たないルールでは、この文面が届くものの全部 — 空にする (標準文面へ戻す) 道は無い
  const docless = head.hasDoc === false;
  const base = docless
    ? '届く文面 (doc が無いので、これだけが届く — 空にはできない)'
    : head.mode === 'inline'
      ? '本文の前に置く 1 行 (空 = 前置きなし)' : '届く文面 (空 = 標準)';
  $('delivery-inject-label').textContent = n >= 2
    ? `${base} — この文面のきっかけ ${n} 件に適用` : base;
  const input = $('delivery-inject');
  input.placeholder = docless ? '' : injectPlaceholder(head.kind, head.mode);
  // inline で編集できるのは前置きの 1 行だけ — 本文の編集面は上の『本文』欄 (行き止まりにしない)
  const helps = [docless ? `{id} はルール id に展開。${INJECT_ONLY_LEAD}`
    : head.mode === 'inline' ? INJECT_HELP_INLINE : INJECT_HELP];
  if (head.mode === 'inline' && !docless) helps.push('本文はすぐ上の『本文』欄で編集');
  if (texts.length > 1) {
    helps.push(`ほかの ${texts.length - 1} 通りの文面は変わらない — それぞれのきっかけの ✎ から`);
  }
  $('delivery-inject-help').textContent = helps.join('。');
  $('delivery-body-btn').hidden = head.mode !== 'inline' || docless;
  $('delivery-inject-reset').hidden = docless;
  const warns = [];
  // 同じ展開結果でもテンプレートの書き方は違うことがある (inject: null と標準文面リテラル /
  // {doc} とパス直書き)。黙って別の書き方を潰さない — 保存が何を揃えるかを先に言う
  const styles = new Set(targets.map((v) => v.inject || ''));
  if (styles.size > 1) {
    warns.push(`同じ文面だが書き方が違うきっかけがある — 保存すると ${head.id} の書き方にそろう`);
  }
  // {id} はきっかけごとに違う値へ展開される — 複数へ保存した瞬間に文面が割れ、
  // この帯は割れた片方しか指さなくなる。押す前に言う (押した後は保存結果の 1 行が実際の結果で言う)
  const tpl = String(state.draftInject ?? head.inject ?? '');
  if (n >= 2 && tpl.includes('{id}')) {
    warns.push(`{id} はきっかけごとに違う値になる — ${n} 件に保存すると文面は ${n} 通りに分かれる`);
  }
  const warn = $('delivery-inject-warn');
  warn.hidden = !warns.length;
  warn.textContent = warns.join(' / ');
}

/** いま帯に出ている文面の集計 (texts / targets / head) を保存値から引き直す。
    編集フォームを開くとき / 保存結果を読み直すときだけ使う (描画は renderDelivery が持つ)。 */
function currentDeliveryGroup() {
  const d = selectedDoc();
  if (!d || (!d.exists && !d.inject_only)) return { texts: [], targets: [], head: null };
  const views = d.triggers.filter((t) => t.enabled !== false)
    .map((t) => viewTrigger(t, {
      docAbs: d.path_abs, docExists: d.exists !== false, hasDoc: !d.inject_only,
    }));
  return deliveryTargets(views, $('editor-body').value);
}

function currentDeliveryHead() { return currentDeliveryGroup().head; }

function openDeliveryEdit() {
  const d = selectedDoc();
  if (!d || $('delivery-edit-btn').hidden) return;
  const head = currentDeliveryHead();
  if (!head) return;
  // 同じ inject キーの編集面を 2 つ同時に開かない (きっかけの鉛筆フォームは畳む) —
  // 開いたままだと、帯で保存した値を鉛筆フォームの保存が黙って巻き戻す
  const pencilOpen = !!state.editingRuleId;
  state.editingRuleId = null;
  state.editingDelivery = true;
  state.deliveryEditKey = deliveryEditKeyOf(d);
  state.injectWrote = [];
  const input = $('delivery-inject');
  input.value = head.inject || ''; // 生テンプレート ({doc} のまま — 展開後ではない)
  state.draftInject = input.value;
  const note = $('delivery-inject-note');
  note.textContent = '';
  note.classList.remove('err');
  if (pencilOpen) renderDetail(false); // 鉛筆フォームの撤去まで含めて描き直す (帯も中で更新)
  else renderDelivery(d);
  input.focus();
}

function closeDeliveryEdit() {
  foldDeliveryEdit();
  const d = selectedDoc();
  if (d) renderDelivery(d);
  updateAccentFocus();
}

/** 「標準に戻す」の保存先 — いま帯が指す先 + 直前にこの帯から書いた先 (実在するものだけ)。
    {id} 入りの文面を複数へ保存すると保存後に文面が割れ、帯は片方しか指さなくなる。
    そのまま戻すと片方に残って「標準文面に戻した」が嘘になるので、書いた先は全部戻す。 */
function deliveryResetTargets() {
  const rules = (state.info && state.info.rules) || [];
  const seen = new Set();
  const out = [];
  for (const t of [...state.injectTargets, ...state.injectWrote]) {
    const k = `${t.layer} ${t.id}`;
    if (seen.has(k)) continue;
    if (!rules.some((r) => r.id === t.id && r.layer === t.layer)) continue; // 消えた先へは投げない
    seen.add(k);
    out.push(t);
  }
  return out;
}

/** 帯で書いた文面を保存する — 保存先は既定で「いま帯に見えている文面を出しているきっかけ」
    全部 (targetsArg を渡せばその集合)。
    空 = patch.inject: null = キー削除で標準文面へ戻る (applyDeliverMode と同型)。 */
async function saveDeliveryInject(value, targetsArg) {
  const note = $('delivery-inject-note');
  // 共有 (追加層) のきっかけへは書かない — 編集面自体を出していないが二重に塞ぐ
  const targets = (targetsArg || state.injectTargets)
    .filter((t) => !isSharedLayer(t.layer));
  const n = targets.length;
  if (!n) return;
  note.textContent = '保存中…';
  note.classList.remove('err');
  // 書き込み (POST) の失敗と、そのあとの再読み込み (loadAll) の失敗は別の事故 —
  // 1 つの try でまとめると「書けたのに失敗と言う」「失敗したのに下書きを消す」が起きる
  let postErr = null;
  for (const t of targets) {
    try {
      await postJson('/api/rule/update', {
        cwd: state.cwd, id: t.id, layer: t.layer,
        patch: { inject: value || null },
      });
    } catch (e) { postErr = e; break; }
  }
  // 途中まで書けた可能性も含め、画面は必ずサーバの実際の状態で描き直す
  let loadErr = null;
  try { await loadAll(state.cwd); } catch (e) { loadErr = e; }
  if (postErr) {
    // 失敗も操作した場所へ返す — 画面最上部のエラーバーへ飛ばさない。
    // 入力欄と下書きには触らない = 打った文面が残るので、押し直すだけで再送できる
    note.textContent = `失敗: ${postErr.message}`;
    note.classList.add('err');
    return;
  }
  markTestStale('届く文面を変えた');
  if (state.editingDelivery) state.injectWrote = targets; // 「標準に戻す」はここへ全部返す
  if (loadErr) {
    // 書き込みは通っている — ここで「失敗」とだけ言うと、保存済みの変更を戻しに行かせてしまう
    note.textContent = '保存した (画面の更新に失敗 — 再読込で反映)';
    return;
  }
  // 何が起きたかは保存後に読み直した状態から言う ({id} はきっかけごとに違う値へ展開されるので、
  // 複数へ同じテンプレートを書くと保存した瞬間に文面が割れる)
  const after = currentDeliveryGroup();
  const kept = after.targets.length;
  if (!value) {
    note.textContent = n >= 2 ? `標準文面に戻した (きっかけ ${n} 件)` : '標準文面に戻した';
  } else if (n >= 2 && kept < n) {
    note.textContent = `きっかけ ${n} 件に書いた — 文面は ${after.texts.length} 通りに分かれた (この帯はうち 1 通り)`;
  } else {
    note.textContent = n >= 2
      ? `保存した — この文面が届く (きっかけ ${n} 件)` : '保存した — この文面が届く';
  }
  // フォームは開いたまま (操作した場所に結果を返す、この画面の決まり)。保存後の実際の値と
  // 入力欄が食い違うときだけ書き戻す — ここが唯一の書き戻し許可点
  const d = selectedDoc();
  if (d && state.editingDelivery) {
    const saved = (after.head && after.head.inject) || '';
    if ($('delivery-inject').value.trim() !== saved) {
      $('delivery-inject').value = saved;
      state.draftInject = saved;
    }
    renderDelivery(d);
  }
}

$('delivery-edit-btn').addEventListener('click', () => {
  if (state.editingDelivery) closeDeliveryEdit();
  else { openDeliveryEdit(); updateAccentFocus(); }
});
$('delivery-text').addEventListener('click', () => {
  const sel = window.getSelection();
  if (sel && !sel.isCollapsed) return; // テキスト選択・コピーの邪魔をしない
  if ($('delivery-edit-btn').hidden) return;
  // 開いている間は「ここでは打てない、打つのはここ」を体で教える
  if (state.editingDelivery) $('delivery-inject').focus();
  else { openDeliveryEdit(); updateAccentFocus(); }
});
$('delivery-inject').addEventListener('input', () => {
  state.draftInject = $('delivery-inject').value;
  const d = selectedDoc();
  if (d) renderDelivery(d); // 帯が {doc}/{id} 展開後の姿へ即時更新 = 因果を挙動で教える
});
$('delivery-edit').addEventListener('submit', (ev) => {
  ev.preventDefault();
  const value = $('delivery-inject').value.trim();
  const head = currentDeliveryHead();
  if (head && head.hasDoc === false && !value) {
    // doc を持たないルールの文面は空にできない (doc も文面も無いルールは何も注入しない) —
    // core も拒むが、送る前にその場で言う
    const note = $('delivery-inject-note');
    note.textContent = '届く文面は空にできない — doc が無いルールは、この文面だけを届ける';
    note.classList.add('err');
    return;
  }
  saveDeliveryInject(value);
});
$('delivery-inject-reset').addEventListener('click', () => {
  $('delivery-inject').value = '';
  state.draftInject = '';
  // 空 = patch.inject: null = キー削除で標準文面へ。戻す先は「いま帯が指す先 + この帯で
  // 直前に書いた先」— 保存後に文面が割れていても、書いたものは全部戻す
  saveDeliveryInject('', deliveryResetTargets());
});
$('delivery-body-btn').addEventListener('click', () => {
  $('editor-body').scrollIntoView({ block: 'center' });
  $('editor-body').focus(); // inline の行き止まり回避 — 本文の正しい編集面へ送る
});

/** 届け方の切替 — 選択中ルールの全きっかけの mode を揃えて書く (mode: null = pointer 既定)。
    結果はセグの脇に 1 行返し、判定・プレビューは loadAll 後の再描画に任せる。 */
async function applyDeliverMode(mode) {
  const d = selectedDoc();
  if (!d || !d.triggers.length) return;
  if (d.inject_only) return; // doc を持たないルールに届け方の別は無い (セグは出していない)
  if (docIsReadonly(d)) return; // 実体が共有 (追加層) の中 — 保存先が無い
  const btn = $(mode === 'inline' ? 'deliver-inline' : 'deliver-pointer');
  if (btn.getAttribute('aria-pressed') === 'true') return; // 既にこの届け方で揃っている
  const res = $('deliver-result');
  res.textContent = '変更中…';
  res.classList.remove('err');
  try {
    for (const t of writableTriggers(d)) {  // 共有のきっかけへは書かない
      await postJson('/api/rule/update', {
        cwd: state.cwd,
        id: t.id,
        layer: t.layer,
        patch: { mode: mode === 'inline' ? 'inline' : null },
      });
    }
    await loadAll(state.cwd);
    markTestStale('届け方を変えた');
    res.textContent = mode === 'inline'
      ? '本文をそのまま渡すようにした' : 'ファイルの場所を届けるようにした';
  } catch (e) {
    // 失敗も操作した場所へ返す (途中まで書けた可能性は再描画がそのまま出す)
    res.textContent = `失敗: ${e.message}`;
    res.classList.add('err');
  }
}
$('deliver-inline').addEventListener('click', () => applyDeliverMode('inline'));
$('deliver-pointer').addEventListener('click', () => applyDeliverMode('pointer'));

/** 対象プロジェクトの root (project 層 dir <root>/.claude/toolhint の root)。
    層 dir が分からなければ null。 */
function projectRoot() {
  const layers = (state.info && state.info.layers) || [];
  const dir = String(((layers.find((l) => l.name === 'project') || {}).dir) || '');
  const m = dir.match(/^(.*)\/\.claude\/toolhint\/?$/);
  return m ? m[1] : null;
}

/** 記録の cwd が対象プロジェクトの中か (root そのもの、またはその配下)。 */
function cwdInProject(cwd) {
  const root = projectRoot();
  const c = String(cwd || '');
  if (!root || !c) return c === state.cwd;
  return c === root || c.startsWith(root + '/');
}

/** doc を持たないルール (inject_only) の本文欄 — エディタの代わりに
    「doc は無く、この文面だけを届ける」と文面 (inject の生テンプレート) を出す。
    帯 (実際に届く文面) が {id} 展開後の姿を言うので、ここは書いたままの形。
    編集は既存のきっかけ編集フォーム (届く文面の欄) へ送る — 編集面を増やさない。
    doc のエントリでは箱を畳んでエディタを戻す (renderDetail のたびに呼ぶ・冪等)。 */
function renderInjectOnlyBody(d, readonly) {
  const box = $('inject-only-box');
  const io = !!(d && d.inject_only);
  box.hidden = !io;
  if (!io) return;
  const t = d.triggers[0] || null;
  const v = t ? viewTrigger(t, { hasDoc: false }) : null;
  const inject = (v && v.inject) || '';
  const textEl = $('inject-only-text');
  if (inject) {
    textEl.textContent = inject;
    textEl.classList.remove('empty');
    textEl.title = '届く文面 (書いたまま — {id} は下の「実際に届く文面」で展開後の姿になる)';
  } else {
    textEl.textContent = INJECT_ONLY_EMPTY_SHORT;
    textEl.classList.add('empty');
    textEl.title = INJECT_ONLY_EMPTY_TITLE;
  }
  const btn = $('inject-only-edit-btn');
  // 共有 (追加層) のルールはこの画面から書かない — 導線を出さない
  btn.hidden = readonly || !t || isSharedLayer(t.layer);
  btn.dataset.id = t ? t.id : '';
  btn.textContent = inject ? '届く文面を変える' : '届く文面を書く';
  btn.title = '届く文面は、きっかけの編集 (下の「注入のきっかけ」の ✎) で変える — このボタンはその編集フォームを開く';
}

/** 「届く文面を変える」— きっかけの編集フォーム (届く文面の欄) を開いて、その欄へ送る。 */
$('inject-only-edit-btn').addEventListener('click', () => {
  const d = selectedDoc();
  const id = $('inject-only-edit-btn').dataset.id;
  if (!d || !d.inject_only || !id) return;
  state.editingRuleId = id;
  foldDeliveryEdit(); // 同じ inject キーの編集面を 2 つ同時に開かない
  $('save-result').hidden = true;
  renderDetail(false);
  const inp = document.querySelector('#cond-list form.rule-edit-form [name=inject]');
  if (inp) {
    inp.focus();
    inp.scrollIntoView({ block: 'center' });
  }
});

function docLogEntries(d) {
  // 照合は doc 絶対パスの厳密一致が第一条件 (basename や rule_id の緩い照合は
  // 別プロジェクトの同名 doc / 同名 id と衝突し、7 日カウントと矛盾する)。
  // doc 無しの記録だけ rule_id + 層で照合し、project 層は記録の cwd がその
  // プロジェクトの中にあることも要求する (core の inject_count_7d と同じ数え方)。
  const ids = new Set(d.triggers.map((t) => t.id));
  return state.log.filter((e) => {
    if (e.doc) return e.doc === d.path_abs;
    if (!ids.has(e.rule_id) || e.layer !== d.layer) return false;
    return d.layer !== 'project' || cwdInProject(e.cwd);
  });
}

async function renderDetail(loadBody) {
  const d = selectedDoc();
  if (!d) { renderDetailEmpty(); return; }
  $('detail-empty').hidden = true;
  $('detail-scroll').hidden = false;

  const label = docLabel(d);
  $('detail-title').textContent = label;
  // 長い doc 名は ellipsis で切れる — 全文へ到達できるように。doc を持たないルールの
  // 見出しはルール id (doc 名が無い) — その旨も hover で言う
  $('detail-title').title = d.inject_only ? `ルール id: ${label} — ${INJECT_ONLY_LEAD}` : label;
  // doc の実体が共有 (追加層) の中にあるなら、この画面からは本文を保存できない —
  // doc 単位の書き換え導線 (保存・きっかけ追加・届け方・届く文面の編集) を
  // .readonly-layer で畳み、本文も編集不可にする。きっかけ 1 件ごとの編集・
  // 有効無効は層ごとに出し分ける (手元の層のきっかけは触れる — ruleActionsHtml)
  const fileLayer = docFileLayer(d);
  const readonly = isSharedLayer(fileLayer);
  const detailRoot = document.querySelector('.detail');
  if (detailRoot) {
    detailRoot.classList.toggle('readonly-layer', readonly);
    // doc を持たないルール — 本文の保存・取り消し (doc が無い) と本文エディタを畳み、
    // 代わりに「doc は無く、この文面だけを届ける」の箱を出す (renderInjectOnlyBody)
    detailRoot.classList.toggle('inject-only', !!d.inject_only);
  }
  $('editor-body').readOnly = readonly;
  $('detail-scope').textContent = readonly
    ? `${scopeLabel(fileLayer)} (読み取り専用)` : scopeLabel(fileLayer);
  $('detail-scope').title = scopeTitle(fileLayer);
  if (d.inject_only) {
    $('detail-path').textContent = 'doc なし';
    $('detail-path').title = INJECT_ONLY_TITLE;
  } else {
    $('detail-path').textContent = abbrHome(d.path_abs);
    $('detail-path').title = d.path_abs;
  }
  renderInjectOnlyBody(d, readonly);

  const entries = docLogEntries(d);
  // 回数は過去の記録 — 未配線のいまも注入が続いていると読めないよう、期間を過去で言う
  const unwired = tellUnwired();
  // 表記は圧縮 (7日 n回 / きっかけ n / 直近 …) — 全文の意味は hover の title が持つ
  const stats = [
    {
      t: `7日 ${d.inject_count_7d}回`,
      title: unwired
        ? `過去 7 日で ${d.inject_count_7d} 回注入 — いまは未配線で停止中なので、これ以上は増えない`
        : `過去 7 日で ${d.inject_count_7d} 回注入 — このルールが実際に注入された回数`,
    },
    { t: `きっかけ ${d.triggers.length}`, title: `きっかけ ${d.triggers.length} 件 — このルールを届かせる条件の数` },
  ];
  if (entries.length) {
    stats.push({ t: `直近 ${relTime(entries[0].ts)}`, title: '最後に注入された時刻' });
  }
  $('detail-stats').innerHTML = stats
    .map((s) => `<span title="${esc(s.title)}">${esc(s.t)}</span>`).join('');

  // 選択替え (loadBody) では、前 doc の本文がエディタ・届く文面プレビューに残ったまま
  // 新 doc のタイトル・パスと並ばないよう、fetch より先にクリアして「読み込み中…」で塗る
  if (loadBody) {
    $('editor-body').value = '';
    autoGrowEditor(); // 前 doc の行数を引きずらない (空 = 下限の高さへ戻す)
    setDirty(false, '読み込み中…');
  }
  renderDelivery(d);
  if (loadBody && d.exists) {
    // renderDelivery は空エディタを写してしまう — fetch 完了 (下の renderDelivery) までは
    // 本文由来のプレビュー 2 箇所も「読み込み中…」と正直に言う
    $('delivery-text').textContent = '読み込み中…';
    $('delivery-read-text').textContent = '読み込み中…';
    $('delivery-read-text').dataset.lines = ''; // 前 doc の行数を引きずらない
    if (!$('delivery-read').hidden) syncReadCap(); // 前 doc の行数の注記を残さない
  }

  // 選択替えの時だけ一時 UI をリセット (データ再読込では保存結果などの表示を消さない)
  if (loadBody) {
    $('test-result').hidden = true;
    clearTestStale();
    $('test-note').hidden = false;
    // 検査の教育文は「結果が出た瞬間」に開示する (runInjectTest) — doc を移ったら畳み直す
    state.testHelpOpen = false;
    syncTestHelp();
    $('save-result').hidden = true;
    $('deliver-result').textContent = ''; // 前ルールの届け方変更の結果を持ち越さない
    setCondFormOpen(false);
    hideCondResult();
  }

  // 注入のきっかけ (タイムラインの縦信号線はきっかけ 0 件のとき消す)
  $('cond-body').classList.toggle('empty', !d.triggers.length);
  if (state.editingRuleId && !d.triggers.some((t) => t.id === state.editingRuleId)) {
    state.editingRuleId = null; // 編集中のきっかけが消えた (削除・再読込) — フォームを畳む
  }
  // 開いている編集フォームの入力途中の値と focus を退避 — loadAll 由来の innerHTML
  // 再構築で入力がサーバ値へ黙って戻らないようにする (cwd-input と同じやり方)
  const openForm = document.querySelector('#cond-list form.rule-edit-form');
  let savedEdit = null;
  if (openForm && openForm.dataset.id === state.editingRuleId) {
    const ae = document.activeElement;
    savedEdit = {
      id: openForm.dataset.id,
      values: {},
      focus: openForm.contains(ae) && ae.name ? ae.name : null,
      selStart: null,
      selEnd: null,
    };
    for (const el of openForm.querySelectorAll('[name]')) {
      savedEdit.values[el.name] = el.type === 'checkbox' ? el.checked : el.value;
    }
    if (savedEdit.focus && typeof ae.selectionStart === 'number') {
      savedEdit.selStart = ae.selectionStart;
      savedEdit.selEnd = ae.selectionEnd;
    }
  }
  // きっかけ 0 件の理由は 2 通り — 本当に無い / 層のルールファイルが読めず分からない。
  // 後者を「無い」と言うと、ファイルを直せば戻るきっかけを足しに行かせてしまう
  const condBroken = !d.triggers.length ? layerParseError(fileLayer) : null;
  $('cond-list').innerHTML = d.triggers.length
    ? d.triggers.map((t) => (t.id === state.editingRuleId
      ? ruleEditFormHtml(t)
      : ruleCardHtml(t))).join('')
    : (condBroken
      ? `<div class="cond-none" title="${esc(condBroken)}">この層のルールファイルが読めないため、きっかけを表示できない — 上の警告のファイルを直すと戻る。</div>`
      : '<div class="cond-none">きっかけが無い — 追加するまでこのルールは注入されない。</div>');
  syncCondAddUi(); // 追加導線 (右肩の小型ボタン / 0 件の説明付き行) を件数へ揃える
  // 直前に編集したきっかけを一瞬だけ指す (CSS アニメーション 1 回)。
  // 再描画のたびに光り直さないよう、指し終わったら印を落とす
  if (state.flashRuleId) {
    const flashed = state.flashRuleId;
    setTimeout(() => { if (state.flashRuleId === flashed) state.flashRuleId = null; }, 1400);
  }
  if (savedEdit && savedEdit.id === state.editingRuleId) {
    const form = document.querySelector('#cond-list form.rule-edit-form');
    if (form && form.dataset.id === savedEdit.id) {
      for (const el of form.querySelectorAll('[name]')) {
        if (!(el.name in savedEdit.values)) continue;
        if (el.type === 'checkbox') el.checked = !!savedEdit.values[el.name];
        else el.value = savedEdit.values[el.name];
      }
      if (savedEdit.focus) {
        const f = form.querySelector(`[name=${savedEdit.focus}]`);
        if (f) {
          f.focus();
          if (savedEdit.selStart !== null && typeof f.setSelectionRange === 'function') {
            f.setSelectionRange(savedEdit.selStart, savedEdit.selEnd);
          }
        }
      }
    }
  }
  // 編集フォームを開いた時点で、既に入っている式の判定を出す (打ち始めるまで黙らない)
  updateMatchHelp(document.querySelector('#cond-list form.rule-edit-form [name=match]'));
  updateAccentFocus(); // 編集フォームの開閉で accent の行き先が変わる

  // 本文 (クリアと「読み込み中…」表示は先頭で済んでいる — ここは fetch と反映だけ)
  if (loadBody) {
    const ed = $('editor-body');
    if (d.inject_only) {
      // 読む本文が無い — エディタは畳んであり、届く文面は箱と帯が言う。
      // 保存は無効のまま (loadedBody null = 保存禁止の番兵) で、状態文も出さない
      state.loadedBody = null;
      setDirty(false);
      renderDelivery(d);
    } else if (d.exists) {
      try {
        const r = await api(`/api/doc?cwd=${encodeURIComponent(state.cwd)}&path=${encodeURIComponent(d.path_abs)}`);
        if (state.selectedKey !== keyOf(d)) return; // 読み込み中に別 doc へ移った
        ed.value = r.content;
        autoGrowEditor(); // 読み込んだ本文の行数へ主作業面を合わせる (上限まで)
        state.loadedBody = r.content;
        setDirty(false);
        renderDelivery(d); // inline のきっかけは本文そのものが届く — 読み込み後に写し直す
      } catch (e) {
        if (state.selectedKey !== keyOf(d)) return; // 失敗中に別 doc へ移った
        state.loadedBody = null; // 番兵: 本文が読めていない間は保存を禁止
        setDirty(false, `読み込み失敗: ${e.message} — doc を選び直すと再読み込み`);
      }
    } else {
      state.loadedBody = '';
      setDirty(false, 'ファイルが無い (注入されない) — 保存すると作られる');
    }
  }
}

// ---------------------------------------------------------------------------
// 下ドック: ③ 確かめる — [判定] (注入テスト) と [記録] (全ルール横断の注入履歴)。
// タブは面の名前 (判定 / 記録)、「試す」は実行ボタンの動詞 — 同語を重ねない。
// ---------------------------------------------------------------------------

function setDockTab(tab) {
  state.dockTab = tab;
  $('dock-tab-try').setAttribute('aria-selected', String(tab === 'try'));
  $('dock-tab-log').setAttribute('aria-selected', String(tab === 'log'));
  $('dock-try').hidden = tab !== 'try';
  $('dock-log').hidden = tab !== 'log';
  syncTestHelp();
}

/** 判定の教育文 (「セッション初回」の抑制は見ない検査 …) は判定の結果に添える文 —
    見せるのは「開示済み × 判定タブを開いている」間だけ。記録タブは実際に届いた
    履歴なので、この文が残ると説明が逆になる。開示は runInjectTest、畳みは doc の
    選択替え (renderDetail) が state.testHelpOpen で持ち、見た目はここ 1 箇所で決める。 */
function syncTestHelp() {
  const th = document.querySelector('.test-help');
  if (th) th.hidden = !(state.dockTab === 'try' && state.testHelpOpen);
}
$('dock-tab-try').addEventListener('click', () => setDockTab('try'));
$('dock-tab-log').addEventListener('click', () => setDockTab('log'));

/** 「判定」へ人を送る唯一の経路 — タブを判定へ切り替えて入力へフォーカスする。 */
function focusTestDock() {
  setDockTab('try');
  $('test-input').focus({ preventScroll: true });
}

/** 試す入力の意味の切替 — 'prompt' = 発言で (ことばきっかけ) / 'tool' = 操作で。
    モードが変わると入力欄の意味も変わる — 前モードの結果は主張ごと畳む。 */
function setTestMode(mode) {
  const m = mode === 'prompt' ? 'prompt' : 'tool';
  if (state.testMode === m) return;
  // 入力はモードごとに退避・復元する — 発言文が操作の判定にそのまま掛かる混乱を作らない
  state.testInputs = state.testInputs || { prompt: '', tool: '' };
  state.testInputs[state.testMode] = $('test-input').value;
  state.testMode = m;
  $('test-mode-prompt').setAttribute('aria-pressed', String(m === 'prompt'));
  $('test-mode-tool').setAttribute('aria-pressed', String(m === 'tool'));
  $('test-tool-field').hidden = m === 'prompt'; // 発言に tool は無い
  // 見出し語は畳んでいる (ドックは placeholder が意味を言う) — aria-label も同期する
  $('test-input-label').textContent = m === 'prompt' ? '発言' : '操作の入力';
  $('test-input').placeholder = m === 'prompt' ? '発言 — 例: そろそろデプロイしたい' : '操作の入力 — 例: grep -r "foo" .';
  $('test-input').setAttribute('aria-label', m === 'prompt' ? '発言' : '操作の入力');
  $('test-input').value = state.testInputs[m] || '';
  $('test-result').hidden = true;
  clearTestStale();
  $('test-note').hidden = false;
}
$('test-mode-prompt').addEventListener('click', () => setTestMode('prompt'));
$('test-mode-tool').addEventListener('click', () => setTestMode('tool'));

/** 記録タブ — 全ルール横断の注入履歴 (state.log は cwd スコープの直近 100 件)。 */
function renderDockLog() {
  // 扱う層が 1 つだけのモードでは、画面に出していない層の記録も出さない
  // (見えないルールの名前・置き場所が記録タブからだけ漏れる)
  const entries = globalOnly()
    ? state.log.filter((e) => e.layer === 'global') : state.log;
  const unwired = tellUnwired();
  // タブの脇の回数 = 一覧の 7 日合計 (棚のカードの数字と同じ出どころ = いまあるルールの分だけ)
  const n7 = state.docs.reduce((a, d) => a + (d.inject_count_7d || 0), 0);
  $('log-tab-count').textContent = n7 ? `7日で${n7}回 (いまあるルール)` : '';
  // 件数は出している行の数 (消したルールの記録も含む) — 母集団を絞ったモードでは「全ルール」と言わない
  $('log-hint').textContent = entries.length
    ? `直近 ${entries.length} 件${globalOnly() ? '' : ' (全ルール、消したルールの記録も含む)'}` : '';
  $('log-table').classList.toggle('empty', !entries.length);
  // 空のときは「空っぽの箱」で終わらせず、次の一歩まで書く (何が足りないかは配線状態で違う)
  const emptyHtml = !unwired
    ? `<div class="log-empty">
      <p>まだ注入の記録が無い。</p>
      <p class="log-empty-next">これから発火するかは、隣の「判定」で先に確かめられる。</p>
      <button type="button" id="log-empty-test-btn" class="btn">試してみる</button>
    </div>`
    : `<div class="log-empty">
      <p>まだ記録が無い — 配線すると、届いた記録がここに残る。</p>
    </div>`;
  // 過去の記録と、いまの停止状態の関係を 1 行だけ通す (行ごとには繰り返さない)
  const staleHead = (unwired && entries.length)
    ? '<div class="log-stale-head" title="配線されていた頃の記録 — いまは停止中で、新しい記録は増えない">配線されていた頃の記録</div>'
    : '';
  // 記録に残る rule_id が、いまのどのルールにも無い = 消された / 名を変えたきっかけ。
  // 「テストでは出ないのにログにはある」食い違いの正体なので、その行に静かな脇注を置く。
  // 「今は無い」は実体の事実 — 判定は /api/state の rules (層の全ルール。doc を持たない
  // ルールも含む) の id で行い、表示モードで畳んだぶんや doc の無いルールを
  // 「消された」と言わない (一覧の側でも inject_only のエントリとして見える)
  const liveIds = new Set(((state.info && state.info.rules) || []).map((r) => r.id));
  for (const d of state.allDocs) for (const t of d.triggers) liveIds.add(t.id);
  $('log-table').innerHTML = entries.length
    ? staleHead + entries.map((e) => {
      // engine は発言きっかけの記録を tool_name="prompt" で書く — 画面では表示語で言う
      const main = `${e.tool_name === 'prompt' ? '発言' : (e.tool_name || '?')} · ${e.rule_id || ''}`;
      const gone = e.rule_id && !liveIds.has(e.rule_id)
        ? '<div class="log-gone" title="この記録を作ったきっかけは、いまどのルールにも無い (削除・改名された) — 判定では出ない">このきっかけは今は無い</div>'
        : '';
      return `<div class="log-row">
        <time class="log-time">${esc(relTime(e.ts))}</time>
        <div class="log-detail">
          <div class="log-main" title="${esc(main)}">${esc(main)}</div>
          ${gone}
          <div class="log-input" title="${esc(e.input_excerpt || '')}">${esc(e.input_excerpt || '')}</div>
          <div class="log-session" title="${esc(e.cwd || e.session_id || '')}">${esc(String(e.cwd || '').split('/').pop() || e.session_id || '')}</div>
        </div>
      </div>`;
    }).join('')
    : emptyHtml;
}

$('log-table').addEventListener('click', (ev) => {
  // 空状態からの導線 — 「まだ記録が無い」で行き止まりにせず試すへ送る
  if (ev.target.closest('#log-empty-test-btn')) focusTestDock();
});

function setDirty(dirty, note) {
  state.dirty = dirty;
  $('editor-dot').classList.toggle('dirty', dirty);
  // クリーン (= 何も起きていない既定) は無言 + hover で状態を言う。dirty と note
  // (読み込み中 / 失敗 等) は状態の変化なので可視のまま
  const st = $('editor-state');
  st.textContent = note || (dirty ? '未保存の変更' : '');
  st.title = note || (dirty ? '未保存の変更 · markdown' : '保存済 · markdown');
  $('save-btn').disabled = !dirty;
  $('body-discard-btn').disabled = !dirty;
  updateAccentFocus(); // 未保存になった / 解消した — accent の行き先が変わる
}

/** 主作業面 (本文エディタ) を内容の行数に追従させる。上下限は CSS の
    --editor-lines-min / --editor-lines-max (画面の高さで切り替わる token) が持ち、
    ここは「内容の高さを測って clamp する」だけ — px も行数もここには書かない。
    高さは必ず「行高 × 整数 + 上下 padding」へスナップする: 端数で止めると最終行が
    水平に半分だけ見え、直せない汚れとして残る (行が縦に欠ける方向へは丸めない)。
    上限で止まったときは .capped を立て、続きがあることを下端フェードで言う。 */
function autoGrowEditor() {
  const el = $('editor-body');
  const cs = getComputedStyle(el);
  const line = parseFloat(cs.lineHeight);
  const pad = parseFloat(cs.paddingTop) + parseFloat(cs.paddingBottom);
  const lines = (k) => parseFloat(cs.getPropertyValue(k));
  if (!(line > 0) || !(lines('--editor-lines-min') > 0)) return; // token が読めない環境は CSS 任せ
  // n 行ぶんの表示高さ。切り上げなので、丸めで最終行が削れることは無い
  const snap = (n) => Math.ceil(line * Math.max(1, n)) + Math.ceil(pad);
  // token 側が端数 (2.5 行) でも、画面に出す高さは整数行に寄せる
  const nMin = Math.max(1, Math.round(lines('--editor-lines-min')));
  const nMax = Math.max(nMin, Math.round(lines('--editor-lines-max')));
  const minPx = snap(nMin);
  const maxTokenPx = snap(nMax);
  // 内容そのものの高さを測る — flex の伸びを一時的に外さないと clientHeight が混ざる
  const keep = { flex: el.style.flex, height: el.style.height, minHeight: el.style.minHeight };
  el.style.flex = '0 0 auto';
  el.style.minHeight = '0';
  el.style.height = '0';
  const need = el.scrollHeight; // padding 込み (box-sizing: border-box)
  el.style.flex = keep.flex;
  el.style.height = keep.height;
  el.style.minHeight = keep.minHeight;
  // 内容の高さも行単位へ。scrollHeight は整数へ丸められて返るので、その 1px で
  // 空の 1 行ぶん伸ばさないよう少しだけ甘く見る (0.15 行 ≒ 4px)
  const nNeed = Math.max(1, Math.ceil((need - pad) / line - 0.15));
  const needPx = snap(nNeed);
  // 展開中 (見出し行の展開ボタン) は上限を内容そのものまで開く — それでも行単位スナップ
  let maxPx = state.editorExpanded ? Math.max(maxTokenPx, needPx) : maxTokenPx;
  el.style.minHeight = `${Math.min(Math.max(needPx, minPx), maxPx)}px`;
  el.style.maxHeight = `${maxPx}px`;
  // 隣カラムの伸び (テスト結果・フォーム等) で shell が textarea より高くなったら、
  // その死んだ余白を行単位で textarea へ配り直す — 高さの desync (shell 231px /
  // textarea 98px の間に空白が空き、下端フェードだけが textarea から離れて浮く) を
  // 作らない。token 上限を当てた状態から測り直すので、原因が消えれば上限へ自然に戻る
  const shell = el.parentElement;
  if (!state.editorExpanded) {
    let others = 0;
    for (const c of shell.children) { if (c !== el) others += c.offsetHeight; }
    const gap = shell.clientHeight - others - el.offsetHeight;
    if (gap >= line) {
      maxPx = snap(nMax + Math.floor(gap / line));
      el.style.maxHeight = `${maxPx}px`;
    }
  }
  // 行単位スナップで配り切れない 1 行未満の残り — 下端フェードはこのぶんだけ持ち上げ、
  // 必ず最終可視行の上に重なる (shell の底ではなく textarea の底に付く)
  {
    let others = 0;
    for (const c of shell.children) { if (c !== el) others += c.offsetHeight; }
    const rem = Math.max(0, shell.clientHeight - others - el.offsetHeight);
    shell.style.setProperty('--editor-fade-gap', `${rem}px`);
  }
  const capped = needPx > maxPx;
  el.classList.toggle('capped', capped);
  el.parentElement.classList.toggle('capped', capped);
  // 隠れ分があるときだけ「開く」道を出す (フェード・常示スクロールバーと同じ条件)。
  // 展開中は「畳む」に役を替えて出続ける
  const btn = $('editor-expand-btn');
  if (btn) {
    btn.hidden = !(capped || state.editorExpanded);
    btn.classList.toggle('open', !!state.editorExpanded);
    btn.title = state.editorExpanded
      ? '折りたたむ (もとの高さへ)'
      : '本文の続きを表示 (スクロールでも読める)';
    btn.setAttribute('aria-label', btn.title);
  }
  syncEditorFade();
}

$('editor-expand-btn').addEventListener('click', () => {
  state.editorExpanded = !state.editorExpanded;
  autoGrowEditor();
});

/** 下端まで送り切ったら霞は嘘になる — その時だけ消す (フェードは「まだ続く」の記号)。 */
function syncEditorFade() {
  const el = $('editor-body');
  el.parentElement.classList.toggle('at-end', el.scrollTop + el.clientHeight >= el.scrollHeight - 1);
}
$('editor-body').addEventListener('scroll', syncEditorFade);

/** 読み取りプレビュー (agent が開いて読む中身) は 5 行で止まる。止まっているときだけ
    「続きがある」ことを脇の見出しで言う (全文が出ていれば何も足さない)。
    霞は敷かない — 最終可視行は丸ごと読める約束 (CSS の max-height) を守る。

    数えるのは doc 本文の行 (data-lines) だけ — 折り返し後の視覚行を数えると、
    同じファイルがウィンドウ幅ごとに違う行数に見え、画面が事実と食い違う
    (5 行の doc が 1200px で「全 6 行」になっていた)。見えている行数も同じ理由で言わない。 */
function syncReadCap() {
  const el = $('delivery-read-text');
  const label = $('delivery-read-label');
  const base = label.dataset.base || label.textContent;
  const total = Number(el.dataset.lines || 0);
  const capped = el.scrollHeight > el.clientHeight + 1;
  label.textContent = capped
    ? `${base} · ${total > 0 ? `全 ${total} 行 — ` : ''}先頭だけ表示 (続きはスクロール)`
    : base;
}

// 画面の高さが変わると行数の上下限 (token) も変わる — 追従させる
let resizeRaf = 0;
window.addEventListener('resize', () => {
  if (resizeRaf) return;
  resizeRaf = requestAnimationFrame(() => {
    resizeRaf = 0;
    autoGrowEditor();
    if (!$('delivery-read').hidden) syncReadCap();
  });
});

// 隣カラムの伸縮 (テスト結果が出た・畳んだ等) は window resize では拾えない —
// shell の取り分が変わるたびに高さの配り直し (autoGrowEditor は冪等) を掛ける
if (typeof ResizeObserver === 'function') {
  let shellRaf = 0;
  new ResizeObserver(() => {
    if (shellRaf) return;
    shellRaf = requestAnimationFrame(() => {
      shellRaf = 0;
      autoGrowEditor();
      if (!$('delivery-read').hidden) syncReadCap();
    });
  }).observe(document.querySelector('.editor-shell'));
}

$('editor-body').addEventListener('input', () => {
  autoGrowEditor(); // 行が増えた / 減った — 上限までは主作業面がそのまま伸びる
  if (state.loadedBody === null) {
    // 本文の読み込みに失敗している — 断片で既存 doc を上書きしないよう保存は無効のまま
    setDirty(false, '読み込み失敗 — 保存は無効。doc を選び直すと再読み込み');
    return;
  }
  setDirty($('editor-body').value !== state.loadedBody);
  // 打った本文はその場で届き方の帯へ写す (inline なら届く文面そのもの、pointer なら
  // agent が読みに来る中身)。別の操作の結果表示は、いま画面に出ている状態と
  // 食い違い始めるので畳む — 「出ている結果はいまの状態の結果」を保つ
  hideCondResult();
  const d = selectedDoc();
  if (d) renderDelivery(d);
});

// 取り消す — 編集中の本文を、最後に読み込んだ保存済み内容へ戻す (サーバは触らない)
$('body-discard-btn').addEventListener('click', () => {
  const d = selectedDoc();
  if (!d || state.loadedBody == null || !state.dirty) return;
  $('editor-body').value = state.loadedBody;
  autoGrowEditor();
  setDirty(false);
  renderDelivery(d); // inline のプレビューは本文そのもの — 戻した内容を写し直す
});

$('save-btn').addEventListener('click', async () => {
  const d = selectedDoc();
  if (!d || d.inject_only || state.loadedBody === null) return; // doc が無い / 本文が読めていない
  if (docIsReadonly(d)) return; // 実体が共有 (追加層) の中 — 保存先が無い
  const content = $('editor-body').value;
  const out = $('save-result');
  $('save-btn').disabled = true;
  // 「この内容が届く」は pointer では嘘 — 届くのはパス 1 行で、変わったのは
  // agent が読みに来るファイルの中身のほう。届き方に応じて言い分ける
  const live = d.triggers.filter((t) => t.enabled !== false);
  const modes = new Set(live.map((t) => viewTrigger(t).mode));
  // dry-run が返す文面が変わるのは inline の doc と、実体が無かった doc (engine は
  // 実体の無い doc をスキップする) だけ。変わらないなら過去の結果は嘘にならない
  const wasCreated = !d.exists;
  try {
    await postJson('/api/savedoc',
      { cwd: state.cwd, layer: d.layer, doc_name: d.name, content });
    state.loadedBody = content;
    setDirty(false);
    if (modes.has('inline') || wasCreated) markTestStale('本文を保存した');
    out.textContent = !live.length
      ? (globalOnly()
        ? '保存した — ただしこの層に有効なきっかけが無いので、この層からは届かない'
        : '保存した — ただし有効なきっかけが無いので、まだ agent には届かない')
      : (modes.size === 1 && modes.has('inline'))
        ? '保存した — 次の注入から、この本文がそのまま届く'
        : '保存した — 次の注入で agent が読みに来るファイルがこの内容になった';
    out.classList.remove('err');
    out.hidden = false;
    await loadAll(state.cwd); // 抜粋・exists・届く文面を更新
  } catch (e) {
    out.textContent = `保存に失敗: ${e.message}`;
    out.classList.add('err');
    out.hidden = false;
    $('save-btn').disabled = false;
  }
});

// 注入テスト (dry-run) — セクション 3 は常時表示。ボタンはそこへ視線を送る

$('test-run-btn').addEventListener('click', runInjectTest);
$('test-input').addEventListener('keydown', (e) => {
  if (e.isComposing || e.keyCode === 229) return; // IME 変換確定の Enter は無視
  if (e.key === 'Enter') runInjectTest();
});

let testSeq = 0; // 世代トークン — 連打時に古い応答が新しい結果を上書きしない

/** 注入テストの結果は「そのときの設定での結果」— きっかけや本文を変えた瞬間に嘘になる。
    黙って残すと、同じ画面で「一致した / 無効」が同時に立つ。主張だけ降ろし、
    同じ入力でやり直す道は残す (結果の見えやすさを落とさずに矛盾を消す)。 */
function markTestStale(reason) {
  const box = $('test-result');
  if (box.hidden || box.dataset.stale === '1') return;
  box.dataset.stale = '1';
  box.classList.add('stale');
  box.innerHTML = `<span class="test-stale-note">${esc(reason)}ので、さっきの結果はもう古い</span>`
    + '<button type="button" class="btn" id="test-rerun-btn">もう一度試す</button>';
}

function clearTestStale() {
  const box = $('test-result');
  box.dataset.stale = '';
  box.classList.remove('stale');
}

$('test-result').addEventListener('click', (ev) => {
  if (ev.target.closest('#test-rerun-btn')) runInjectTest(); // 入力欄はそのまま = 同じ入力
});

async function runInjectTest() {
  // ドックは全ルール横断の家 — ルール未選択でも試せる (選択中ルールは結果で強調するだけ)
  const d = selectedDoc();
  hideCondResult(); // きっかけ編集の結果はここで畳む — テスト結果と 2 つの主張を同居させない
  const seq = ++testSeq;
  const box = $('test-result');
  $('test-note').hidden = true;
  clearTestStale();
  box.hidden = false;
  // 結果 (空入力の案内も含む) が出た瞬間に、この検査が何を見ないかの教育文を開示する
  // (見えるのは判定タブの間だけ — 記録タブへ移ると syncTestHelp が畳む)
  state.testHelpOpen = true;
  syncTestHelp();
  // 入力が空のままの「試す」は判定しない — 「一致するきっかけが無い」と答えると
  // 設定の問題に読める。中立の案内で入力へ送り返す (API も呼ばない)
  if (!$('test-input').value.trim()) {
    box.innerHTML = state.testMode === 'prompt'
      ? '<span class="test-empty-note">発言を書いてから試す — 例: そろそろデプロイしたい</span>'
      : '<span class="test-empty-note">操作の入力を書いてから試す — 例: grep -r "foo" .</span>';
    $('test-input').focus({ preventScroll: true });
    return;
  }
  box.textContent = '確認中…';
  try {
    // 発言モードは event: prompt で core の prompt 経路へ (tool は送らない)
    const r = await postJson('/api/dryrun', state.testMode === 'prompt'
      ? { cwd: state.cwd, event: 'prompt', input: $('test-input').value }
      : { cwd: state.cwd, tool: $('test-tool').value, input: $('test-input').value });
    if (seq !== testSeq) return;
    const ids = new Set(d ? d.triggers.map((t) => t.id) : []);
    // 扱う層が 1 つだけのモードでは、画面に出していない層の一致は出さない
    // (見えないルールの id と置き場所が判定結果からだけ漏れる)。件数もこの後の
    // 見出し・行がすべて絞ったあとの ms を数える
    const ms = (r.matches || []).filter((m) => !globalOnly() || m.layer === 'global');
    // dry-run が見ているのはルールだけ — 未配線でも判定は返る。一致した結果にだけ
    // その 1 行を添え、「一致した = いま届いている」と読めないようにする。
    // 一致 0 件は配線の有無に関わらず注入されない — 否定を重ねず 1 文で終える
    // (未配線そのものの正直な語りは上部バナーと hero が持つ)
    const foot = tellUnwired()
      ? '<div class="test-result-foot">これはルール上の判定 — いま未配線なので、実際の注入は起きない</div>' : '';
    if (!ms.length) {
      // 1 層しか見ていないモードでは全体を断定できない — その層の話として言う
      box.innerHTML = globalOnly()
        ? `<span class="miss">この層に一致するきっかけが無い — この${state.testMode === 'prompt' ? '発言' : '操作'}では、この層から何も注入されない。</span>`
        : (state.testMode === 'prompt'
          ? '<span class="miss">一致するきっかけが無い — この設定では、この発言で何も注入されない。</span>'
          : '<span class="miss">一致するきっかけが無い — この設定では、この操作で何も注入されない。</span>');
      return;
    }
    // ヒットはあるが選択中のルールは 1 件も含まれない — 「一致した」と同じ絵で
    // 祝わない。不発を見出しの主文にし、他ルールの行は .hit-other で減灯する
    // (ルール未選択のドック単独テストでは強調なし — 全ヒットを同格で並べる)
    const noneMine = d && !ms.some((m) => ids.has(m.id));
    // 下の等幅 1 行は engine が実際に流し込む文字列そのもの — その旨を 1 度だけ言う
    const label = noneMine
      ? `<div class="test-result-label test-result-miss">選択中のルール (${esc(docLabel(d))}) は一致しない — 一致したのは他のルール ${ms.length} 件</div>`
      : `<div class="test-result-label">一致したきっかけ ${ms.length} 件と、そのとき実際に届く文面</div>`;
    box.innerHTML = label + ms.map((m) => {
      const mine = d && ids.has(m.id);
      return `<div class="hit${mine ? ' hit-this' : (d ? ' hit-other' : ' hit-this')}">${mine ? '→' : '·'} ${esc(m.id)} [${esc(m.layer)}]${mine ? ' (選択中のルール)' : ''}<br><span class="miss">${esc(m.text)}</span></div>`;
    }).join('') + foot;
  } catch (e) {
    if (seq !== testSeq) return;
    box.innerHTML = `<span class="miss">失敗: ${esc(e.message)}</span>`;
  }
}

// ---------------------------------------------------------------------------
// 注入のきっかけ — カード描画と CRUD (編集 / 有効・無効 / 削除)
// ---------------------------------------------------------------------------

/** きっかけ 1 件のカードの操作ボタン列 (編集 / 有効・無効 / 削除) — op と kw で共通。
    共有 (追加層) のきっかけは書き換えないので、ボタンの代わりに出どころのしるしを出す
    (同じ doc に手元の層のきっかけが並んでいても、そちらのボタンは消さない)。 */
function ruleActionsHtml(t, attrs, dis) {
  if (isSharedLayer(t.layer)) {
    return `<span class="rule-actions">
      <span class="shared-chip" title="${esc(scopeTitle(t.layer))}">共有</span>
    </span>`;
  }
  return `<span class="rule-actions">
      <button class="rule-act" type="button" data-act="edit" ${attrs}
        title="このきっかけを編集" aria-label="きっかけ ${esc(t.id)} を編集">${ICON_EDIT}</button>
      <button class="rule-act" type="button" data-act="toggle" data-next="${dis ? 'true' : 'false'}" ${attrs}
        title="${dis ? '有効にする (注入を再開)' : '無効にする (注入を止める。設定は残る)'}"
        aria-label="きっかけ ${esc(t.id)} を${dis ? '有効' : '無効'}にする">${ICON_POWER}</button>
      <button class="rule-act rule-act-del" type="button" data-act="del" ${attrs}
        title="このきっかけを削除 (doc 本文は残る)" aria-label="きっかけ ${esc(t.id)} を削除">${ICON_TRASH}</button>
    </span>`;
}

/** きっかけ 1 件のカード。頻度・届き方・id・tool 正規表現は枠を外して 1 本の脇テキストへ
    (バッジは増やさない)。disable 中だけは例外の状態なのでバッジを出す。
    kind で分岐 — kw (ことばきっかけ) は種別語チップ + keywords。死判定は op 専用。 */
function ruleCardHtml(t) {
  const v = viewTrigger(t);
  const dis = t.enabled === false;
  const attrs = `data-id="${esc(t.id)}" data-layer="${esc(t.layer)}"`;
  const flash = t.id === state.flashRuleId
    ? ` just-changed${state.flashTone === 'warn' ? ' just-changed-off' : ''}` : '';
  if (v.kind === 'kw') {
    const pat = v.keywords || '(ことば未設定)';
    const patTitle = v.find === 'regex'
      ? `正規表現: ${v.keywords}`
      : `発言にどれか 1 つ含まれると一致: ${v.keywords}`;
    const badges = dis ? '<span class="disabled-chip">無効</span>' : '';
    return `<div class="condition-rule${dis ? ' disabled' : ''}${flash}" ${attrs}>
    <span class="tool-chip kind-kw" title="ことばきっかけ — ユーザーの発言に反応する">ことば</span>
    <div class="condition-copy">
      <div class="condition-pattern" title="${esc(patTitle)}">${esc(pat)}</div>
      ${triggerMetaHtml(v)}
    </div>
    ${badges ? `<span class="rule-badges">${badges}</span>` : ''}
    ${ruleActionsHtml(t, attrs, dis)}
  </div>`;
  }
  // pattern / meta とも ellipsis で切れうる — title で全文へ到達できるようにする。
  // match 無しの書き下しは 1 語に圧縮し、全文は title で言う
  const pat = t.match || 'すべて';
  const patTitle = t.match || 'この tool のすべての操作';
  // 決して一致しない書き方は「設定の不具合」— warn を名乗れるのはこのバッジだけ。
  // 無効は自分で選んで止めた状態なので同格にしない (無彩色の .disabled-chip)。
  // 一部の枝だけ死ぬ式 (partial) はここでは黙る (誤警告になるため。書く場所でだけ注記)
  const dm = deadMatchReason(t.match);
  const dead = dm && dm.kind === 'dead' ? dm : null;
  const badges = (dis ? '<span class="disabled-chip">無効</span>' : '')
    + (dead ? `<span class="dead-chip" title="${esc(dead.text)}">決して一致しない</span>` : '');
  // 診断の理由は hover (title) に隠さない — 行の中に脇テキストで常設する。
  // 語彙は deadMatchReason の why をそのまま使う (バッジが「決して一致しない」を言うので
  // 理由の行では繰り返さない)
  const deadWhy = dead ? `<div class="dead-reason">${esc(dead.why)}</div>` : '';
  return `<div class="condition-rule${dis ? ' disabled' : ''}${dead ? ' dead' : ''}${flash}" ${attrs}>
    <span class="tool-chip" title="tool: ${esc(t.tool)}">${esc(toolLabel(t.tool))}</span>
    <div class="condition-copy">
      <div class="condition-pattern" title="${esc(dead ? `${pat} — ${dead.text}` : patTitle)}">${esc(pat)}</div>
      ${triggerMetaHtml(v, { omitDelivery: !!dead })}
      ${deadWhy}
    </div>
    ${badges ? `<span class="rule-badges">${badges}</span>` : ''}
    ${ruleActionsHtml(t, attrs, dis)}
  </div>`;
}

/** 起案の確認に出すきっかけ 1 行の中身 — 本体の一覧 (ruleCardHtml) と同じ部品・
    同じ語彙で描く (バッジと操作ボタンは起案には無い)。両種別を扱う。 */
function proposalCondHtml(v) {
  if (v.kind === 'kw') {
    const pat = v.keywords || '(ことば未設定)';
    const patTitle = v.find === 'regex'
      ? `正規表現: ${v.keywords}`
      : `発言にどれか 1 つ含まれると一致: ${v.keywords}`;
    return `<span class="tool-chip kind-kw" title="ことばきっかけ — ユーザーの発言に反応する">ことば</span>
      <div class="condition-copy">
        <div class="condition-pattern" title="${esc(patTitle)}">${esc(pat)}</div>
        ${triggerMetaHtml(v)}
      </div>`;
  }
  return `<span class="tool-chip" title="tool: ${esc(v.tool)}">${esc(toolLabel(v.tool))}</span>
    <div class="condition-copy">
      <div class="condition-pattern">${esc(v.match || '(この tool のすべての操作)')}</div>
      ${triggerMetaHtml(v)}
    </div>`;
}

/** きっかけの編集フォーム (カードの位置にインライン表示)。kind で分岐 —
    kw は keywords / 一致のしかた (find) / 大小区別 (case) / 頻度。
    op は tool / match / 頻度 (deadMatch のライブ検証は op の match 欄専用)。
    届く文面 (inject) は両種別・両届き方 (pointer / inline) で有効なので常に出す —
    inline では本文の前置き 1 行になる (engine の build_text と同じ)。 */
function ruleEditFormHtml(t) {
  const v = viewTrigger(t);
  const always = t.every === 'always';
  const everyField = `<label class="field">
        <span class="field-label">頻度</span>
        <select class="input" name="every">
          <option value="session"${always ? '' : ' selected'}>セッション初回</option>
          <option value="always"${always ? ' selected' : ''}>毎回</option>
        </select>
      </label>`;
  // 空 = 標準文面 (placeholder に実物を出す)。値を消して保存すると inject キーが消える。
  // inline だけは空でも標準文面は出ない (本文の前置きが無くなるだけ) — 帯の編集面と
  // 同じ語で言い分ける (placeholder だけ直すと、欄の説明と placeholder が食い違う)
  // doc を持たないルールでは、この文面が届くものの全部 — 空 (標準文面) の道は無い
  const docless = v.hasDoc === false;
  const inlineInject = v.mode === 'inline';
  const injectHelp = docless ? `{id} はルール id に展開。${INJECT_ONLY_LEAD} — 空にはできない`
    : inlineInject ? INJECT_HELP_INLINE : INJECT_HELP;
  const injectLabel = docless ? '届く文面 (doc が無いので、これだけが届く)'
    : inlineInject ? '本文の前に置く 1 行 (空 = 前置きなし)' : '届く文面 (空 = 標準)';
  const injectField = `<label class="field grow" title="${esc(injectHelp)}">
        <span class="field-label">${esc(injectLabel)}</span>
        <input class="input" name="inject" value="${esc(v.inject || '')}"
          placeholder="${esc(docless ? '' : injectPlaceholder(v.kind, v.mode))}" spellcheck="false">
        <span class="field-help defer">${esc(injectHelp)}</span>
      </label>`;
  const actions = `<div class="form-actions">
      <button class="btn btn-primary" type="submit">保存する</button>
      <button class="btn" type="button" data-act="edit-cancel">やめる</button>
      <span class="form-note rule-edit-note"></span>
    </div>`;
  if (v.kind === 'kw') {
    return `<form class="cond-form rule-edit-form" data-id="${esc(t.id)}" data-layer="${esc(t.layer)}" data-kind="kw">
    <div class="condition-meta">編集中: id ${esc(t.id)} (ことばきっかけ)</div>
    <div class="cond-form-grid">
      <label class="field grow">
        <span class="field-label">ことば (, か 、 か ， で区切る)</span>
        <input class="input" name="keywords" value="${esc(v.keywords)}" spellcheck="false">
        <span class="field-help">発言にどれか 1 つ含まれると一致。「正規表現」では区切らず全体を 1 つの式として読む</span>
      </label>
      <label class="field">
        <span class="field-label">一致のしかた</span>
        <select class="input" name="find">
          <option value="substring"${v.find === 'substring' ? ' selected' : ''}>含む</option>
          <option value="word"${v.find === 'word' ? ' selected' : ''}>語として</option>
          <option value="regex"${v.find === 'regex' ? ' selected' : ''}>正規表現</option>
        </select>
      </label>
      <label class="field field-check" title="ON で大文字小文字を区別する (既定は区別しない)">
        <span class="field-label">大小区別</span>
        <input type="checkbox" name="case"${v.caseSensitive ? ' checked' : ''}>
      </label>
      ${everyField}
      ${injectField}
    </div>
    ${actions}
  </form>`;
  }
  return `<form class="cond-form rule-edit-form" data-id="${esc(t.id)}" data-layer="${esc(t.layer)}" data-kind="op">
    <div class="condition-meta">編集中: id ${esc(t.id)}</div>
    <div class="cond-form-grid">
      <label class="field field-tool">
        <span class="field-label">tool</span>
        <input class="input mono" name="tool" value="${esc(t.tool)}" spellcheck="false">
      </label>
      <label class="field grow">
        <span class="field-label">match (入力への正規表現)</span>
        <input class="input mono" name="match" value="${esc(t.match || '')}" spellcheck="false">
        <span class="field-help">空にすると、この tool のすべての操作が対象になる</span>
      </label>
      ${everyField}
      ${injectField}
    </div>
    ${actions}
  </form>`;
}

// ---------------------------------------------------------------------------
// match を「書く場所」のライブ検証 — 追加フォーム / 編集フォーム / 手動作成の 3 箇所。
//
// 打った瞬間に、その式が決して一致しないことを理由つきで返す。保存はブロックしない —
// engine は保存を拒まないので、止めると画面と実挙動が食い違う。
// 画面がすることは「黙らないこと」だけ。
// ---------------------------------------------------------------------------

/** その入力欄の直下ヘルプを、いま打たれている式の判定で書き換える。
    死 = warn で断定 / 一部の枝だけ死 = 静かな注記 / それ以外 = もとの静的ヘルプへ戻す。 */
function updateMatchHelp(input) {
  if (!input) return;
  const field = input.closest('.field');
  const help = field && field.querySelector('.field-help');
  if (!help) return;
  // 場所ごとに静的ヘルプの文言が違う — 初回に控えて、判定が消えたら必ずそこへ戻す
  if (help.dataset.staticHelp === undefined) help.dataset.staticHelp = help.textContent;
  const dm = deadMatchReason(input.value.trim());
  help.classList.toggle('field-help-warn', !!(dm && dm.kind === 'dead'));
  help.textContent = dm ? dm.text : help.dataset.staticHelp;
  help.title = dm ? dm.why : '';
}

$('cond-match').addEventListener('input', () => updateMatchHelp($('cond-match')));
$('manual-match').addEventListener('input', () => updateMatchHelp($('manual-match')));
// 編集フォームは innerHTML で作り直される — 個別 listener ではなく委譲で受ける
$('cond-list').addEventListener('input', (ev) => {
  const inp = ev.target.closest('form.rule-edit-form [name=match]');
  if (inp) updateMatchHelp(inp);
});

// ---------------------------------------------------------------------------
// きっかけ編集の結果表示 — 追加 / 更新 / 有効・無効 / 削除の「効き目」をその場で返す。
// 黙って再描画するだけでは、何がどう変わったのか・本当に発火するのかが確認できない。
// ---------------------------------------------------------------------------

let condResultTrigger = null; // 「注入テストで確かめる」が指すきっかけ (無ければ非表示)

/** tone は結果の「向き」— ok = 届くようになった / warn = 届かなくなった / err = 失敗。
    届かなくなる変更を ok 緑で祝わない。 */
function showCondResult(text, trigger, tone) {
  condResultTrigger = (tone === 'ok' || tone === undefined) ? (trigger || null) : null;
  const el = $('cond-result');
  el.classList.remove('warn', 'err');
  if (tone === 'warn' || tone === 'err') el.classList.add(tone);
  el.innerHTML = `<span class="cond-result-text">${esc(text)}</span>`
    + (condResultTrigger
      ? '<button type="button" class="cond-result-act" id="cond-result-test-btn">注入テストで確かめる</button>'
      : '');
  el.hidden = false;
  $('save-result').hidden = true; // きっかけを触ったら本文保存の結果は畳む (同居させない)
}

/** 変更の「向き」— 決して一致しない書き方に変えたのを ok 緑で祝わない。
    行のバッジ (warn) と結果行の色が割れないよう、判定は同じ出どころで揃える。 */
function triggerTone(t) { return (t && isDeadMatch(t.match)) ? 'warn' : 'ok'; }

function hideCondResult() {
  const el = $('cond-result');
  el.hidden = true;
  el.classList.remove('warn', 'err');
  condResultTrigger = null;
}

/** 再読込後の state から、同じ id のきっかけを引き直す (mode などサーバ確定値で言うため)。 */
function findTrigger(id) {
  const d = selectedDoc();
  return d ? (d.triggers.find((t) => t.id === id) || null) : null;
}

/** 正規表現から「必ず一致する入力例」を安全に取れるときだけ取る。
    量化子・グループ・選択などが残る式は諦める — 一致しない例を出す方が嘘になる。 */
function literalSample(match) {
  if (!match) return ''; // match 無し = この tool のすべての操作 — 入力は何でもよい
  const s = String(match).replace(/\\b/g, '').replace(/^\^/, '').replace(/\$$/, '');
  return /^[A-Za-z0-9 _./:=-]+$/.test(s) ? s : null;
}

/** 結果行 → 注入テスト。きっかけの kind でドックの試し方 (発言で / 操作で) を強制的に
    合わせ、導ける入力例があればそのまま実行して発火まで見せる。 */
function runTestForTrigger(t) {
  if (!t) return;
  setDockTab('try');
  if (triggerKind(t) === 'kw') {
    setTestMode('prompt');
    // 正規表現からは入力例を導かない (作り話の例を入れない — literalSample と同じ決まり)
    if (viewTrigger(t).find === 'regex') {
      $('test-input').focus({ preventScroll: true });
      return;
    }
    const first = splitKeywords(t.keywords)[0];
    if (first) {
      $('test-input').value = first;
      runInjectTest();
    } else {
      $('test-input').focus({ preventScroll: true });
    }
    return;
  }
  setTestMode('tool');
  const toolOk = /^[A-Za-z0-9_]+$/.test(String(t.tool || ''));
  const sample = literalSample(t.match);
  if (toolOk) $('test-tool').value = t.tool;
  if (toolOk && sample !== null) {
    $('test-input').value = sample;
    runInjectTest();
  } else {
    // 入力例を機械的に導けない正規表現 — 人が書く場所へ送るだけ (作り話の例は入れない)
    $('test-input').focus({ preventScroll: true });
  }
}

$('cond-result').addEventListener('click', (ev) => {
  if (!ev.target.closest('#cond-result-test-btn')) return;
  runTestForTrigger(condResultTrigger);
});

$('cond-list').addEventListener('click', async (ev) => {
  const b = ev.target.closest('button[data-act]');
  if (!b) return;
  const act = b.dataset.act;
  if (act === 'edit-cancel') {
    state.editingRuleId = null;
    renderDetail(false);
    return;
  }
  const id = b.dataset.id;
  const layer = b.dataset.layer;
  // 共有 (追加層) のきっかけは読み取り専用 — ボタン自体を出していないが、
  // 万一到達しても書きに行かない (server も global | project 以外を 400 で弾く)
  if (isSharedLayer(layer)) return;
  if (act === 'edit') {
    state.editingRuleId = id;
    // 同じ inject キーの編集面を 2 つ同時に開かない (帯の中の文面編集は畳む)
    foldDeliveryEdit();
    $('save-result').hidden = true; // きっかけを触り始めた — 本文保存の結果は畳む
    renderDetail(false);
    // op は match 欄・kw は keywords 欄 — 開いた瞬間に主戦場へ
    const inp = document.querySelector('.rule-edit-form [name=match], .rule-edit-form [name=keywords]');
    if (inp) inp.focus();
    return;
  }
  if (act === 'toggle') {
    const enabled = b.dataset.next === 'true';
    b.disabled = true;
    try {
      await postJson('/api/rule/toggle', { cwd: state.cwd, id, layer, enabled });
      state.flashRuleId = id;
      state.flashTone = enabled ? 'ok' : 'warn';
      await loadAll(state.cwd);
      markTestStale('きっかけを変えた');
      const t = findTrigger(id);
      if (enabled) {
        showCondResult(t ? `有効にした — ${triggerSentence(viewTrigger(t))}`
          : `有効にした — きっかけ「${id}」`, t, triggerTone(t));
      } else {
        showCondResult(`無効にした — きっかけ「${id}」からは届かなくなった (設定は残る)`, null, 'warn');
      }
    } catch (e) {
      // 失敗も操作した場所へ返す (画面最上部のエラーバーへ飛ばさない)
      showCondResult(`${enabled ? '有効化' : '無効化'}に失敗: ${e.message}`, null, 'err');
    } finally {
      b.disabled = false;
    }
    return;
  }
  if (act === 'del') {
    // 確認は 1 段 — doc 本文は残る (孤児 doc は doctor が報告する) ことも伝える。
    // doc を持たないルールでは残るものが無い — ルールごと消えると言う
    const selected = selectedDoc();
    const injectOnly = !!(selected && selected.inject_only);
    const confirmText = injectOnly
      ? `きっかけ "${id}" を削除する?\nこのルールは doc を持たない — ルールごと消える (届いていた文面も届かなくなる)。`
      : `きっかけ "${id}" を削除する?\nこのきっかけからの注入だけが止まる — doc 本文は残る。`;
    if (!window.confirm(confirmText)) return;
    b.disabled = true;
    try {
      await postJson('/api/rule/delete', { cwd: state.cwd, id, layer });
      await loadAll(state.cwd);
      markTestStale('きっかけを変えた');
      showCondResult(injectOnly
        ? `ルール「${id}」を削除した — この文面はもう届かない`
        : `きっかけ「${id}」を削除した — このきっかけからは届かなくなった (doc 本文は残る)`, null, 'warn');
    } catch (e) {
      showCondResult(`きっかけの削除に失敗: ${e.message}`, null, 'err');
    } finally {
      b.disabled = false;
    }
  }
});

$('cond-list').addEventListener('submit', async (ev) => {
  const form = ev.target.closest('form.rule-edit-form');
  if (!form) return;
  ev.preventDefault();
  const note = form.querySelector('.rule-edit-note');
  const every = form.querySelector('[name=every]').value;
  // 届く文面は空 = 標準文面 — null で inject キーごと削除する (既定へ戻す)
  const inject = form.querySelector('[name=inject]').value.trim() || null;
  // doc を持たないルールの文面は空にできない (doc も文面も無いルールは何も注入しない) —
  // core も拒むが、送る前にその場で言う
  const editing = findTrigger(form.dataset.id);
  if (!inject && editing && viewTrigger(editing).hasDoc === false) {
    note.textContent = '届く文面は空にできない — doc が無いルールは、この文面だけを届ける';
    note.classList.add('err');
    return;
  }
  let patch;
  if (form.dataset.kind === 'kw') {
    const keywords = form.querySelector('[name=keywords]').value.trim();
    if (!keywords) { note.textContent = 'ことば (キーワード) は必須'; return; }
    const find = form.querySelector('[name=find]').value;
    // 既定 (含む / 大小無視 / セッション初回) は null でキーごと削除 (core の正準形)
    patch = {
      keywords,
      find: (find === 'word' || find === 'regex') ? find : null,
      case: form.querySelector('[name=case]').checked ? 'sensitive' : null,
      every: every === 'always' ? 'always' : null,
      inject,
    };
  } else {
    const tool = form.querySelector('[name=tool]').value.trim();
    const match = form.querySelector('[name=match]').value.trim();
    if (!tool) { note.textContent = 'tool は必須'; return; }
    // 空 match / 既定頻度は null でキーごと削除 (core の正準形 — add-rule の省略と同じ)
    patch = {
      tool,
      match: match || null,
      every: every === 'always' ? 'always' : null,
      inject,
    };
  }
  note.textContent = '保存中…';
  note.classList.remove('err');
  const btn = form.querySelector('button[type=submit]');
  btn.disabled = true;
  try {
    const editedId = form.dataset.id;
    await postJson('/api/rule/update',
      { cwd: state.cwd, id: editedId, layer: form.dataset.layer, patch });
    state.editingRuleId = null;
    state.flashRuleId = editedId;
    // 光る色は再描画 (loadAll の中) で使われる — 送った式で先に決める。
    // 決して一致しない式に変えたのを ok 緑で祝わない
    state.flashTone = triggerTone(patch);
    await loadAll(state.cwd);
    markTestStale('きっかけを変えた');
    const t = findTrigger(editedId);
    showCondResult(t ? `きっかけを更新した — ${triggerSentence(viewTrigger(t))}`
      : `きっかけ「${editedId}」を更新した`, t, triggerTone(t));
  } catch (e) {
    // 失敗はフォームの中 (= 操作した場所) に残す。エラーバーへは飛ばさない
    note.textContent = `失敗: ${e.message}`;
    note.classList.add('err');
  } finally {
    btn.disabled = false;
  }
});

// きっかけ追加 (既存 doc へ add-rule、doc-content 省略)
/** 追加導線の出し分け — きっかけがあるときはカード見出し右肩の小型ボタン (+ 操作 /
    + ことば)、0 件のときだけ説明付きの行 (発見可能性はこちらが持つ)。
    フォームを開いている間はどちらも畳む (ボタンとフォームを同時に見せない)。 */
function syncCondAddUi() {
  const formOpen = !$('cond-form').hidden;
  const d = selectedDoc();
  const hasTriggers = !!(d && d.triggers.length);
  // doc を持たないルールのエントリはルール 1 件そのもの — 「この doc へきっかけを足す」
  // 導線は無い (足すなら別のルールを + 新規で作る)
  const injectOnly = !!(d && d.inject_only);
  $('cond-add-row').hidden = formOpen || hasTriggers || injectOnly;
  $('cond-add-mini').hidden = formOpen || !hasTriggers || injectOnly;
}

/** 追加フォームは追加導線 (小型ボタン / 説明付きの行) の代わりに開く —
    ボタンとフォームを同時に見せない。kind で見せる欄を切り替える (op = tool/match、
    kw = keywords/一致のしかた/大小区別)。 */
function setCondFormOpen(open, kind) {
  const form = $('cond-form');
  if (open && kind) form.dataset.kind = kind === 'kw' ? 'kw' : 'op';
  const k = form.dataset.kind === 'kw' ? 'kw' : 'op';
  for (const el of form.querySelectorAll('.cond-op-field')) el.hidden = k !== 'op';
  for (const el of form.querySelectorAll('.cond-kw-field')) el.hidden = k !== 'kw';
  // 届く文面は両種別で出す — 空のときに何が届くか (標準文面) だけが種別で違う
  $('cond-inject').placeholder = injectPlaceholder(k);
  form.hidden = !open;
  syncCondAddUi();
  // 死判定のライブ検証は op の match 欄専用 — kw の keywords には掛けない
  if (open && k === 'op') updateMatchHelp($('cond-match'));
  updateAccentFocus(); // 開いている間は accent をフォームの主ボタンへ譲る
}

function openCondForm(kind) {
  $('cond-form-note').textContent = '';
  $('cond-form-note').classList.remove('err');
  $('save-result').hidden = true; // きっかけを触り始めた — 本文保存の結果は畳む
  setCondFormOpen(true, kind);
  (kind === 'kw' ? $('cond-keywords') : $('cond-match')).focus();
}
$('cond-add-btn').addEventListener('click', () => openCondForm('op'));
$('cond-add-kw-btn').addEventListener('click', () => openCondForm('kw'));
$('cond-add-btn-empty').addEventListener('click', () => openCondForm('op'));
$('cond-add-kw-btn-empty').addEventListener('click', () => openCondForm('kw'));
$('cond-cancel-btn').addEventListener('click', () => setCondFormOpen(false));

function genRuleId(doc) {
  const base = doc.name.replace(/\.md$/, '').toLowerCase()
    .replace(/[^a-z0-9-]+/g, '-').replace(/^-+|-+$/g, '') || 'doc';
  // id は全層で見て衝突を避ける — engine は同 id を project→global の override として
  // 扱うため、層違いの同 id は global 側のルールを黙って無効化してしまう
  // 畳んだ一覧ではなく全件で見る — 画面に出していない層の同 id とも衝突させない
  const used = new Set(state.allDocs.flatMap((x) => x.triggers.map((t) => t.id)));
  if (!used.has(base)) return base;
  for (let i = 2; ; i++) {
    if (!used.has(`${base}-${i}`)) return `${base}-${i}`;
  }
}

$('cond-form').addEventListener('submit', async (ev) => {
  ev.preventDefault();
  const d = selectedDoc();
  if (!d || d.inject_only) return; // doc を持たないルールに「この doc へ追加」は無い (導線も出していない)
  const kind = $('cond-form').dataset.kind === 'kw' ? 'kw' : 'op';
  const every = $('cond-every').value;
  const note = $('cond-form-note');
  const inject = $('cond-inject').value.trim(); // 空 = 標準文面 (キーごと省く)
  let rule;
  if (kind === 'kw') {
    const keywords = $('cond-keywords').value.trim();
    if (!keywords) { note.textContent = 'ことば (キーワード) は必須'; return; }
    const find = $('cond-find').value;
    rule = {
      id: genRuleId(d), event: 'prompt', keywords,
      ...(find === 'word' || find === 'regex' ? { find } : {}),
      ...($('cond-case').checked ? { case: 'sensitive' } : {}),
      doc: `docs/${d.name}`,
      ...(inject ? { inject } : {}),
      ...(every === 'always' ? { every: 'always' } : {}),
    };
  } else {
    const tool = $('cond-tool').value.trim();
    const match = $('cond-match').value.trim();
    if (!tool) { note.textContent = 'tool は必須'; return; }
    rule = {
      id: genRuleId(d), tool,
      ...(match ? { match } : {}),
      doc: `docs/${d.name}`,
      ...(inject ? { inject } : {}),
      ...(every === 'always' ? { every: 'always' } : {}),
    };
  }
  note.textContent = '追加中…';
  note.classList.remove('err');
  $('cond-submit-btn').disabled = true; // 多重送信ガード (rules.yaml の追記競合を防ぐ)
  try {
    await postJson('/api/apply', { cwd: state.cwd, layer: d.layer, rule });
    setCondFormOpen(false);
    $('cond-match').value = '';
    $('cond-keywords').value = '';
    $('cond-inject').value = '';
    state.flashRuleId = rule.id;
    state.flashTone = triggerTone(rule); // 一致しない式で追加したのを ok 緑で祝わない
    await loadAll(state.cwd);
    markTestStale('きっかけを変えた');
    // サーバ確定値を引けなくても、追加した事実は必ず 1 行返す (無言の成功を作らない)
    const t = findTrigger(rule.id);
    showCondResult(t ? `きっかけを追加した — ${triggerSentence(viewTrigger(t))}`
      : `きっかけ「${rule.id}」を追加した`, t, triggerTone(t));
  } catch (e) {
    note.textContent = `失敗: ${e.message}`;
    note.classList.add('err');
  } finally {
    $('cond-submit-btn').disabled = false;
  }
});

// ---------------------------------------------------------------------------
// ステータスバー
// ---------------------------------------------------------------------------

/** accent (青い塗り) は画面につねに 1 つだけ。どれに付くかは
    「いまこの画面で何に詰まっているか」で決まる:

      未保存            → 保存 (書いた内容が消えうる状態 — 配線より手前の詰まり)
      未配線            → 配線コマンドのコピー (この製品が何もしていない状態)
      それ以外          → + 新規 (次の入口)
      モーダル/インラインフォームが開いている間 → その中の主ボタンへ譲って全部降ろす

    accent を譲ったボタンは .btn-strong のまま残る — 消したり押せなく見せたりしない。 */
function updateAccentFocus() {
  const modalOpen = !$('modal').hidden;
  const formOpen = !$('cond-form').hidden
    || !!document.querySelector('#cond-list form.rule-edit-form')
    || !$('delivery-edit').hidden; // 帯の中の文面編集 — 主ボタンへ accent を譲る
  let target = 'new';
  if (modalOpen || formOpen) target = 'none';
  else if (state.dirty) target = 'save';
  // 配線を語らないモードでは配線の行そのものを出さない — 見えない行へ accent を渡さない
  else if (tellUnwired()) target = 'wire';
  $('wire-copy-btn').classList.toggle('btn-primary', target === 'wire');
  $('save-btn').classList.toggle('btn-primary', target === 'save');
  $('new-doc-btn').classList.toggle('btn-primary', target === 'new');
}

$('wire-copy-btn').addEventListener('click', async () => {
  const b = $('wire-copy-btn');
  try {
    await copyText(b.dataset.cmd);
    b.textContent = 'コピーした';
  } catch {
    b.textContent = 'コピー不可 — 手で選択';
  }
  setTimeout(() => { b.textContent = 'コピー'; }, 1800);
});

function renderStatusbar(coreKind) {
  const eng = state.info && state.info.engine;
  const dot = $('engine-dot');
  const item = $('engine-status');
  const stateText = $('engine-state-text');
  if (globalOnly()) {
    // 検知はこのサーバが動く 1 台ぶんの事実 — 共有層の編集面としては誤読を招くので
    // 表示そのものを持たない (.off も付けない = 直し方の行も開かない)
    dot.classList.remove('off');
    stateText.classList.remove('off');
    stateText.textContent = '';
  } else if (eng && eng.connected) {
    dot.classList.remove('off');
    stateText.classList.remove('off');
    stateText.textContent = '注入 稼働中';
    // 可視は dot + 一語 — 説明の全文は hover の title へ (#engine-text は畳んだまま)
    $('engine-text').textContent = '操作の直前に docs が届く';
    item.title = `操作の直前に docs が届く — 配線済み: ${abbrHome(eng.source || '')} に PreToolUse hook が登録されている`;
  } else {
    dot.classList.add('off');
    stateText.classList.add('off');
    stateText.textContent = '注入 停止中';
    $('engine-text').textContent =
      '配線されていません — 配線すると操作の直前に docs が届く';
    item.title = 'このパソコンには配線されていません。配線するには (2 段): claude plugin marketplace add AI-Driven-R-D-Dept/toolhint (手元の clone なら <repo のパス 例 ./toolhint>) → claude plugin install toolhint@toolhint (詳細は README のインストール手順)';
  }
  // 「注入のきっかけ」の説明は見出しの hover (title) が持つ — 常時表示のテキストは
  // 置かない。未配線なら、この 1 文が下のきっかけ一覧ぜんぶの時制を引き受ける
  // (停止中そのものの警告は上部バナーが持つ)
  const condTitle = tellUnwired()
    ? 'いまは停止中 — 配線すると、一致した操作の直前に注入する'
    : '一致した操作の直前に注入する — 実行は止めない';
  $('cond-title').title = condTitle;
  const condHint = $('cond-hint');
  condHint.textContent = ''; // 可視の再掲はしない (要素は互換のため残す)
  condHint.title = condTitle;
  // 内訳もルール (きっかけ) の数 — 左上の「ルール N」と同じ単位で、きっかけが
  // どの層に置かれているかで数える (doc 1 枚に 2 層のきっかけが付いていれば 1 ずつ。
  // どのルールからも参照されない doc は 0 — 一覧には出るがルールではない)
  const counts = { global: 0, project: 0, shared: 0 };
  for (const d of state.docs) {
    for (const t of d.triggers) {
      const l = isSharedLayer(t.layer) ? 'shared' : (t.layer === 'global' ? 'global' : 'project');
      counts[l] += 1;
    }
  }
  const total = ruleCount(state.docs);
  const layersEl = $('layers-text');
  if (globalOnly()) {
    // 扱う層が 1 つだけのモード — 内訳ではなく、その層の件数を 1 つだけ言う。
    // 数えるのは一覧に並んでいるルールそのもの (実体が別の層にある doc を
    // 手元のきっかけで使っている行も、この画面が扱うルールなので数に入る)
    const label = globalOnlyLabel();
    layersEl.innerHTML =
      `<span class="nowrap"><span class="layer-key layer-global">${esc(label)} ${total}</span></span>`;
    layersEl.title = `${label} = どのプロジェクトの操作でも注入されるルール`
      + ' (~/.claude/toolhint/) — この画面はこの層だけを扱う';
  } else {
    // 折り返しは節の切れ目でだけ起こす — 「このプロジェクト 3 / docs」と割れて読めなくなるのを防ぐ。
    // 区切りの「·」は後続の nowrap 節の中に置く — 行末に「·」だけがぶら下がるのを防ぐ。
    // .layer-key の色ドット (CSS ::before) が棚カードの層ドットと対応する
    // project 層 0 件 (一覧は全体層だけ) の案内は、この「このプロジェクト 0」の
    // hover に吸収する — 棚に常時のピル行を足さない
    const projTitle = (!counts.project && total)
      ? `このプロジェクトのルールはまだ無い — 一覧のルール ${total} 件は全体層${counts.shared ? 'か共有' : ''}。「+ 新規」の保存先で「このプロジェクト」を選ぶと作れる`
      : '';
    // 共有 (追加層 = layers.d/*) は、その層のきっかけがあるときだけ内訳に足す
    const sharedCount = counts.shared;
    const sharedTitle = '共有 = 外から配られた読み取り専用のルール'
      + ' (~/.claude/toolhint/layers.d/<名前>/) — この画面からは変更できない';
    layersEl.innerHTML =
      `<span class="nowrap"><span class="layer-key layer-global">全体 ${counts.global}</span></span>`
      + ' '
      + `<span class="nowrap">· <span class="layer-key layer-project"${projTitle ? ` title="${esc(projTitle)}"` : ''}>このプロジェクト ${counts.project}</span></span>`
      + (sharedCount
        ? ` <span class="nowrap">· <span class="layer-key layer-shared" title="${esc(sharedTitle)}">共有 ${sharedCount}</span></span>`
        : '');
    layersEl.title =
      '全体 = どのプロジェクトでも注入されるルール (~/.claude/toolhint/) / このプロジェクト = 対象プロジェクトだけのルール (.claude/toolhint/)'
      + (sharedCount ? ` / ${sharedTitle}` : '');
  }
  // core 種別は開発者情報 — 可視の再掲 (#core-text は hidden) はやめ、hover をヘッダの
  // brand-name へ移す (id と要素は残す)
  const coreTitle = `core: ${coreKind || (state.info && state.info.core) || '?'} (開発者情報)`;
  const core = $('core-text');
  core.textContent = 'toolhint';
  core.title = coreTitle;
  const brandName = document.querySelector('.brand-name');
  if (brandName) brandName.title = coreTitle;
  updateAccentFocus(); // 配線状態が変わると accent の行き先も変わる
}

// ---------------------------------------------------------------------------
// ヘッダ: cwd 切替 / 検索
// ---------------------------------------------------------------------------

// 非フォーカス時はパス末尾 (project 名) を可視に保つ。編集中はスクロールを動かさない
function scrollCwdToEnd() {
  const el = $('cwd-input');
  if (document.activeElement === el) return;
  el.scrollLeft = el.scrollWidth;
}

/** 対象プロジェクト box をパスの実必要幅に合わせる — 「余白があるのにパスが
    切れている」を避ける。min/max は style.css の .target-box が持ち、ここは
    flex-basis (必要幅) だけを動かす。幅が足りない時は flex-shrink で縮み、
    その場合の末尾可視は scrollCwdToEnd が保つ。 */
function fitCwdBox() {
  const el = $('cwd-input');
  const box = el.closest('.target-box');
  if (box) {
    // box の飾り幅 (padding + アイコン + gap + border) を測って値の幅に足す
    const extra = box.getBoundingClientRect().width - el.getBoundingClientRect().width;
    box.style.flexBasis = `${Math.ceil(el.scrollWidth + Math.max(0, extra))}px`;
  }
  scrollCwdToEnd();
}

// フォント読み込みで文字幅が変わる / リサイズで clientWidth が変わる — どちらも
// 末尾アンカーが古くなるので取り直す (フォント後は必要幅も変わるため fit ごと)
window.addEventListener('resize', scrollCwdToEnd);
if (document.fonts && document.fonts.ready) {
  document.fonts.ready.then(() => fitCwdBox());
}

$('cwd-input').addEventListener('keydown', (e) => {
  if (e.isComposing || e.keyCode === 229) return; // IME 変換確定の Enter は無視
  if (e.key !== 'Enter') return;
  if (!confirmDiscardDirty()) return;
  loadAll($('cwd-input').value.trim());
  $('cwd-input').blur(); // 応答が来たら解決済み cwd へ同期される
});
$('cwd-input').addEventListener('blur', () => {
  // Chrome は blur で input のスクロールを先頭へ戻す — 次フレームで末尾可視を回復
  requestAnimationFrame(scrollCwdToEnd);
  const v = $('cwd-input').value.trim();
  if (!v || v === state.cwd || v === lastRequestedCwd) return; // Enter 直後の二重発火を抑止
  if (!confirmDiscardDirty()) { $('cwd-input').value = state.cwd; return; }
  loadAll(v);
});

// 未保存の本文をリロード・タブ閉じで黙って失わない
window.addEventListener('beforeunload', (e) => {
  if (!state.dirty) return;
  e.preventDefault();
  e.returnValue = '';
});

$('search-input').addEventListener('input', () => {
  state.search = $('search-input').value.trim();
  renderShelf();
});

// ---------------------------------------------------------------------------
// + 新しい doc (モーダル: ことばで頼む / 手動で作る)
// ---------------------------------------------------------------------------

let proposal = null;     // /api/propose の結果 (閉じても保持し、再オープンで復元)
let askInFlight = false; // 起案リクエストが飛んでいる間 true

/** 起案の確認の出し入れはここだけを通す — 表示中は「起案してもらう」の accent を
    降ろし、青塗りを「この内容で保存」1 つに絞る (accent は 1 つ、の原則をモーダル内でも守る)。
    discard / apply / 非表示で「起案してもらう」へ復帰する。 */
function setProposalVisible(show) {
  $('proposal').hidden = !show;
  $('ask-btn').classList.toggle('btn-primary', !show);
}

function openModal() {
  $('modal').hidden = false;
  switchTab(true);
  $('ask-error').hidden = true;
  $('manual-error').hidden = true;
  setProposalVisible(!!proposal); // 未処理の起案結果があれば復元 (数十秒の起案を捨てない)
  updateMatchHelp($('manual-match'));
  updateAccentFocus(); // モーダル内の主ボタンへ譲る — 背面の accent は降ろす
  $('ask-input').focus();
}
function closeModal() {
  if (askInFlight && !window.confirm(
    '起案の途中 — 閉じても起案は続き、結果は次にこの画面を開いた時に表示される。閉じる?')) return;
  $('modal').hidden = true;
  updateAccentFocus();
}

$('new-doc-btn').addEventListener('click', openModal);
$('modal-close-btn').addEventListener('click', closeModal);
$('modal').addEventListener('click', (e) => { if (e.target === $('modal')) closeModal(); });
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && !$('modal').hidden) closeModal();
});

function switchTab(ask) {
  $('tab-ask').classList.toggle('active', ask);
  $('tab-manual').classList.toggle('active', !ask);
  $('pane-ask').hidden = !ask;
  $('pane-manual').hidden = ask;
}
$('tab-ask').addEventListener('click', () => switchTab(true));
$('tab-manual').addEventListener('click', () => switchTab(false));

// -- ことばで頼む (propose → apply)

// 起案を書いたもの (server の engine 値) の表示名 — 未知の値は生のまま出す
const ENGINE_LABEL = { sdk: 'Agent SDK', 'claude-p': 'claude -p' };

// 起案するきっかけの種別 — 手動タブと同じセグメント (既定 = 操作)。
// 何を書けばいいかは種別で違うので、依頼文の例 (placeholder) も一緒に差し替える
let askKind = 'op';
const ASK_PLACEHOLDER = {
  op: '例:「grep を打とうとしたら rg を勧めて」',
  kw: '例:「デプロイという言葉が出たらデプロイ前チェックリストを渡して」',
};
function setAskKind(kind) {
  askKind = kind === 'kw' ? 'kw' : 'op';
  $('ask-kind-op').setAttribute('aria-pressed', String(askKind === 'op'));
  $('ask-kind-kw').setAttribute('aria-pressed', String(askKind === 'kw'));
  $('ask-input').placeholder = ASK_PLACEHOLDER[askKind];
}
$('ask-kind-op').addEventListener('click', () => setAskKind('op'));
$('ask-kind-kw').addEventListener('click', () => setAskKind('kw'));
setAskKind(askKind);

/** 起案の doc がこのまま保存されたときの絶対パス (層 dir + rule.doc) —
    「実際に届く文面」の {doc} 展開に使う。層 dir を引けなければ null。 */
function proposalDocAbs(p) {
  const layers = (state.info && state.info.layers) || [];
  const dir = (layers.find((l) => l.name === p.layer) || {}).dir;
  const rel = (p.rule && p.rule.doc) || (p.doc_name ? `docs/${p.doc_name}` : '');
  return dir && rel ? `${dir}/${rel}` : null;
}

/** 起案が保存されたとき agent に届く文面 — 本体の帯とまったく同じ deliveryText を通す。
    doc 名は保存前に変えられるので、入力欄の現在値でパスを組み直す (古いパスを見せない)。
    既存 doc へのきっかけ追加 (attach_to) は起案に本文が無い — inline で本文を
    空のまま描くと「何も届かない」と嘘になるので、その場所を注記で埋める。 */
function renderProposalDelivery() {
  const box = $('proposal-delivery');
  if (!proposal) { box.hidden = true; return; }
  const name = $('proposal-name').value.trim() || proposal.doc_name;
  const rule = { ...proposal.rule, doc: `docs/${name}` };
  const v = viewTrigger(rule, {
    rule, docExists: true,
    docAbs: proposalDocAbs({ ...proposal, rule, doc_name: name }),
  });
  const body = (proposal.attach_to && v.mode === 'inline')
    ? '(既存 doc の本文がここに入る)'
    : proposal.doc_content;
  const text = deliveryText(v, body);
  box.hidden = !text;
  $('proposal-delivery-text').textContent = text || '';
}
// doc 名を変えると届くパスも変わる — 上の文面をその場で追随させる
$('proposal-name').addEventListener('input', renderProposalDelivery);

$('ask-btn').addEventListener('click', async () => {
  const request = $('ask-input').value.trim();
  if (!request) {
    $('ask-error').textContent = `依頼文を書いてください — ${ASK_PLACEHOLDER[askKind]}`;
    $('ask-error').hidden = false;
    return;
  }
  askInFlight = true;
  $('ask-btn').disabled = true;
  $('ask-spinner').hidden = false;
  $('ask-status').hidden = false;
  $('ask-status').textContent = 'agent が起案中… (数十秒かかることがある)';
  $('ask-error').hidden = true;
  setProposalVisible(false);
  try {
    const r = await postJson('/api/propose',
      { cwd: state.cwd, request, layer: pickLayer($('ask-layer')), kind: askKind });
    proposal = r;
    // 起案元は server が返した値をそのまま出す — 既知の 2 つだけ読みやすく言い換え、
    // それ以外 (stub 等) は生の値で見せる (何が書いたのかを隠さない)
    $('proposal-engine').textContent = `起案: ${ENGINE_LABEL[r.engine] || r.engine || '(不明)'}`;
    $('proposal-rationale').textContent = r.rationale || '';
    // 置き場所 (保存先の層) は doc の事実 — 画面の他所と同じく doc 名の隣に置く。
    // きっかけの脇テキストは本体の一覧とまったく同じ語彙・同じ順で出す (承認前に
    // 届き方と頻度が見えないと、inline の起案を見ないまま通してしまう)
    $('proposal-scope').textContent = scopeLabel(r.layer);
    $('proposal-scope').title = scopeTitle(r.layer);
    // 操作きっかけ / ことばきっかけのどちらも、本体の一覧と同じ語彙で描く
    const pv = viewTrigger(r.rule, { rule: r.rule, docExists: true, docAbs: proposalDocAbs(r) });
    $('proposal-cond').innerHTML = proposalCondHtml(pv);
    $('proposal-name').value = r.doc_name;
    // 既存 doc へのきっかけ追加 (attach_to) は本文を持たない — 名前を変えると
    // 「実在しない doc への追加」になり保存できないので、欄ごと固定する
    // (ラベルも差し替える — 「変更できる」のまま固定すると無言の失敗になる)
    $('proposal-name').readOnly = !!r.attach_to;
    $('proposal-name').title = r.attach_to
      ? '既存 doc へのきっかけ追加 — doc 名は変えられない (別の doc にしたいときは起案をやり直す)'
      : '';
    $('proposal-name-label').textContent = r.attach_to
      ? 'doc 名 — 既存 doc へのきっかけ追加 (変更できない)'
      : 'doc 名 (*.md) — agent の提案。保存前に変更できる';
    renderProposalDelivery(); // 起案の inject / 届き方をそのまま映した「実際に届く文面」
    // attach_to の起案は本文が無い — 空箱を無言で見せない
    $('proposal-doc').textContent = r.attach_to
      ? '(既存 doc の本文のまま — この起案は本文を変えない)'
      : r.doc_content;
    setProposalVisible(true);
  } catch (e) {
    // 復旧導線 — 起案は claude CLI に依存するため、失敗しても手動タブで即作れる。
    // ENOENT (claude コマンド不在) は生のエラーだと初見に読めないため言い換える
    const noCli = /ENOENT/.test(e.message);
    const msg = noCli
      ? 'claude コマンドが見つからない (Claude Code が未インストールか、PATH が通っていない)'
      : e.message;
    const hint = noCli
      ? 'Claude Code を入れると使える (README のインストール手順)。今すぐ作るなら手動タブへ'
      : 'claude CLI のログインが必要な場合がある。今すぐ作るなら手動タブへ';
    $('ask-error').innerHTML = `起案に失敗: ${esc(msg)}`
      + `<div class="ask-error-recover">${esc(hint)}`
      + ' <button type="button" id="goto-manual-btn" class="btn">手動で作る</button></div>';
    $('ask-error').hidden = false;
  } finally {
    askInFlight = false;
    $('ask-btn').disabled = false;
    $('ask-spinner').hidden = true;
    $('ask-status').hidden = true;
  }
});

// 動的に描く「手動で作る」ボタン (起案失敗時) は委譲で受ける
$('ask-error').addEventListener('click', (ev) => {
  if (ev.target.closest('#goto-manual-btn')) switchTab(false);
});

$('discard-btn').addEventListener('click', () => { setProposalVisible(false); proposal = null; });

$('apply-btn').addEventListener('click', async () => {
  if (!proposal) return;
  // doc 名は保存前に変更できる — 手動タブと同一の検証をかけ、rule.doc も上書きする
  // (server は rule.doc を優先するため doc_name だけの変更では反映されない)
  const name = $('proposal-name').value.trim();
  if (!/^[A-Za-z0-9._\-]+\.md$/.test(name)) {
    $('ask-error').textContent = 'doc 名は英数字の *.md (例: search-tools.md)';
    $('ask-error').hidden = false;
    return;
  }
  $('ask-error').hidden = true;
  proposal.doc_name = name;
  proposal.rule.doc = 'docs/' + name;
  $('apply-btn').disabled = true;
  try {
    await postJson('/api/apply', {
      cwd: state.cwd, layer: proposal.layer, rule: proposal.rule,
      doc_name: proposal.doc_name, doc_content: proposal.doc_content,
    });
    const key = `${proposal.layer} ${proposal.doc_name}`;
    proposal = null; // 保存済み — 次のオープンで復元しない
    setProposalVisible(false);
    closeModal();
    $('ask-input').value = '';
    await loadAll(state.cwd);
    if (state.docs.some((d) => keyOf(d) === key)) selectDoc(key);
  } catch (e) {
    $('ask-error').textContent = `保存に失敗: ${e.message}`;
    $('ask-error').hidden = false;
  } finally {
    $('apply-btn').disabled = false;
  }
});

// -- 手動で作る (doc 名 + 本文 + きっかけ → add-rule)

// きっかけ種別の切替 (操作に反応 / ことばに反応) — 見せる欄の行ごと切り替える
let manualKind = 'op';
function setManualKind(kind) {
  manualKind = kind === 'kw' ? 'kw' : 'op';
  $('manual-kind-op').setAttribute('aria-pressed', String(manualKind === 'op'));
  $('manual-kind-kw').setAttribute('aria-pressed', String(manualKind === 'kw'));
  $('manual-op-row').hidden = manualKind !== 'op';
  $('manual-kw-row').hidden = manualKind !== 'kw';
  // 届く文面の欄は種別で消さない (両方で有効) — 空のときの標準文面だけ差し替える
  $('manual-inject').placeholder = injectPlaceholder(manualKind);
}
$('manual-kind-op').addEventListener('click', () => setManualKind('op'));
$('manual-kind-kw').addEventListener('click', () => setManualKind('kw'));
setManualKind(manualKind); // placeholder の初期化 (HTML には標準文面を写さない)

$('manual-save-btn').addEventListener('click', async () => {
  const name = $('manual-name').value.trim();
  const layer = pickLayer($('manual-layer'));
  const body = $('manual-body').value;
  const every = $('manual-every').value;
  const inject = $('manual-inject').value.trim(); // 空 = 標準文面 (キーごと省く)
  const errBox = $('manual-error');
  errBox.hidden = true;
  const fail = (msg) => { errBox.textContent = msg; errBox.hidden = false; };
  if (!/^[A-Za-z0-9._\-]+\.md$/.test(name)) return fail('doc 名は英数字の *.md (例: search-tools.md)');
  if (!body.trim()) return fail('本文が空 — 注入する内容を書く');
  let rule;
  if (manualKind === 'kw') {
    const keywords = $('manual-keywords').value.trim();
    if (!keywords) return fail('きっかけのことば (キーワード) は必須');
    const find = $('manual-find').value;
    rule = {
      id: genRuleId({ name, layer }), event: 'prompt', keywords,
      ...(find === 'word' || find === 'regex' ? { find } : {}),
      ...($('manual-case').checked ? { case: 'sensitive' } : {}),
      doc: `docs/${name}`,
      ...(inject ? { inject } : {}),
      ...(every === 'always' ? { every: 'always' } : {}),
    };
  } else {
    const tool = $('manual-tool').value.trim();
    const match = $('manual-match').value.trim();
    if (!tool) return fail('きっかけの tool は必須');
    rule = {
      id: genRuleId({ name, layer }), tool,
      ...(match ? { match } : {}),
      doc: `docs/${name}`,
      ...(inject ? { inject } : {}),
      ...(every === 'always' ? { every: 'always' } : {}),
    };
  }
  $('manual-save-btn').disabled = true;
  try {
    await postJson('/api/apply',
      { cwd: state.cwd, layer, rule, doc_name: name, doc_content: body });
    const key = `${layer} ${name}`;
    closeModal();
    for (const id of ['manual-name', 'manual-body', 'manual-match', 'manual-keywords',
      'manual-inject']) $(id).value = '';
    await loadAll(state.cwd);
    if (state.docs.some((d) => keyOf(d) === key)) selectDoc(key);
  } catch (e) {
    fail(`保存に失敗: ${e.message}`);
  } finally {
    $('manual-save-btn').disabled = false;
  }
});

// ---------------------------------------------------------------------------
// boot
// ---------------------------------------------------------------------------

// URL ?cwd が最優先。無ければ前回使った対象を復元 (localStorage 不可環境は素通し)。
// モードは server が /api/state で返すまで分からないので、全体層モードのときだけ
// loadAll が既定の対象へ読み直す (対象を選ぶ意味が無いモードなので指定を捨てる)
let lastCwd = '';
try { lastCwd = localStorage.getItem('toolhint.last-cwd') || ''; } catch { /* 不可環境 */ }
loadAll(new URLSearchParams(location.search).get('cwd') || lastCwd || '');
