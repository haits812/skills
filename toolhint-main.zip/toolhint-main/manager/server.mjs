#!/usr/bin/env node
// toolhint manager — 操作 docs の管理 GUI サーバ
//
// Node 標準 http のみで動く (express 等なし)。
// core (core/toolhint_core.py) の JSON 契約だけに依存する。core が無い / 必要な
// subcommand を持たない環境では、読み取り系に限り fixtures/toolhint_core_mock.py
// (同一契約) へフォールバックする。
// agent 起案は Agent SDK (@anthropic-ai/claude-agent-sdk) を優先し、
// SDK が無い/失敗した環境では `claude -p` 子プロセスへ自動フォールバック。

import http from 'node:http';
import { execFile, spawn } from 'node:child_process';
import crypto from 'node:crypto';
import { existsSync, readdirSync, statSync } from 'node:fs';
import { readFile, realpath } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const REPO_ROOT = path.resolve(__dirname, '..');
const PUBLIC_DIR = path.join(__dirname, 'public');
const PORT = Number(process.env.PORT || 4517);
const HOST = process.env.HOST || '127.0.0.1';

// ---------------------------------------------------------------------------
// 表示モード (起動オプション)
//
// TOOLHINT_GLOBAL_ONLY=1 — 全体層だけを扱う表示にする。この GUI を「共有ルール層の
//   編集面」として別の管理画面に組み込む / 共有ルール専用のインスタンスを立てる
//   ときのモード: そこでは対象プロジェクト
//   (cwd) の切り替えとプロジェクト層に意味が無く、出しておくと「共有したつもりで
//   プロジェクト層に保存する」誤操作になる。engine の検知表示も、このサーバが動く
//   1 台の事実でしかないため出さない。
// TOOLHINT_GLOBAL_LABEL — そのとき対象欄の代わりに出す固定の表示ラベル。
//
// 効くのは GUI の見せ方だけ — API の挙動 (層の解決・書き込み先) と認可は変えない。
// 未設定なら /api/state に ui フィールドごと出さない (従来どおりの画面)。
// ---------------------------------------------------------------------------

const GLOBAL_ONLY = /^(1|true|yes|on)$/i.test(String(process.env.TOOLHINT_GLOBAL_ONLY || '').trim());
const GLOBAL_LABEL = String(process.env.TOOLHINT_GLOBAL_LABEL || '').trim() || '全体';

/** /api/state に載せる UI モード。既定 (未設定) は null = フィールドを出さない。 */
function uiMode() {
  return GLOBAL_ONLY ? { global_only: true, global_label: GLOBAL_LABEL } : null;
}

// ---------------------------------------------------------------------------
// 認証・CSRF 防御
//
// この GUI は rules/docs の書き換え = Claude セッションへの注入内容の書き換え
// (プロンプトインジェクション面) なので、変更系はブラウザ経路 (CSRF/DNS
// rebinding) と直接 POST (同じネットワーク上のピア等) の両方を塞ぐ:
//  1. Host ヘッダ allowlist — DNS rebinding (攻撃者ドメイン → この IP) を遮断
//  2. POST は同一オリジンのみ — Origin / Sec-Fetch-Site を検査 (CSRF 遮断)
//  3. readBody は Content-Type: application/json 必須 — text/plain の
//     simple request (プリフライト回避) を殺す
//  4. 非 loopback bind (リモート公開等) は /api 全体に token 必須 —
//     TOOLHINT_TOKEN で固定するか、無ければプロセスごとに生成して起動ログに出す。
//     GUI は http://<host>:<port>/?token=<値> で開く (app.js が保持して送る)
// ---------------------------------------------------------------------------

const LOOPBACK_BINDS = new Set(['127.0.0.1', 'localhost', '::1', '[::1]']);
const AUTH_TOKEN = process.env.TOOLHINT_TOKEN
  || (LOOPBACK_BINDS.has(HOST) ? null : crypto.randomBytes(16).toString('hex'));

const EXTRA_HOSTS = (process.env.TOOLHINT_ALLOWED_HOSTS || '')
  .split(',').map((s) => s.trim().toLowerCase()).filter(Boolean);

/** Host ヘッダの hostname 部が許可済みか。攻撃者ドメイン経由 (DNS rebinding) を弾く。 */
function hostAllowed(hostHeader) {
  let name;
  try { name = new URL(`http://${hostHeader}`).hostname.toLowerCase(); }
  catch { return false; }
  if (name === 'localhost' || name === '127.0.0.1' || name === '::1') return true;
  if (name === HOST.toLowerCase()) return true;
  if (EXTRA_HOSTS.includes(name)) return true;
  // これ以外のホスト名 (VPN やプライベート DNS の名前など) は TOOLHINT_ALLOWED_HOSTS で
  // 明示的に許可する (無条件の suffix 許可は持たない — DNS rebinding 対策の穴になる)
  const full = os.hostname().toLowerCase();
  const short = full.split('.')[0];
  // 自ホスト名 (mDNS の <ホスト名>.local など)
  return name === full || name === short || name.startsWith(`${short}.`);
}

/** 変更系 (POST) のブラウザ経路検査 — cross-origin なら 403。 */
function assertSameOrigin(req) {
  const origin = req.headers.origin;
  if (origin) {
    let originHost = null;
    try { originHost = new URL(origin).host.toLowerCase(); } catch { /* 不正 Origin */ }
    if (!originHost || originHost !== String(req.headers.host || '').toLowerCase()) {
      throw httpError(403, 'cross-origin の変更リクエストは受け付けない');
    }
    return;
  }
  const site = req.headers['sec-fetch-site'];
  if (site && site !== 'same-origin' && site !== 'none') {
    throw httpError(403, 'cross-site の変更リクエストは受け付けない');
  }
  // Origin も Sec-Fetch-Site も無い = 非ブラウザ (curl 等) — token 検査に委ねる
}

function tokenMatches(given) {
  if (typeof given !== 'string' || !given) return false;
  const a = Buffer.from(given);
  const b = Buffer.from(AUTH_TOKEN);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

/** token 必須時 (非 loopback bind / TOOLHINT_TOKEN 指定時) の認証。/api 全体に掛ける。 */
function assertAuth(req) {
  if (!AUTH_TOKEN) return; // loopback bind — 同一マシンのみ (token 不要)
  const bearer = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  const given = req.headers['x-toolhint-token'] || bearer;
  if (!tokenMatches(given)) {
    throw httpError(401,
      '認証 token が必要 — 起動ログの ?token= 付き URL で GUI を開くか、'
      + 'X-Toolhint-Token ヘッダを付ける');
  }
}

const REAL_CORE = path.join(REPO_ROOT, 'core', 'toolhint_core.py');
const MOCK_CORE = path.join(__dirname, 'fixtures', 'toolhint_core_mock.py');

// ---------------------------------------------------------------------------
// core 呼び出し (契約: list / dry-run / add-rule / docs / log / save-doc → JSON on stdout)
//
// core が対応する subcommand を --help から検知し、未対応のコマンドだけ fixtures
// モックへフォールバックする。検知結果は 15 秒ごとに更新するので、core を
// 差し替えても manager の再起動は要らない。
// ---------------------------------------------------------------------------

const NEW_CMDS = ['docs', 'log', 'save-doc'];

let capCache = { path: null, cmds: null, ts: 0, full: false };

function probeCoreCommands(cp) {
  const now = Date.now();
  if (capCache.path === cp && capCache.cmds
      && (capCache.full || now - capCache.ts < 15_000)) {
    return Promise.resolve(capCache.cmds);
  }
  return new Promise((resolve) => {
    execFile('python3', [cp, '--help'], { timeout: 10_000 }, (err, stdout, stderr) => {
      const out = String(stdout) + String(stderr);
      const m = out.match(/\{([a-z0-9,\- ]+)\}/i);
      if (err && !m) {
        // probe 一時失敗 (timeout / fork 失敗等): 空集合をキャッシュせず
        // 前回の成功値を保つ (ts も更新しない → 次リクエストで再 probe)。
        console.error(`[manager] core probe 失敗 (${path.basename(cp)}): `
          + String(err.message).slice(0, 200));
        return resolve(capCache.path === cp && capCache.cmds ? capCache.cmds : new Set());
      }
      const cmds = new Set(m ? m[1].split(',').map((s) => s.trim()) : []);
      capCache = {
        path: cp, cmds, ts: now,
        full: NEW_CMDS.every((c) => cmds.has(c)),
      };
      resolve(cmds);
    });
  });
}

function httpError(status, msg) {
  const e = new Error(msg);
  e.status = status;
  return e;
}

/**
 * コマンドに使う core 実体を選ぶ。
 * needNew: true → 新契約 (add-rule の --doc-content 省略など) が必要 —
 *          real core が新契約 (NEW_CMDS) を持たなければ mock へ。
 * write:  true → 書き込み系 (add-rule / save-doc)。mock は real core の安全機構
 *          (.bak 退避・read-back 検証・ロールバック) を欠くため実データを書かせない —
 *          real core が使えない状態は 503 で はっきり失敗する (読み取り系のみ mock 許容)。
 */
async function corePathFor(cmd, needNew = false, write = false) {
  if (process.env.TOOLHINT_CORE) return process.env.TOOLHINT_CORE;
  if (!existsSync(REAL_CORE)) {
    if (write) throw httpError(503, 'real core (core/toolhint_core.py) が無いため書き込みを中止 (mock では書かない)');
    return MOCK_CORE;
  }
  const cmds = await probeCoreCommands(REAL_CORE);
  if (!cmds.has(cmd) || (needNew && !capCache.full)) {
    if (write) throw httpError(503, `core probe 失敗中か ${cmd} 未対応のため書き込みを中止 (mock では書かない)`);
    return MOCK_CORE;
  }
  return REAL_CORE;
}

function coreKindOf(p) {
  if (p === MOCK_CORE) return 'mock';
  if (p === REAL_CORE) return 'real';
  return 'custom';
}

/** core 実行。args[0] が subcommand。戻り値: { out, kind } */
function runCoreAt(cp, args) {
  if (coreKindOf(cp) === 'mock') {
    // mock 実行は無告知にしない (実行時の real→mock 切り替わりを可視化)
    console.error(`[manager] mock core で実行: ${args[0]}`);
  }
  return new Promise((resolve, reject) => {
    execFile('python3', [cp, ...args],
      { maxBuffer: 16 * 1024 * 1024, timeout: 30_000 },
      (err, stdout, stderr) => {
        // 契約: エラーも {"ok":false,"error"} を stdout に出す (exit code は非 0 のことがある)
        try {
          return resolve({ out: JSON.parse(stdout), kind: coreKindOf(cp) });
        } catch { /* stdout が JSON でない場合のみ実行エラー扱い */ }
        if (err) {
          return reject(new Error(
            `core 実行失敗 (${path.basename(cp)}): ${String(stderr || err.message).slice(0, 500)}`));
        }
        reject(new Error(`core の出力が JSON でない: ${String(stdout).slice(0, 400)}`));
      });
  });
}

async function runCore(args, { needNew = false, write = false } = {}) {
  const cp = await corePathFor(args[0], needNew, write);
  const r = await runCoreAt(cp, args);
  return r.out;
}

async function runCoreWithKind(args, { needNew = false, write = false } = {}) {
  const cp = await corePathFor(args[0], needNew, write);
  return runCoreAt(cp, args);
}

// ---------------------------------------------------------------------------
// engine 接続検知 (PreToolUse hook が登録されているか)
// ---------------------------------------------------------------------------

/** hooks.PreToolUse[].hooks[].command に toolhint を含むエントリが実在するか (構造検査)。 */
function hasToolhintHook(obj) {
  const groups = obj && obj.hooks && obj.hooks.PreToolUse;
  if (!Array.isArray(groups)) return false;
  return groups.some((g) => Array.isArray(g && g.hooks)
    && g.hooks.some((h) => typeof (h && h.command) === 'string'
      && h.command.includes('toolhint')));
}

async function detectEngine(cwd) {
  const files = [
    path.join(os.homedir(), '.claude', 'settings.json'),
    path.join(os.homedir(), '.claude', 'settings.local.json'),
    path.join(cwd, '.claude', 'settings.json'),
    path.join(cwd, '.claude', 'settings.local.json'),
  ];
  let fallback = null;
  for (const f of files) {
    let text;
    try { text = await readFile(f, 'utf-8'); }
    catch { continue; /* 無いファイルは無視 */ }
    let obj = null;
    try { obj = JSON.parse(text); } catch { /* parse 不能時のみ下の substring fallback */ }
    if (obj && typeof obj === 'object') {
      // 構造検査: 実際に注入が効く配線 (PreToolUse hook / plugin 有効化) だけを稼働中とする。
      // marketplace 登録・allowlist 等の 'toolhint' 言及だけでは稼働中と言わない。
      if (hasToolhintHook(obj)) return { connected: true, source: f, route: 'hook' };
      const plugins = obj.enabledPlugins;
      if (plugins && plugins['toolhint@toolhint'] === true) {
        return { connected: true, source: f, route: 'plugin' };
      }
    } else if (!fallback && text.includes('toolhint')) {
      fallback = { connected: true, source: f, route: 'unknown' };
    }
  }
  return fallback || { connected: false, source: null, route: null };
}

// ---------------------------------------------------------------------------
// agent 起案 — Agent SDK 優先、claude -p フォールバック
// ---------------------------------------------------------------------------

let sdkChecked = false;
let sdkQuery = null;

async function loadSdk() {
  if (sdkChecked) return sdkQuery;
  sdkChecked = true;
  if (process.env.TOOLHINT_AGENT === 'claude-p') {
    console.error('[manager] TOOLHINT_AGENT=claude-p → SDK を使わない');
    sdkQuery = null;
    return null;
  }
  try {
    const m = await import('@anthropic-ai/claude-agent-sdk');
    sdkQuery = typeof m.query === 'function' ? m.query : null;
  } catch {
    sdkQuery = null;
  }
  if (!sdkQuery) console.error('[manager] Agent SDK なし → claude -p フォールバックで動作');
  return sdkQuery;
}

function claudeP(prompt) {
  return new Promise((resolve, reject) => {
    const args = ['-p', '--output-format', 'text'];
    if (process.env.TOOLHINT_MODEL) args.push('--model', process.env.TOOLHINT_MODEL);
    const child = spawn('claude', args, { stdio: ['pipe', 'pipe', 'pipe'] });
    let out = '';
    let errBuf = '';
    const timer = setTimeout(() => {
      child.kill('SIGKILL');
      reject(new Error('claude -p timeout (180s)'));
    }, 180_000);
    child.stdout.on('data', (d) => { out += d; });
    child.stderr.on('data', (d) => { errBuf += d; });
    child.on('error', (e) => { clearTimeout(timer); reject(e); });
    child.on('close', (code) => {
      clearTimeout(timer);
      if (code !== 0) return reject(new Error(`claude -p exit ${code}: ${errBuf.slice(0, 400)}`));
      resolve(out);
    });
    child.stdin.write(prompt);
    child.stdin.end();
  });
}

const AGENT_TIMEOUT_MS = 180_000;

let stubCall = 0; // TOOLHINT_AGENT_STUB の何回目の出力を返すか (retry の検証用)

async function runAgent(prompt) {
  // テスト用の差し込み口 — LLM を呼ばずこの文字列を「起案の生出力」として扱う
  // (検証・retry・自己検証の経路は本番と同一のまま自動テストできる)。
  // 2 回目以降の呼び出し (retry) 用に \x1e 区切りで複数出力を並べられる。
  if (process.env.TOOLHINT_AGENT_STUB) {
    const outs = process.env.TOOLHINT_AGENT_STUB.split('\x1e');
    const text = outs[Math.min(stubCall++, outs.length - 1)];
    return { text, engine: 'stub' };
  }
  const q = await loadSdk();
  if (q) {
    // SDK 経路も claude -p と同じ 180s で打ち切る (query が刺さると
    // リクエストが無限滞留するため)。abortController 対応 SDK なら中断も渡す。
    const ac = new AbortController();
    let timer = null;
    try {
      const text = await Promise.race([
        (async () => {
          let result = '';
          for await (const msg of q({
            prompt,
            options: {
              maxTurns: 1, allowedTools: [], permissionMode: 'bypassPermissions',
              abortController: ac,
            },
          })) {
            if (msg.type === 'result') {
              if (msg.subtype === 'success') result = msg.result;
              else throw new Error(`SDK result subtype: ${msg.subtype}`);
            }
          }
          if (!result) throw new Error('SDK が結果を返さなかった');
          return result;
        })(),
        new Promise((_, reject) => {
          timer = setTimeout(() => {
            try { ac.abort(); } catch { /* abort 未対応でも race で打ち切る */ }
            reject(new Error(`SDK timeout (${AGENT_TIMEOUT_MS / 1000}s)`));
          }, AGENT_TIMEOUT_MS);
        }),
      ]);
      return { text, engine: 'sdk' };
    } catch (e) {
      console.error('[manager] SDK 経路失敗 → claude -p フォールバック:', e.message);
    } finally {
      if (timer) clearTimeout(timer);
    }
  }
  return { text: await claudeP(prompt), engine: 'claude-p' };
}

/** 既存ルール一覧の 1 行 — 種別 (操作 / ことば) が分かる形で書く。
    重複起案 (同じ操作・同じことばに 2 本目) を防ぐための材料なので、
    種別ごとに「何に反応するか」のキーを出す。 */
function existingRuleLine(r) {
  if (r.event === 'prompt') {
    return `- [${r.layer}] ${r.id} (ことばきっかけ: keywords: ${r.keywords ?? '(なし)'}`
      + `, find: ${r.find ?? 'substring'}, doc: ${r.doc ?? '(なし)'}, inject: ${r.inject ?? '(既定)'})`;
  }
  return `- [${r.layer}] ${r.id} (操作きっかけ: tool: ${r.tool}, match: ${r.match ?? '(なし)'}`
    + `, doc: ${r.doc ?? '(なし)'}, inject: ${r.inject ?? '(既定)'})`;
}

/**
 * 配置先層に実在する doc 名の一覧 (attach_to で指せる集合)。
 * attach_to の形式 (docs/<name>.md — 階層なし) に合わせ docs/ 直下だけを見る。
 * dot 始まり (save-doc の一時ファイル等) と .md 以外 (.bak 含む) は core の
 * cmd_docs と同じく対象外。層 dir 不明・docs/ 未作成は空 = attach_to 不可。
 */
function listLayerDocs(layerDir) {
  if (!layerDir) return [];
  try {
    return readdirSync(path.join(layerDir, 'docs'))
      .filter((f) => f.endsWith('.md') && !f.startsWith('.'))
      .sort();
  } catch { return []; }
}

/** 起案プロンプトの「配置先層に実在する docs」節 — 無い層では attach_to を禁じる。 */
function layerDocsSection(layerDocs) {
  return (layerDocs && layerDocs.length)
    ? layerDocs.map((n) => `docs/${n}`).join('\n')
    : '(なし — この層にはまだ docs が無い。attach_to は使わず新規 doc を出力する)';
}

/** 起案プロンプト。kind = 'op' (操作きっかけ) | 'kw' (ことばきっかけ = event: prompt)。
    フィールドの意味・有効値は core / engine の実仕様 (validate_event_keys /
    rule_matches_prompt / build_text) を写している — 片方だけ直さない。 */
function buildProposePrompt(request, layer, rules, retryError, kind, layerDocs) {
  if (kind === 'kw') return buildProposePromptKw(request, layer, rules, retryError, layerDocs);
  const existing = rules.length ? rules.map(existingRuleLine).join('\n') : '(なし)';
  const retry = retryError
    ? `\n# 前回出力の問題 (修正して再出力)\n${retryError}\n`
    : '';
  return `あなたは toolhint のルール起案アシスタント。
依頼を「操作に docs を紐づけるルール」(rules.yaml のルール 1 件 + docs/*.md 1 枚) に変換し、厳密な JSON のみを出力する。

# toolhint の仕組み
- Claude Code の PreToolUse hook が tool 実行直前に rules.yaml と照合し、マッチしたらその操作の docs への案内 (inject) を agent に渡す (実行は止めない)
- rule のフィールド:
  - id: kebab-case で一意 (既存 id と重複禁止)
  - tool: tool 名への Python 正規表現 (完全一致 fullmatch — "Bash" は BashOutput に発火しない)。対応表: shell コマンド → "Bash" / ファイル編集 → "Edit|Write" / skill 起動 → "Skill" (match は \\"skill\\": \\"<名前>\\" に掛ける) / MCP ツール → "mcp__<server>__<tool>"。依頼文に skill 名や MCP らしき語があれば Bash ではなくこの表で選ぶ
  - match: tool_input を JSON 文字列化した 1 行 (例: {"command": "git push --force", "description": "..."}) への Python 正規表現 (re.search)。先頭は必ず {" なので ^ や $ のアンカーは使わない (永久に不一致)。" は \\" にエスケープ済み、値内の改行は \\n の 2 文字になる (\\s では跨げない)
  - doc: docs/<name>.md への相対パス
  - inject: マッチ時に agent へ渡す一文。{doc} は doc の絶対パスに展開される。省略すると既定文面「この操作の docs: {doc} — 必要なら読む」
  - mode: "pointer" (既定 — inject の一文だけ渡す) | "inline" (doc 全文をその場で注入 — 短い注意事項向け)
  - every: "session" (既定 — セッション初回のみ) | "always" (毎回)。破壊的・危険操作への注意喚起は、無害な操作で先に消費されないよう every: "always" (+ doc が短ければ mode: "inline") を検討

# 既存ルール一覧 (id はこれらと重複させない)
${existing}

# 配置先層に実在する docs (attach_to で指せるのはこの一覧だけ)
${layerDocsSection(layerDocs)}

- 既存ルールが依頼と同じ操作を既にカバーしている場合は、新しい doc を作らず既存 doc への「きっかけ追加」にする: rule.doc に上の一覧に実在する doc を指定し、doc_content の代わりに "attach_to": "docs/<既存名>.md" を出力する (doc_content は出力しない)。一覧に無い名前を attach_to に書かない。似た match の新規 doc を作ると同じ操作に二重注入される

# 依頼 (この操作に docs を紐づける)
${request}

# 配置先層
${layer}
${retry}
# 出力の決まり
- toolhint は記憶やメモの仕組みではないので、inject と doc_content に「記憶」「メモ」という語を使わない (語彙は「docs」)
- sample_input: このルールがマッチするはずの tool_input の JSON 文字列化 1 行を必ず出力する (自己検証に使う)

# 出力形式 (この JSON オブジェクト 1 個だけを出力。説明文・前置き・コードフェンス禁止)
{"rule": {"id": "...", "tool": "...", "match": "...", "doc": "docs/<name>.md", "inject": "...", "mode": "pointer", "every": "session"}, "doc_name": "<name>.md", "doc_content": "(doc の全文 markdown。依頼の意図を 3-10 行で。冗長にしない)", "sample_input": "{\\"command\\": \\"...\\"}", "rationale": "(起案理由 1-2 文)"}`;
}

/** ことばきっかけ (event: prompt) の起案プロンプト。
    仕様の出どころ: keywords/find/case = engine の rule_matches_prompt +
    split_prompt_keywords、inject/mode = engine の build_text、
    キーの可否 = core の validate_event_keys (tool / match は使えない)。 */
function buildProposePromptKw(request, layer, rules, retryError, layerDocs) {
  const existing = rules.length ? rules.map(existingRuleLine).join('\n') : '(なし)';
  const retry = retryError
    ? `\n# 前回出力の問題 (修正して再出力)\n${retryError}\n`
    : '';
  return `あなたは toolhint のルール起案アシスタント。
依頼を「ユーザーの発言 (ことば) に docs を紐づけるルール」(rules.yaml のルール 1 件 + docs/*.md 1 枚) に変換し、厳密な JSON のみを出力する。

# toolhint の仕組み (ことばきっかけ)
- Claude Code の UserPromptSubmit hook がユーザーの発言を rules.yaml と照合し、マッチしたらその話題の docs への案内 (inject) を agent に渡す (発言は書き換えない)
- rule のフィールド:
  - id: kebab-case で一意 (既存 id と重複禁止)
  - event: 必ず "prompt" (これがことばきっかけの目印。省略・別値は操作きっかけになる)
  - keywords: 反応することばの列。"," か "、" か "，" で区切る (どれか 1 つが発言に現れたら一致 = OR)。区切り文字そのものをことばに含めることはできない。日本語の表記ゆれ (漢字・かな・英字・略称) は同じルールに並べる
  - find: "substring" (既定 — 部分一致。「デプロイ」は「デプロイして」に一致) | "word" (語の単位で一致。英単語が別語の一部に埋もれるのを避けたいとき。日本語には境界が無いので substring と同じに働く) | "regex" (keywords 全体を 1 つの Python 正規表現として読む。この時だけ "," "、" "，" で分割しない)
  - case: "sensitive" のときだけ大文字小文字を区別する。区別しないなら case を出力しない (既定が大小無視)
  - tool / match は使えない (操作きっかけ専用のキー — 出力するとルールごと拒否される)
  - doc: docs/<name>.md への相対パス
  - inject: マッチ時に agent へ渡す一文。{doc} は doc の絶対パスに展開される。省略すると既定文面「この話題の docs: {doc} — 必要なら読む」
  - mode: "pointer" (既定 — inject の一文だけ渡す) | "inline" (doc 全文をその場で注入 — 短い注意事項・言い回しの直し向け)
  - every: "session" (既定 — セッション初回のみ) | "always" (毎回)。毎回言い直させたい矯正は every: "always" (+ doc が短ければ mode: "inline") を検討

# 既存ルール一覧 (id はこれらと重複させない)
${existing}

# 配置先層に実在する docs (attach_to で指せるのはこの一覧だけ)
${layerDocsSection(layerDocs)}

- 既存ルールが依頼と同じ話題を既にカバーしている場合は、新しい doc を作らず既存 doc への「きっかけ追加」にする: rule.doc に上の一覧に実在する doc を指定し、doc_content の代わりに "attach_to": "docs/<既存名>.md" を出力する (doc_content は出力しない)。一覧に無い名前を attach_to に書かない。似た keywords の新規 doc を作ると同じ発言に二重注入される

# 依頼 (この話題に docs を紐づける)
${request}

# 配置先層
${layer}
${retry}
# 出力の決まり
- toolhint は記憶やメモの仕組みではないので、inject と doc_content に「記憶」「メモ」という語を使わない (語彙は「docs」)
- keywords は広すぎない: 「する」「やって」のような日常語だけのルールは毎回発火して邪魔になる。話題を名指しする語 (固有名・専門語・表記ゆれ) を並べる
- sample_prompt: このルールに一致するはずのユーザー発言 1 行を必ず出力する (自己検証に使う。keywords のどれかを実際に含む自然な日本語の文にする)

# 出力形式 (この JSON オブジェクト 1 個だけを出力。説明文・前置き・コードフェンス禁止)
{"rule": {"id": "...", "event": "prompt", "keywords": "語1、語2", "find": "substring", "doc": "docs/<name>.md", "inject": "...", "mode": "pointer", "every": "session"}, "doc_name": "<name>.md", "doc_content": "(doc の全文 markdown。依頼の意図を 3-10 行で。冗長にしない)", "sample_prompt": "(このルールに一致するはずのユーザー発言 1 行)", "rationale": "(起案理由 1-2 文)"}`;
}

function extractJson(text) {
  // 前置き・コードフェンス付きでも拾えるよう、'{' から文字列リテラルを考慮した
  // 括弧対応で JSON オブジェクトを切り出す (doc_content 内の ``` や '}' に耐える)。
  // 前置き散文に '{doc}' 等の括弧が混ざっても、parse 失敗したら次の '{' から
  // 再走査して同一 attempt 内で回収する (retry を空費しない)。
  const t = String(text);
  let start = t.indexOf('{');
  let lastErr = null;
  while (start !== -1) {
    let depth = 0;
    let inStr = false;
    let esc = false;
    let end = -1;
    for (let i = start; i < t.length; i++) {
      const c = t[i];
      if (inStr) {
        if (esc) esc = false;
        else if (c === '\\') esc = true;
        else if (c === '"') inStr = false;
      } else if (c === '"') inStr = true;
      else if (c === '{') depth++;
      else if (c === '}') {
        depth--;
        if (depth === 0) { end = i; break; }
      }
    }
    if (end === -1) break; // ここから先に閉じたオブジェクトはない
    try { return JSON.parse(t.slice(start, end + 1)); }
    catch (e) { lastErr = e; start = t.indexOf('{', start + 1); }
  }
  throw new Error(lastErr
    ? `出力から JSON オブジェクトを取り出せない: ${lastErr.message}`
    : '出力に JSON オブジェクトが見つからない (または閉じていない)');
}

// 改行・制御文字 (rules.yaml の 1 行値に入れられない / mock 経路の YAML 破壊防止)
const CTRL_RE = /[\u0000-\u001f\u007f\u0085\u2028\u2029]/;

/**
 * 書き込み先の層の検証 — 書けるのは global | project だけ。
 * 追加層 (layers.d/<名前>) は外から配られる読み取り専用の層で、core の書き込み
 * 経路にも存在しない。黙って project へ倒すと「共有ルールを直したつもりが
 * 手元に別物ができる」ので、明示的に 400 で断る。
 */
function assertWritableLayer(layer) {
  if (layer === 'global' || layer === 'project') return layer;
  throw httpError(400, `書き込み先の層は global | project: ${JSON.stringify(layer ?? null)}`
    + ' (layers.d/* は読み取り専用)');
}

function assertRuleValuesClean(rule) {
  for (const [k, v] of Object.entries(rule)) {
    if (typeof v === 'string' && CTRL_RE.test(v)) {
      throw new Error(`rule.${k} に改行・制御文字が含まれる — 1 行の値にする`);
    }
  }
}

function validateProposal(p, layerIds, kind, layerDocs) {
  if (!p || typeof p !== 'object') throw new Error('JSON がオブジェクトでない');
  const r = p.rule;
  if (!r || typeof r !== 'object') throw new Error('rule フィールドがない');
  if (!r.id || !/^[a-z0-9][a-z0-9-]*$/.test(r.id)) throw new Error(`rule.id が不正: ${JSON.stringify(r.id)}`);
  const isKw = kind === 'kw';
  if (isKw) {
    // ことばきっかけ: event: prompt 固定 + keywords 必須。tool/match は core が
    // 混在キーとして拒否するので、人の承認前 (retry の効くここ) で弾く
    if (r.event !== undefined && r.event !== 'prompt') throw new Error(`rule.event は "prompt" (ことばきっかけ): ${JSON.stringify(r.event)}`);
    r.event = 'prompt';
    if (!r.keywords || typeof r.keywords !== 'string') throw new Error('rule.keywords がない (ことばきっかけの必須キー)');
    for (const k of ['tool', 'match']) {
      if (r[k] !== undefined) throw new Error(`rule.${k} は event: prompt のルールに使えない (操作きっかけ専用のキー)`);
    }
    if (r.find !== undefined && !['substring', 'word', 'regex'].includes(r.find)) throw new Error(`rule.find は substring | word | regex: ${JSON.stringify(r.find)}`);
    if (r.case !== undefined && r.case !== 'sensitive') throw new Error(`rule.case は "sensitive" のみ (大小無視なら省く): ${JSON.stringify(r.case)}`);
    // 区切りは engine の split_prompt_keywords と同じ `,` `、` `，` (全角カンマ) の 3 種
    if (r.find !== 'regex' && !r.keywords.split(/[,、，]/).some((s) => s.trim())) {
      throw new Error('rule.keywords に有効な要素がない (区切り文字だけ)');
    }
  } else {
    if (!r.tool || typeof r.tool !== 'string') throw new Error('rule.tool がない');
    if (!r.match || typeof r.match !== 'string') throw new Error('rule.match がない');
  }
  const attachTo = typeof p.attach_to === 'string' ? p.attach_to : '';
  const docsList = (layerDocs && layerDocs.length)
    ? layerDocs.map((n) => `docs/${n}`).join(', ')
    : '(なし)';
  if (attachTo) {
    // 既存 doc への「きっかけ追加」— doc_content なしで apply (--doc-content 省略の新契約)
    if (!/^docs\/[A-Za-z0-9._\-]+\.md$/.test(attachTo)) throw new Error(`attach_to が不正 (docs/<name>.md のみ): ${JSON.stringify(attachTo)}`);
    // 実在しない doc への attach_to は apply で必ず死ぬ (core が --doc-content 省略時に
    // 実在を要求する) — 人の承認画面に出す前のここで弾いて retry へ回す
    if (!layerDocs || !layerDocs.includes(attachTo.slice('docs/'.length))) {
      throw new Error(`attach_to の doc が配置先層に実在しない: ${attachTo}`
        + ` (実在する docs: ${docsList}) — 実在する doc を指すか、新規 doc (doc_name + doc_content) にする`);
    }
    r.doc = attachTo;
    p.doc_name = attachTo.slice('docs/'.length);
  } else {
    if (!p.doc_name || !/^[A-Za-z0-9._\-]+\.md$/.test(p.doc_name)) throw new Error(`doc_name が不正: ${JSON.stringify(p.doc_name)}`);
    if (!p.doc_content || typeof p.doc_content !== 'string') throw new Error('doc_content がない (既存 doc へ紐づけるなら attach_to を出力)');
    // 既存 doc と同名の新規 doc は apply で必ず死ぬ (core は内容が違う doc の
    // 上書きを拒否する) — 既存へ紐づけるのか別名の新規なのかを agent に決め直させる。
    // 大文字小文字を区別しないファイルシステム (macOS / Windows の既定) があるので比較も大小無視で行う
    const lower = p.doc_name.toLowerCase();
    if (layerDocs && layerDocs.some((n) => n.toLowerCase() === lower)) {
      throw new Error(`doc_name ${JSON.stringify(p.doc_name)} は配置先層に既に存在する doc — `
        + `既存 doc へ紐づけるなら "attach_to": "docs/${p.doc_name}" を出力、新規 doc なら別名にする`);
    }
    // rule.doc は doc_name から組む (LLM が別の doc を指してきても従わない —
    // 承認画面の doc 名と保存される参照が食い違う穴になる)
    r.doc = `docs/${p.doc_name}`;
  }
  if (typeof r.doc !== 'string' || !r.doc.startsWith('docs/') || r.doc.includes('..')) {
    throw new Error(`rule.doc が不正 (docs/ 配下のみ・'..' 禁止): ${JSON.stringify(r.doc)}`);
  }
  if (r.mode !== undefined && !['pointer', 'inline'].includes(r.mode)) throw new Error(`rule.mode は pointer | inline: ${JSON.stringify(r.mode)}`);
  if (r.every !== undefined && !['session', 'always'].includes(r.every)) throw new Error(`rule.every は session | always: ${JSON.stringify(r.every)}`);
  if (layerIds.has(r.id)) throw new Error(`id "${r.id}" は配置先層に既に存在する — 別の id にする`);
  // 既定値 (find: substring / case 無し) はキーごと省く — core の正準形に合わせる
  const rule = isKw
    ? {
      id: r.id, event: 'prompt', keywords: r.keywords, doc: r.doc,
      ...(r.find && r.find !== 'substring' ? { find: r.find } : {}),
      ...(r.case === 'sensitive' ? { case: 'sensitive' } : {}),
      ...(r.inject ? { inject: r.inject } : {}),
      ...(r.mode ? { mode: r.mode } : {}),
      ...(r.every ? { every: r.every } : {}),
    }
    : {
      id: r.id, tool: r.tool, match: r.match, doc: r.doc,
      ...(r.inject ? { inject: r.inject } : {}),
      ...(r.mode ? { mode: r.mode } : {}),
      ...(r.every ? { every: r.every } : {}),
    };
  assertRuleValuesClean(rule);
  // 自己検証の入力 — 操作きっかけは tool_input の JSON 1 行、ことばきっかけは発言 1 行。
  // 欠けたら通さない: 無いと「実際に発火するか」の突き合わせも二重注入検査も走らず、
  // 一度も発火しないルールが無検証で人の承認画面まで届く (プロンプトも必須と言っている)
  const sampleKey = isKw ? 'sample_prompt' : 'sample_input';
  const sample = p[sampleKey];
  if (typeof sample !== 'string' || !sample.trim()) {
    throw new Error(`${sampleKey} がない (自己検証に必須 — ${isKw
      ? 'このルールに一致するはずのユーザー発言 1 行'
      : 'このルールがマッチするはずの tool_input の JSON 文字列化 1 行'}を出力する)`);
  }
  return {
    rule,
    doc_name: p.doc_name,
    doc_content: attachTo ? '' : p.doc_content,
    ...(attachTo ? { attach_to: attachTo } : {}),
    sample_input: isKw ? '' : sample,
    sample_prompt: isKw ? sample : '',
    rationale: typeof p.rationale === 'string' ? p.rationale : '',
  };
}

/**
 * 提案 rule の正規表現を Python 実 compile で事前検証する (JS の RegExp は
 * Python 方言と非互換なので使わない)。sample_input があれば match が実際に
 * 発火するかも突き合わせる。戻り値 {errors: string[], bash: boolean}。
 */
function pyCheckProposal(rule, sampleInput) {
  const script = [
    'import json,re,sys',
    'd=json.load(sys.stdin)',
    'errs=[]',
    'for k in ("tool","match"):',
    '    try: re.compile(d[k])',
    '    except re.error as e: errs.append("rule.%s が Python 正規表現として不正: %s" % (k,e))',
    'bash=False',
    'if not errs:',
    '    try: bash=bool(re.fullmatch(d["tool"],"Bash"))',
    '    except Exception: pass',
    '    if d.get("sample") and not re.search(d["match"], d["sample"]):',
    '        errs.append("match が sample_input にマッチしない (一度も発火しないルール) — match か sample_input を修正")',
    'print(json.dumps({"errors":errs,"bash":bash}))',
  ].join('\n');
  return new Promise((resolve, reject) => {
    const child = execFile('python3', ['-c', script], { timeout: 10_000 }, (err, stdout) => {
      try { return resolve(JSON.parse(stdout)); } catch { /* fallthrough */ }
      reject(new Error(`regex 事前検証の実行に失敗: ${err ? err.message : String(stdout).slice(0, 200)}`));
    });
    child.stdin.write(JSON.stringify({ tool: rule.tool, match: rule.match, sample: sampleInput || null }));
    child.stdin.end();
  });
}

/**
 * ことばきっかけ (event: prompt) の提案を、engine の実マッチャで事前検証する。
 * 判定は engine の rule_matches_prompt — core dry-run --event=prompt が内部で
 * 呼ぶのと同じ関数 (dry-run は rules.yaml に既に在るルールしか見られないため、
 * 未保存の提案はこの経路で「実際に発火するか」を確かめる。既存ルールとの
 * 二重注入検査だけは dry-run --event=prompt に流す)。戻り値 {errors: string[]}。
 */
function pyCheckProposalPrompt(rule, samplePrompt) {
  const script = [
    'import json,re,sys',
    'd=json.load(sys.stdin)',
    'sys.path.insert(0, d["engine"])',
    'import toolhint',
    'rule=d["rule"]',
    'errs=[]',
    'if toolhint.rule_find(rule) == "regex":',
    '    try: re.compile(rule.get("keywords") or "")',
    '    except re.error as e: errs.append("rule.keywords が Python 正規表現として不正 (find: regex): %s" % e)',
    'if not errs and d.get("sample"):',
    '    if not toolhint.rule_matches_prompt(rule, d["sample"]):',
    '        errs.append("keywords が sample_prompt に一致しない (一度も発火しないルール) — keywords か sample_prompt を修正")',
    'print(json.dumps({"errors":errs,"bash":False}))',
  ].join('\n');
  return new Promise((resolve, reject) => {
    const child = execFile('python3', ['-c', script], { timeout: 10_000 }, (err, stdout) => {
      try { return resolve(JSON.parse(stdout)); } catch { /* fallthrough */ }
      reject(new Error(`ことばきっかけの事前検証に失敗: ${err ? err.message : String(stdout).slice(0, 200)}`));
    });
    child.stdin.write(JSON.stringify({
      engine: path.join(REPO_ROOT, 'engine', 'scripts'),
      rule,
      sample: samplePrompt || null,
    }));
    child.stdin.end();
  });
}

// ---------------------------------------------------------------------------
// HTTP まわり
// ---------------------------------------------------------------------------

function sendJson(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
  });
  res.end(body);
}

function readBody(req) {
  // Content-Type: application/json を必須にする — text/plain のままだと
  // プリフライト無しの cross-site simple request (CSRF) が素通りする
  const ct = String(req.headers['content-type'] || '').trim();
  if (!/^application\/json\b/i.test(ct)) {
    return Promise.reject(httpError(415, 'Content-Type: application/json が必要'));
  }
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', (c) => {
      data += c;
      if (data.length > 4 * 1024 * 1024) {
        reject(new Error('body too large'));
        req.destroy();
      }
    });
    req.on('end', () => {
      try { resolve(data ? JSON.parse(data) : {}); }
      catch { reject(new Error('body が JSON でない')); }
    });
    req.on('error', reject);
  });
}

const STATIC_FILES = {
  '/': ['index.html', 'text/html; charset=utf-8'],
  '/index.html': ['index.html', 'text/html; charset=utf-8'],
  '/app.js': ['app.js', 'text/javascript; charset=utf-8'],
  '/style.css': ['style.css', 'text/css; charset=utf-8'],
};

async function serveStatic(res, urlPath) {
  const entry = STATIC_FILES[urlPath];
  if (!entry) {
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('not found');
    return;
  }
  const body = await readFile(path.join(PUBLIC_DIR, entry[0]));
  res.writeHead(200, { 'Content-Type': entry[1], 'Cache-Control': 'no-store' });
  res.end(body);
}

function isDir(p) {
  try { return statSync(p).isDirectory(); } catch { return false; }
}

/**
 * 起動 dir から親方向へ .git を探し、git root を返す (無ければ null)。
 * .git は dir (通常 clone) と file (worktree) の両方があるので種別は問わない。
 */
function findGitRoot(start) {
  let d = start;
  while (true) {
    try { statSync(path.join(d, '.git')); return d; } catch { /* 上へ */ }
    const p = path.dirname(d);
    if (p === d) return null;
    d = p;
  }
}

// 読み取り系の既定 cwd — サーバ起動 dir (manager/) ではなく git root。
const DEFAULT_CWD = findGitRoot(process.cwd()) ?? process.cwd();

/**
 * cwd の解決。forWrite: true (書き込み系) は typo/誤所書き込み防止のため
 * (1) cwd の明示を必須にし (サーバ起動 dir への暗黙フォールバック禁止)、
 * (2) 実在するディレクトリでなければ 400 (存在しないパスへ層を新規作成しない)。
 */
function resolveCwd(raw, { forWrite = false } = {}) {
  let c = (raw || '').trim();
  if (!c) {
    if (forWrite) throw httpError(400, '書き込みには cwd (対象プロジェクト) の明示が必要');
    return DEFAULT_CWD;
  }
  // `~` / `~/...` を home へ展開 (path.resolve は ~ を解さず起動 dir 相対にしてしまう)
  if (c === '~' || c.startsWith('~/')) c = os.homedir() + c.slice(1);
  const abs = path.resolve(c);
  if (forWrite && !isDir(abs)) {
    throw httpError(400, `cwd が存在するディレクトリでない: ${abs}`);
  }
  return abs;
}

/** doc パスが toolhint 層ディレクトリ配下かを検証して読む。外なら 403。 */
async function readDocSafe(cwd, docPath) {
  const state = await runCore(['list', `--cwd=${cwd}`]);
  const layerDirs = [];
  for (const l of state.layers || []) {
    if (!l.dir) continue;
    try { layerDirs.push(await realpath(l.dir)); }
    catch { layerDirs.push(path.resolve(l.dir)); }
  }
  const abs = path.resolve(docPath);
  let real = abs;
  try { real = await realpath(abs); }
  catch { /* 実在しない場合は resolve 済みパスで判定 → 404 は後段 */ }
  const inside = layerDirs.some((d) => real === d || real.startsWith(d + path.sep));
  if (!inside) return { status: 403, error: 'toolhint 層ディレクトリ配下以外のパスは読めない' };
  if (!existsSync(real)) return { status: 404, error: 'doc が存在しない' };
  const content = await readFile(real, 'utf-8');
  return { status: 200, content };
}

// ---------------------------------------------------------------------------
// ルーティング
// ---------------------------------------------------------------------------

const server = http.createServer(async (req, res) => {
  let url;
  try { url = new URL(req.url, `http://${req.headers.host || 'localhost'}`); }
  catch { return sendJson(res, 400, { error: 'Host ヘッダが不正' }); }
  const p = url.pathname;
  try {
    // DNS rebinding 対策 — 未知の Host ヘッダは静的ファイル含め全 route で拒否
    if (!hostAllowed(req.headers.host || '')) {
      throw httpError(403, `この Host は許可されていない: ${JSON.stringify(String(req.headers.host || ''))}`
        + ' (必要なら TOOLHINT_ALLOWED_HOSTS で追加)');
    }
    if (req.method === 'GET' && (p === '/' || p === '/index.html' || p === '/app.js' || p === '/style.css')) {
      return await serveStatic(res, p);
    }

    // /api 全体の防御 — 変更系はブラウザ経路 (CSRF) も遮断し、token 必須時は
    // 読み取り系にも認証を要求する (同一ネットワークのピアからの docs/rules 読み出しも塞ぐ)
    if (p.startsWith('/api/')) {
      if (req.method === 'POST') assertSameOrigin(req);
      assertAuth(req);
    }

    if (req.method === 'GET' && p === '/api/state') {
      const cwd = resolveCwd(url.searchParams.get('cwd'));
      const [{ out: state, kind }, engine] = await Promise.all([
        runCoreWithKind(['list', `--cwd=${cwd}`]),
        detectEngine(cwd),
      ]);
      // cwd_exists: false = typo/未作成パス — GUI が警告を出すための実在フラグ
      // ui: 起動オプションで決まる表示モード (未設定ならキーごと出さない)
      const ui = uiMode();
      return sendJson(res, 200, {
        cwd, cwd_exists: isDir(cwd), core: kind, engine, ...(ui ? { ui } : {}), ...state,
      });
    }

    if (req.method === 'GET' && p === '/api/docs') {
      const cwd = resolveCwd(url.searchParams.get('cwd'));
      const { out, kind } = await runCoreWithKind(['docs', `--cwd=${cwd}`], { needNew: true });
      return sendJson(res, 200, { cwd, core: kind, ...out });
    }

    if (req.method === 'GET' && p === '/api/log') {
      const cwd = resolveCwd(url.searchParams.get('cwd'));
      const limit = Math.min(500, Math.max(1, Number(url.searchParams.get('limit')) || 50));
      const { out, kind } = await runCoreWithKind(
        ['log', `--cwd=${cwd}`, `--limit=${limit}`], { needNew: true });
      return sendJson(res, 200, { cwd, core: kind, ...out });
    }

    if (req.method === 'POST' && p === '/api/savedoc') {
      const body = await readBody(req);
      const cwd = resolveCwd(body.cwd, { forWrite: true });
      const layer = assertWritableLayer(body.layer);
      const docName = String(body.doc_name || '');
      const content = String(body.content ?? '');
      // docs/ 直下の *.md 以外は 403 (core 側の拒否にも依拠する二重ガード)
      if (!/^[A-Za-z0-9._\-]+\.md$/.test(docName) || docName.includes('..')
          || docName.includes('/') || docName.includes('\\')) {
        return sendJson(res, 403, { error: `docs/ 外のパスへは保存できない: ${JSON.stringify(docName)}` });
      }
      const { out, kind } = await runCoreWithKind(
        ['save-doc', `--cwd=${cwd}`, `--layer=${layer}`,
         `--doc-name=${docName}`, `--content=${content}`],
        { needNew: true, write: true });
      return sendJson(res, out.ok ? 200 : 409, { ...out, core: kind });
    }

    if (req.method === 'GET' && p === '/api/doc') {
      const cwd = resolveCwd(url.searchParams.get('cwd'));
      const docPath = url.searchParams.get('path') || '';
      if (!docPath) return sendJson(res, 400, { error: 'path が必要' });
      const r = await readDocSafe(cwd, docPath);
      if (r.status !== 200) return sendJson(res, r.status, { error: r.error });
      return sendJson(res, 200, { path: docPath, content: r.content });
    }

    if (req.method === 'POST' && p === '/api/dryrun') {
      const body = await readBody(req);
      const cwd = resolveCwd(body.cwd);
      const input = String(body.input ?? '');
      // = 連結形式: 先頭 '-' の入力 ("-r" 等) でも argparse が値として受理する
      const args = ['dry-run', `--cwd=${cwd}`];
      if (body.event === 'prompt') {
        // ことばきっかけ — input をユーザー発言として event: prompt のルールのみ判定
        // (--tool は不要。マッチは core が engine の rule_matches_prompt へ委譲)
        args.push('--event=prompt');
      } else {
        const tool = (body.tool || 'Bash').trim() || 'Bash';
        args.push(`--tool=${tool}`);
      }
      args.push(`--input=${input}`);
      const { out, kind } = await runCoreWithKind(args);
      return sendJson(res, 200, { ...out, core: kind });
    }

    if (req.method === 'POST' && p === '/api/propose') {
      const body = await readBody(req);
      const cwd = resolveCwd(body.cwd);
      const request = String(body.request || '').trim();
      // 起案の配置先も書き込み先と同じ検証 — 不明値を黙って project に倒すと
      // 「共有ルールを直すつもりの起案が手元へ落ちる」誤りが起きる
      const layer = assertWritableLayer(body.layer);
      // きっかけ種別 — 省略時は操作きっかけ (後方互換)
      const kind = body.kind === 'kw' ? 'kw' : 'op';
      if (!request) return sendJson(res, 400, { error: '依頼文が空' });

      const state = await runCore(['list', `--cwd=${cwd}`]);
      const rules = state.rules || [];
      const layerIds = new Set(rules.filter((r) => r.layer === layer).map((r) => r.id));
      // 配置先層に実在する docs — プロンプト (attach_to の許される集合) と
      // 起案検証 (実在しない attach_to / 既存名の新規 doc を retry へ回す) の両方で使う
      const layerDir = ((state.layers || []).find((l) => l.name === layer) || {}).dir;
      const layerDocs = listLayerDocs(layerDir);

      let lastErr = null;
      let engine = null;
      for (let attempt = 0; attempt < 2; attempt++) {
        const prompt = buildProposePrompt(request, layer, rules, lastErr, kind, layerDocs);
        let raw;
        try {
          const r = await runAgent(prompt);
          raw = r.text;
          engine = r.engine;
        } catch (e) {
          return sendJson(res, 502, { error: `agent 実行に失敗: ${e.message}` });
        }
        try {
          const proposal = validateProposal(extractJson(raw), layerIds, kind, layerDocs);
          // 自己検証 (種別ごとに同じ厳しさ): 操作きっかけは Python 実 compile +
          // sample_input 突き合わせ / ことばきっかけは engine の実マッチャで
          // sample_prompt 突き合わせ。不発ルールは人の承認前に retry へ回す
          // (検証自体の失敗は fail-open でスキップ)
          let check = null;
          try {
            check = kind === 'kw'
              ? await pyCheckProposalPrompt(proposal.rule, proposal.sample_prompt)
              : await pyCheckProposal(proposal.rule, proposal.sample_input);
          } catch (e2) { console.error('[manager] 起案の事前検証をスキップ:', e2.message); }
          if (check && check.errors && check.errors.length) {
            throw new Error(check.errors.join(' / '));
          }
          // 既存ルールとの二重注入検査: sample を core dry-run に通し、
          // 同じ入力で共鳴する既存ルールを overlap として GUI へ返す
          let overlap = [];
          try {
            let dr = null;
            if (kind === 'kw') {
              if (check && proposal.sample_prompt) {
                dr = await runCore(['dry-run', `--cwd=${cwd}`, '--event=prompt',
                  `--input=${proposal.sample_prompt}`]);
              }
            } else if (check && check.bash && proposal.sample_input) {
              let cmd = null;
              try {
                const si = JSON.parse(proposal.sample_input);
                if (si && typeof si.command === 'string') cmd = si.command;
              } catch { /* flat が JSON でない場合は検査しない */ }
              if (cmd) {
                dr = await runCore(['dry-run', `--cwd=${cwd}`, '--tool=Bash', `--input=${cmd}`]);
              }
            }
            if (dr) {
              overlap = (dr.matches || [])
                .filter((m) => m.id !== proposal.rule.id)
                .map((m) => ({ id: m.id, layer: m.layer }));
            }
          } catch (e3) {
            console.error('[manager] overlap 検査をスキップ:', e3.message);
          }
          return sendJson(res, 200, {
            ...proposal, layer, kind, engine,
            ...(overlap.length ? { overlap } : {}),
          });
        } catch (e) {
          lastErr = `${e.message}\n(前回の生出力冒頭: ${String(raw).slice(0, 300)})`;
        }
      }
      return sendJson(res, 502, { error: `起案 JSON の検証に 2 回失敗: ${lastErr}`, engine });
    }

    // rule CRUD (update / delete / toggle) — real core の安全経路のみ (mock では書かない)
    if (req.method === 'POST' && (p === '/api/rule/update' || p === '/api/rule/delete' || p === '/api/rule/toggle')) {
      const body = await readBody(req);
      const cwd = resolveCwd(body.cwd, { forWrite: true });
      const id = String(body.id || '').trim();
      if (!id) return sendJson(res, 400, { error: 'id が必要' });
      const layer = body.layer == null || body.layer === '' ? null : body.layer;
      if (layer !== null && layer !== 'global' && layer !== 'project') {
        return sendJson(res, 400, { error: `layer は global | project: ${JSON.stringify(body.layer)}` });
      }
      const layerArg = layer ? [`--layer=${layer}`] : []; // 省略時は core が両層から探す
      let args;
      if (p === '/api/rule/update') {
        const patch = body.patch;
        if (!patch || typeof patch !== 'object' || Array.isArray(patch)
            || !Object.keys(patch).length) {
          return sendJson(res, 400, { error: 'patch (空でない JSON オブジェクト) が必要' });
        }
        // 改行・制御文字は rules.yaml を壊し得るので core に渡る前に 400 (null = キー削除)
        for (const [k, v] of Object.entries(patch)) {
          if (v === null) continue;
          if (typeof v !== 'string' || CTRL_RE.test(v)) {
            return sendJson(res, 400, { error: `patch.${k} は改行・制御文字なしの文字列 (または削除の null) にする` });
          }
        }
        args = ['update-rule', `--cwd=${cwd}`, `--id=${id}`, ...layerArg,
          `--patch=${JSON.stringify(patch)}`];
      } else if (p === '/api/rule/delete') {
        args = ['rm-rule', `--cwd=${cwd}`, `--id=${id}`, ...layerArg];
      } else { // toggle
        if (typeof body.enabled !== 'boolean') {
          return sendJson(res, 400, { error: 'enabled (boolean) が必要' });
        }
        args = [body.enabled ? 'enable-rule' : 'disable-rule',
          `--cwd=${cwd}`, `--id=${id}`, ...layerArg];
      }
      const { out, kind } = await runCoreWithKind(args, { write: true });
      return sendJson(res, out.ok ? 200 : 409, { ...out, core: kind });
    }

    if (req.method === 'POST' && p === '/api/apply') {
      const body = await readBody(req);
      const cwd = resolveCwd(body.cwd, { forWrite: true });
      const layer = assertWritableLayer(body.layer);
      const rule = body.rule;
      // 必須キーは種別で違う: 操作きっかけ = tool / ことばきっかけ (event: prompt) =
      // keywords。詳細検証 (混在キー拒否・find/case の値) は core が持つ
      const isPrompt = !!rule && typeof rule === 'object' && rule.event === 'prompt';
      if (!rule || typeof rule !== 'object' || !rule.id
          || (isPrompt ? !rule.keywords : !rule.tool)) {
        return sendJson(res, 400, { error: isPrompt
          ? 'rule (id, keywords 必須 — event: prompt) が必要'
          : 'rule (id, tool 必須) が必要' });
      }
      if (!rule.doc && body.doc_name) rule.doc = `docs/${body.doc_name}`;
      // 改行・制御文字は rules.yaml を壊し得るので core に渡る前に 400 で弾く
      try { assertRuleValuesClean(rule); }
      catch (e) { return sendJson(res, 400, { error: e.message }); }
      if (rule.doc && String(rule.doc).includes('..')) {
        return sendJson(res, 400, { error: `rule.doc に '..' は使えない: ${JSON.stringify(rule.doc)}` });
      }
      const docContent = String(body.doc_content ?? '');
      // doc_content 空 = 既存 doc へのきっかけ追加。core も同じ実在検査を持つが、
      // そのエラーは CLI フラグ語彙 (--doc-content 省略時は…) で GUI の人に読めない —
      // ここで先に、何をすればよいかまで言う 400 にする (起案の doc 名を書き換えた
      // とき等に通る経路)
      // 正準形 (docs/<name>.md) のときだけ — 絶対パス等の異形は core の検証
      // (「doc は層ディレクトリ配下を指すこと」) のほうが正確なので覆い隠さない
      if (!docContent && /^docs\/[A-Za-z0-9._\-]+\.md$/.test(String(rule.doc || ''))) {
        const st = await runCore(['list', `--cwd=${cwd}`]);
        const dir = ((st.layers || []).find((l) => l.name === layer) || {}).dir;
        if (dir && !existsSync(path.join(dir, String(rule.doc)))) {
          return sendJson(res, 400, {
            error: `${rule.doc} は配置先の層にまだ無い — 本文なしで保存できるのは実在する doc への`
              + 'きっかけ追加だけ。doc 名を実在するものに戻すか、本文 (doc_content) も送る',
          });
        }
      }
      const args = ['add-rule', `--layer=${layer}`, `--cwd=${cwd}`,
        `--rule=${JSON.stringify(rule)}`];
      if (docContent) args.push(`--doc-content=${docContent}`);
      const { out, kind } = await runCoreWithKind(args, { needNew: !docContent, write: true });
      return sendJson(res, out.ok ? 200 : 409, { ...out, core: kind });
    }

    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('not found');
  } catch (e) {
    // httpError (400/503 等) は status を尊重する (500 に丸めない)
    sendJson(res, e.status || 500, { error: e.message });
  }
});

// propose は retry 込みで最大 2 × 180s + core 呼び出し。Node 既定の
// requestTimeout (300s) だと成功間際に接続が切れるため余裕を持たせる。
server.requestTimeout = 420_000;

server.listen(PORT, HOST, async () => {
  console.log(`[manager] toolhint manager: http://${HOST}:${PORT}/`);
  if (AUTH_TOKEN) {
    console.log(`[manager] 認証 token 有効 (非 loopback bind / TOOLHINT_TOKEN 指定) — `
      + `GUI はこの URL で開く: http://${HOST}:${PORT}/?token=${AUTH_TOKEN}`);
    console.log('[manager] API 直叩きは X-Toolhint-Token ヘッダ (または Authorization: Bearer) を付ける');
  }
  if (GLOBAL_ONLY) {
    console.log('[manager] 全体層モード有効 (TOOLHINT_GLOBAL_ONLY) — GUI は全体層だけを扱う'
      + ` / 対象の表示: ${GLOBAL_LABEL}`);
  }
  if (process.env.TOOLHINT_AGENT_STUB) {
    // 起案が LLM の実出力でないことは必ず声に出す (無言でスタブが効いていると
    // 「起案できている」と誤読する)
    console.error('[manager] TOOLHINT_AGENT_STUB 有効 — 起案は LLM を呼ばず '
      + 'env の固定出力を使う (テスト用。本番では外すこと)');
  }
  const cp = await corePathFor('docs', true);
  console.log(`[manager] core (新契約 docs): ${cp} (${coreKindOf(cp)})`);
});
