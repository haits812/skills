# toolhint (engine)

注入エンジン — Claude Code の hook で、きっかけに紐づけた docs (ポインタ or 本文) を
`additionalContext` として注入する。きっかけは 2 種: **操作きっかけ** (PreToolUse —
エージェントがツールを使う直前) と **ことばきっかけ** (UserPromptSubmit — ユーザー発言に
`keywords` がマッチした時)。
**実行は絶対に止めない** (どんな異常でも exit 0 の fail-open)。依存は python3 標準ライブラリのみ。
plugin として単独動作する本体で、CLI / GUI の管理面はリポジトリルートの README を参照。

例: `match: \bgrep\b` のルールがあると、agent が `grep -r foo .` を実行する直前に

```
[toolhint] この操作の docs: ~/.claude/toolhint/docs/search-tools.md — 必要なら読む
```

が context に注入される (pointer 既定。`mode: inline` なら doc 本文ごと注入)。

## 仕組み

1. すべてのツール呼び出し直前 (PreToolUse, matcher `*`) とユーザー発言時
   (UserPromptSubmit, argv `--event=prompt`) に `scripts/toolhint.py` が起動 (timeout 5s)
2. 層の `rules.yaml` を読む
   - **追加層 (任意)**: `<global層>/layers.d/<名前>/` (サブディレクトリ 1 つが 1 層。
     名前の辞書順。無ければ何も起きない)
   - **global 層**: `~/.claude/toolhint/` (環境変数 `TOOLHINT_GLOBAL` で変更可)
   - **project 層**: cwd から上方向 (ホーム or ルートまで) に最初に見つかる `<dir>/.claude/toolhint/`
   - `layers.d/*` → global → project の順にマージし、同 `id` は後勝ち (= より手元の層が勝つ)。
     手元の層に同 `id` で `enabled: "false"` のルールを置けば、追加層のルールを
     そのマシン / プロジェクトだけ止められる
   - 追加層のルールが参照できる `doc` は**その層 dir 配下だけ** (realpath 判定)。
     `../` や symlink で層外を指すルールは警告してスキップする — 配られた層が
     層外の任意ファイルを注入できないようにする安全側の制限 (global / project 層は
     従来どおり制限しない)
   - 1 つの層のルールファイルは 2 本 — `rules.yaml` と `rules-scoped.yaml`
     (この順に読み、同 `id` は後勝ち)。書式も扱いも同じで、適用範囲つきの
     ルール (下記 `scope`) を後者に置き分ける。分けてある理由は 1 つ:
     この形式を知らない古い版の engine は `rules.yaml` しか読まないため、
     適用範囲つきのルールが「範囲を無視してどこでも発火する」事故が起きない。
     どちらかがパース不能なら、その層全体を読み飛ばす (fail-open)
3. マッチしたルールの文面を
   `{"hookSpecificOutput": {"hookEventName": "<イベント名>", "additionalContext": "..."}}` で注入。
   操作きっかけは `tool_name` と `tool_input` (JSON 文字列化) への正規表現マッチ
   (`tool` は完全一致 = fullmatch。`Bash` が `BashOutput` に誤発火しない)、
   ことばきっかけは発言への `keywords` マッチ (記法は下記)
4. `every: session` (既定) のルールは同一 context (main 会話 / 各 subagent) につき 1 回だけ発火
   (状態は `<global層>/state/<session_id>[__<agent_id>].json`。subagent は fresh context
   なので親で表示済みでも別カウントで注入する)
   - 並列 tool call の state 更新は flock で直列化。二重配線 (settings.json 手動 + plugin 等)
     で同じきっかけに hook プロセスが 2 つ起動しても、`state/claims/` を先取りした
     1 プロセスだけが注入する (claim 機構)。鍵はきっかけ別:
     - 操作きっかけ: payload の `tool_use_id` (`state/claims/<tool_use_id>.claim`)
     - ことばきっかけ: payload に一意な id が無いので `session_id` + context (`agent_id`)
       + 発言本文 + マッチしたルール id 集合のハッシュ (`state/claims/prompt-<hash>.claim`)。
       同じ鍵の claim が **10 秒以内**に既にあれば後着とみなして注入しない。10 秒より
       古ければ「同じ発言をもう一度送った」ものとして claim を更新し、通常どおり注入する
       (`every: always` のルールは再注入される)。裏返すと、同じ session で全く同じ発言を
       10 秒以内に 2 回送ると 2 回目には `every: always` でも注入されない
   - state/claims はファイル数が閾値 (200) を超えた時のみ 14 日超の古いものを best-effort GC

## ルール記法 (rules.yaml)

**操作きっかけ** (既定 — `event` キー無し or `event: tool`):

```yaml
rules:
  - id: search-tools            # 必須。層マージのキー
    tool: Bash                  # 必須。tool_name への正規表現
    match: \bgrep\b             # tool_input (JSON 文字列化) への正規表現。省略時は常にマッチ
    doc: docs/search-tools.md   # rules.yaml のあるディレクトリからの相対パス
    inject: "読め: {doc}"       # 文面テンプレ。{doc}=doc の絶対パス, {id} が使える
    mode: pointer               # pointer (既定) = ポインタ注入 | inline = doc 本文を注入
    every: session              # session (既定) = session 内 1 回 | always = 毎回
```

- `inject` 省略時の pointer 既定文面: `この操作の docs: {doc} — 必要なら読む`
- `inline` の文面: `この操作の docs ({id}):` + doc 本文 (`inject` 指定時はその展開結果を先頭行に)
- **`inline` の上限**: doc ファイルが **64KB (65536 バイト)** を超えるルールは本文を注入せず、
  ポインタ形式に落とす (毎回のツール実行で context を大きく圧迫しないための安全弁)。
  文面は 1 行目に `(本文が大きいので場所だけ: <実サイズ> バイト > 上限 <上限> バイト)`、
  続けて pointer と同じ文面 (`inject` があればその展開結果、`inject` が `{doc}` を含まなければ
  さらに既定のポインタ行)。落とした時は stderr に警告を出す。上限は環境変数
  `TOOLHINT_INLINE_MAX` (バイト数、1 以上の整数) で変更できる — 不正な値は既定に倒す。
  ことばきっかけの `inline` にも同じ上限がかかる (落ちる先はことばきっかけ用の既定ポインタ)
- `doc` 未指定で `inject` だけのルール (文面だけ注入する) も可
- `doc` が実在しないルール・正規表現が不正なルールは stderr 警告してスキップ

**ことばきっかけ** (`event: prompt` — ユーザー発言に反応):

```yaml
rules:
  - id: deploy-docs
    event: prompt               # prompt でことばきっかけ。他の値・省略は tool に倒す
    keywords: デプロイ, deploy   # 必須。`,` / `、` / `，` 区切りで複数 — いずれか 1 つで発火
    find: substring             # substring (既定) = 部分一致 | word = 語単位 |
                                # regex = keywords 全体を 1 つの正規表現として扱う (分割しない)
    case: sensitive             # 大小を区別。省略 (既定) は区別しない
    doc: docs/deploy.md         # doc / inject / mode / every は操作きっかけと同じ
```

- `tool` / `match` はことばきっかけでは使わない。`keywords` の無いルールは発火しない
- `inject` 省略時の pointer 既定文面: `この話題の docs: {doc} — 必要なら読む`
- `find: word` の語境界は ASCII (`[A-Za-z0-9_]`) 判定 — 日本語キーワードでも壊れない
- `find` の不正値は substring に、`case` の `sensitive` 以外は大小無視に倒す (fail-open)

**適用範囲 (`scope`)** — 操作きっかけ・ことばきっかけ共通の任意キー:

```yaml
rules:
  - id: monorepo-api-docs
    tool: Bash
    match: \bmigrate\b
    doc: docs/api-migrations.md
    scope: "*/services/api*"    # この場所で作業している間だけ発火
```

- 値は**作業ディレクトリ (hook が受け取る `cwd`) の絶対パスに対する glob パターン**
  (`fnmatch`。`*` は `/` も跨いで任意の文字列に一致する)。上の例なら
  `/home/me/repo/services/api/handlers` で作業している間だけ発火し、他では発火しない。
  絶対パスは必ず `/` 始まりなので、パターンも `/` かワイルドカード (`*` `?` `[`)
  で始めること (大文字小文字は区別する)
- モノレポの一部や特定プロジェクト配下でだけ効かせたいルールに使う。
  `scope` の無いルールは従来どおりどこでも発火する
- 作業ディレクトリが分からないときは発火させない (実行は止めないが、場所が
  不明な以上「場所を限定したルール」は出さない)。パターンが不正でも警告して
  スキップするだけで hook は落ちない
- 置き場所は `rules-scoped.yaml` を推奨 (上記「仕組み」2 — 古い版の engine への
  安全側の分離。CLI/GUI は `scope` の有無で自動的に置き分ける)

YAML は **strict subset の自前パーサ**: `rules:` 直下のリスト + フラットな dict +
スカラ値 (プレーン / 'single' / "double") + コメントのみ対応。
ネスト dict や複数行文字列が来たらその層全体を読み飛ばす (fail-open)。
`[` `{` `|` `>` で始まる値はクォートすること。プレーン値は「空白 + `#`」以降を
行末コメントとして無視する (無視した旨を stderr に警告) ので、リテラル ` #` を
含む値 (正規表現等) も必ずクォートすること。

## 導入方法

```sh
# 経路 A: GitHub から直接 — Claude Code が repo ごと clone する (clone 先は
#   ~/.claude/plugins/marketplaces/toolhint/。private の間は add する側に GitHub 認証が要る)
claude plugin marketplace add AI-Driven-R-D-Dept/toolhint
claude plugin install toolhint@toolhint

# 経路 B: 手元の clone から — repo ルートの marketplace (source: ./engine) を登録して install
claude plugin marketplace add <repo のパス>
claude plugin install toolhint@toolhint
```

install はこの engine を**その時点の版でスナップショットコピー**する
(`~/.claude/plugins/cache/toolhint/toolhint/<version>/`)。repo を更新しても
実 hook は自動で変わらない — engine 更新後は
`claude plugin update toolhint@toolhint` (不可なら uninstall → install) で
差し替えること。古いスナップショットのままだと管理面 (CLI/GUI) と実挙動が
食い違う (`toolhint doctor` が stale を警告する)。

**リリース時の決まり**: engine のコードを変更してリリースする時は
`.claude-plugin/plugin.json` の `version` bump を必ず含める — 同 version のままでは
plugin update が既存インストールを差し替えない。

plugin を使わない場合は `~/.claude/settings.json` (または project の
`.claude/settings.json`) に hook を手動で書く
(`hooks/hooks.json` と同内容 — `command` だけ絶対パスに置き換える。
ことばきっかけも使うなら UserPromptSubmit の配線まで含めること)。
`command` のパスは `hooks/hooks.json` と同じくダブルクォートで囲む (JSON の中なので
`\"` でエスケープ)。囲まないと、パスに空白が含まれるとき shell が別のコマンドと解釈して
hook が無言で動かなくなる:

```json
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "*",
        "hooks": [
          {
            "type": "command",
            "command": "\"/絶対パス/toolhint/engine/scripts/toolhint.py\"",
            "timeout": 5
          }
        ]
      }
    ],
    "UserPromptSubmit": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "\"/絶対パス/toolhint/engine/scripts/toolhint.py\" --event=prompt",
            "timeout": 5
          }
        ]
      }
    ]
  }
}
```

plugin と手動設定の二重配線になっても、claim 機構 (上記「仕組み」4) で注入は 1 回だけ —
操作きっかけは `tool_use_id`、ことばきっかけは session + 発言本文 + ルール id のハッシュ
(10 秒の窓) を鍵にする。

ルール見本の有効化 — samples を global 層にコピー
(この engine ディレクトリで実行。plugin として install した場合の samples は
install 先の plugin ディレクトリ配下にある):

```sh
mkdir -p ~/.claude/toolhint && cp -r samples/. ~/.claude/toolhint/
# ⚠ 既存の ~/.claude/toolhint/ がある場合、rules.yaml や docs/ を無警告で
#   上書きし得る — 運用中なら rules.yaml へ必要ルールだけ追記すること
```

samples はコピーするまで自動では有効化されない見本。project 固有のルールと docs は
`<repo>/.claude/toolhint/rules.yaml` + `docs/` に置く (ルール作成は root README の
CLI `toolhint add` / manager GUI が安全)。

## デバッグ・テスト

以下は engine/ ディレクトリで実行。hook は global 層に `state/` `log/` を書くので、
samples を使い捨ての層にコピーしてから叩く (samples 直下や作業ツリーを汚さない):

```sh
layer=$(mktemp -d) && cp -r samples/. "$layer"

# 手動確認 — 操作きっかけ (samples の search-tools が発火する)
echo '{"session_id":"s1","cwd":"/tmp","tool_name":"Bash","tool_input":{"command":"grep -r foo ."}}' \
  | TOOLHINT_GLOBAL=$layer scripts/toolhint.py

# 手動確認 — ことばきっかけ (samples の deploy-docs が発火する)
echo '{"session_id":"s1","cwd":"/tmp","prompt":"デプロイの手順教えて"}' \
  | TOOLHINT_GLOBAL=$layer scripts/toolhint.py --event=prompt

# テスト (依存ゼロ)
python3 tests/test_toolhint.py

# 例外トレースを見る
TOOLHINT_DEBUG=1 scripts/toolhint.py < payload.json
```
