# npm publish の前チェック

- `npm pack --dry-run` で tarball に入るファイル一覧を確認 (秘密ファイル・テスト・
  ローカル設定が混ざっていないか。`files` フィールドか `.npmignore` で絞る)
- `package.json` の `version` を上げたか (`npm version patch|minor|major`)。同じ
  version は publish できない
- CHANGELOG / README の更新、`npm test` の green を確認
- 初回公開の scoped package は `--access public` が要る。誤公開は 72 時間以内なら
  `npm unpublish` できるが、それ以降は deprecate しかできない
