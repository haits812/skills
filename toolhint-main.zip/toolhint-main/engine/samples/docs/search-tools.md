# 検索は rg / fd を使う

- `grep -r` より `rg` (ripgrep) — 速く、.gitignore を自動で尊重する
- ファイル名検索は `find` より `fd`
- 例: `rg -n "pattern" src/` / `fd -e py toolhint`
- rg が無い環境でだけ grep にフォールバックする
