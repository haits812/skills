# git push --force の前に

- 共有ブランチ (main / develop / 他人が pull 済みのブランチ) への force push は他人の
  履歴を壊す。**自分専用のブランチ以外では原則やらない**
- どうしても要るなら `--force-with-lease` (リモートが自分の知らない間に進んでいたら
  失敗する) を使い、`--force` は最後の手段
- 直前に `git log --oneline origin/<branch>..HEAD` と `git status` で何を上書きするか確認
- 実行したら、同じブランチを持つ人へ `git fetch && git reset --hard origin/<branch>` が
  要ることを伝える
