# pip install は仮想環境の中で

- システムの python に直接 `pip install` しない — 依存が他のプロジェクトと衝突し、
  OS が使う python を壊すことがある (`error: externally-managed-environment` はその警告)
- プロジェクトごとに仮想環境を作って有効化してから入れる:
  `python3 -m venv .venv && source .venv/bin/activate` (Windows は `.venv\Scripts\activate`)
- 入れたら `pip freeze > requirements.txt` (または `pyproject.toml`) に残し、再現できるようにする
- 一時的に試すだけなら `pipx run <tool>` / `uvx <tool>` のような使い捨ての実行でもよい
