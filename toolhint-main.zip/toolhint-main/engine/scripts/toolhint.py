#!/usr/bin/env python3
"""toolhint — 注入エンジン (Claude Code hook).

PreToolUse (既定): ツール実行の直前に stdin の hook payload を受け取り、
rules.yaml のルールにマッチした操作の docs (ポインタ or 本文) を
hookSpecificOutput.additionalContext として注入する。

UserPromptSubmit (argv `--event=prompt`): ユーザー発言 (prompt) に
event: prompt のルール (keywords / find / case) がマッチしたとき、
同じ層・state・ログの仕組みで docs を注入する。

適用範囲 (scope): ルールに scope (作業ディレクトリの glob パターン) があると、
そのパターンに一致する場所で作業しているときだけ発火する。

原則: 実行は絶対に止めない。どんな異常でも exit 0 (fail-open)。
依存: python3 標準ライブラリのみ (PyYAML 不使用 — ミニ YAML パーサ内蔵)。
デバッグ: TOOLHINT_DEBUG=1 で stderr にトレースを出す。
"""

import fnmatch
import hashlib
import json
import os
import re
import signal
import sys
import time

DEBUG = os.environ.get("TOOLHINT_DEBUG") == "1"

DEFAULT_POINTER_TEMPLATE = "この操作の docs: {doc} — 必要なら読む"

DEFAULT_POINTER_TEMPLATE_PROMPT = "この話題の docs: {doc} — 必要なら読む"

LOG_MAX_BYTES = 2 * 1024 * 1024  # injections.jsonl がこれを超えたら先頭半分を捨てる

MATCH_BUDGET_SEC = 0.3  # 1 ルールの正規表現評価の時間予算 (破滅的 backtracking 対策)

INPUT_EXCERPT_MAX = 160  # 注入ログに残す操作原文 (input_excerpt) の最大文字数

STATE_GC_THRESHOLD = 200           # state dir 内のファイル数がこれ以下なら GC しない
STATE_GC_MAX_AGE_SEC = 14 * 86400  # これより古い state/lock/claim を削除する

DEFAULT_INLINE_MAX_BYTES = 64 * 1024  # mode: inline で本文ごと注入する doc の上限 (バイト)
INLINE_MAX_ENV = "TOOLHINT_INLINE_MAX"  # 上限を変える環境変数 (1 以上の整数)
INLINE_FALLBACK_NOTICE = "(本文が大きいので場所だけ: %d バイト > 上限 %d バイト)"

# ことばきっかけの二重配線 dedup: 同じ session × 発言 × ルール集合の claim が
# この秒数以内に既にあれば後着とみなす。それより古い claim は「同じ発言をもう
# 一度送った」ものとして更新し、通常どおり注入する
PROMPT_CLAIM_WINDOW_SEC = 10


def _warn(msg):
    try:
        sys.stderr.write("[toolhint] %s\n" % msg)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# ミニ YAML パーサ (strict subset)
#
# 対応構文:
#   rules:                     ... トップレベルはこのキーのみ
#     - id: value              ... リスト要素はフラットな dict
#       key: value             ... 値はスカラのみ (プレーン / 'single' / "double")
#   # コメント行・行末コメント (クォート外のみ)・空行は無視
#   インデントは 2 スペース基準だが揺れは許容
#
# 構文外の構造 (ネスト dict・複数行文字列・flow collection 等) は
# MiniYamlError — 呼び出し側で層全体を読み飛ばす (fail-open)。
# ---------------------------------------------------------------------------

class MiniYamlError(ValueError):
    pass


_SINGLE_RE = re.compile(r"^'((?:[^']|'')*)'\s*(?:#.*)?$")
_DOUBLE_RE = re.compile(r'^"((?:[^"\\]|\\.)*)"\s*(?:#.*)?$')
_KV_RE = re.compile(r"^([A-Za-z0-9_\-]+):(?:\s+(.*))?$")
_RULES_RE = re.compile(r"^rules:\s*(?:#.*)?$")


def _unescape_double(s):
    """"double" クォート値の最小限の unescape (\\n \\t \\" \\\\)。
    未知のエスケープはそのまま残す (regex を書きやすくするための lenient 仕様)。"""
    out = []
    i = 0
    known = {"n": "\n", "t": "\t", '"': '"', "\\": "\\"}
    while i < len(s):
        c = s[i]
        if c == "\\" and i + 1 < len(s):
            n = s[i + 1]
            out.append(known.get(n, "\\" + n))
            i += 2
        else:
            out.append(c)
            i += 1
    return "".join(out)


def _parse_value(raw, lineno):
    raw = raw.strip()
    if raw.startswith("'"):
        m = _SINGLE_RE.match(raw)
        if not m:
            raise MiniYamlError("line %d: 不正な single quote 値" % lineno)
        return m.group(1).replace("''", "'")
    if raw.startswith('"'):
        m = _DOUBLE_RE.match(raw)
        if not m:
            raise MiniYamlError("line %d: 不正な double quote 値" % lineno)
        return _unescape_double(m.group(1))
    # プレーンスカラ: 行末コメント (空白 + #) を除去。手書きの正規表現が
    # 無警告で壊れないよう、切り落とした事実を stderr に可視化する
    m = re.search(r"\s#", raw)
    if m:
        _warn("line %d: 行末コメントとして %r を無視 — ' #' をリテラルに含む値はクォートすること"
              % (lineno, raw[m.start():]))
        raw = raw[: m.start()].rstrip()
    if raw == "":
        raise MiniYamlError("line %d: 値が空 (ネスト構造?)" % lineno)
    if raw[0] in "|>[{&*":
        raise MiniYamlError("line %d: 構文外の値: %r" % (lineno, raw))
    return raw


def _split_kv(s, lineno):
    m = _KV_RE.match(s)
    if not m:
        raise MiniYamlError("line %d: 'key: value' 形式でない: %r" % (lineno, s))
    if m.group(2) is None or m.group(2).strip() == "":
        raise MiniYamlError(
            "line %d: キー %r の値が空 (ネスト dict は構文外)" % (lineno, m.group(1)))
    return m.group(1), _parse_value(m.group(2), lineno)


def parse_rules_yaml(text):
    """strict subset をパースしてルール dict のリストを返す。構文外は MiniYamlError。"""
    rules = []
    current = None
    seen_rules_key = False
    effective_lines = 0
    for lineno, line in enumerate(text.splitlines(), 1):
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        effective_lines += 1
        indent = len(line) - len(line.lstrip(" \t"))
        if indent == 0:
            if _RULES_RE.match(stripped):
                if seen_rules_key:
                    raise MiniYamlError("line %d: rules: が重複" % lineno)
                seen_rules_key = True
                continue
            raise MiniYamlError("line %d: 構文外のトップレベル行: %r" % (lineno, stripped))
        if not seen_rules_key:
            raise MiniYamlError("line %d: rules: より前にインデント行" % lineno)
        if stripped == "-":
            current = {}
            rules.append(current)
        elif stripped.startswith("- "):
            current = {}
            rules.append(current)
            key, val = _split_kv(stripped[2:].strip(), lineno)
            current[key] = val
        else:
            if current is None:
                raise MiniYamlError("line %d: リスト要素の外に mapping 行" % lineno)
            key, val = _split_kv(stripped, lineno)
            current[key] = val
    if effective_lines == 0:
        return []  # 空ファイル (コメントのみ含む) はルールなし扱い
    if not seen_rules_key:
        raise MiniYamlError("トップレベル rules: キーがない")
    return rules


# ---------------------------------------------------------------------------
# event 判別 (tool rule / prompt rule)
# ---------------------------------------------------------------------------

VALID_FINDS = ("substring", "word", "regex")


def rule_event(rule):
    """ルールの event 種別 ("tool" | "prompt") を返す共通判別関数 (core も import)。
    `event: prompt` のみ prompt rule。キー無し = tool rule (後方互換)、
    `event: tool` も tool rule。それ以外の値は tool に倒す (fail-open)。"""
    v = rule.get("event")
    if v is None:
        return "tool"
    return "prompt" if str(v).strip() == "prompt" else "tool"


def rule_find(rule):
    """prompt rule の find 値を正規化。substring (既定) | word | regex。
    不正値は substring に倒す (fail-open + 警告)。"""
    v = rule.get("find")
    if v is None:
        return "substring"
    v = str(v).strip()
    if v in VALID_FINDS:
        return v
    _warn("ルール %r: find %r は不正 — substring として扱う" % (rule.get("id"), v))
    return "substring"


PROMPT_KEYWORD_SEPARATORS = ",、，"  # 半角カンマ・読点・全角カンマ (U+FF0C)


def split_prompt_keywords(keywords):
    """substring / word の keywords 分割: `,` `、` `，` のいずれも区切りに分割 →
    trim → 空要素を除去 (末尾カンマ・連続カンマで空文字キーワードが生まれ
    「何にでも一致」になる事故を塞ぐ)。全角カンマも区切りにするのは、日本語入力の
    読点が `，` の設定でも keywords が丸ごと 1 語 (= どの発言にも一致しない) に
    ならないようにするため。find=regex では呼ばない (分割しない)。"""
    return [p.strip()
            for p in re.split("[%s]" % PROMPT_KEYWORD_SEPARATORS, str(keywords))
            if p.strip()]


# ---------------------------------------------------------------------------
# 層の発見・ロード・マージ
# ---------------------------------------------------------------------------

def find_global_dir():
    """global 層の dir。環境変数 TOOLHINT_GLOBAL があればそれ、無ければ
    ~/.claude/toolhint。core はこの関数を import して使う (ここ 1 箇所で決める)。"""
    p = os.environ.get("TOOLHINT_GLOBAL")
    if p:
        return os.path.abspath(os.path.expanduser(p))
    return os.path.join(os.path.expanduser("~"), ".claude", "toolhint")


LAYERS_D_DIRNAME = "layers.d"  # グローバル層 dir 直下の「追加層」置き場


def find_extra_layers(global_dir):
    """`<global層>/layers.d/<名前>/` を追加層として名前の辞書順に返す。

    返り値: [(表示名 "layers.d/<名前>", 層 dir), ...]。
    用途は外から配布される共有ルール (誰がどう置くかにはこのツールは関知しない)。
    layers.d が無い・空・読めないときは [] — 既存の 2 層だけの挙動と一致する
    (fail-open)。dotfile/dot dir (.git 等) は層にしない。層 dir が symlink の
    場合は os.path.isdir が解決するので、既存の層と同じ扱いで読む。"""
    if not global_dir:
        return []
    root = os.path.join(global_dir, LAYERS_D_DIRNAME)
    try:
        names = sorted(os.listdir(root))
    except OSError:
        return []
    out = []
    for name in names:
        if name.startswith("."):
            continue
        d = os.path.join(root, name)
        try:
            if not os.path.isdir(d):
                continue
        except OSError:
            continue
        out.append(("%s/%s" % (LAYERS_D_DIRNAME, name), d))
    return out


def _realpath(path):
    try:
        return os.path.realpath(path)
    except OSError:
        return os.path.abspath(path)


def layer_name_map(global_dir, project_dir=None, extras=None):
    """層 dir (realpath) → 表示名 ("global" | "project" | "layers.d/<名前>")。

    注入ログ・dry-run・一覧の層表示はここが唯一の出どころ (core も import)。
    extras は find_extra_layers の結果 — merge_layers と同じ 1 回のスキャンを
    使い回すために渡す (省略時はここで 1 回だけ読む)。"""
    m = {}
    for name, d in (find_extra_layers(global_dir) if extras is None else extras):
        m[_realpath(d)] = name
    if global_dir:
        m[_realpath(global_dir)] = "global"
    if project_dir:
        m[_realpath(project_dir)] = "project"
    return m


def layer_display_name(layer_dir, name_map):
    """層 dir → 表示名。未知の dir は "global" 扱い (従来の既定)。"""
    return name_map.get(_realpath(layer_dir), "global")


def is_extra_layer_name(layer_name):
    """表示名が追加層 (layers.d/<名前>) のものか。"""
    return isinstance(layer_name, str) \
        and layer_name.startswith(LAYERS_D_DIRNAME + "/")


def doc_within_layer(doc_path, layer_dir):
    """doc が層 dir の内側か — 両辺 realpath で判定する。

    追加層 (layers.d) の doc 参照を層内へ閉じるための包含判定。realpath で
    見るので `../` だけでなく層内の symlink 経由の層外参照も塞ぐ。"""
    layer_real = _realpath(layer_dir)
    doc_real = _realpath(doc_path)
    return doc_real == layer_real or doc_real.startswith(layer_real + os.sep)


def find_project_dir(cwd, global_dir):
    """cwd から上方向へ辿り (ホーム or ルートまで)、最初の <dir>/.claude/toolhint。

    解決済み global 層と同一の dir、および既定 global 置き場 (~/.claude/toolhint)
    は project 層候補から除外する — TOOLHINT_GLOBAL で隔離した環境でも、
    home 配下の cwd からの walk-up が本来の global 置き場を project 層として
    誤認しないため (隔離テスト・GUI の層表示の誤読を防ぐ)。"""
    if not cwd:
        return None
    d = os.path.abspath(os.path.expanduser(cwd))
    home = os.path.expanduser("~")
    excluded = {
        os.path.realpath(global_dir),
        os.path.realpath(os.path.join(home, ".claude", "toolhint")),
    }
    try:  # HOME を差し替えたテスト環境でも、OS アカウント本来の home の既定置き場は除外
        import pwd
        account_home = pwd.getpwuid(os.getuid()).pw_dir
        if account_home:
            excluded.add(os.path.realpath(
                os.path.join(account_home, ".claude", "toolhint")))
    except Exception:
        pass  # 非 Unix 等 pwd が無い環境は HOME ベースの除外のみ
    while True:
        cand = os.path.join(d, ".claude", "toolhint")
        if os.path.isdir(cand) and os.path.realpath(cand) not in excluded:
            return cand
        if d == home:
            return None
        parent = os.path.dirname(d)
        if parent == d:  # ルート到達
            return None
        d = parent


RULES_FILENAME = "rules.yaml"
SCOPED_RULES_FILENAME = "rules-scoped.yaml"
# 層のルールファイル (この順に読む)。同 id が両方にあれば後 (scoped) が勝つ。
RULES_FILENAMES = (RULES_FILENAME, SCOPED_RULES_FILENAME)


def _check_rule_keys(rule, index, path):
    """load 時の必須キー検証 (ここが core cmd_list / docs / dry-run 含む唯一の
    入口)。読めるルールなら True、engine が読み飛ばすものは警告して False。"""
    if not rule.get("id"):
        _warn("%s: ルール #%d に id がない — スキップ" % (path, index + 1))
        return False
    # 必須キーは event 別
    if rule_event(rule) == "prompt":
        if not rule.get("keywords"):
            _warn("%s: ルール %r に keywords がない — スキップ"
                  % (path, rule.get("id")))
            return False
        if rule_find(rule) != "regex" \
                and not split_prompt_keywords(rule["keywords"]):
            _warn("%s: ルール %r の keywords に有効な要素がない (区切りのみ) — スキップ"
                  % (path, rule.get("id")))
            return False
    elif not rule.get("tool"):
        _warn("%s: ルール %r に tool がない — スキップ" % (path, rule.get("id")))
        return False
    return True


def load_rules(layer_dir):
    """層のルールファイル (rules.yaml → rules-scoped.yaml) を読む。

    rules-scoped.yaml は「適用範囲 (scope) 付きルールの置き場」として分けた
    2 本目のファイル。書式も扱いも rules.yaml と全く同じで、scope キー自体は
    どちらのファイルにあっても効く。分けてある理由は 1 つ — この形式を知らない
    古い版の engine は rules.yaml しか読まないので、そこに scope 付きルールを
    置かない限り「適用範囲を無視してどこでも発火する」事故が構造的に起きない。

    どちらかがパース不能なら、その層全体を警告付きで読み飛ばす
    (fail-open — rules.yaml 1 本だった頃と同じ層単位の握り方)。"""
    out = []
    for name in RULES_FILENAMES:
        path = os.path.join(layer_dir, name)
        if not os.path.isfile(path):
            continue
        try:
            with open(path, "r", encoding="utf-8") as f:
                text = f.read()
            parsed = parse_rules_yaml(text)
        except Exception as e:
            _warn("層を読み飛ばし %s: %s" % (path, e))
            return []
        out += [r for i, r in enumerate(parsed) if _check_rule_keys(r, i, path)]
    return out


def merge_layers(global_dir, project_dir, extras=None):
    """layers.d/* (名前の辞書順) → global → project の順に読み、同 id は後勝ち
    (= より手元の層が勝つ)。返り値: {id: (rule, layer_dir)} (挿入順保持)。
    各層の読みは load_rules (rules.yaml → rules-scoped.yaml) が担う。

    enabled: false の判定はマージの後 (rule_matches / rule_matches_prompt) —
    手元の層 (global / project) に同 id で `enabled: false` のルールを置けば、
    追加層のルールをそのマシン / プロジェクトだけ止められる。
    extras は find_extra_layers の結果 — 層名の解決 (layer_name_map) と
    スキャンを 1 回で共有するために渡す (省略時はここで 1 回だけ読む)。"""
    merged = {}
    layers = [d for _name, d in
              (find_extra_layers(global_dir) if extras is None else extras)]
    layers += [global_dir, project_dir]
    for layer in layers:
        if not layer:
            continue
        for r in load_rules(layer):
            merged[r["id"]] = (r, layer)
    return merged


# ---------------------------------------------------------------------------
# マッチ判定
# ---------------------------------------------------------------------------

def flatten_tool_input(tool_input):
    return json.dumps(tool_input, ensure_ascii=False)


class _MatchTimeout(Exception):
    pass


def _raise_match_timeout(signum, frame):
    raise _MatchTimeout()


def _budget_start():
    """SIGALRM でルール単位の時間予算を開始。
    使えない環境 (非 Unix / 非 main thread) では None を返し予算なしで続行。"""
    try:
        if not hasattr(signal, "setitimer") or not hasattr(signal, "SIGALRM"):
            return None
        old = signal.signal(signal.SIGALRM, _raise_match_timeout)
        signal.setitimer(signal.ITIMER_REAL, MATCH_BUDGET_SEC)
        return old
    except Exception:
        return None


def _budget_end(old):
    if old is None:
        return
    try:
        signal.setitimer(signal.ITIMER_REAL, 0)
        signal.signal(signal.SIGALRM, old)
    except Exception:
        pass


def rule_enabled(rule):
    """enabled: false のルールは注入対象外 (rule_matches が False を返す)。
    キー無し・その他の値は enabled 扱い (後方互換 — 既存の rules.yaml は全て有効)。
    ミニ YAML の値は常に文字列なので文字列比較。"""
    v = rule.get("enabled")
    if v is None:
        return True
    return str(v).strip().lower() != "false"


def rule_in_scope(rule, cwd):
    """ルールの適用範囲 (scope) の判定 — 操作きっかけ / ことばきっかけ共通。

    scope は作業ディレクトリ (hook が受け取る cwd) の絶対パスに対する glob
    パターン (fnmatch。`*` は `/` も跨いで任意の文字列に一致する)。
    例: `scope: "*/myproject*"` は /home/me/myproject/sub で作業している間だけ
    発火し、他の場所では発火しない — モノレポの一部や特定プロジェクト配下
    だけに効かせたいルールのためのキー。

    - scope キーが無いルールは常に True (どこでも発火 = 従来の挙動)
    - cwd が取れないときは False — 実行は止めないが、場所が分からない以上
      「場所を限定したルール」は出さない
    - パターン不正等で例外が出ても False (hook 全体を殺さない)。評価には
      match と同じ MATCH_BUDGET_SEC の時間予算をかける"""
    scope = rule.get("scope")
    if scope is None:
        return True
    if not cwd:
        _warn("ルール %r: scope 付きだが作業ディレクトリが不明 — スキップ"
              % rule.get("id"))
        return False
    old = _budget_start()
    try:
        return fnmatch.fnmatch(os.path.abspath(os.path.expanduser(cwd)),
                               str(scope))
    except _MatchTimeout:
        _warn("ルール %r: scope の評価が時間予算 %.2fs を超過 — スキップ"
              % (rule.get("id"), MATCH_BUDGET_SEC))
        return False
    except Exception as e:
        _warn("ルール %r: scope %r の判定に失敗 (%s) — スキップ"
              % (rule.get("id"), scope, e))
        return False
    finally:
        _budget_end(old)


def rule_matches(rule, tool_name, flat, cwd=None):
    """tool は tool_name への完全一致 (fullmatch — `Bash` は `BashOutput` に
    発火しない)、match は flat への部分一致 (search)。
    enabled: false のルールは常に不一致 (管理面の disable を尊重)。
    scope 付きのルールは cwd が適用範囲に入るときだけ一致 (rule_in_scope)。
    1 ルールの評価には MATCH_BUDGET_SEC の時間予算をかけ、破滅的
    backtracking するルールはスキップして残りのルールと hook 全体を守る。"""
    if not rule_enabled(rule):
        return False
    if not rule_in_scope(rule, cwd):
        return False
    tool_pat = rule.get("tool")
    if not tool_pat:
        return False  # tool キー欠落 (prompt rule 等) — tool 経路では常に不一致
    old = _budget_start()
    try:
        if not re.fullmatch(tool_pat, tool_name):
            return False
        pat = rule.get("match")
        if pat is not None and not re.search(pat, flat):
            return False
        return True
    except re.error as e:
        _warn("ルール %r: 不正な正規表現 (%s) — スキップ" % (rule.get("id"), e))
        return False
    except _MatchTimeout:
        _warn("ルール %r: 正規表現の評価が時間予算 %.2fs を超過 (破滅的 backtracking?) — スキップ"
              % (rule.get("id"), MATCH_BUDGET_SEC))
        return False
    finally:
        _budget_end(old)


def rule_matches_prompt(rule, prompt, cwd=None):
    """prompt rule がユーザー発言 prompt にマッチするか。

    - find=substring: keywords を分割し、いずれかを部分一致 (既定は大小無視 —
      .lower() 比較 (JS の toLowerCase 相当)。casefold は使わない)
    - find=word: 分割した各語を ASCII 境界 (?<![A-Za-z0-9_])kw(?![A-Za-z0-9_])
      で検索 (日本語キーワードでも壊れない)。既定 IGNORECASE
    - find=regex: keywords 全体が 1 つの正規表現 (分割しない)
    - case: sensitive で大小区別。それ以外の値は既定 (区別しない) に倒す
    - scope 付きのルールは cwd が適用範囲に入るときだけ一致 (rule_in_scope)
    - 予算は 1 ルール毎に MATCH_BUDGET_SEC (rule_matches と同粒度)。
      re.error / timeout は警告スキップ (fail-open)"""
    if not rule_enabled(rule):
        return False
    if not rule_in_scope(rule, cwd):
        return False
    if not isinstance(prompt, str) or prompt == "":
        return False
    keywords = rule.get("keywords")
    if not keywords:
        return False
    find = rule_find(rule)
    case_sensitive = str(rule.get("case") or "").strip() == "sensitive"
    old = _budget_start()
    try:
        if find == "regex":
            flags = 0 if case_sensitive else re.IGNORECASE
            return re.search(keywords, prompt, flags) is not None
        kws = split_prompt_keywords(keywords)
        if not kws:
            _warn("ルール %r: keywords に有効な要素がない (区切りのみ) — スキップ"
                  % rule.get("id"))
            return False
        if find == "word":
            flags = 0 if case_sensitive else re.IGNORECASE
            for kw in kws:
                if re.search(r"(?<![A-Za-z0-9_])%s(?![A-Za-z0-9_])" % re.escape(kw),
                             prompt, flags):
                    return True
            return False
        # substring (既定)
        hay = prompt if case_sensitive else prompt.lower()
        for kw in kws:
            if (kw if case_sensitive else kw.lower()) in hay:
                return True
        return False
    except re.error as e:
        _warn("ルール %r: 不正な正規表現 (%s) — スキップ" % (rule.get("id"), e))
        return False
    except _MatchTimeout:
        _warn("ルール %r: 正規表現の評価が時間予算 %.2fs を超過 (破滅的 backtracking?) — スキップ"
              % (rule.get("id"), MATCH_BUDGET_SEC))
        return False
    finally:
        _budget_end(old)


# ---------------------------------------------------------------------------
# session 状態 (every=session の重複抑制)
# ---------------------------------------------------------------------------

def state_path(global_dir, session_id, agent_id=None):
    """every=session の state ファイル。session × context (main / 各 subagent の
    agent_id) 単位でキーする — subagent は fresh context なので親で表示済みの
    docs も別カウントで注入する。"""
    key = session_id or "unknown"
    if agent_id:
        key = "%s__%s" % (key, agent_id)
    sid = re.sub(r"[^A-Za-z0-9._\-]", "_", key) or "unknown"
    return os.path.join(global_dir, "state", sid + ".json")


def load_shown(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        shown = data.get("shown")
        return list(shown) if isinstance(shown, list) else []
    except Exception:
        return []


def save_shown(path, shown):
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump({"shown": shown}, f, ensure_ascii=False)
    except Exception:
        pass  # 書き込み失敗は無視 (fail-open)


def _lock_state(spath):
    """<spath>.lock による排他 flock — state / 注入ログの read-modify-write を
    直列化する (並列 tool call・hook プロセスの race 対策)。
    返り値は解放用 fd。取得できない環境・失敗時は None (ロックなしで続行 = fail-open)。"""
    try:
        import fcntl
        os.makedirs(os.path.dirname(spath), exist_ok=True)
        fd = os.open(spath + ".lock", os.O_CREAT | os.O_RDWR)
        try:
            fcntl.flock(fd, fcntl.LOCK_EX)
        except Exception:
            os.close(fd)
            return None
        return fd
    except Exception:
        return None


def _unlock_state(fd):
    if fd is None:
        return
    try:
        os.close(fd)  # close で flock も解放される
    except Exception:
        pass


def claim_tool_use(global_dir, tool_use_id):
    """同一 tool_use_id の注入を最初の 1 hook プロセスに限定する (二重配線 dedup)。
    O_CREAT|O_EXCL で claim ファイルを先取りできたら True。
    tool_use_id 不明・claim 失敗 (異常系) は True (fail-open で通常処理)。"""
    if not tool_use_id:
        return True
    try:
        claims_dir = os.path.join(global_dir, "state", "claims")
        os.makedirs(claims_dir, exist_ok=True)
        name = re.sub(r"[^A-Za-z0-9._\-]", "_", tool_use_id) or "unknown"
        fd = os.open(os.path.join(claims_dir, name + ".claim"),
                     os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.close(fd)
        return True
    except FileExistsError:
        return False
    except Exception:
        return True


def prompt_claim_key(session_id, agent_id, prompt, rule_ids):
    """ことばきっかけの claim 鍵 — session × context (agent_id) × 発言本文 ×
    マッチしたルール id 集合の SHA-256 (先頭 32 桁)。二重配線された hook
    プロセスは同じ payload と同じ層を読むので、同じ鍵に到達する。"""
    parts = [session_id or "unknown", agent_id or "", prompt or ""]
    parts += sorted(str(r) for r in (rule_ids or []))
    h = hashlib.sha256("\0".join(parts).encode("utf-8", "surrogatepass"))
    return h.hexdigest()[:32]


def claim_prompt(global_dir, session_id, agent_id, prompt, rule_ids):
    """ことばきっかけの注入を最初の 1 hook プロセスに限定する (二重配線 dedup)。

    UserPromptSubmit の payload には tool_use_id のような一意な id が無いので、
    prompt_claim_key を鍵に state/claims/prompt-<鍵>.claim を O_CREAT|O_EXCL で
    先取りする。先取りできたら True。既に claim があっても、その mtime が
    PROMPT_CLAIM_WINDOW_SEC より古ければ「同じ発言をもう一度送った」ものとして
    mtime を更新し True (every: always のルールは再注入される)。窓の内側なら
    後着プロセスなので False。呼び出し側は state の flock 下で呼ぶ (更新判定が
    直列化される)。異常系は True (fail-open で通常処理)。"""
    try:
        claims_dir = os.path.join(global_dir, "state", "claims")
        os.makedirs(claims_dir, exist_ok=True)
        key = prompt_claim_key(session_id, agent_id, prompt, rule_ids)
        path = os.path.join(claims_dir, "prompt-" + key + ".claim")
        try:
            fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            os.close(fd)
            return True
        except FileExistsError:
            pass
        try:
            age = time.time() - os.path.getmtime(path)
        except OSError:
            return True  # 見た直後に消えた等 — 通常処理
        if age > PROMPT_CLAIM_WINDOW_SEC:
            try:
                os.utime(path, None)  # 窓を張り直す
            except OSError:
                pass
            return True
        return False
    except Exception:
        return True


def gc_state(global_dir):
    """state/ (per-context JSON・.lock) と state/claims/ の best-effort GC。

    注入が実際に起きた呼び出しの後でのみ実行され (散発)、ファイル数が
    STATE_GC_THRESHOLD を超えた dir だけを対象に mtime が 14 日超のファイルを
    削除する。完全 fail-open — 失敗しても本処理に影響しない。"""
    try:
        now = time.time()
        state_dir = os.path.join(global_dir, "state")
        for d in (state_dir, os.path.join(state_dir, "claims")):
            try:
                names = os.listdir(d)
            except OSError:
                continue
            if len(names) <= STATE_GC_THRESHOLD:
                continue
            for name in names:
                p = os.path.join(d, name)
                try:
                    if (os.path.isfile(p)
                            and now - os.path.getmtime(p) > STATE_GC_MAX_AGE_SEC):
                        os.remove(p)
                except OSError:
                    pass
    except Exception:
        pass


# ---------------------------------------------------------------------------
# 注入文面の生成
# ---------------------------------------------------------------------------

_inline_max_cache = {}


def inline_max_bytes():
    """mode: inline で本文ごと注入する doc の上限 (バイト)。環境変数
    TOOLHINT_INLINE_MAX (1 以上の整数) があればそれ、無い・不正なら既定
    DEFAULT_INLINE_MAX_BYTES。上限はここ 1 箇所で決める (core も import 可)。"""
    raw = os.environ.get(INLINE_MAX_ENV)
    if raw is None or raw.strip() == "":
        return DEFAULT_INLINE_MAX_BYTES
    if raw in _inline_max_cache:
        return _inline_max_cache[raw]
    try:
        v = int(raw.strip())
        if v < 1:
            raise ValueError(raw)
    except ValueError:
        _warn("%s=%r は 1 以上の整数でない — 既定 %d バイトを使う"
              % (INLINE_MAX_ENV, raw, DEFAULT_INLINE_MAX_BYTES))
        v = DEFAULT_INLINE_MAX_BYTES
    _inline_max_cache[raw] = v
    return v


def build_text(rule, layer_dir, restrict_doc=False):
    """1 ルール分の注入文面。発火できないルールは警告して None。

    文面は event 別 (tool 側は従来と 1 字も変えない):
    - tool inline はヘッダ「この操作の docs (id):」付き / prompt inline は
      ヘッダ無しで本文そのまま (発言に返す文面はそのまま届ける)
    - 既定ポインタは tool =「この操作の docs: …」/ prompt =「この話題の docs: …」
    - inline の doc が上限 (inline_max_bytes) を超えるときは本文を注入せず、
      1 行目に INLINE_FALLBACK_NOTICE を添えたポインタ形式に落とす (stderr 警告)

    restrict_doc=True (追加層 layers.d のルール) では doc が層 dir の内側かを
    realpath で検査し、外を指すルールは注入しない — 配られた層が `../` や
    symlink で層外の任意ファイルを本文注入 (inline) / ポインタ提示 (pointer)
    できないようにする。手元の層 (global / project) は従来どおり検査しない
    (既存の層をまたぐ参照を壊さない。検査面は doctor が持つ)。"""
    rid = rule.get("id", "")
    doc = rule.get("doc")
    inject = rule.get("inject")
    mode = rule.get("mode", "pointer")
    is_prompt = rule_event(rule) == "prompt"

    doc_path = None
    if doc:
        doc_path = os.path.abspath(os.path.join(layer_dir, doc))
        if restrict_doc and not doc_within_layer(doc_path, layer_dir):
            _warn("ルール %r: doc が層の外を指す: %s — スキップ "
                  "(追加層のルールが参照できるのは層 dir 配下の doc だけ)"
                  % (rid, doc_path))
            return None
        if not os.path.isfile(doc_path):
            _warn("ルール %r: doc が実在しない: %s — スキップ" % (rid, doc_path))
            return None

    def expand(tpl):
        return tpl.replace("{doc}", doc_path or "").replace("{id}", rid)

    def default_pointer():
        return expand(DEFAULT_POINTER_TEMPLATE_PROMPT if is_prompt
                      else DEFAULT_POINTER_TEMPLATE)

    if mode == "inline":
        if doc_path:
            limit = inline_max_bytes()
            try:
                size = os.path.getsize(doc_path)
            except OSError as e:
                _warn("ルール %r: doc を読めない (%s) — スキップ" % (rid, e))
                return None
            if size > limit:
                # 上限超過: 本文は注入せず、通知 1 行 + ポインタ形式に落とす
                _warn("ルール %r: inline の doc が上限を超える (%d バイト > %d バイト) "
                      "— 本文は注入せず場所だけ示す: %s (上限は環境変数 %s で変更可)"
                      % (rid, size, limit, doc_path, INLINE_MAX_ENV))
                lines = [INLINE_FALLBACK_NOTICE % (size, limit)]
                if inject:
                    lines.append(expand(inject))
                if not (inject and "{doc}" in inject):
                    lines.append(default_pointer())
                return "\n".join(lines)
            try:
                with open(doc_path, "r", encoding="utf-8") as f:
                    body = f.read().rstrip("\n")
            except Exception as e:
                _warn("ルール %r: doc を読めない (%s) — スキップ" % (rid, e))
                return None
            if is_prompt:
                text = body  # ヘッダ無し (本文そのまま)
            else:
                text = "この操作の docs (%s):\n%s" % (rid, body)
            if inject:
                text = expand(inject) + "\n" + text
            return text
        if inject and "{doc}" not in inject:
            return expand(inject)  # 文面だけのルール
        _warn("ルール %r: inline なのに doc がない — スキップ" % rid)
        return None

    # pointer (既定)
    if inject:
        if "{doc}" in inject and not doc_path:
            _warn("ルール %r: inject が {doc} を参照するが doc がない — スキップ" % rid)
            return None
        return expand(inject)
    if not doc_path:
        _warn("ルール %r: doc も inject もない — スキップ" % rid)
        return None
    return default_pointer()


# ---------------------------------------------------------------------------
# 注入ログ (<global層>/log/injections.jsonl)
#
# 管理面 (core/manager) が「最近の注入」「7 日集計」を読むための JSONL。
# 完全 fail-open — 書けなくても本処理 (マッチ・注入・state 抑制) に影響ゼロ。
# ---------------------------------------------------------------------------

def _rotate_log(path):
    """LOG_MAX_BYTES 超過なら先頭半分を捨てる (行境界に合わせる)。best-effort。

    書き戻しは同一 dir の tmp → fsync → os.replace の原子的置換 — 読み手
    (core の log / docs 集計) が途中状態のファイルを見ることはない。
    tmp 名は pid 付き (並行 hook と衝突しない)。"""
    tmp = "%s.rot.%d.tmp" % (path, os.getpid())
    try:
        if os.path.getsize(path) <= LOG_MAX_BYTES:
            return
        with open(path, "rb") as f:
            data = f.read()
        half = data[len(data) // 2:]
        nl = half.find(b"\n")
        if nl >= 0:
            half = half[nl + 1:]
        with open(tmp, "wb") as f:
            f.write(half)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    except Exception:
        try:
            os.remove(tmp)  # 失敗時の tmp 残骸を掃除 (未作成なら黙って抜ける)
        except Exception:
            pass


def make_input_excerpt(tool_input, flat):
    """ログ用の操作原文 — tool_input.command があればそれ、無ければ flat の先頭。"""
    cmd = tool_input.get("command") if isinstance(tool_input, dict) else None
    src = cmd if isinstance(cmd, str) and cmd else flat
    return src[:INPUT_EXCERPT_MAX]


def log_injections(global_dir, session_id, cwd, tool_name, injected,
                   input_excerpt=None, tool_use_id=None):
    """注入を実際に行ったルールを 1 ルール 1 行で append する。

    injected: [(rule_id, layer_name, doc_abs_or_None, mode, every), ...]
    どんな失敗も無視 (fail-open)。ログ dir は無ければ作る。
    """
    if not injected:
        return
    try:
        log_dir = os.path.join(global_dir, "log")
        os.makedirs(log_dir, exist_ok=True)
        path = os.path.join(log_dir, "injections.jsonl")
        ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        lines = []
        for rid, layer_name, doc_abs, mode, every in injected:
            lines.append(json.dumps(
                {"ts": ts, "session_id": session_id, "cwd": cwd,
                 "tool_name": tool_name, "rule_id": rid,
                 "layer": layer_name, "doc": doc_abs,
                 "mode": mode, "every": every,
                 "input_excerpt": input_excerpt, "tool_use_id": tool_use_id},
                ensure_ascii=False))
        # rotate + append を flock で括る — ローテーション中の他プロセスの追記が
        # 置換で消える窓と二重ローテーションを塞ぐ (取得失敗時はロックなし続行)
        lock_fd = _lock_state(path)
        try:
            _rotate_log(path)
            with open(path, "a", encoding="utf-8") as f:
                f.write("".join(line + "\n" for line in lines))
        finally:
            _unlock_state(lock_fd)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------

def main():
    # hooks.json の配線: PreToolUse は引数なし / UserPromptSubmit は --event=prompt
    event = "prompt" if "--event=prompt" in sys.argv[1:] else "tool"
    data = json.loads(sys.stdin.read())
    session_id = data.get("session_id") or "unknown"
    agent_id = data.get("agent_id") or ""  # subagent の fresh context 識別 (無ければ main)
    cwd = data.get("cwd") or ""
    tool_use_id = ""
    if event == "prompt":
        prompt = data.get("prompt")
        if not isinstance(prompt, str) or prompt == "":
            return
    else:
        tool_name = data.get("tool_name") or ""
        tool_input = data.get("tool_input")
        if tool_input is None:
            tool_input = {}
        flat = flatten_tool_input(tool_input)
        tool_use_id = data.get("tool_use_id") or ""

    global_dir = find_global_dir()
    project_dir = find_project_dir(cwd, global_dir)
    extras = find_extra_layers(global_dir)  # 層スキャンは 1 回 (merge と層名で共有)
    merged = merge_layers(global_dir, project_dir, extras)
    if not merged:
        return

    if event == "prompt":
        matched = [(rid, rule, layer) for rid, (rule, layer) in merged.items()
                   if rule_event(rule) == "prompt"
                   and rule_matches_prompt(rule, prompt, cwd)]
        hook_event_name = "UserPromptSubmit"
        tool_name = "prompt"  # ログ上の識別子 (発言きっかけ)
        input_excerpt = prompt[:INPUT_EXCERPT_MAX]
    else:
        matched = [(rid, rule, layer) for rid, (rule, layer) in merged.items()
                   if rule_event(rule) == "tool"
                   and rule_matches(rule, tool_name, flat, cwd)]
        hook_event_name = "PreToolUse"
        input_excerpt = make_input_excerpt(tool_input, flat)
    if not matched:
        return

    spath = state_path(global_dir, session_id, agent_id)
    # 層名は「ログの層表示」と「追加層かどうか (doc の層内制限)」の両方に使う
    layer_names = layer_name_map(global_dir, project_dir, extras)
    entries = []
    injected = []
    lock_fd = _lock_state(spath)  # 並列 tool call 間の read-modify-write を直列化
    try:
        shown = load_shown(spath)
        newly = []
        seen_texts = set()
        for rid, rule, layer in matched:
            every = rule.get("every", "session")
            if every != "always" and rid in shown:
                continue  # この context (session × agent) で既出
            layer_name = layer_display_name(layer, layer_names)
            # 追加層のルールは層 dir 配下の doc しか参照できない (層外注入の防止)
            text = build_text(rule, layer,
                              restrict_doc=is_extra_layer_name(layer_name))
            if text is None:
                continue
            if every != "always":
                newly.append(rid)
            if text in seen_texts:
                continue  # 別ルールでも同一文面 (同一 doc の既定ポインタ等) は 1 回に併合
            seen_texts.add(text)
            entries.append("[toolhint] " + text)
            doc = rule.get("doc")
            doc_abs = os.path.abspath(os.path.join(layer, doc)) if doc else None
            injected.append((rid, layer_name,
                             doc_abs, rule.get("mode", "pointer"), every))
        # claim (二重配線 dedup) — tool 経路は payload の tool_use_id、prompt 経路は
        # session × 発言本文 × マッチしたルール id 集合の鍵で先取りする
        if entries:
            if event == "prompt":
                claimed = claim_prompt(global_dir, session_id, agent_id, prompt,
                                       [rid for rid, _rule, _layer in matched])
            else:
                claimed = claim_tool_use(global_dir, tool_use_id)
        else:
            claimed = True
        if not claimed:
            entries = []  # 二重配線の後着プロセス — 注入も state 更新もしない
        elif entries and newly:
            save_shown(spath, shown + newly)
    finally:
        _unlock_state(lock_fd)

    if not entries:
        return
    out = {
        "hookSpecificOutput": {
            "hookEventName": hook_event_name,
            "additionalContext": "\n".join(entries),
        }
    }
    sys.stdout.write(json.dumps(out, ensure_ascii=False) + "\n")
    log_injections(global_dir, session_id, cwd, tool_name, injected,
                   input_excerpt=input_excerpt,
                   tool_use_id=tool_use_id or None)
    gc_state(global_dir)


if __name__ == "__main__":
    try:
        main()
    except Exception:
        if DEBUG:
            import traceback
            traceback.print_exc()
    sys.exit(0)
