#!/usr/bin/env python3
"""toolhint エンジンのテスト。

- 依存ゼロ (python3 標準ライブラリのみ)、assert ベース
- `python3 tests/test_toolhint.py` 一発で全件実行し PASS/FAIL 集計を出力
- 方式: ミニ YAML パーサ等は関数 import、hook 全体の挙動は subprocess
  (一時ディレクトリに層を作り TOOLHINT_GLOBAL で注入)
"""

import contextlib
import importlib.util
import io
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time

TESTS_DIR = os.path.dirname(os.path.abspath(__file__))
ENGINE_DIR = os.path.dirname(TESTS_DIR)
SCRIPT = os.path.join(ENGINE_DIR, "scripts", "toolhint.py")
SAMPLES_DIR = os.path.join(ENGINE_DIR, "samples")

_spec = importlib.util.spec_from_file_location("toolhint", SCRIPT)
toolhint = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(toolhint)


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def run_hook(payload=None, global_dir=None, raw=None, env_extra=None, args=()):
    env = os.environ.copy()
    env["TOOLHINT_GLOBAL"] = global_dir
    env.pop("TOOLHINT_DEBUG", None)
    env.update(env_extra or {})
    data = raw if raw is not None else json.dumps(payload, ensure_ascii=False)
    return subprocess.run(
        [sys.executable, SCRIPT] + list(args), input=data,
        capture_output=True, text=True, env=env, timeout=30)


def run_prompt_hook(payload=None, global_dir=None, raw=None):
    """UserPromptSubmit 側の配線 (hooks.json の --event=prompt) で hook を起動。"""
    return run_hook(payload, global_dir, raw=raw, args=("--event=prompt",))


def make_layer(root, rules_text, docs=None):
    os.makedirs(root, exist_ok=True)
    with open(os.path.join(root, "rules.yaml"), "w", encoding="utf-8") as f:
        f.write(rules_text)
    for rel, body in (docs or {}).items():
        p = os.path.join(root, rel)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, "w", encoding="utf-8") as f:
            f.write(body)


def payload(command="echo hi", session="s-test", cwd="/tmp", tool="Bash",
            agent_id=None, tool_use_id=None):
    p = {"session_id": session, "cwd": cwd, "tool_name": tool,
         "tool_input": {"command": command}, "hook_event_name": "PreToolUse"}
    if agent_id:
        p["agent_id"] = agent_id
    if tool_use_id:
        p["tool_use_id"] = tool_use_id
    return p


def prompt_payload(prompt="hello", session="s-test", cwd="/tmp", agent_id=None):
    p = {"session_id": session, "cwd": cwd, "prompt": prompt,
         "hook_event_name": "UserPromptSubmit"}
    if agent_id:
        p["agent_id"] = agent_id
    return p


def prompt_claim_files(global_dir):
    """state/claims/ にあることばきっかけの claim ファイル名 (ソート済み)。"""
    d = os.path.join(global_dir, "state", "claims")
    if not os.path.isdir(d):
        return []
    return sorted(n for n in os.listdir(d) if n.startswith("prompt-"))


def age_prompt_claims(global_dir, seconds):
    """ことばきっかけの claim を seconds 秒だけ古く見せる (時間経過の代わり)。"""
    d = os.path.join(global_dir, "state", "claims")
    old = time.time() - seconds
    for n in prompt_claim_files(global_dir):
        os.utime(os.path.join(d, n), (old, old))


def get_context(p, event="PreToolUse"):
    """exit 0 を検証しつつ additionalContext を返す (出力なしなら None)。"""
    assert p.returncode == 0, "exit=%d stderr=%s" % (p.returncode, p.stderr)
    if not p.stdout.strip():
        return None
    lines = p.stdout.strip().splitlines()
    assert len(lines) == 1, "stdout は 1 行 JSON のはず: %r" % p.stdout
    out = json.loads(lines[0])
    hso = out["hookSpecificOutput"]
    assert hso["hookEventName"] == event, hso
    return hso["additionalContext"]


# ---------------------------------------------------------------------------
# ミニ YAML パーサ
# ---------------------------------------------------------------------------

def test_yaml_parser_normal():
    text = (
        "# leading comment\n"
        "\n"
        "rules:\n"
        "  # comment line\n"
        "  - id: a\n"
        "    tool: Bash\n"
        "    match: 'single quoted'  # trailing comment\n"
        "\n"
        "  - id: b\n"
        '    tool: "Ba\\"sh"\n'
        "    doc: docs/x.md\n"
        "  - id: c\n"
        "    tool: Bash\n"
        "    match: plain # comment\n"
        "    inject: \"line1\\nline2\"\n"
    )
    rules = toolhint.parse_rules_yaml(text)
    assert len(rules) == 3, rules
    assert rules[0] == {"id": "a", "tool": "Bash", "match": "single quoted"}
    assert rules[1]["tool"] == 'Ba"sh'
    assert rules[1]["doc"] == "docs/x.md"
    assert rules[2]["match"] == "plain"
    assert rules[2]["inject"] == "line1\nline2"
    # プレーン値の途中の # (空白なし) はコメントにならない
    rules2 = toolhint.parse_rules_yaml(
        "rules:\n  - id: h\n    tool: Bash\n    match: foo#bar\n")
    assert rules2[0]["match"] == "foo#bar"


def test_yaml_parser_nested_error():
    text = "rules:\n  - id: a\n    tool: Bash\n    meta:\n      x: y\n"
    try:
        toolhint.parse_rules_yaml(text)
        assert False, "ネスト dict は MiniYamlError のはず"
    except toolhint.MiniYamlError:
        pass


def test_yaml_plain_trailing_comment_warns():
    # プレーン値の行末コメント切断は挙動維持のまま stderr に可視化する
    err = io.StringIO()
    with contextlib.redirect_stderr(err):
        rules = toolhint.parse_rules_yaml(
            "rules:\n  - id: a\n    tool: Bash\n    match: foo #bar\n")
    assert rules[0]["match"] == "foo"
    assert "行末コメント" in err.getvalue(), err.getvalue()
    # クォート値は切断も警告もなし
    err2 = io.StringIO()
    with contextlib.redirect_stderr(err2):
        rules2 = toolhint.parse_rules_yaml(
            "rules:\n  - id: a\n    tool: Bash\n    match: \"foo #bar\"\n")
    assert rules2[0]["match"] == "foo #bar"
    assert "行末コメント" not in err2.getvalue()


def test_load_rules_broken_layer_skipped():
    with tempfile.TemporaryDirectory() as td:
        make_layer(td, "rules:\n  - id: a\n    tool: Bash\n    nested:\n      x: 1\n")
        err = io.StringIO()
        with contextlib.redirect_stderr(err):
            rules = toolhint.load_rules(td)
        assert rules == []
        assert "読み飛ばし" in err.getvalue()


# ---------------------------------------------------------------------------
# マッチ判定
# ---------------------------------------------------------------------------

def test_match_and_invalid_regex_skip():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        make_layer(g,
            "rules:\n"
            "  - id: bad\n"
            "    tool: Bash\n"
            "    match: \"[\"\n"
            "    inject: BADRULE\n"
            "  - id: good\n"
            "    tool: Bash\n"
            "    match: \\bgrep\\b\n"
            "    inject: GOODRULE {id}\n")
        p = run_hook(payload(command="grep -r foo ."), g)
        ctx = get_context(p)
        assert ctx == "[toolhint] GOODRULE good", ctx  # 不正 regex はスキップ
        assert "正規表現" in p.stderr
        # tool 正規表現が合わなければ発火しない
        p2 = run_hook(payload(command="grep x", tool="Edit", session="s2"), g)
        assert get_context(p2) is None
        # match 正規表現が合わなければ発火しない
        p3 = run_hook(payload(command="rg foo", session="s3"), g)
        assert get_context(p3) is None


def test_tool_fullmatch_not_partial():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        make_layer(g,
            "rules:\n"
            "  - id: b\n    tool: Bash\n    inject: BASH_RULE\n"
            "  - id: m\n    tool: mcp__.*\n    inject: MCP_RULE\n")
        # tool: Bash は BashOutput に発火しない (fullmatch)
        assert get_context(run_hook(payload(tool="BashOutput", session="fm-1"), g)) is None
        assert "BASH_RULE" in get_context(run_hook(payload(tool="Bash", session="fm-2"), g))
        # 正規表現 tool は fullmatch でも従来通り効く
        ctx = get_context(run_hook(payload(tool="mcp__foo__bar", session="fm-3"), g))
        assert "MCP_RULE" in ctx and "BASH_RULE" not in ctx, ctx


def test_match_budget_catastrophic_regex_skipped():
    # 破滅的 backtracking するルールは時間予算でスキップし、健全ルールは生かす
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        make_layer(g,
            "rules:\n"
            "  - id: evil\n    tool: Bash\n    match: (a+)+$\n    inject: EVIL\n"
            "  - id: good\n    tool: Bash\n    match: \\bgrep\\b\n    inject: GOOD\n")
        t0 = time.time()
        p = run_hook(payload(command="grep " + "a" * 40 + "!"), g)
        elapsed = time.time() - t0
        assert elapsed < 5, "hook が timeout 相当まで停止: %.1fs" % elapsed
        ctx = get_context(p)
        assert ctx == "[toolhint] GOOD", ctx
        assert "時間予算" in p.stderr, p.stderr


def test_multiple_matches_joined():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        make_layer(g,
            "rules:\n"
            "  - id: r1\n    tool: Bash\n    match: foo\n    inject: ONE\n"
            "  - id: r2\n    tool: Bash\n    inject: TWO\n")  # match 省略 = 常にマッチ
        ctx = get_context(run_hook(payload(command="foo"), g))
        assert ctx == "[toolhint] ONE\n[toolhint] TWO", ctx


# ---------------------------------------------------------------------------
# 層マージ (project が global を上書き)
# ---------------------------------------------------------------------------

def test_project_overrides_global():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        proj = os.path.join(td, "proj", "sub")  # サブディレクトリから上方向探索
        layer = os.path.join(td, "proj", ".claude", "toolhint")
        make_layer(g,
            "rules:\n"
            "  - id: x\n    tool: Bash\n    match: foo\n    inject: FROM_GLOBAL\n"
            "  - id: gonly\n    tool: Bash\n    match: foo\n    inject: GLOBAL_ONLY\n")
        make_layer(layer,
            "rules:\n  - id: x\n    tool: Bash\n    match: foo\n    inject: FROM_PROJECT\n")
        os.makedirs(proj, exist_ok=True)
        ctx = get_context(run_hook(payload(command="foo", cwd=proj), g))
        assert "FROM_PROJECT" in ctx, ctx
        assert "FROM_GLOBAL" not in ctx, ctx
        assert "GLOBAL_ONLY" in ctx, ctx  # 上書きされない global ルールは残る


def test_isolated_global_excludes_home_default_from_walkup():
    # TOOLHINT_GLOBAL で隔離しても、home 配下の cwd からの walk-up が
    # 既定の global 置き場 (~/.claude/toolhint) を project 層として拾わない
    # (getting-started の推奨隔離手順・GUI の層表示を誤読させる回帰の防止)
    with tempfile.TemporaryDirectory() as td:
        home = os.path.join(td, "home")
        real_global = os.path.join(home, ".claude", "toolhint")
        make_layer(real_global,
            "rules:\n  - id: real\n    tool: Bash\n    match: foo\n"
            "    inject: FROM_REAL_HOME\n")
        g = os.path.join(td, "g")
        make_layer(g,
            "rules:\n  - id: iso\n    tool: Bash\n    match: foo\n"
            "    inject: FROM_ISOLATED\n")
        proj = os.path.join(home, "projects", "demo")  # 自前の層なし
        os.makedirs(proj, exist_ok=True)
        # hook 縦貫: 隔離 global のルールだけが発火し、home の実 global は無視される
        ctx = get_context(run_hook(payload(command="foo", cwd=proj), g,
                                   env_extra={"HOME": home}))
        assert "FROM_ISOLATED" in ctx, ctx
        assert "FROM_REAL_HOME" not in ctx, ctx
        # 単体: find_project_dir も None (project 層なし)。通常の project 層は
        # 引き続き拾う (除外は global 由来の dir だけ)
        old_home = os.environ.get("HOME")
        os.environ["HOME"] = home
        try:
            assert toolhint.find_project_dir(proj, os.path.abspath(g)) is None
            layer = os.path.join(home, "projects", ".claude", "toolhint")
            os.makedirs(layer, exist_ok=True)
            assert toolhint.find_project_dir(proj, os.path.abspath(g)) == layer
        finally:
            if old_home is None:
                os.environ.pop("HOME", None)
            else:
                os.environ["HOME"] = old_home


# ---------------------------------------------------------------------------
# 追加層 (<global層>/layers.d/<名前>/) — 外から配布される共有ルールの置き場
# ---------------------------------------------------------------------------

def extra_layer(global_dir, name):
    """<global層>/layers.d/<名前> のパス (make_layer に渡す)。"""
    return os.path.join(global_dir, "layers.d", name)


def test_layers_d_fires_and_logs_layer_name():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        make_layer(g, "rules:\n")  # global 層は空 (ルールなし)
        make_layer(extra_layer(g, "team"),
            "rules:\n"
            "  - id: team-rule\n    tool: Bash\n    match: foo\n"
            "    doc: docs/t.md\n",
            docs={"docs/t.md": "team body\n"})
        p = run_hook(payload(command="foo", session="ld-1"), g)
        ctx = get_context(p)
        abs_doc = os.path.join(os.path.abspath(g), "layers.d", "team", "docs", "t.md")
        assert ctx == "[toolhint] この操作の docs: %s — 必要なら読む" % abs_doc, ctx
        # 注入ログの層表示は "layers.d/<名前>"
        with open(os.path.join(g, "log", "injections.jsonl"), encoding="utf-8") as f:
            entries = [json.loads(l) for l in f.read().splitlines()]
        assert len(entries) == 1, entries
        assert entries[0]["layer"] == "layers.d/team", entries[0]
        assert entries[0]["doc"] == abs_doc, entries[0]
        # ことばきっかけ (prompt 経路) も同じ層から発火する
        make_layer(extra_layer(g, "team"),
            "rules:\n"
            "  - id: team-kw\n    event: prompt\n    keywords: deploy\n"
            "    inject: TEAM_KW\n")
        ctx2 = get_context(run_prompt_hook(prompt_payload("deploy ちょうだい"), g),
                           event="UserPromptSubmit")
        assert ctx2 == "[toolhint] TEAM_KW", ctx2


def test_layers_d_read_order_local_wins():
    # 読み順 layers.d/* → global → project、同 id は後勝ち (= より手元が勝つ)
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        proj_root = os.path.join(td, "proj")
        proj_layer = os.path.join(proj_root, ".claude", "toolhint")
        make_layer(extra_layer(g, "team"),
            "rules:\n"
            "  - id: x\n    tool: Bash\n    match: foo\n    inject: FROM_TEAM\n"
            "    every: always\n"
            "  - id: teamonly\n    tool: Bash\n    match: foo\n"
            "    inject: TEAM_ONLY\n    every: always\n")
        make_layer(g,
            "rules:\n  - id: x\n    tool: Bash\n    match: foo\n"
            "    inject: FROM_GLOBAL\n    every: always\n")
        # global が layers.d を上書きする (project 層なし)
        ctx = get_context(run_hook(payload(command="foo", cwd=td), g))
        assert "FROM_GLOBAL" in ctx and "FROM_TEAM" not in ctx, ctx
        assert "TEAM_ONLY" in ctx, ctx  # 上書きされない追加層のルールは残る
        # project 層があれば project が最後 (最も手元) — global も上書きする
        make_layer(proj_layer,
            "rules:\n  - id: x\n    tool: Bash\n    match: foo\n"
            "    inject: FROM_PROJECT\n    every: always\n")
        ctx2 = get_context(run_hook(payload(command="foo", cwd=proj_root), g))
        assert "FROM_PROJECT" in ctx2, ctx2
        assert "FROM_GLOBAL" not in ctx2 and "FROM_TEAM" not in ctx2, ctx2


def test_layers_d_disabled_by_local_override():
    # 手元の層 (global / project) に同 id + enabled: "false" を置くと、追加層の
    # ルールをそのマシン / プロジェクトだけ止められる (後勝ちマージ → enabled 判定)
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        proj_root = os.path.join(td, "proj")
        proj_layer = os.path.join(proj_root, ".claude", "toolhint")
        os.makedirs(proj_root, exist_ok=True)
        make_layer(extra_layer(g, "team"),
            "rules:\n"
            "  - id: t-op\n    tool: Bash\n    match: foo\n    inject: TEAM_OP\n"
            "    every: always\n"
            "  - id: t-kw\n    event: prompt\n    keywords: foo\n"
            "    inject: TEAM_KW\n    every: always\n"
            "  - id: t-keep\n    tool: Bash\n    match: foo\n    inject: TEAM_KEEP\n"
            "    every: always\n")
        # まずは素で発火する
        assert "TEAM_OP" in get_context(run_hook(payload(command="foo", cwd=proj_root), g))
        assert "TEAM_KW" in get_context(
            run_prompt_hook(prompt_payload("foo"), g), event="UserPromptSubmit")
        # global 層で 2 件を止める (同 id + enabled: "false")
        make_layer(g,
            "rules:\n"
            "  - id: t-op\n    tool: Bash\n    enabled: \"false\"\n"
            "  - id: t-kw\n    event: prompt\n    keywords: foo\n"
            "    enabled: \"false\"\n")
        ctx = get_context(run_hook(payload(command="foo", cwd=proj_root), g))
        assert ctx == "[toolhint] TEAM_KEEP", ctx  # 止めていないルールは生きる
        assert get_context(run_prompt_hook(prompt_payload("foo"), g),
                           event="UserPromptSubmit") is None
        # project 層でも止められる (そのプロジェクトだけ)
        make_layer(proj_layer,
            "rules:\n  - id: t-keep\n    tool: Bash\n    enabled: \"false\"\n")
        assert get_context(run_hook(payload(command="foo", cwd=proj_root), g)) is None
        # 別プロジェクト (project 層なし) では t-keep は生きたまま
        other = os.path.join(td, "other")
        os.makedirs(other, exist_ok=True)
        assert "TEAM_KEEP" in get_context(run_hook(payload(command="foo", cwd=other), g))


def test_layers_d_multiple_layers_sorted():
    # 複数の追加層は名前の辞書順に読む — 同 id は後の名前が勝つ
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        make_layer(g, "rules:\n")
        make_layer(extra_layer(g, "aaa"),
            "rules:\n"
            "  - id: dup\n    tool: Bash\n    match: foo\n    inject: FROM_AAA\n"
            "    every: always\n"
            "  - id: only-a\n    tool: Bash\n    match: foo\n    inject: ONLY_A\n"
            "    every: always\n")
        make_layer(extra_layer(g, "bbb"),
            "rules:\n"
            "  - id: dup\n    tool: Bash\n    match: foo\n    inject: FROM_BBB\n"
            "    every: always\n")
        ctx = get_context(run_hook(payload(command="foo", cwd=td), g))
        assert "FROM_BBB" in ctx and "FROM_AAA" not in ctx, ctx
        assert "ONLY_A" in ctx, ctx
        # 単体: 辞書順 + 表示名
        assert toolhint.find_extra_layers(g) == [
            ("layers.d/aaa", os.path.join(g, "layers.d", "aaa")),
            ("layers.d/bbb", os.path.join(g, "layers.d", "bbb")),
        ], toolhint.find_extra_layers(g)


def test_layers_d_absent_or_empty_unchanged():
    # layers.d が無い / 空 / 中身がファイルだけ / dotfile のみ → 既存挙動のまま
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        make_layer(g,
            "rules:\n  - id: a\n    tool: Bash\n    match: foo\n    inject: BASE\n"
            "    every: always\n")
        assert toolhint.find_extra_layers(g) == []
        assert get_context(run_hook(payload(command="foo", cwd=td), g)) == "[toolhint] BASE"
        os.makedirs(os.path.join(g, "layers.d"))  # 空 dir
        assert toolhint.find_extra_layers(g) == []
        assert get_context(run_hook(payload(command="foo", cwd=td), g)) == "[toolhint] BASE"
        # 通常ファイル・dot dir は層にしない
        with open(os.path.join(g, "layers.d", "README"), "w", encoding="utf-8") as f:
            f.write("not a layer\n")
        os.makedirs(os.path.join(g, "layers.d", ".git"))
        assert toolhint.find_extra_layers(g) == []
        assert get_context(run_hook(payload(command="foo", cwd=td), g)) == "[toolhint] BASE"
        # layers.d 自体がファイル (読めない) でも fail-open
        g2 = os.path.join(td, "g2")
        make_layer(g2,
            "rules:\n  - id: a\n    tool: Bash\n    match: foo\n    inject: BASE2\n")
        with open(os.path.join(g2, "layers.d"), "w", encoding="utf-8") as f:
            f.write("x")
        assert toolhint.find_extra_layers(g2) == []
        p = run_hook(payload(command="foo", cwd=td, session="ld-file"), g2)
        assert get_context(p) == "[toolhint] BASE2"


def test_layers_d_doc_outside_layer_skipped():
    # 追加層のルールが層 dir の外の doc を指したら発火させない (inline / pointer 両方)。
    # 配られた層が層外の任意ファイルを context へ流し込めないようにする制限
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        make_layer(g, "rules:\n")
        secret = os.path.join(td, "secret.md")
        with open(secret, "w", encoding="utf-8") as f:
            f.write("TOP SECRET BODY\n")
        team = extra_layer(g, "team")
        make_layer(team,
            "rules:\n"
            "  - id: esc-inline\n    tool: Bash\n    match: foo\n"
            "    doc: ../../../secret.md\n    mode: inline\n    every: always\n"
            "  - id: esc-pointer\n    tool: Bash\n    match: foo\n"
            "    doc: ../../../secret.md\n    every: always\n"
            "  - id: esc-symlink\n    tool: Bash\n    match: foo\n"
            "    doc: docs/link.md\n    mode: inline\n    every: always\n"
            "  - id: ok\n    tool: Bash\n    match: foo\n    doc: docs/ok.md\n"
            "    mode: inline\n    every: always\n",
            docs={"docs/ok.md": "TEAM OK BODY\n"})
        # 層内 symlink → 層外の実体 (realpath 判定でないとすり抜ける)
        os.symlink(secret, os.path.join(team, "docs", "link.md"))
        p = run_hook(payload(command="foo", cwd=td), g)
        ctx = get_context(p)
        assert ctx == "[toolhint] この操作の docs (ok):\nTEAM OK BODY", ctx
        assert "TOP SECRET BODY" not in (ctx or ""), ctx
        assert secret not in (ctx or ""), ctx
        assert p.stderr.count("層の外を指す") == 3, p.stderr
        # 手元の層 (global) は従来どおり制限しない (既存インストールを壊さない)
        make_layer(g,
            "rules:\n  - id: gesc\n    tool: Bash\n    match: foo\n"
            "    doc: ../secret.md\n    mode: inline\n    every: always\n")
        ctx2 = get_context(run_hook(payload(command="foo", cwd=td, session="esc-2"), g))
        assert "TOP SECRET BODY" in ctx2, ctx2
        # 単体: doc_within_layer は realpath 判定
        assert toolhint.doc_within_layer(os.path.join(team, "docs", "ok.md"), team)
        assert not toolhint.doc_within_layer(
            os.path.join(team, "docs", "link.md"), team)
        assert not toolhint.doc_within_layer(secret, team)


def test_layers_d_symlinked_layer_and_broken_rules_skipped():
    # 層 dir が symlink でも既存層と同じ扱いで読む / 壊れた追加層は層ごと読み飛ばす
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        make_layer(g, "rules:\n")
        src = os.path.join(td, "shared-src")
        make_layer(src,
            "rules:\n  - id: sym\n    tool: Bash\n    match: foo\n    inject: SYMLINKED\n"
            "    every: always\n"
            "  - id: symdoc\n    tool: Bash\n    match: foo\n    doc: docs/s.md\n"
            "    mode: inline\n    every: always\n",
            docs={"docs/s.md": "SYM BODY\n"})
        os.makedirs(os.path.join(g, "layers.d"))
        os.symlink(src, os.path.join(g, "layers.d", "team"))
        ctx0 = get_context(run_hook(payload(command="foo", cwd=td), g))
        assert "SYMLINKED" in ctx0, ctx0
        # 層 dir 自体が symlink でも、その層の中の doc は層内として通る
        assert "SYM BODY" in ctx0, ctx0
        # 壊れた追加層は読み飛ばし、他の層は生きる (fail-open)
        make_layer(extra_layer(g, "broken"),
            "rules:\n  - id: b\n    tool: Bash\n    nested:\n      x: 1\n")
        p = run_hook(payload(command="foo", cwd=td, session="ld-sym-2"), g)
        assert "SYMLINKED" in get_context(p)
        assert "読み飛ばし" in p.stderr, p.stderr


# ---------------------------------------------------------------------------
# 適用範囲 (scope) — 特定のディレクトリ配下でだけ効くルール
# ---------------------------------------------------------------------------

def scoped_layer(root, rules_text, docs=None):
    """層に rules-scoped.yaml を書く (make_layer の rules.yaml 版と対)。"""
    os.makedirs(root, exist_ok=True)
    with open(os.path.join(root, "rules-scoped.yaml"), "w", encoding="utf-8") as f:
        f.write(rules_text)
    for rel, body in (docs or {}).items():
        p = os.path.join(root, rel)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, "w", encoding="utf-8") as f:
            f.write(body)


def test_scope_fires_only_inside_matching_dir():
    # scope 付きは一致する作業ディレクトリでだけ発火 / scope 無しは従来どおり
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        inside = os.path.join(td, "work", "alpha", "sub")
        outside = os.path.join(td, "work", "beta")
        os.makedirs(inside)
        os.makedirs(outside)
        make_layer(g,
            "rules:\n"
            "  - id: anywhere\n    tool: Bash\n    match: foo\n    inject: ANYWHERE\n"
            "    every: always\n"
            "  - id: scoped\n    tool: Bash\n    match: foo\n    inject: SCOPED\n"
            "    every: always\n    scope: \"*/work/alpha*\"\n")
        ctx = get_context(run_hook(payload(command="foo", cwd=inside), g))
        assert "SCOPED" in ctx and "ANYWHERE" in ctx, ctx
        # 範囲外では scope 付きだけが消える (他のルールは無傷)
        ctx2 = get_context(run_hook(payload(command="foo", cwd=outside), g))
        assert ctx2 == "[toolhint] ANYWHERE", ctx2
        # 範囲そのもの (末尾の sub なし) も一致する
        assert "SCOPED" in get_context(
            run_hook(payload(command="foo", cwd=os.path.join(td, "work", "alpha")), g))


def test_scope_on_prompt_rule():
    # ことばきっかけにも同じ scope が効く
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        inside = os.path.join(td, "shop")
        outside = os.path.join(td, "other")
        os.makedirs(inside)
        os.makedirs(outside)
        make_layer(g,
            "rules:\n"
            "  - id: kw-any\n    event: prompt\n    keywords: deploy\n"
            "    inject: KW_ANY\n    every: always\n"
            "  - id: kw-scoped\n    event: prompt\n    keywords: deploy\n"
            "    inject: KW_SCOPED\n    every: always\n    scope: \"*/shop*\"\n")
        ctx = get_context(run_prompt_hook(prompt_payload("deploy して", cwd=inside), g),
                          event="UserPromptSubmit")
        assert "KW_SCOPED" in ctx and "KW_ANY" in ctx, ctx
        ctx2 = get_context(run_prompt_hook(prompt_payload("deploy して", cwd=outside), g),
                           event="UserPromptSubmit")
        assert ctx2 == "[toolhint] KW_ANY", ctx2


def test_scope_unknown_cwd_does_not_fire():
    # cwd が取れない payload では scope 付きルールを出さない (場所が不明なため)。
    # 実行は止めない = scope 無しのルールは従来どおり発火する
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        make_layer(g,
            "rules:\n"
            "  - id: anywhere\n    tool: Bash\n    match: foo\n    inject: ANYWHERE\n"
            "    every: always\n"
            "  - id: scoped\n    tool: Bash\n    match: foo\n    inject: SCOPED\n"
            "    every: always\n    scope: \"*\"\n")  # どこにでも一致するパターン
        p = run_hook({"session_id": "nc-1", "tool_name": "Bash",
                      "tool_input": {"command": "foo"},
                      "hook_event_name": "PreToolUse"}, g)  # cwd キーなし
        assert get_context(p) == "[toolhint] ANYWHERE", p.stdout
        assert "作業ディレクトリが不明" in p.stderr, p.stderr
        # cwd があれば同じルールが発火する (パターン自体は正しい)
        assert "SCOPED" in get_context(
            run_hook(payload(command="foo", cwd=td, session="nc-2"), g))


def test_scoped_rules_file_read_alongside():
    # rules-scoped.yaml も同じ層のルールとして読む (書式・扱いは rules.yaml と同じ)
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        inside = os.path.join(td, "here")
        os.makedirs(inside)
        make_layer(g,
            "rules:\n"
            "  - id: plain\n    tool: Bash\n    match: foo\n    inject: PLAIN\n"
            "    every: always\n")
        scoped_layer(g,
            "rules:\n"
            "  - id: only-here\n    tool: Bash\n    match: foo\n    inject: ONLY_HERE\n"
            "    every: always\n    scope: \"*/here*\"\n"
            "  - id: doc-rule\n    tool: Bash\n    match: foo\n    doc: docs/s.md\n"
            "    mode: inline\n    every: always\n    scope: \"*/here*\"\n",
            docs={"docs/s.md": "SCOPED BODY\n"})
        ctx = get_context(run_hook(payload(command="foo", cwd=inside), g))
        assert "PLAIN" in ctx and "ONLY_HERE" in ctx, ctx
        assert "SCOPED BODY" in ctx, ctx  # doc の解決基準は同じ層 dir
        # 範囲外では rules-scoped.yaml のルールだけ消える
        ctx2 = get_context(run_hook(payload(command="foo", cwd=td), g))
        assert ctx2 == "[toolhint] PLAIN", ctx2
        # 注入ログの層表示は従来どおり (ファイルが 2 本でも層は 1 つ)
        with open(os.path.join(g, "log", "injections.jsonl"), encoding="utf-8") as f:
            layers = {json.loads(l)["layer"] for l in f.read().splitlines()}
        assert layers == {"global"}, layers


def test_scoped_rules_file_same_id_wins_within_layer():
    # 同じ層で同 id なら後に読む rules-scoped.yaml が勝つ (読み順どおり)
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        make_layer(g,
            "rules:\n  - id: dup\n    tool: Bash\n    match: foo\n"
            "    inject: FROM_PLAIN\n    every: always\n")
        scoped_layer(g,
            "rules:\n  - id: dup\n    tool: Bash\n    match: foo\n"
            "    inject: FROM_SCOPED\n    every: always\n    scope: \"*\"\n")
        ctx = get_context(run_hook(payload(command="foo", cwd=td), g))
        assert ctx == "[toolhint] FROM_SCOPED", ctx


def test_scoped_rules_file_broken_skips_layer():
    # rules-scoped.yaml が壊れていたら層全体を読み飛ばす (rules.yaml と同じ握り方)
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        make_layer(g,
            "rules:\n  - id: plain\n    tool: Bash\n    match: foo\n"
            "    inject: PLAIN\n    every: always\n")
        scoped_layer(g, "rules:\n  - id: b\n    tool: Bash\n    nested:\n      x: 1\n")
        p = run_hook(payload(command="foo", cwd=td), g)
        assert p.returncode == 0, p.stderr
        assert get_context(p) is None, p.stdout
        assert "読み飛ばし" in p.stderr and "rules-scoped.yaml" in p.stderr, p.stderr
        # 単体でも同じ (層のルールは 0 件)
        err = io.StringIO()
        with contextlib.redirect_stderr(err):
            assert toolhint.load_rules(g) == []


def test_scope_broken_pattern_does_not_kill_hook():
    # 変なパターンでもプロセスは死なず、他のルールは通常どおり発火する
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        make_layer(g,
            "rules:\n"
            "  - id: weird\n    tool: Bash\n    match: foo\n    inject: WEIRD\n"
            "    every: always\n    scope: \"[\"\n"
            "  - id: good\n    tool: Bash\n    match: foo\n    inject: GOOD\n"
            "    every: always\n")
        p = run_hook(payload(command="foo", cwd=td), g)
        assert p.returncode == 0, p.stderr
        assert get_context(p) == "[toolhint] GOOD", p.stdout
        # 空パターンも「どこにも一致しない」に倒れるだけ (実行は止まらない)
        make_layer(g,
            "rules:\n"
            "  - id: empty\n    tool: Bash\n    match: foo\n    inject: EMPTY\n"
            "    every: always\n    scope: \"\"\n")
        p2 = run_hook(payload(command="foo", cwd=td, session="wp-2"), g)
        assert p2.returncode == 0 and get_context(p2) is None, p2.stdout


def test_scope_unit_helper():
    # scope 無し = どこでも / 一致 / 不一致 / cwd 不明 / 相対 cwd の絶対パス化
    assert toolhint.rule_in_scope({"id": "a"}, "/tmp/x") is True
    assert toolhint.rule_in_scope({"id": "a"}, "") is True  # scope 無しは cwd 不問
    r = {"id": "a", "scope": "*/proj*"}
    assert toolhint.rule_in_scope(r, "/home/me/proj/sub") is True
    assert toolhint.rule_in_scope(r, "/home/me/other") is False
    assert toolhint.rule_in_scope(r, "") is False  # cwd 不明なら出さない
    assert toolhint.rule_in_scope(r, None) is False
    # `*` は `/` を跨ぐ (パス全体への glob)
    assert toolhint.rule_in_scope({"id": "a", "scope": "/home/*/sub"},
                                  "/home/me/deep/sub") is True
    # 相対 cwd は絶対パス化してから照合する
    cwd_abs = os.path.abspath(".")
    assert toolhint.rule_in_scope({"id": "a", "scope": cwd_abs + "*"}, ".") is True
    # マッチ判定の入口 (tool / prompt) の両方で効く
    assert toolhint.rule_matches({"id": "a", "tool": "Bash", "scope": "*/proj*"},
                                 "Bash", "{}", "/home/me/proj") is True
    assert toolhint.rule_matches({"id": "a", "tool": "Bash", "scope": "*/proj*"},
                                 "Bash", "{}", "/home/me/nope") is False
    assert toolhint.rule_matches_prompt(
        {"id": "a", "event": "prompt", "keywords": "foo", "scope": "*/proj*"},
        "foo", "/home/me/proj") is True
    assert toolhint.rule_matches_prompt(
        {"id": "a", "event": "prompt", "keywords": "foo", "scope": "*/proj*"},
        "foo", "/home/me/nope") is False
    # cwd 引数なしで呼ばれたら scope 付きは不発 (既定 None = 場所不明)
    assert toolhint.rule_matches({"id": "a", "tool": "Bash", "scope": "*"},
                                 "Bash", "{}") is False


def test_rules_yaml_only_layer_unchanged():
    # 後方互換の確認: rules-scoped.yaml が無い層は従来と 1 字も変わらない
    # (旧版 engine は rules.yaml しか読まない — その層の挙動が今回の変更で
    #  変わっていないことを、注入文面・state・ログの全部で確かめる)
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        make_layer(g,
            "rules:\n"
            "  - id: p\n    tool: Bash\n    match: foo\n    doc: docs/p.md\n",
            docs={"docs/p.md": "body\n"})
        abs_doc = os.path.join(os.path.abspath(g), "docs", "p.md")
        ctx = get_context(run_hook(payload(command="foo", session="bc-1"), g))
        assert ctx == "[toolhint] この操作の docs: %s — 必要なら読む" % abs_doc, ctx
        assert get_context(run_hook(payload(command="foo", session="bc-1"), g)) is None
        state = json.load(open(os.path.join(g, "state", "bc-1.json")))
        assert state == {"shown": ["p"]}, state
        with open(os.path.join(g, "log", "injections.jsonl"), encoding="utf-8") as f:
            entries = [json.loads(l) for l in f.read().splitlines()]
        assert len(entries) == 1 and entries[0]["layer"] == "global", entries
        # scoped ファイルは engine が勝手に作らない
        assert sorted(os.listdir(g)) == ["docs", "log", "rules.yaml", "state"], \
            os.listdir(g)


# ---------------------------------------------------------------------------
# every: session / always
# ---------------------------------------------------------------------------

def test_every_session_suppression():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        make_layer(g, "rules:\n  - id: s\n    tool: Bash\n    match: foo\n    inject: SESSIONRULE\n")
        assert "SESSIONRULE" in get_context(run_hook(payload(command="foo", session="sid1"), g))
        # 同一 session の 2 回目は発火しない
        assert get_context(run_hook(payload(command="foo", session="sid1"), g)) is None
        # 別 session なら発火する
        assert "SESSIONRULE" in get_context(run_hook(payload(command="foo", session="sid2"), g))
        # state ファイルに記録されている
        state = json.load(open(os.path.join(g, "state", "sid1.json")))
        assert state == {"shown": ["s"]}, state


def test_state_keyed_by_agent_context():
    # subagent (agent_id あり) は fresh context — 親で表示済みでも別カウントで注入
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        make_layer(g, "rules:\n  - id: s\n    tool: Bash\n    match: foo\n    inject: CTX\n")
        assert "CTX" in get_context(run_hook(payload(command="foo", session="ag-1"), g))
        assert get_context(run_hook(payload(command="foo", session="ag-1"), g)) is None
        # 同一 session でも subagent context では再注入される
        sub = payload(command="foo", session="ag-1", agent_id="sub1")
        assert "CTX" in get_context(run_hook(sub, g))
        # 同一 subagent の 2 回目は抑制
        assert get_context(run_hook(sub, g)) is None
        # state は context ごとに分離される
        assert os.path.isfile(os.path.join(g, "state", "ag-1.json"))
        assert os.path.isfile(os.path.join(g, "state", "ag-1__sub1.json"))


def test_tool_use_id_claim_dedup():
    # 二重配線 (同一 tool_use_id で 2 プロセス起動) は先着 1 プロセスだけが注入する
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        make_layer(g,
            "rules:\n"
            "  - id: al\n    tool: Bash\n    match: foo\n    inject: DEDUP\n"
            "    every: always\n")
        p1 = run_hook(payload(command="foo", session="c1", tool_use_id="tu-1"), g)
        assert "DEDUP" in get_context(p1)
        # 後着 (別プロセス・同一 tool_use_id) は every:always でも注入しない
        p2 = run_hook(payload(command="foo", session="c2", tool_use_id="tu-1"), g)
        assert get_context(p2) is None
        assert os.path.isfile(os.path.join(g, "state", "claims", "tu-1.claim"))
        # 別の tool_use_id なら通常通り注入
        p3 = run_hook(payload(command="foo", session="c3", tool_use_id="tu-2"), g)
        assert "DEDUP" in get_context(p3)
        # tool_use_id 不明の payload は fail-open で通常処理
        p4 = run_hook(payload(command="foo", session="c4"), g)
        assert "DEDUP" in get_context(p4)


def test_state_gc_removes_old_files():
    # state/ が閾値超のときだけ、14 日超の古いファイルを best-effort GC
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        make_layer(g, "rules:\n  - id: a\n    tool: Bash\n    match: foo\n    inject: X\n")
        state_dir = os.path.join(g, "state")
        os.makedirs(state_dir)
        old = time.time() - 15 * 86400
        for i in range(201):
            p = os.path.join(state_dir, "old-%d.json" % i)
            with open(p, "w", encoding="utf-8") as f:
                f.write("{}")
            os.utime(p, (old, old))
        fresh = os.path.join(state_dir, "fresh.json")  # 閾値超でも新しいものは残る
        with open(fresh, "w", encoding="utf-8") as f:
            f.write("{}")
        assert "X" in get_context(run_hook(payload(command="foo", session="gc-1"), g))
        names = os.listdir(state_dir)
        assert not any(n.startswith("old-") for n in names), names[:5]
        assert "fresh.json" in names and "gc-1.json" in names, names


def test_every_always():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        make_layer(g,
            "rules:\n"
            "  - id: al\n    tool: Bash\n    match: foo\n    inject: ALWAYSRULE\n"
            "    every: always\n")
        assert "ALWAYSRULE" in get_context(run_hook(payload(command="foo", session="sidA"), g))
        assert "ALWAYSRULE" in get_context(run_hook(payload(command="foo", session="sidA"), g))
        # always は state に記録しない → state ファイル自体が作られない
        assert not os.path.exists(os.path.join(g, "state", "sidA.json"))


# ---------------------------------------------------------------------------
# mode: pointer / inline、doc の扱い
# ---------------------------------------------------------------------------

def test_pointer_doc_absolute_path():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        make_layer(g,
            "rules:\n"
            "  - id: p\n    tool: Bash\n    match: foo\n    doc: docs/p.md\n"
            "  - id: q\n    tool: Bash\n    match: foo\n    doc: docs/p.md\n"
            "    inject: READ {doc} FOR {id}\n",
            docs={"docs/p.md": "pointer body\n"})
        ctx = get_context(run_hook(payload(command="foo"), g))
        abs_doc = os.path.join(os.path.abspath(g), "docs", "p.md")
        lines = ctx.split("\n")
        assert lines[0] == "[toolhint] この操作の docs: %s — 必要なら読む" % abs_doc, ctx
        assert lines[1] == "[toolhint] READ %s FOR q" % abs_doc, ctx
        assert "pointer body" not in ctx  # pointer は本文を注入しない


def test_same_doc_default_pointer_merged_once():
    # 同一 doc への既定ポインタが複数ルールから出ても文面は 1 回に併合される
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        make_layer(g,
            "rules:\n"
            "  - id: p1\n    tool: Bash\n    match: foo\n    doc: docs/x.md\n"
            "  - id: p2\n    tool: Bash\n    match: foo\n    doc: docs/x.md\n",
            docs={"docs/x.md": "body\n"})
        ctx = get_context(run_hook(payload(command="foo", session="mg-1"), g))
        assert len(ctx.split("\n")) == 1, ctx
        # 両ルールとも表示済みとして記録される (2 回目は何も出ない)
        state = json.load(open(os.path.join(g, "state", "mg-1.json")))
        assert set(state["shown"]) == {"p1", "p2"}, state
        assert get_context(run_hook(payload(command="foo", session="mg-1"), g)) is None


def test_inline_injects_body():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        make_layer(g,
            "rules:\n"
            "  - id: i\n    tool: Bash\n    match: foo\n    doc: docs/i.md\n"
            "    mode: inline\n"
            "  - id: j\n    tool: Bash\n    match: foo\n    doc: docs/i.md\n"
            "    mode: inline\n"
            "    inject: HEADLINE {id}\n",
            docs={"docs/i.md": "INLINE BODY LINE\nsecond line\n"})
        ctx = get_context(run_hook(payload(command="foo"), g))
        assert "[toolhint] この操作の docs (i):\nINLINE BODY LINE\nsecond line" in ctx, ctx
        # inject があれば展開結果が先頭行
        assert "[toolhint] HEADLINE j\nこの操作の docs (j):\nINLINE BODY LINE" in ctx, ctx


def test_inline_over_limit_falls_back_to_pointer():
    # inline の doc が上限 (既定 64KB) を超えると本文は注入せず、
    # 通知 1 行 + ポインタ形式に落ちる (stderr に警告)
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        big = "X" * (toolhint.DEFAULT_INLINE_MAX_BYTES + 1000)
        make_layer(g,
            "rules:\n"
            "  - id: big\n    tool: Bash\n    match: foo\n    doc: docs/big.md\n"
            "    mode: inline\n    every: always\n"
            "  - id: head\n    tool: Bash\n    match: foo\n    doc: docs/big.md\n"
            "    mode: inline\n    inject: HEAD {id}\n    every: always\n"
            "  - id: withdoc\n    tool: Bash\n    match: foo\n    doc: docs/big.md\n"
            "    mode: inline\n    inject: READ {doc} NOW\n    every: always\n"
            "  - id: small\n    tool: Bash\n    match: foo\n    doc: docs/small.md\n"
            "    mode: inline\n    every: always\n",
            docs={"docs/big.md": big, "docs/small.md": "SMALL BODY\n"})
        p = run_hook(payload(command="foo", session="il-1"), g)
        ctx = get_context(p)
        abs_doc = os.path.join(os.path.abspath(g), "docs", "big.md")
        notice = "(本文が大きいので場所だけ: %d バイト > 上限 %d バイト)" % (
            len(big), toolhint.DEFAULT_INLINE_MAX_BYTES)
        entries = ctx.split("\n[toolhint] ")
        assert len(entries) == 4, ctx
        # 既定ポインタ: 通知 + 「この操作の docs: …」
        assert entries[0] == "[toolhint] %s\nこの操作の docs: %s — 必要なら読む" % (
            notice, abs_doc), entries[0]
        # inject (見出し) があればその展開結果を挟んでポインタ行
        assert entries[1] == "%s\nHEAD head\nこの操作の docs: %s — 必要なら読む" % (
            notice, abs_doc), entries[1]
        # inject が {doc} を含めば、その展開結果がポインタ (既定行は付けない)
        assert entries[2] == "%s\nREAD %s NOW" % (notice, abs_doc), entries[2]
        # 上限内の doc は従来どおり本文ごと
        assert entries[3] == "この操作の docs (small):\nSMALL BODY", entries[3]
        assert "XXXX" not in ctx, "本文が注入されている"
        assert len(ctx) < 2000, len(ctx)
        assert p.stderr.count("上限を超える") == 3, p.stderr
        assert "TOOLHINT_INLINE_MAX" in p.stderr, p.stderr


def test_inline_limit_boundary_and_env_override():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        limit = toolhint.DEFAULT_INLINE_MAX_BYTES
        make_layer(g,
            "rules:\n"
            "  - id: exact\n    tool: Bash\n    match: exact\n    doc: docs/exact.md\n"
            "    mode: inline\n    every: always\n"
            "  - id: over\n    tool: Bash\n    match: over\n    doc: docs/over.md\n"
            "    mode: inline\n    every: always\n"
            "  - id: tiny\n    tool: Bash\n    match: tiny\n    doc: docs/tiny.md\n"
            "    mode: inline\n    every: always\n",
            docs={"docs/exact.md": "E" * limit,        # ちょうど上限 = 本文ごと
                  "docs/over.md": "O" * (limit + 1),   # 1 バイト超過 = ポインタ
                  "docs/tiny.md": "T" * 200})
        ctx = get_context(run_hook(payload(command="exact", session="ib-1"), g))
        assert ctx == "[toolhint] この操作の docs (exact):\n" + "E" * limit, ctx[:80]
        ctx = get_context(run_hook(payload(command="over", session="ib-2"), g))
        assert ctx.startswith("[toolhint] (本文が大きいので場所だけ: %d バイト > 上限 %d バイト)"
                              % (limit + 1, limit)), ctx[:120]
        assert "OOOO" not in ctx
        # 環境変数で上限を下げる: 200 バイトの doc も上限 100 ならポインタ
        p = run_hook(payload(command="tiny", session="ib-3"), g,
                     env_extra={"TOOLHINT_INLINE_MAX": "100"})
        ctx = get_context(p)
        assert ctx.startswith("[toolhint] (本文が大きいので場所だけ: 200 バイト > 上限 100 バイト)"), ctx
        assert "TTTT" not in ctx
        # 上限を上げれば大きな doc も本文ごと
        p = run_hook(payload(command="over", session="ib-4"), g,
                     env_extra={"TOOLHINT_INLINE_MAX": str(limit * 4)})
        assert get_context(p) == "[toolhint] この操作の docs (over):\n" + "O" * (limit + 1)
        # 不正値 (整数でない / 0 以下) は既定に倒す + 警告。hook は落ちない
        for bad in ("abc", "0", "-5", "1.5"):
            p = run_hook(payload(command="tiny", session="ib-5"), g,
                         env_extra={"TOOLHINT_INLINE_MAX": bad})
            assert get_context(p) == "[toolhint] この操作の docs (tiny):\n" + "T" * 200, bad
            assert "TOOLHINT_INLINE_MAX" in p.stderr and "既定" in p.stderr, (bad, p.stderr)
            p = run_hook(payload(command="over", session="ib-6"), g,
                         env_extra={"TOOLHINT_INLINE_MAX": bad})
            assert "本文が大きいので場所だけ" in get_context(p), bad
        # 空文字は「未設定」と同じ (警告なし)
        p = run_hook(payload(command="tiny", session="ib-7"), g,
                     env_extra={"TOOLHINT_INLINE_MAX": ""})
        assert get_context(p) == "[toolhint] この操作の docs (tiny):\n" + "T" * 200
        assert "TOOLHINT_INLINE_MAX" not in p.stderr, p.stderr


def test_inline_limit_unit_helper():
    # inline_max_bytes: 未設定 = 既定 / 正の整数 = その値 / 不正 = 既定 (警告)
    old = os.environ.get("TOOLHINT_INLINE_MAX")
    try:
        os.environ.pop("TOOLHINT_INLINE_MAX", None)
        assert toolhint.inline_max_bytes() == toolhint.DEFAULT_INLINE_MAX_BYTES == 65536
        os.environ["TOOLHINT_INLINE_MAX"] = " 4096 "
        assert toolhint.inline_max_bytes() == 4096
        err = io.StringIO()
        with contextlib.redirect_stderr(err):
            os.environ["TOOLHINT_INLINE_MAX"] = "big"
            assert toolhint.inline_max_bytes() == toolhint.DEFAULT_INLINE_MAX_BYTES
            assert toolhint.inline_max_bytes() == toolhint.DEFAULT_INLINE_MAX_BYTES
        assert err.getvalue().count("既定") == 1, err.getvalue()  # 同じ値の警告は 1 回
    finally:
        if old is None:
            os.environ.pop("TOOLHINT_INLINE_MAX", None)
        else:
            os.environ["TOOLHINT_INLINE_MAX"] = old


def test_doc_missing_skipped_and_text_only_fires():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        make_layer(g,
            "rules:\n"
            "  - id: broken\n    tool: Bash\n    match: foo\n    doc: docs/nothere.md\n"
            "  - id: textonly\n    tool: Bash\n    match: foo\n    inject: TEXT ONLY {id}\n")
        p = run_hook(payload(command="foo"), g)
        ctx = get_context(p)
        assert ctx == "[toolhint] TEXT ONLY textonly", ctx
        assert "nothere.md" in p.stderr  # doc 不在は stderr 警告


# ---------------------------------------------------------------------------
# prompt rules (event: prompt — UserPromptSubmit 経路)
# ---------------------------------------------------------------------------

def test_prompt_inline_fires_e2e():
    # 発言 → UserPromptSubmit で inline 本文がヘッダ無しで注入され、ログに残る
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        make_layer(g,
            "rules:\n"
            "  - id: kw1\n"
            "    event: prompt\n"
            "    keywords: deploy, デプロイ\n"
            "    doc: docs/z.md\n"
            "    mode: inline\n",
            docs={"docs/z.md": "デプロイ手順\n二行目\n"})
        p = run_prompt_hook(prompt_payload("このデプロイを整えたい", session="pr-1"), g)
        ctx = get_context(p, event="UserPromptSubmit")
        # inline はヘッダ (「この操作の docs (id):」) 無しで本文そのまま
        assert ctx == "[toolhint] デプロイ手順\n二行目", ctx
        # ログ: tool_name="prompt"、input_excerpt=prompt 先頭 160 字
        log_path = os.path.join(g, "log", "injections.jsonl")
        with open(log_path, encoding="utf-8") as f:
            lines = [json.loads(l) for l in f.read().splitlines()]
        assert len(lines) == 1, lines
        e = lines[0]
        assert e["tool_name"] == "prompt" and e["rule_id"] == "kw1"
        assert e["input_excerpt"] == "このデプロイを整えたい"
        assert e["tool_use_id"] is None
        # 区切りのもう一方 (substring・大小無視) でも発火する
        p2 = run_prompt_hook(prompt_payload("DEPLOY please", session="pr-2"), g)
        assert get_context(p2, event="UserPromptSubmit") is not None
        # 長い発言の excerpt は 160 字で切られる
        p3 = run_prompt_hook(prompt_payload("デプロイ " + "x" * 500, session="pr-3"), g)
        assert get_context(p3, event="UserPromptSubmit") is not None
        with open(log_path, encoding="utf-8") as f:
            last = json.loads(f.read().splitlines()[-1])
        assert len(last["input_excerpt"]) == 160, last


def test_prompt_pointer_template():
    # prompt の既定ポインタは「この話題の docs: …」(tool 側の文面と別)
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        make_layer(g,
            "rules:\n"
            "  - id: kp\n"
            "    event: prompt\n"
            "    keywords: foo\n"
            "    doc: docs/p.md\n",
            docs={"docs/p.md": "body\n"})
        ctx = get_context(run_prompt_hook(prompt_payload("say foo"), g),
                          event="UserPromptSubmit")
        abs_doc = os.path.join(os.path.abspath(g), "docs", "p.md")
        assert ctx == "[toolhint] この話題の docs: %s — 必要なら読む" % abs_doc, ctx


def test_prompt_inline_inject_headline():
    # inline + inject: expand(inject) が先頭、本文はヘッダ無しのまま続く
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        make_layer(g,
            "rules:\n"
            "  - id: ki\n"
            "    event: prompt\n"
            "    keywords: foo\n"
            "    doc: docs/i.md\n"
            "    mode: inline\n"
            "    inject: HEAD {id}\n",
            docs={"docs/i.md": "BODY\n"})
        ctx = get_context(run_prompt_hook(prompt_payload("foo!"), g),
                          event="UserPromptSubmit")
        assert ctx == "[toolhint] HEAD ki\nBODY", ctx


def test_prompt_find_word_and_case():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        make_layer(g,
            "rules:\n"
            "  - id: w\n    event: prompt\n    keywords: grep, デプロイ\n"
            "    find: word\n    inject: WORD\n    every: always\n")
        # ASCII 境界: 「grepped」には発火しない / 単語として現れれば発火
        assert get_context(run_prompt_hook(prompt_payload("I grepped it"), g),
                           event="UserPromptSubmit") is None
        assert "WORD" in get_context(run_prompt_hook(prompt_payload("run grep now"), g),
                                     event="UserPromptSubmit")
        # 既定は大小無視 (IGNORECASE)
        assert "WORD" in get_context(run_prompt_hook(prompt_payload("GREP now"), g),
                                     event="UserPromptSubmit")
        # 日本語キーワードは非 ASCII 隣接でも発火 (境界は ASCII のみ)
        assert "WORD" in get_context(run_prompt_hook(prompt_payload("このデプロイを見る"), g),
                                     event="UserPromptSubmit")

    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        make_layer(g,
            "rules:\n"
            "  - id: cs\n    event: prompt\n    keywords: Deploy\n"
            "    case: sensitive\n    inject: CASE\n    every: always\n")
        # case: sensitive は大小を区別する (substring)
        assert get_context(run_prompt_hook(prompt_payload("deploy"), g),
                           event="UserPromptSubmit") is None
        assert "CASE" in get_context(run_prompt_hook(prompt_payload("Deploy"), g),
                                     event="UserPromptSubmit")


def test_prompt_find_regex_not_split():
    # find=regex は keywords 全体が 1 つの正規表現 — `,` `、` で分割しない
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        make_layer(g,
            "rules:\n"
            "  - id: rx\n    event: prompt\n    keywords: \"a{1,3}x\"\n"
            "    find: regex\n    inject: REGEX\n    every: always\n")
        assert "REGEX" in get_context(run_prompt_hook(prompt_payload("say aax"), g),
                                      event="UserPromptSubmit")
        # 分割されていれば "a{1" / "3}x" の substring 判定になり "b a{1 c" で誤発火する
        assert get_context(run_prompt_hook(prompt_payload("b a{1 c"), g),
                           event="UserPromptSubmit") is None


def test_prompt_keyword_split_edges():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        # 末尾カンマ・連続カンマの空要素は除去 — 「何にでも一致」にならない
        make_layer(g,
            "rules:\n"
            "  - id: tr\n    event: prompt\n    keywords: \"foo,,\"\n"
            "    inject: TRAIL\n    every: always\n")
        assert get_context(run_prompt_hook(prompt_payload("bar baz"), g),
                           event="UserPromptSubmit") is None
        assert "TRAIL" in get_context(run_prompt_hook(prompt_payload("foo bar"), g),
                                      event="UserPromptSubmit")
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        # 区切りのみ (有効要素 0) のルールは警告スキップ — どの発言にも発火しない
        make_layer(g,
            "rules:\n"
            "  - id: emp\n    event: prompt\n    keywords: \",、\"\n"
            "    inject: EMPTY\n    every: always\n")
        p = run_prompt_hook(prompt_payload("anything at all"), g)
        assert get_context(p, event="UserPromptSubmit") is None
        assert "有効な要素がない" in p.stderr, p.stderr
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        # `、` 区切りも `,` と同格
        make_layer(g,
            "rules:\n"
            "  - id: ja\n    event: prompt\n    keywords: デプロイ、でぷろい\n"
            "    inject: JA\n    every: always\n")
        assert "JA" in get_context(run_prompt_hook(prompt_payload("でぷろい を頼む"), g),
                                   event="UserPromptSubmit")


def test_prompt_keyword_fullwidth_comma_separator():
    # 全角カンマ `，` (U+FF0C) も `,` `、` と同格の区切り — 「本番，ほんばん」は 2 語
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        make_layer(g,
            "rules:\n"
            "  - id: fw\n    event: prompt\n    keywords: 本番，ほんばん\n"
            "    inject: FW\n    every: always\n")
        # 1 語目・2 語目それぞれ単独で発火する (1 語 「本番，ほんばん」 のままなら
        # 「本番に出す」には一致しない)
        assert "FW" in get_context(run_prompt_hook(prompt_payload("本番に出す"), g),
                                   event="UserPromptSubmit")
        assert "FW" in get_context(run_prompt_hook(prompt_payload("ほんばんへ"), g),
                                   event="UserPromptSubmit")
        assert get_context(run_prompt_hook(prompt_payload("開発で試す"), g),
                           event="UserPromptSubmit") is None
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        # 3 種の区切りが混在しても全部の語で発火し、空要素は残らない
        make_layer(g,
            "rules:\n"
            "  - id: mix\n    event: prompt\n    keywords: \"alpha，beta、gamma,，\"\n"
            "    inject: MIX\n    every: always\n")
        for said in ("alpha!", "the beta", "gamma ray"):
            assert "MIX" in get_context(run_prompt_hook(prompt_payload(said), g),
                                        event="UserPromptSubmit"), said
        assert get_context(run_prompt_hook(prompt_payload("delta"), g),
                           event="UserPromptSubmit") is None
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        # `，` だけの keywords は区切りのみ (有効要素 0) — 警告スキップで発火しない
        make_layer(g,
            "rules:\n"
            "  - id: fwemp\n    event: prompt\n    keywords: \"，，\"\n"
            "    inject: FWEMPTY\n    every: always\n")
        p = run_prompt_hook(prompt_payload("anything at all"), g)
        assert get_context(p, event="UserPromptSubmit") is None
        assert "有効な要素がない" in p.stderr, p.stderr
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        # find=regex は `，` でも分割しない — 正規表現の一部としてそのまま一致する
        make_layer(g,
            "rules:\n"
            "  - id: fwrx\n    event: prompt\n    keywords: \"a，b\"\n"
            "    find: regex\n    inject: FWREGEX\n    every: always\n")
        assert "FWREGEX" in get_context(run_prompt_hook(prompt_payload("say a，b"), g),
                                        event="UserPromptSubmit")
        assert get_context(run_prompt_hook(prompt_payload("just a"), g),
                           event="UserPromptSubmit") is None


def test_prompt_every_session_always_enabled():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        make_layer(g,
            "rules:\n"
            "  - id: ps\n    event: prompt\n    keywords: foo\n    inject: SESS\n"
            "  - id: pa\n    event: prompt\n    keywords: foo\n    inject: ALWAYS\n"
            "    every: always\n"
            "  - id: pd\n    event: prompt\n    keywords: foo\n    inject: DISABLED\n"
            "    enabled: \"false\"\n")
        ctx1 = get_context(run_prompt_hook(prompt_payload("foo", session="pe-1"), g),
                           event="UserPromptSubmit")
        assert "SESS" in ctx1 and "ALWAYS" in ctx1, ctx1
        assert "DISABLED" not in ctx1, ctx1  # enabled:false は発火しない
        # 同一 session 2 回目 (時間を置いて同じ発言): every=session は抑制、always は再注入
        age_prompt_claims(g, toolhint.PROMPT_CLAIM_WINDOW_SEC + 60)
        ctx2 = get_context(run_prompt_hook(prompt_payload("foo", session="pe-1"), g),
                           event="UserPromptSubmit")
        assert ctx2 == "[toolhint] ALWAYS", ctx2
        # 別 session なら session ルールも再発火
        ctx3 = get_context(run_prompt_hook(prompt_payload("foo", session="pe-2"), g),
                           event="UserPromptSubmit")
        assert "SESS" in ctx3, ctx3
        # state は tool 側と同じ shown 共用ファイル
        state = json.load(open(os.path.join(g, "state", "pe-1.json")))
        assert state == {"shown": ["ps"]}, state


def test_prompt_claim_dedup_double_wiring():
    # 二重配線 (同じ発言で 2 プロセス起動) は先着 1 プロセスだけが注入する —
    # ことばきっかけには tool_use_id が無いので session × 発言 × ルール id の鍵で claim
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        make_layer(g,
            "rules:\n"
            "  - id: pa\n    event: prompt\n    keywords: デプロイ\n    inject: ALWAYS\n"
            "    every: always\n")
        p1 = run_prompt_hook(prompt_payload("デプロイの手順", session="pc-1"), g)
        assert get_context(p1, event="UserPromptSubmit") == "[toolhint] ALWAYS"
        claims = prompt_claim_files(g)
        assert len(claims) == 1 and claims[0].endswith(".claim"), claims
        # 後着 (同じ session・同じ発言) は every:always でも注入しない
        p2 = run_prompt_hook(prompt_payload("デプロイの手順", session="pc-1"), g)
        assert get_context(p2, event="UserPromptSubmit") is None, p2.stdout
        assert prompt_claim_files(g) == claims  # claim は増えない
        # 注入ログも 1 行のまま (抑制した側は記録しない)
        with open(os.path.join(g, "log", "injections.jsonl"), encoding="utf-8") as f:
            assert len(f.read().splitlines()) == 1
        # 発言が違えば別の鍵 — 通常どおり注入
        p3 = run_prompt_hook(prompt_payload("デプロイの手順を詳しく", session="pc-1"), g)
        assert get_context(p3, event="UserPromptSubmit") == "[toolhint] ALWAYS"
        # session が違っても別の鍵
        p4 = run_prompt_hook(prompt_payload("デプロイの手順", session="pc-2"), g)
        assert get_context(p4, event="UserPromptSubmit") == "[toolhint] ALWAYS"
        # subagent context (agent_id) が違っても別の鍵
        p5 = run_prompt_hook(prompt_payload("デプロイの手順", session="pc-1",
                                            agent_id="sub1"), g)
        assert get_context(p5, event="UserPromptSubmit") == "[toolhint] ALWAYS"
        assert len(prompt_claim_files(g)) == 4, prompt_claim_files(g)
        # 窓 (PROMPT_CLAIM_WINDOW_SEC) を過ぎた claim は「同じ発言をもう一度送った」
        # 扱い — 再注入され、claim ファイルは増えず mtime だけ更新される
        age_prompt_claims(g, toolhint.PROMPT_CLAIM_WINDOW_SEC + 60)
        p6 = run_prompt_hook(prompt_payload("デプロイの手順", session="pc-1"), g)
        assert get_context(p6, event="UserPromptSubmit") == "[toolhint] ALWAYS"
        assert len(prompt_claim_files(g)) == 4, prompt_claim_files(g)
        renewed = os.path.join(g, "state", "claims", claims[0])
        assert time.time() - os.path.getmtime(renewed) < 30
        # 張り直した直後の同じ発言はまた後着扱い
        p7 = run_prompt_hook(prompt_payload("デプロイの手順", session="pc-1"), g)
        assert get_context(p7, event="UserPromptSubmit") is None, p7.stdout
        # マッチしないと claim は作らない
        p8 = run_prompt_hook(prompt_payload("関係ない話", session="pc-9"), g)
        assert get_context(p8, event="UserPromptSubmit") is None
        assert len(prompt_claim_files(g)) == 4


def test_prompt_claim_session_rules_and_mixed():
    # every: session だけの発言: 2 回目は state で抑制 (claim も 1 回目に作られる)。
    # session + always 混在: 後着は両方とも出ない、時間を置けば always だけ再注入
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        make_layer(g,
            "rules:\n"
            "  - id: ps\n    event: prompt\n    keywords: foo\n    inject: SESS\n"
            "  - id: pa\n    event: prompt\n    keywords: foo\n    inject: ALWAYS\n"
            "    every: always\n")
        ctx1 = get_context(run_prompt_hook(prompt_payload("foo", session="pm-1"), g),
                           event="UserPromptSubmit")
        assert ctx1 == "[toolhint] SESS\n[toolhint] ALWAYS", ctx1
        assert get_context(run_prompt_hook(prompt_payload("foo", session="pm-1"), g),
                           event="UserPromptSubmit") is None
        age_prompt_claims(g, toolhint.PROMPT_CLAIM_WINDOW_SEC + 60)
        ctx3 = get_context(run_prompt_hook(prompt_payload("foo", session="pm-1"), g),
                           event="UserPromptSubmit")
        assert ctx3 == "[toolhint] ALWAYS", ctx3
        state = json.load(open(os.path.join(g, "state", "pm-1.json")))
        assert state == {"shown": ["ps"]}, state


def test_prompt_claim_key_unit():
    k = toolhint.prompt_claim_key
    base = k("s1", "", "デプロイして", ["a", "b"])
    assert re.fullmatch(r"[0-9a-f]{32}", base), base
    assert k("s1", "", "デプロイして", ["b", "a"]) == base  # ルール id の順序は不問
    assert k("s1", None, "デプロイして", ["a", "b"]) == base  # agent_id 無し = ""
    assert k("s2", "", "デプロイして", ["a", "b"]) != base
    assert k("s1", "sub", "デプロイして", ["a", "b"]) != base
    assert k("s1", "", "デプロイして!", ["a", "b"]) != base
    assert k("s1", "", "デプロイして", ["a"]) != base
    assert k(None, None, None, None) == k("unknown", "", "", [])


def test_prompt_claim_fail_open():
    # claims dir を作れない (state/claims がファイル) → claim は諦めて通常どおり注入
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        make_layer(g,
            "rules:\n"
            "  - id: pa\n    event: prompt\n    keywords: foo\n    inject: ALWAYS\n"
            "    every: always\n")
        os.makedirs(os.path.join(g, "state"))
        with open(os.path.join(g, "state", "claims"), "w", encoding="utf-8") as f:
            f.write("not a dir")
        for _ in range(2):
            p = run_prompt_hook(prompt_payload("foo", session="pf-1"), g)
            assert get_context(p, event="UserPromptSubmit") == "[toolhint] ALWAYS", p.stderr
        # 単体でも True (fail-open)
        assert toolhint.claim_prompt(g, "pf-1", "", "foo", ["pa"]) is True
        # tool 経路は prompt の claim を作らない (tool_use_id の claim だけ)
        make_layer(g,
            "rules:\n  - id: t\n    tool: Bash\n    match: foo\n    inject: T\n"
            "    every: always\n")
        os.remove(os.path.join(g, "state", "claims"))
        assert "T" in get_context(run_hook(payload(command="foo", session="pf-2",
                                                    tool_use_id="tu-x"), g))
        assert prompt_claim_files(g) == [], prompt_claim_files(g)
        assert os.path.isfile(os.path.join(g, "state", "claims", "tu-x.claim"))


def test_prompt_inline_over_limit_uses_prompt_pointer():
    # ことばきっかけの inline も同じ上限 — 落ちる先は prompt 用の既定ポインタ
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        make_layer(g,
            "rules:\n"
            "  - id: kb\n    event: prompt\n    keywords: foo\n    doc: docs/big.md\n"
            "    mode: inline\n    every: always\n",
            docs={"docs/big.md": "B" * 300})
        p = run_prompt_hook(prompt_payload("foo"), g,)
        # 上限内は本文そのまま (ヘッダ無し)
        assert get_context(p, event="UserPromptSubmit") == "[toolhint] " + "B" * 300
        p2 = run_hook(prompt_payload("foo", session="pi-2"), g,
                      env_extra={"TOOLHINT_INLINE_MAX": "64"}, args=("--event=prompt",))
        ctx = get_context(p2, event="UserPromptSubmit")
        abs_doc = os.path.join(os.path.abspath(g), "docs", "big.md")
        assert ctx == ("[toolhint] (本文が大きいので場所だけ: 300 バイト > 上限 64 バイト)\n"
                       "この話題の docs: %s — 必要なら読む" % abs_doc), ctx
        assert "上限を超える" in p2.stderr, p2.stderr


def test_prompt_tool_cross_isolation():
    # 混在層: tool 経路は tool rule のみ (文面も従来と 1 字も変わらない) /
    # prompt 経路は prompt rule のみ — 相互不発
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        make_layer(g,
            "rules:\n"
            "  - id: t1\n    tool: Bash\n    match: foo\n    inject: TOOLRULE\n"
            "    every: always\n"
            "  - id: t2\n    event: tool\n    tool: Bash\n    match: foo\n"
            "    inject: TOOL2\n    every: always\n"
            "  - id: p1\n    event: prompt\n    keywords: foo\n    inject: PROMPTRULE\n"
            "    every: always\n")
        # PreToolUse: prompt rule は tool_input に keyword があっても発火しない
        ctx = get_context(run_hook(payload(command="foo"), g))
        assert ctx == "[toolhint] TOOLRULE\n[toolhint] TOOL2", ctx
        # UserPromptSubmit: tool rule は発火しない (event: tool 明示も同じ)
        ctx2 = get_context(run_prompt_hook(prompt_payload("foo"), g),
                           event="UserPromptSubmit")
        assert ctx2 == "[toolhint] PROMPTRULE", ctx2


def test_prompt_broken_regex_fail_open_and_budget():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        make_layer(g,
            "rules:\n"
            "  - id: bad\n    event: prompt\n    keywords: \"[\"\n"
            "    find: regex\n    inject: BAD\n    every: always\n"
            "  - id: evil\n    event: prompt\n    keywords: (a+)+$\n"
            "    find: regex\n    inject: EVIL\n    every: always\n"
            "  - id: good\n    event: prompt\n    keywords: foo\n"
            "    inject: GOOD\n    every: always\n")
        t0 = time.time()
        p = run_prompt_hook(prompt_payload("foo " + "a" * 40 + "!"), g)
        elapsed = time.time() - t0
        assert elapsed < 5, "hook が timeout 相当まで停止: %.1fs" % elapsed
        ctx = get_context(p, event="UserPromptSubmit")
        assert ctx == "[toolhint] GOOD", ctx  # 壊れ regex / 予算超過はスキップ
        assert "正規表現" in p.stderr, p.stderr
        assert "時間予算" in p.stderr, p.stderr


def test_prompt_invalid_find_falls_back_to_substring():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        make_layer(g,
            "rules:\n"
            "  - id: iv\n    event: prompt\n    keywords: foo\n"
            "    find: bogus\n    inject: FALLBACK\n    every: always\n")
        p = run_prompt_hook(prompt_payload("say foo"), g)
        assert "FALLBACK" in get_context(p, event="UserPromptSubmit")
        assert "find" in p.stderr, p.stderr  # 不正値は警告して substring に倒す


def test_prompt_empty_or_missing_prompt_exit0():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        make_layer(g,
            "rules:\n"
            "  - id: p1\n    event: prompt\n    keywords: foo\n    inject: X\n")
        # prompt キー無し / 空文字は何もしない (exit 0)
        p = run_prompt_hook({"session_id": "s", "cwd": "/tmp"}, g)
        assert p.returncode == 0 and p.stdout.strip() == ""
        p2 = run_prompt_hook(prompt_payload(""), g)
        assert p2.returncode == 0 and p2.stdout.strip() == ""
        # stdin 不正も fail-open
        p3 = run_prompt_hook(global_dir=g, raw="not json")
        assert p3.returncode == 0 and p3.stdout.strip() == ""


def test_prompt_unit_helpers():
    # rule_event: キー無し = tool / event: tool = tool / event: prompt = prompt /
    # 不明値は tool に倒す
    assert toolhint.rule_event({"id": "a"}) == "tool"
    assert toolhint.rule_event({"id": "a", "event": "tool"}) == "tool"
    assert toolhint.rule_event({"id": "a", "event": "prompt"}) == "prompt"
    assert toolhint.rule_event({"id": "a", "event": "bogus"}) == "tool"
    # split_prompt_keywords: `,` `、` `，` の 3 種区切り + trim + 空要素除去
    assert toolhint.split_prompt_keywords("a, b、 c") == ["a", "b", "c"]
    assert toolhint.split_prompt_keywords("foo,,") == ["foo"]
    assert toolhint.split_prompt_keywords(" ,、 ") == []
    assert toolhint.split_prompt_keywords("本番，ほんばん") == ["本番", "ほんばん"]
    assert toolhint.split_prompt_keywords("a，b、c, d，") == ["a", "b", "c", "d"]
    assert toolhint.split_prompt_keywords(" ，、, ") == []
    assert toolhint.PROMPT_KEYWORD_SEPARATORS == ",、，"
    # rule_matches の防御: tool キー欠落 (prompt rule 等) は常に False
    assert toolhint.rule_matches({"id": "x"}, "Bash", "{}") is False
    assert toolhint.rule_matches(
        {"id": "x", "event": "prompt", "keywords": "Bash"}, "Bash", "{}") is False
    # rule_matches_prompt の防御: keywords 欠落 / 空 prompt は False
    assert toolhint.rule_matches_prompt({"id": "x", "event": "prompt"}, "foo") is False
    assert toolhint.rule_matches_prompt(
        {"id": "x", "event": "prompt", "keywords": "foo"}, "") is False
    # substring は .lower() 比較 (casefold ではない — JS toLowerCase 相当):
    # ß.casefold() == "ss" だが lower では別物のまま
    assert toolhint.rule_matches_prompt(
        {"id": "x", "event": "prompt", "keywords": "ss"}, "straße") is False


def test_prompt_load_rules_event_validation():
    # load_rules の必須キー検証は event 別 (keywords 無し prompt rule はスキップ)
    with tempfile.TemporaryDirectory() as td:
        make_layer(td,
            "rules:\n"
            "  - id: nokw\n    event: prompt\n    inject: X\n"
            "  - id: ok\n    event: prompt\n    keywords: foo\n    inject: Y\n"
            "  - id: notool\n    inject: Z\n"
            "  - id: t\n    tool: Bash\n    inject: W\n")
        err = io.StringIO()
        with contextlib.redirect_stderr(err):
            rules = toolhint.load_rules(td)
        assert [r["id"] for r in rules] == ["ok", "t"], rules
        assert "keywords がない" in err.getvalue(), err.getvalue()
        assert "tool がない" in err.getvalue(), err.getvalue()


# ---------------------------------------------------------------------------
# fail-open
# ---------------------------------------------------------------------------

def test_broken_yaml_fail_open():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        make_layer(g, "rules:\n  - id: a\n    tool: Bash\n    nested:\n      x: 1\n")
        p = run_hook(payload(command="grep foo"), g)
        assert p.returncode == 0
        assert p.stdout.strip() == ""


def test_non_json_stdin_fail_open():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        make_layer(g, "rules:\n  - id: a\n    tool: Bash\n    inject: X\n")
        p = run_hook(global_dir=g, raw="this is not json")
        assert p.returncode == 0
        assert p.stdout.strip() == ""


# ---------------------------------------------------------------------------
# 注入ログ (log/injections.jsonl)
# ---------------------------------------------------------------------------

def test_injection_log_written():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        proj_root = os.path.join(td, "proj")
        proj_layer = os.path.join(proj_root, ".claude", "toolhint")
        make_layer(g,
            "rules:\n  - id: gl\n    tool: Bash\n    match: foo\n    doc: docs/gl.md\n",
            docs={"docs/gl.md": "body\n"})
        make_layer(proj_layer,
            "rules:\n  - id: pr\n    tool: Bash\n    match: foo\n    inject: PROJ\n")
        p = run_hook(payload(command="foo bar", cwd=proj_root, session="log-1",
                             tool_use_id="tu-log"), g)
        assert get_context(p) is not None
        log_path = os.path.join(g, "log", "injections.jsonl")
        with open(log_path, encoding="utf-8") as f:
            lines = [json.loads(l) for l in f.read().splitlines()]
        assert len(lines) == 2, lines
        by_id = {e["rule_id"]: e for e in lines}
        gl = by_id["gl"]
        assert gl["layer"] == "global"
        assert gl["doc"] == os.path.join(os.path.abspath(g), "docs", "gl.md")
        assert gl["session_id"] == "log-1" and gl["tool_name"] == "Bash"
        assert gl["cwd"] == proj_root
        assert re.match(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$", gl["ts"]), gl
        # どの操作がこの docs を呼んだかをログから遡れる (mode/every/原文/tool_use_id)
        assert gl["mode"] == "pointer" and gl["every"] == "session"
        assert gl["input_excerpt"] == "foo bar"
        assert gl["tool_use_id"] == "tu-log"
        pr = by_id["pr"]
        assert pr["layer"] == "project" and pr["doc"] is None
        # input_excerpt は command 優先・上限 160 文字、command 不在なら flat の先頭
        assert toolhint.make_input_excerpt({"command": "x" * 500}, "flat") == "x" * 160
        assert toolhint.make_input_excerpt({"file_path": "/tmp/a"}, '{"file_path":"/tmp/a"}') \
            == '{"file_path":"/tmp/a"}'
        # 2 回目 (every=session 抑制で注入なし) はログも増えない
        p2 = run_hook(payload(command="foo bar", cwd=proj_root, session="log-1"), g)
        assert get_context(p2) is None
        with open(log_path, encoding="utf-8") as f:
            assert len(f.read().splitlines()) == 2


def test_injection_log_broken_dir_fail_open():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        make_layer(g, "rules:\n  - id: a\n    tool: Bash\n    match: foo\n    inject: X\n")
        # log を「ディレクトリでなくファイル」にして makedirs を失敗させる
        with open(os.path.join(g, "log"), "w", encoding="utf-8") as f:
            f.write("not a dir")
        p = run_hook(payload(command="foo"), g)
        assert p.returncode == 0, p.stderr
        assert get_context(p) == "[toolhint] X"  # 注入自体は成功する


def test_injection_log_rotation_halves():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        make_layer(g, "rules:\n  - id: a\n    tool: Bash\n    match: foo\n    inject: X\n")
        log_dir = os.path.join(g, "log")
        os.makedirs(log_dir)
        log_path = os.path.join(log_dir, "injections.jsonl")
        line = json.dumps({"ts": "2026-01-01T00:00:00Z", "rule_id": "old"}) + "\n"
        n = (2 * 1024 * 1024) // len(line) + 16
        with open(log_path, "w", encoding="utf-8") as f:
            f.write(line * n)
        size_before = os.path.getsize(log_path)
        assert size_before > 2 * 1024 * 1024
        assert get_context(run_hook(payload(command="foo", session="rot-1"), g)) \
            == "[toolhint] X"
        size_after = os.path.getsize(log_path)
        assert size_after < size_before, (size_before, size_after)
        # 旧内容は半分以下に切られ、追記は今回の注入 1 行分 (< 1KB) だけ
        assert size_after <= size_before // 2 + 1024, (size_before, size_after)
        with open(log_path, encoding="utf-8") as f:
            parsed = [json.loads(l) for l in f.read().splitlines()]  # 全行 JSON のまま
        assert parsed[-1]["rule_id"] == "a"  # 今回の注入が末尾に残る
        # ローテーションは atomic 置換 — tmp 残骸が残らない (.lock は残ってよい)
        leftovers = [n for n in os.listdir(log_dir) if n.endswith(".tmp")]
        assert leftovers == [], leftovers


def test_injection_log_rotation_atomic_and_interrupt_safe():
    """ローテーションの書き戻しが tmp+fsync+os.replace であること:
    中断 (fsync 失敗 = rename 前のクラッシュ相当) では元ファイル無傷 + tmp 掃除、
    正常系では完成品への置換のみ (読み手が途中状態を見ない)。"""
    with tempfile.TemporaryDirectory() as td:
        path = os.path.join(td, "injections.jsonl")
        line = (json.dumps({"rule_id": "old"}) + "\n").encode("utf-8")
        n = (toolhint.LOG_MAX_BYTES // len(line)) + 16
        with open(path, "wb") as f:
            f.write(line * n)
        before = os.path.getsize(path)
        assert before > toolhint.LOG_MAX_BYTES

        def boom(fd):
            raise OSError("simulated crash before rename")
        real_fsync = os.fsync
        os.fsync = boom
        try:
            toolhint._rotate_log(path)  # best-effort — 例外は外に漏れない
        finally:
            os.fsync = real_fsync
        assert os.path.getsize(path) == before  # 元ファイル無傷
        assert os.listdir(td) == ["injections.jsonl"], os.listdir(td)  # tmp なし

        toolhint._rotate_log(path)  # 正常系: 半分に切られ全行 JSON のまま
        after = os.path.getsize(path)
        assert after <= before // 2 + len(line), (before, after)
        with open(path, encoding="utf-8") as f:
            for l in f.read().splitlines():
                json.loads(l)
        assert os.listdir(td) == ["injections.jsonl"], os.listdir(td)


# ---------------------------------------------------------------------------
# samples が実際に動く (手動確認例の自動化)
# ---------------------------------------------------------------------------

def test_samples_grep_rule_fires():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        shutil.copytree(SAMPLES_DIR, g)
        ctx = get_context(run_hook(payload(command="grep -r foo ."), g))
        assert "search-tools.md" in ctx, ctx
        assert ctx.startswith("[toolhint] この操作の docs: "), ctx
        # 6 ルールすべて id/doc が引ける (doc 実在チェック込み)。操作 5 + ことば 1
        rules = toolhint.load_rules(g)
        assert len(rules) == 6, rules
        for r in rules:
            assert os.path.isfile(os.path.join(g, r["doc"])), r
        assert [toolhint.rule_event(r) for r in rules].count("prompt") == 1, rules
        # 見本のことばきっかけ (deploy-docs) も samples だけで発火する
        ctx = get_context(run_prompt_hook(prompt_payload("そろそろ deploy したい"), g),
                          event="UserPromptSubmit")
        assert "deploy-checklist.md" in ctx, ctx
        # 見本の操作きっかけ (rm -rf / git push --force / npm publish) が想定コマンドで発火する
        for cmd, doc in (("rm -rf ./build", "rm-rf.md"),
                         ("git push --force origin main", "git-force-push.md"),
                         ("npm publish --access public", "npm-publish.md"),
                         ("pip install requests", "pip-venv.md")):
            ctx = get_context(run_hook(payload(command=cmd), g))
            assert doc in ctx, (cmd, ctx)


def test_global_dir_env():
    """global 層の env: TOOLHINT_GLOBAL があればそれ、無ければ ~/.claude/toolhint。"""
    old = os.environ.get("TOOLHINT_GLOBAL")
    try:
        os.environ["TOOLHINT_GLOBAL"] = "/tmp/some-layer"
        assert toolhint.find_global_dir() == "/tmp/some-layer"
        os.environ.pop("TOOLHINT_GLOBAL")
        assert toolhint.find_global_dir() == os.path.join(
            os.path.expanduser("~"), ".claude", "toolhint")
    finally:
        if old is None:
            os.environ.pop("TOOLHINT_GLOBAL", None)
        else:
            os.environ["TOOLHINT_GLOBAL"] = old


# ---------------------------------------------------------------------------
# runner
# ---------------------------------------------------------------------------

def main():
    tests = [(n, f) for n, f in sorted(globals().items())
             if n.startswith("test_") and callable(f)]
    passed, failed = 0, 0
    for name, fn in tests:
        try:
            fn()
        except Exception as e:
            failed += 1
            print("FAIL %s: %r" % (name, e))
        else:
            passed += 1
            print("PASS %s" % name)
    print("---")
    print("%d passed, %d failed, %d total" % (passed, failed, passed + failed))
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
