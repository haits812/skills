# 用語集 — この repo で使う言葉

README / docs / GUI / CLI で同じ意味で使う言葉の定義。迷ったらここに合わせる。

- **ルール** — 「きっかけ + 渡すもの」の 1 組。manager GUI の一覧に並ぶ単位で、doc ファイル 1 つとそれに紐づくきっかけ (triggers) からなる。利用者向けの文言ではこの語で統一する。
- **doc ファイル** — ルールの本文の実体 (`docs/*.md`)。ファイルそのものを指すときだけこの語を使う。`rules.yaml` の各エントリを指す内部語 rule とは別物。
- **きっかけ** — ルールが発火する条件。次の 2 種類がある。
  - **操作きっかけ** — agent がツールを使う直前 (PreToolUse) に、tool 名と入力への正規表現で反応する。
  - **ことばきっかけ** — ユーザーの発言 (UserPromptSubmit) に `keywords` で反応する (`event: prompt`)。`keywords` は `,` / `、` / `，` 区切りで複数 — いずれか 1 つで発火。記法は engine/README.md。GUI の一覧では両者を 1 本に混ぜ、種別チップで絞る。CLI では `add --event prompt --id X --keywords "<a, b>" …` で作り、`rule update <id> --keywords "…"` で直し、`test --event prompt "<発言>"` で dry-run する (`--event` を省略すると操作きっかけ)。agent 起案 (「ことばで頼む」) は GUI のみ。
- **dry-run** — state を変えずに「この入力に何が注入されるか」を見ること (`toolhint test` / GUI の [判定])。操作きっかけにはコマンド文字列を、ことばきっかけには発言を渡す (`toolhint test --event prompt "<発言>"`)。`every` の抑制は無視して全マッチを出す。
- **層 (layer)** — ルールと doc の置き場。追加層 (`layers.d/*`) → global 層 (`~/.claude/toolhint/`) → project 層 (`<repo>/.claude/toolhint/`) の順にマージし、同じ `id` は後勝ち。
- **適用範囲 (scope)** — ルールを「作業ディレクトリがこのパターンに一致する場所でだけ発火する」に絞るキー (値は作業ディレクトリの絶対パスへの glob)。操作きっかけ・ことばきっかけ共通。適用範囲つきのルールは層の 2 本目のファイル **rules-scoped.yaml** に置く (この形式を知らない古い版の engine は rules.yaml しか読まないので、範囲を無視した発火が起きない)。GUI の新規作成で層 (このプロジェクト / 全体) を選ぶ欄は「**保存先**」で、これとは別物 — 保存先は「どの層に書くか」、適用範囲は「どの作業ディレクトリで発火するか」(GUI に適用範囲の編集欄はまだ無く、付け外しは CLI か手編集)。
- **確かめるドック** — manager GUI 下端の全幅の作業面。[判定] = 注入テスト (実行ボタンは「試す」) / [記録] = 全ルール横断の注入履歴、の 2 タブ。
- **全体層モード** — manager GUI を全体層だけを扱う画面にする起動オプション (`TOOLHINT_GLOBAL_ONLY`)。共有ルール専用のインスタンスを立てる / 別の管理画面に組み込むときの姿で、対象プロジェクトの切替・プロジェクト層・注入の稼働表示を出さない。変わるのは画面だけで API と認可は同じ (画面からの保存先は全体層に固定されるが、API 直叩きではプロジェクト層にも書ける)。
- **配線** — toolhint の hook が Claude Code に登録されていて、実際に注入が起きる状態。plugin install か settings.json への手書きで配線する。未配線ならルールを作っても注入は起きない (GUI は「未配線」と表示する)。
- **注入** — hook が `additionalContext` として agent に文面を渡すこと。`pointer` (doc へのポインタ 1 行) と `inline` (doc 本文ごと) の 2 通り。
- **fail-open** — hook がどんな異常でも exit 0 で終わり、ツール実行やユーザー発言を止めないこと。engine の設計原則。
