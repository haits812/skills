# toolhint 導入ガイド

初見の開発者が 15 分で「導入 → 動作確認 → 最初の doc 登録 → 日常運用」まで辿り着くための手順書。
toolhint が何であるかは [ルートの README](../README.md) を先に 1 分だけ読むこと。

1. [前提](#1-前提)
2. [インストール](#2-インストール)
3. [動作確認](#3-動作確認)
4. [manager GUI の起動](#4-manager-gui-の起動)
5. [最初の doc を作る](#5-最初の-doc-を作る)
6. [project 層と global 層の使い分け](#6-project-層と-global-層の使い分け)
7. [バックアップと持ち出し](#7-バックアップと持ち出し)
8. [トラブルシュート](#8-トラブルシュート)
9. [アーキテクチャ](#9-アーキテクチャ)

## 1. 前提

- **python3** (3.9 以上で動作確認) — engine / core / CLI の実行に必要。標準ライブラリのみ (`pip install` 不要)。
  **`python3` が PATH に通っていること** — 無いと hook は無音で発火せず、`doctor` も動かない
  ([§8](#注入が一度も出ない-python3-が-path-に無い))
- **Claude Code (`claude` CLI)** — hook の実行環境。`toolhint add --ai` と GUI の
  agent 起案は `claude` CLI ログイン済みが前提
- **Node.js >= 18** — manager GUI を使う場合のみ (`npm install` なしで起動できる)

## 2. インストール

インストールは 2 経路 — **経路 A: GitHub から直接** (普通に使う人はこちら。clone は
Claude Code がやる) / **経路 B: 手元に clone** (コードを触る・オフラインで入れる。
GUI はどちらの経路でも動く — [§4](#4-manager-gui-の起動))。plugin を使わず hooks を手で書く方法は
[補足: 手動 hooks 設定](#補足-手動-hooks-設定-plugin-を使わない)。

以降このガイドの `toolhint` コマンドは CLI (`cli/toolhint`) を指す。実体の場所は経路で
変わる — 経路 A は `~/.claude/plugins/marketplaces/toolhint/cli/toolhint`、経路 B は
clone 先の `cli/toolhint`。どちらも PATH に通す前提で書く (各経路の手順に PATH の行がある)。

手順中の `./toolhint/...` の相対パスは、経路 B で clone した**親**ディレクトリ
(`toolhint/` が見える場所) が基準 — **経路 A の人は `./toolhint/` を
`~/.claude/plugins/marketplaces/toolhint/` に読み替える** (Claude Code が作る clone。
中身は同じ repo)。この基準を離れるのは [§5](#5-最初の-doc-を作る) で自分のプロジェクトへ
`cd` するときだけで、そこから先の engine 直叩きは clone 先の絶対パスで書いてある。

### 経路 A: GitHub から直接 (推奨)

どのディレクトリで打ってもよい:

```sh
claude plugin marketplace add AI-Driven-R-D-Dept/toolhint   # marketplace 名 = toolhint
claude plugin install toolhint@toolhint
export PATH="$HOME/.claude/plugins/marketplaces/toolhint/cli:$PATH"
```

- `marketplace add` が repo を `~/.claude/plugins/marketplaces/toolhint/` に clone し、
  `install` が engine をその時点の版で
  `~/.claude/plugins/cache/toolhint/toolhint/<version>/` へスナップショットコピーする
  (実際に hook として動くのはこちら)
- **repo が private の間は、add する側に GitHub の認証が要る** (`gh auth login` 済みか
  SSH 鍵。無いと add の clone が失敗する)
- 更新は 2 段: `claude plugin marketplace update toolhint` (clone を最新へ) →
  `claude plugin update toolhint@toolhint` (実 hook を差し替え)。`toolhint doctor` は
  この経路でも plugin スナップショットの鮮度を見る (clone の engine と実 hook を比較 —
  [§8 plugin が stale](#plugin-が-stale-repo-を更新したのに挙動が古い))
- `~/.claude/plugins/marketplaces/toolhint/` は Claude Code の管理領域 — 手で編集しない
  (update で上書きされる)。コードを触るなら経路 B

### 経路 B: 手元に clone

repo ルートの `.claude-plugin/marketplace.json` が local marketplace 定義
(plugin 本体は `./engine`)。clone して、その場所を marketplace として登録する:

```sh
git clone https://github.com/AI-Driven-R-D-Dept/toolhint.git toolhint
export PATH="$PWD/toolhint/cli:$PATH"
claude plugin marketplace add ./toolhint     # marketplace 名 = toolhint
claude plugin install toolhint@toolhint
```

⚠ install は engine を**その時点の版でスナップショットコピー**する。repo を
`git pull` しただけでは実 hook に反映されない — engine 更新後は
`claude plugin update toolhint@toolhint` で差し替える
([§8 plugin が stale](#plugin-が-stale-repo-を更新したのに挙動が古い))。

### 補足: 手動 hooks 設定 (plugin を使わない)

`~/.claude/settings.json` (または project の `.claude/settings.json`) に
hook を直接書く (PreToolUse = 操作きっかけ / UserPromptSubmit = ことばきっかけの 2 本):

```json
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "*",
        "hooks": [
          {
            "type": "command",
            "command": "\"/絶対パス/toolhint/engine/scripts/toolhint.py\"",
            "timeout": 5
          }
        ]
      }
    ],
    "UserPromptSubmit": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "\"/絶対パス/toolhint/engine/scripts/toolhint.py\" --event=prompt",
            "timeout": 5
          }
        ]
      }
    ]
  }
}
```

`command` のパスは plugin の `hooks.json` と同じくダブルクォートで囲む (JSON 内なので
`\"` でエスケープ) — clone 先のパスに空白があっても壊れない。クォート無しだと空白の位置で
コマンドが切れ、hook は exit 127 で終わって注入が無音で消える (ツール実行は止まらない)。

**既に `~/.claude/settings.json` を使っている場合は、上のスニペットで丸ごと置き換えない
こと** — 既存の設定 (permissions や他の hooks) が消える。既存の `"hooks"` →
`"PreToolUse"` / `"UserPromptSubmit"` 配列があればそこへ要素を追記し、無いキーだけを足す。

plugin と手動設定が二重配線になっても、engine 側の claim 機構で注入は 1 回だけになる —
操作きっかけは payload の `tool_use_id`、ことばきっかけはセッション ID・発言内容・一致した
ルール集合から作ったハッシュ鍵を先取りした 1 プロセスだけが注入する
(仕組みは [engine/README.md](../engine/README.md) 参照)。
ことばきっかけの鍵は 10 秒の窓で先取りするため、同じ session で同じ発言を 10 秒以内に
送り直した場合も後着扱いで注入されない (`every: always` のルールでも。10 秒を過ぎた再送は
通常どおり判定される)。

## 3. 動作確認

インストール直後はルールが空。まず配管が通っているかを 2 コマンドで確認する:

```sh
toolhint doctor
```

```
plugin: 0.5.2 (最新)
ok — 問題なし (全層とも健全)
```

(`0.5.2` の部分は入れた plugin の version)

`doctor` は両層 (global / project — 層の意味は [§6](#6-project-層と-global-層の使い分け))
の rules.yaml の parse 可否・doc の実在・backup 状態・plugin スナップショットの鮮度を
まとめて診断する (問題あり = exit 1)。`plugin:` の行は健全でも必ず 1 行出る —
`(最新)` なら配布済み plugin が repo の engine と一致していて、plugin の検査も通っている。
食い違えば `(stale — repo の engine と食い違う)` + 「注意」行
([§8](#plugin-が-stale-repo-を更新したのに挙動が古い))、plugin を入れず手動 hooks 設定
([§2 補足](#補足-手動-hooks-設定-plugin-を使わない)) なら `plugin: 未インストール (…)` (それで正常)。
既に global 層を使っている環境では層の状態行と「注意 backup なし」が付くが、
末尾が「ok — 問題なし (注意 N 件)」なら正常 (backup は [§7](#7-バックアップと持ち出し) で設定する)。

次に dry-run — 「このコマンドを打ったら何が注入されるか」を state を変えずに見る:

```sh
toolhint test "grep -r foo ."
```

```
マッチなし (tool=Bash, input='grep -r foo .')
```

ルール登録前なので「マッチなし」が正常 (既に global 層でルールを使っている環境では、
そのルールがマッチして注入内容が出ることがある — それも正常)。ルールを作ったあと
([§5](#5-最初の-doc-を作る)) に再実行すると注入内容が表示される。

`--event` を省略した `test` は操作きっかけだけを見る。ことばきっかけ (ユーザーの発言に
反応するルール) の dry-run は `--event prompt` を付けて発言を渡す:

```sh
toolhint test --event prompt "そろそろデプロイしたい"
```

```
マッチなし (event=prompt, input='そろそろデプロイしたい')
```

(操作きっかけの `test` がマッチ 0 件で、読み込んだ層にことばきっかけがあるときは、末尾に 1 行案内が出る:
「この層にはことばきっかけが N 件ある — 発言に対する dry-run は `toolhint test --event prompt "<発言>"`」)

hook 単体を直接叩いて確認することもできる (Claude Code が hook に渡す JSON を
stdin へ流す — マッチが無ければ何も出力せず exit 0。clone の親ディレクトリに居る前提で
`./toolhint/...` と書いている)。経路 A の読み替え先 (marketplace clone) は実 hook
(cache のスナップショット) とは別のコピーなので、更新直後に挙動が食い違ったら
`claude plugin update toolhint@toolhint` で揃える
([§8](#plugin-が-stale-repo-を更新したのに挙動が古い)):

```sh
echo '{"session_id":"s1","cwd":"'$PWD'","tool_name":"Bash","tool_input":{"command":"grep -r foo ."}}' \
  | ./toolhint/engine/scripts/toolhint.py
```

## 4. manager GUI の起動

サーバは起動したターミナルを占有するので、**別のターミナルを開き**、同じく clone の
親ディレクトリで起動する (経路 A で入れた場合は
`node ~/.claude/plugins/marketplaces/toolhint/manager/server.mjs` — 動くものは同じ):

```sh
node ./toolhint/manager/server.mjs
```

```
[manager] toolhint manager: http://127.0.0.1:4517/
[manager] core (新契約 docs): /path/to/toolhint/core/toolhint_core.py (real)
```

- 既定は **loopback bind (127.0.0.1:4517) — 同一マシンからのみアクセス可で、token 不要**。
  まずはこれで使う
- `PORT` (既定 4517) / `HOST` (既定 127.0.0.1) は環境変数で変更できる
- Node 標準 http のみで動く — `npm install` なしで起動できる。「ことばで頼む」
  (agent 起案) は Agent SDK (`manager/ で npm install` した場合) を優先し、無ければ
  `claude -p` 子プロセスへ自動フォールバック (どちらも claude CLI ログイン済みが前提)。
  経路 A の clone は管理領域なので npm install はしない — フォールバックで足りる
- 画面上部の「対象プロジェクト」に対象 repo の絶対パスを入れて使う (初期値は起動した
  場所 — git repo の中で起動すればその root、それ以外は起動時のディレクトリ)
- `TOOLHINT_GLOBAL_ONLY=1` で起動すると **全体層だけを扱う画面**になる (対象プロジェクトの
  切替とプロジェクト層を出さない — 共有ルール層の編集面として別の管理画面に組み込む /
  共有ルール専用のインスタンスを立てる用途。
  対象欄の代わりに出る表示ラベルは `TOOLHINT_GLOBAL_LABEL`、既定「全体」)。
  変わるのは画面だけで、API の挙動と認可は既定のまま (API 直叩きではプロジェクト層にも
  書ける — [下の補足](#補足-全体層だけを扱うモード-共有ルール層の編集面として組み込む))

### 補足: リモート (LAN / VPN) に公開する場合 (TOOLHINT_TOKEN)

**非 loopback bind (`HOST=0.0.0.0` 等) は `/api` 全体に認証 token が必須**になり、
アクセスに使うホスト名/IP の許可も要る:

```sh
HOST=0.0.0.0 TOOLHINT_TOKEN=<秘密の文字列> TOOLHINT_ALLOWED_HOSTS=<公開するホスト名や IP> node ./toolhint/manager/server.mjs
```

- `TOOLHINT_TOKEN` を指定しなければ起動ごとに自動生成され、起動ログに出る
  (再起動すると URL も変わる)
- GUI は起動ログの `?token=` 付き URL で開く。API 直叩きは `X-Toolhint-Token`
  ヘッダ (または `Authorization: Bearer`)。token 無し/誤りは 401
- **`HOST=0.0.0.0` のとき、アクセスに使うホスト名/IP は `TOOLHINT_ALLOWED_HOSTS` に
  列挙が要る (自ホスト名・localhost 以外は 403)** — `HOST=0.0.0.0` は「全インターフェースで
  待つ」の意味で、Host の許可名にはならない。LAN の IP (例 `192.168.1.17`) や VPN の名前で
  開くなら、その値をカンマ区切りで並べる (Host ヘッダ allowlist = DNS rebinding 対策)。
  許可されていない Host は token が合っていても 403 で、応答本文に
  「この Host は許可されていない: "…" (必要なら TOOLHINT_ALLOWED_HOSTS で追加)」と出る
- 変更系 POST は同一オリジン + `Content-Type: application/json` のみ (CSRF 対策)

### 補足: GUI をサブパス配下で公開する (リバースプロキシ)

`https://<host>/<プレフィックス>/` で出したい場合は、プレフィックスを剥がして manager の
ルートへ転送する (`/<プレフィックス>/api/state` → `/api/state`)。アセット参照と API 呼び出しは
ページ基準の相対なのでそのまま動く — 末尾スラッシュ付きの URL で開くこと (無いと 1 階層上に解決される)。
POST は Origin と Host の一致検査があるので、プロキシ側で `Origin` をこのサーバのオリジンへ
書き換える (Host を素通しする構成なら `TOOLHINT_ALLOWED_HOSTS` に足す)。token 必須で運用するなら
プロキシが `Authorization: Bearer <token>` を足せば、ブラウザ側に token を渡さずに済む。
`HOST=0.0.0.0` で待ち受ける場合も同じで、アクセスに使うホスト名/IP (公開ホスト名・LAN の IP・
VPN の名前) は `TOOLHINT_ALLOWED_HOSTS` に列挙が要る — 自ホスト名・localhost 以外は 403 になる
(`HOST=0.0.0.0` は「全インターフェースで待つ」の意味で、Host の許可名にはならない)。

### 補足: 全体層だけを扱うモード (共有ルール層の編集面として組み込む)

`TOOLHINT_GLOBAL_ONLY=1` で起動すると、GUI は全体層 (`~/.claude/toolhint/`) だけを扱う画面になる。
チーム共有のルールを 1 箇所で編集させたいとき — 別の管理画面へ iframe や上記リバースプロキシで
組み込むときや、共有ルール専用のインスタンスを 1 つ立てるとき — の姿。
対象プロジェクト (cwd) の切替欄とプロジェクト層は出ず、画面は `?cwd=` や前回値も無視してサーバ既定の
対象で動く — 画面からの保存先は常に全体層なので、GUI 操作で「共有のつもりでプロジェクト層に保存した」が起きない。
注入の稼働表示も出さない (このサーバが動く 1 台の検知でしかなく、共有面としては誤読を招くため)。
対象欄の代わりに出る固定の表示ラベルは `TOOLHINT_GLOBAL_LABEL` で変えられる (既定「全体」)。
**この保証は画面 (GUI) の側だけ** — API の挙動と認可は既定と同じで、`/api/state?cwd=` の指定や
`/api/savedoc` に `layer=project` を渡す直叩きは通常どおり通る (プロジェクト層にも書ける)。
API を直接叩ける相手にまで全体層限定を強制したい場合は、このモードではなく token
([上の補足](#補足-リモート-lan--vpn-に公開する場合-toolhint_token)) やプロキシ側の認可で守ること。

## 5. 最初の doc を作る

**先に cwd を決める** — `add` は既定で **cwd の project 層** に書く。ルールを入れたい
自分のプロジェクトの dir へ `cd` してから実行すること (toolhint の clone 内で打つと
clone 自身にルールが入る)。マシン全体に効かせたい場合は場所を問わず `--layer global`。
ここから先は clone の親ディレクトリに居ないので、`./toolhint/...` の相対パスは通らない —
`toolhint` コマンドは PATH に通してあればそのまま、通していなければ clone 先の絶対パス
(`/絶対パス/toolhint/cli/toolhint`) で打つ。

### GUI「ことばで頼む」

1. GUI を開き、「対象プロジェクト」が正しいことを確認
2. 「**+ 新しい doc**」→「**ことばで頼む**」タブ
3. きっかけの種類を選ぶ — **操作に反応** (tool の実行直前) / **ことばに反応**
   (ユーザーの発言に反応)
4. 要望を書く — 例:「grep を打とうとしたら rg を勧めて」/「デプロイの話が出たら
   デプロイ前チェックリストを渡して」→「起案してもらう」
5. 起案された doc 名・本文・きっかけ (操作 = tool / match 正規表現、ことば =
   keywords / 一致のしかた) と「実際に届く文面」をプレビューで確認・手直しして
   「この内容で保存」

(自分で全部書きたい場合は「手動で作る」タブ)

agent に届く一文は、きっかけの「**届く文面**」欄で書き換えられる (空 = 標準文面。
`{doc}` は doc の絶対パス、`{id}` はルール id に展開される)。

### CLI で (手動指定)

```sh
toolhint add --id use-rg --tool Bash --match '\bgrep\b' \
  --doc-name use-rg.md \
  --doc-content 'grep より rg (ripgrep) を使う。`rg -n "pattern"` が速く .gitignore も尊重する。'
```

```
[toolhint] project 層は backup 未設定 (履歴は上書き前の .bak 1 世代のみ) — `toolhint backup init --layer project` で git 化 (この案内は 7 日に 1 回)
追記した: /path/to/project/.claude/toolhint/rules.yaml
doc     : /path/to/project/.claude/toolhint/docs/use-rg.md
```

(1 行目の backup 案内は正常 — [§7](#7-バックアップと持ち出し) で設定すると消える)

既定の層は project (`--layer global` で global 層へ)。`--inject` / `--mode inline` /
`--every always` などの追加フラグは `toolhint add --help` に一覧があり、各キーの意味は
[engine/README.md](../engine/README.md)「ルール記法」。

### CLI で (agent 起案)

```sh
toolhint add --ai "grep を使ったら rg を勧めて"
```

`claude -p` がルール (id / match 正規表現 / doc 本文) を起案し、追記プレビューを
出して y/n 確認してから書く。非対話 (stdin が tty でない) 時は `--yes` が必須。
`claude` CLI にログイン済みが前提 — 未ログインだと `claude -p` の失敗 (その出力つき) として止まる。
要望の文字列は `--ai` の直後に置く (`--layer global` などのオプションはその後ろ)。
`add --ai` は操作きっかけ専用 — ことばきっかけの agent 起案は GUI の「ことばで頼む」で行う
(手で書くなら次の `add --event prompt`)。

### ことばきっかけ (ユーザーの発言に反応) を作るには

ことばきっかけ (`event: prompt`) は CLI でも作成・編集・dry-run ができる —
作成は `add --event prompt`、編集は `rule update <id> --keywords`、dry-run は `test --event prompt`。
`--event` を省略した `add` / `test` は従来どおり操作きっかけ。GUI なら「ことばで頼む」
(agent 起案 — CLI には無い) か「手動で作る」で、きっかけの種類に「ことばに反応」を選ぶ。
各キーの意味は [engine/README.md](../engine/README.md)「ルール記法」の「ことばきっかけ」。

**作成** — 形は次のとおり (操作きっかけの `--tool` / `--match` の代わりに `--keywords`。
`--id` は操作きっかけと同じく層内で一意の名前で、必須):

```
toolhint add --event prompt --id X --keywords "<a, b>" [--find substring|word|regex] [--case sensitive|insensitive] (--doc-name X --doc-content Y | --inject "…") [--every session|always] [--mode pointer|inline] [--layer global|project] [--scope …] [--yes]
```

```sh
toolhint add --event prompt --id deploy-docs --keywords "デプロイ, deploy" \
  --doc-name deploy.md \
  --doc-content 'デプロイ前チェックリスト: テストが全部通っている / migration の有無 / 戻し方を確認してから。'
```

- `--keywords` は `,` / `、` / `，` 区切りで複数 (半角カンマ・読点・全角カンマのどれでもよい) —
  いずれか 1 つで発火。区切りだけで語が 1 つも残らない指定
  (「keywords に有効な要素がない (区切り文字のみ)」) は拒否される。`--find` (既定 substring =
  部分一致。word = 語単位 / regex = keywords 全体を 1 つの正規表現として扱う) と `--case`
  (既定 insensitive = 大小を区別しない) は rules.yaml の `find` / `case` そのもの
- doc を作らず文面だけ渡すなら `--doc-name` / `--doc-content` の代わりに `--inject "…"`
  (`{id}` が使える。`{doc}` は doc があるときだけ — doc 無しで `{doc}` を書くと拒否される)
- `--event prompt` に `--tool` / `--match` を付けると
  「event: prompt のルールに tool は使えない (操作きっかけ専用のキー)」(`--match` なら
  `match は使えない`) で拒否され、ファイルは変わらない。逆に `--event prompt` 無しの
  `--keywords` / `--find` / `--case` も「--keywords は --event prompt のときだけ使える」で拒否される

**編集** — keywords / 一致のしかた / 大小区別を差し替える:

```sh
toolhint rule update deploy-docs --keywords "デプロイ, deploy, リリース"
```

形は `toolhint rule update <id> --keywords "…" [--find …] [--case …]`。
操作きっかけのルールに `--keywords` / `--find` / `--case` を当てると
「操作きっかけのルールに keywords は使えない (ことばきっかけ専用のキー)」
(`--find` / `--case` なら `find` / `case`) で拒否され、ファイルは変わらない。
ことばきっかけへの `--tool` / `--pattern` も
「event: prompt のルールに tool は使えない (操作きっかけ専用のキー)」(`--pattern` なら `match`)
で同じく拒否される。`--frequency` / `--scope` / `--layer` は両方のきっかけに使える。

**dry-run** — 発言を渡して、何が注入されるかを state を変えずに見る:

```sh
toolhint test --event prompt "そろそろデプロイしたい"
```

```
1 件マッチ (every 抑制は無視・state 不変):
- deploy-docs (project)
    [toolhint] この話題の docs: /path/to/project/.claude/toolhint/docs/deploy.md — 必要なら読む
```

一致しなければ `マッチなし (event=prompt, input='そろそろデプロイしたい')`。
`--event` を省略した `test` は操作きっかけしか見ない — そちらがマッチ 0 件で層にことばきっかけが
あるときは、末尾に 1 行案内が出る:
「この層にはことばきっかけが N 件ある — 発言に対する dry-run は `toolhint test --event prompt "<発言>"`」

hook 単体を直接叩いて確かめることもできる (実セッションで hook が受け取る payload そのもの)。
[§3](#3-動作確認) の例と違い、今は自分のプロジェクトの dir に居るので engine は
clone 先の絶対パスで指す (`$PWD` = そのプロジェクト。project 層のルールもそこを起点に
探索される):

```sh
echo '{"session_id":"s1","cwd":"'$PWD'","prompt":"そろそろデプロイしたい"}' \
  | "/絶対パス/toolhint/engine/scripts/toolhint.py" --event=prompt
```

### 登録できたか確認

```sh
toolhint list                     # 層と一覧を表形式で (ことばきっかけは EVENT / KEYWORDS 列に出る)
toolhint test "grep -r foo ."     # dry-run — 何が注入されるか (操作きっかけ)
```

```
1 件マッチ (every 抑制は無視・state 不変):
- use-rg (project)
    [toolhint] この操作の docs: /path/to/project/.claude/toolhint/docs/use-rg.md — 必要なら読む
```

(ことばきっかけの dry-run は `toolhint test --event prompt "<発言>"` — 上の例のとおり)

最後に実セッションで確認 — その project で claude を開き、`grep` を含むコマンドを
実行させると直前に上記の 1 行が context 注入される (ことばきっかけなら、発言に
keywords を含めた直後)。`every: session` (既定) のルールは同一セッション 1 回だけ発火する
点に注意 (毎回出したければ `--every always`)。

## 6. project 層と global 層の使い分け

ルールの実体は層ごとの `rules.yaml` + `docs/*.md` (すべてプレーンファイル)。
自分で書く層は次の 2 つ:

| 層 | 場所 | 誰のためか |
|---|---|---|
| **project** | cwd から上方向に最初に見つかる `<dir>/.claude/toolhint/` | そのプロジェクトの約束事。**repo にコミットされるのはこちら** — チームで共有でき、PR で差分レビューできる |
| **global** | `~/.claude/toolhint/` (環境変数 `TOOLHINT_GLOBAL` で変更可) | 自分のマシン全体。どの repo でも効かせたい自分用の決まりごと・道具の知識 |

- global → project の順にマージし、**同 `id` は project が上書き**
  (`list` では global 側に「上書きされ無効」と表示される)
- CLI の `add` の既定は project 層。GUI は保存時に層を選べる
- 記法 (rules.yaml の書き方・YAML subset の制約) は [engine/README.md](../engine/README.md)
- rules.yaml は「機械管理・人間可読・手編集可」— ただし CLI/GUI がルール本体を書き換える操作
  (`rule update` や `import --overwrite` 等) では rules.yaml 全体を正準形へ再直列化するため、
  手書きコメントは保存されない (追記のみの操作では残る)

### 追加層 (layers.d) — チームで共有するルールの置き場

自分で書く 2 層のほかに、**外から配られたルール**を読む場所がある:

```
~/.claude/toolhint/layers.d/<名前>/     ← ディレクトリ 1 つが 1 層 (層名 "layers.d/<名前>")
├── rules.yaml
└── docs/
```

- 中身は global / project 層とまったく同じ形 (`rules.yaml` + `docs/*.md`)
- **配る手段は自由** — そこへファイルを置く仕組み (同期の仕掛け・シンボリック
  リンク・配布ツールなど何でも) は各自の運用。toolhint はどう置かれたかを見ない
- ⚠ **置いた層は、そのマシンの agent へ文面を注入する権限そのもの**。
  **信頼できる配布元のものだけ置くこと。** 安全側の制限として、追加層のルールが
  参照できる doc は層 dir の中だけ — `../` や symlink で層の外のファイルを
  注入しようとするルールは発火せず、`doctor` が問題として報告する
- 読み順は **`layers.d/*` (名前の辞書順) → global → project** で、同じ `id` は
  後勝ち (= より手元の層が勝つ)
- **書き込みはしない** — CLI/GUI が書くのは従来どおり global / project 層だけ。
  追加層は `list` / `test` (dry-run) / `doctor` / GUI の一覧には出るが、
  GUI では読み取り専用 (「共有」と表示され、編集の導線は出ない)
- `layers.d` が無い・空なら、これまでどおり 2 層だけの動きになる

配られたルールを**このマシンだけ / このプロジェクトだけ**止めたいときは、手元の層に
**同じ `id` で `enabled: "false"` のルール**を置く (後勝ちマージで無効になる):

```sh
# 例: 配られた team-grep-rule を、このプロジェクトでだけ止める
#   <repo>/.claude/toolhint/rules.yaml に次を足す
```

```yaml
rules:
  - id: team-grep-rule    # 追加層のルールと同じ id
    tool: Bash            # 種別のキー (ことばきっかけなら keywords) は必要
    enabled: "false"
```

止まったかは dry-run で確かめられる:

```sh
toolhint test "grep -r foo ." --tool Bash            # 一覧に出なければ止まっている
toolhint test --event prompt "そろそろデプロイしたい"   # ことばきっかけを止めた場合はこちら
```

### 適用範囲 (scope) — 特定のディレクトリ配下でだけ効くルール

ルールに `scope` を付けると、**作業ディレクトリがそのパターンに一致する場所で
作業しているときだけ**発火する。モノレポの一部や特定プロジェクト配下でだけ
効かせたいルールに使う (`scope` の無いルールは従来どおりどこでも発火する)。

```yaml
# ~/.claude/toolhint/rules-scoped.yaml
rules:
  - id: monorepo-api-docs
    tool: Bash
    match: \bmigrate\b
    doc: docs/api-migrations.md
    scope: "*/services/api*"   # 作業ディレクトリの絶対パスへの glob (* は / も跨ぐ)
```

- パターンは**作業ディレクトリの絶対パス**に対して照合する (`*` は `/` も跨ぐ)。
  絶対パスは必ず `/` 始まりなので、パターンも `/` かワイルドカード (`*` `?` `[`)
  で始めること。大文字小文字は区別する。作業ディレクトリが分からないときは
  発火させない (実行は止めない)
- 各層のルールファイルは 2 本 — `rules.yaml` と **`rules-scoped.yaml`**。
  書式も扱いも同じで、`scope` 付きのルールを後者に置き分ける。分けてある理由は
  「この形式を知らない古い版の engine は `rules.yaml` しか読まない」ため — そこに
  置かなければ、範囲を無視してどこでも発火する事故が起きない
- 置き先は **`scope` の有無から自動的に決まる** (`scope` を付けた/外したときは
  ルール行が 2 ファイル間を移動する)。`export`/`import` も 2 本とも扱う。
  手で書く場合も同じ置き方を推奨 — ずれていれば `doctor` が警告する

```sh
# CLI から (add と rule update に --scope。"" で外す。上の YAML 例と同じ global 層へ)
toolhint add --layer global --id monorepo-api-docs --tool Bash --match '\bmigrate\b' \
  --doc-name api-migrations.md --doc-content "..." --scope "*/services/api*"
toolhint rule update monorepo-api-docs --scope ""
```

GUI (manager) には `scope` の編集面がまだ無い — 一覧・注入テスト・doctor には
出るが、付け外しは CLI か手編集で行う。

## 7. バックアップと持ち出し

- **project 層は repo が守る** — `.claude/toolhint/` をコミットすれば履歴も
  off-machine も repo と同じ扱い
- **global 層は git 化する**:

```sh
toolhint backup init --layer global
```

```
git 化した: ~/.claude/toolhint (以後、書き込み成功ごとに auto-commit)
```

以後、CLI/GUI の書き込み成功のたびに対象ファイルだけが自動 commit される
(best-effort — commit に失敗しても本体操作は成功のまま)。git 化していない層は
上書き前の `.bak` 1 世代退避のみ。

- **持ち出し・移設は export / import**:

```sh
toolhint export --layer global --out ./bundle.tar.gz   # rules.yaml + docs/ + manifest のみ
toolhint import ./bundle.tar.gz --layer project --dry-run   # 計画だけ見る (一切書かない)
toolhint import ./bundle.tar.gz --layer project             # 取り込み (id 衝突は既定 skip)
```

`--overwrite` で衝突を bundle 側で上書き (rules.yaml は正準形へ再直列化されるため
取り込み先の手書きコメントは残らない)。bundle に log/ state/ は含まれない。

## 8. トラブルシュート

### doctor の見方

```sh
toolhint doctor    # 問題あり = exit 1
```

- `ok — 問題なし` = 健全。`注意` は warning (例: backup 未設定) で exit 0 のまま
- `NG` は problem (exit 1) — いずれも engine が無言でスキップするもの。rules.yaml が
  parse 不能 (層ごと読み飛ばし) / ルールが指す doc が不在 / `doc` も `inject` も無い
  (一致しても注入するものが無い) / `inject` が `{doc}` を参照するのに `doc` が無い
- `注意` は warning (exit 0 のまま)。backup 未設定 / どのルールからも参照されない
  孤児 doc / 同じ層に同じ `id` が 2 回以上 (最後の 1 行だけが効く) / `mode: inline` の
  doc が上限 (既定 64KB、環境変数 `TOOLHINT_INLINE_MAX`) を超えている (本文は注入されず
  場所だけになる) / plugin スナップショットの stale
- 各層の行に backup 状態も出る: `git (auto-commit 有効)` / `repo 内` /
  `なし (上書き前の .bak 1 世代のみ)`
- `plugin:` の行は結果にかかわらず必ず出る: `<version> (最新)` /
  `<version> (stale — repo の engine と食い違う)` + 注意行 / `未インストール (…)` (plugin として
  入れていない — 手動 hooks 設定なら正常) / `不明 (…)` + 注意行 (検査自体ができなかった)

### plugin が stale (repo を更新したのに挙動が古い)

plugin install は engine をその時点の版でコピーするため、`git pull` しても実 hook は
変わらない。`toolhint doctor` が配布済みスナップショットと repo の食い違いを
警告したら:

```sh
claude plugin update toolhint@toolhint
# update が使えない環境では: claude plugin uninstall toolhint@toolhint → install し直す
```

### 401 (認証エラー)

非 loopback bind の manager は `/api` 全体が token 必須 ([§4 補足](#補足-リモート-lan--vpn-に公開する場合-toolhint_token))。

- GUI: 起動ログの `?token=` 付き URL で開き直す
- API 直叩き: `X-Toolhint-Token: <token>` ヘッダ (または `Authorization: Bearer`) を付ける
- `TOOLHINT_TOKEN` 未指定だと起動ごとに token が再生成される — 再起動したら古い URL は
  無効。固定したければ `TOOLHINT_TOKEN` を指定して起動する

### 403 (この Host は許可されていない)

token が合っているのに 403 で、応答本文が「この Host は許可されていない: "…" (必要なら
TOOLHINT_ALLOWED_HOSTS で追加)」なら、開くのに使ったホスト名/IP が Host allowlist に無い。
`HOST=0.0.0.0` で待ち受けても、許可されるのは自ホスト名・localhost・`HOST` の値そのものだけ —
LAN の IP や VPN の名前で開くなら、その値を `TOOLHINT_ALLOWED_HOSTS` (カンマ区切り) に列挙して
起動し直す ([§4 補足](#補足-リモート-lan--vpn-に公開する場合-toolhint_token))。

### rules.yaml を手で壊した

手編集で engine の YAML subset から外れると、doctor が NG を出す:

```
NG   rules.yaml が engine パーサで読めない — 層全体が無言で読み飛ばされる (fail-open): line 7: ...
```

engine は fail-open なので**ツール実行は止まらない** (その層の注入が出なくなるだけ。
stderr に 1 行警告が出る)。復旧手順:

1. doctor のエラーメッセージの行番号を見て該当行を直す。よくある原因は
   `[` `{` `|` `>` で始まる値や ` #` を含む正規表現をクォートしていないこと
   (記法の制約は [engine/README.md](../engine/README.md)「ルール記法」)
2. `backup init` 済みの層なら git で戻せる:
   `git -C ~/.claude/toolhint checkout -- rules.yaml`
   (履歴の確認は `git -C ~/.claude/toolhint log --oneline`)
3. project 層を repo にコミットしていれば、repo の git で同様に戻す

なお CLI/GUI の上書き操作で置き換わった doc は旧内容が `<doc>.md.bak` に残っている。

### 注入が一度も出ない (python3 が PATH に無い)

hook は `#!/usr/bin/env python3` で起動する。`python3` が PATH に無いと hook は
`env: python3: No such file or directory` (exit 127) で終わり、注入は無音で消える —
fail-open なので**ツール実行は止まらず**、セッションの中には何の警告も出ない。
同じ理由で `toolhint doctor` も動かない (CLI も python3 なので)。

- 確認: hook を動かすシェルと同じ環境で `python3 --version` が通るか
  (GUI ツールから起動した Claude Code は、シェルの rc ファイルで足した PATH を
  持たないことがある)
- 直し方: python3 を入れる、または PATH に通す。手動 hooks 設定 ([§2 補足](#補足-手動-hooks-設定-plugin-を使わない)) なら
  `"command"` に python3 の絶対パスを前置してもよい:
  `"\"/絶対パス/python3\" \"/絶対パス/toolhint/engine/scripts/toolhint.py\""`

## 9. アーキテクチャ

**engine** が hook 本体 (PreToolUse = 操作きっかけ / UserPromptSubmit = ことばきっかけ) —
plugin として単独動作し、fail-open (どんな異常でもツール実行を止めない)。
パーサ・マッチ・層発見のロジックは engine にだけ実装がある。
**core** は読み書き・マージ・dry-run など機械操作の単一窓口 (stdout は常に JSON 1 行 —
契約は `core/toolhint_core.py` 冒頭の docstring で定義)。engine のロジックを import して
再利用し、二重実装しない。管理面なのでエラーは素直に返す。
**cli** は core を叩く人間/agent 向けの薄い皮、**manager** は core を子プロセスで叩く
GUI (Node 標準 http のみ — `npm install` なしで起動できる)。

```
engine/    plugin 本体 — 注入 hook (操作/ことば) + マッチャ (単独動作。記法・仕組み: engine/README.md)
core/      管理 core — 機械操作の単一窓口 (JSON 契約の定義: core/toolhint_core.py docstring)
cli/       toolhint — core を叩く人間/agent 向け CLI
manager/   GUI — docs 起点の管理面 (server.mjs + public/*)
docs/      導入ガイド (getting-started.md) + 用語集 (glossary.md)
```
