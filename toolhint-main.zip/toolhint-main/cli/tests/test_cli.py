#!/usr/bin/env python3
"""cli/toolhint のテスト (表示層)。

- 依存ゼロ (python3 標準ライブラリのみ)、assert ベース
- `python3 cli/tests/test_cli.py` 一発で全件実行し PASS/FAIL 集計を出力
- 方式: cli/toolhint をサブプロセスで叩く。層は temp HOME + TOOLHINT_GLOBAL の
  一時 dir に隔離し、実 ~/.claude/toolhint には触らない。plugin 検査の
  レジストリも TOOLHINT_INSTALLED_PLUGINS で一時パスへ向ける。
  `add --ai` は PATH の先頭に置いた偽の `claude` で、claude 本体なしに確かめる。
  ことばきっかけ (add --event prompt / rule update --keywords / test --event prompt)
  は成功系 (engine パーサで read-back) と拒否系 (文言 + ファイル無変更) の両方。
  keywords の区切り 3 種 (`,` / `、` / `，`) は engine の分割 → 保存 → dry-run 発火まで
  通しで見て、docs / --help の記述とも突き合わせる
"""

import importlib.machinery
import importlib.util
import json
import os
import re
import shlex
import shutil
import stat
import subprocess
import sys
import tempfile

TESTS_DIR = os.path.dirname(os.path.abspath(__file__))
CLI_DIR = os.path.dirname(TESTS_DIR)
REPO_ROOT = os.path.dirname(CLI_DIR)
CLI = os.path.join(CLI_DIR, "toolhint")
ENGINE = os.path.join(REPO_ROOT, "engine", "scripts", "toolhint.py")

sys.path.insert(0, os.path.join(REPO_ROOT, "engine", "scripts"))
import toolhint  # noqa: E402  (engine パーサで書いた rules.yaml を読み戻す)


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def run_cli(args, home, global_dir, extra_env=None, path_prepend=None, cwd=None):
    """cli/toolhint を隔離環境で実行する。HOME / TOOLHINT_GLOBAL /
    TOOLHINT_INSTALLED_PLUGINS をすべて一時 dir へ向ける。cwd はプロセスの
    作業ディレクトリ (docs の例のように --cwd を付けないコマンドを試すとき)。"""
    env = os.environ.copy()
    env["HOME"] = home
    env["TOOLHINT_GLOBAL"] = global_dir
    env["TOOLHINT_INSTALLED_PLUGINS"] = os.path.join(
        home, "_no_installed_plugins.json")
    env.pop("TOOLHINT_DEBUG", None)
    if path_prepend:
        env["PATH"] = path_prepend + os.pathsep + env.get("PATH", "")
    if extra_env:
        env.update(extra_env)
    return subprocess.run([sys.executable, CLI] + args, capture_output=True,
                          text=True, env=env, timeout=60, stdin=subprocess.DEVNULL,
                          cwd=cwd)


def make_layer(root, rules_text, docs=None):
    os.makedirs(root, exist_ok=True)
    with open(os.path.join(root, "rules.yaml"), "w", encoding="utf-8") as f:
        f.write(rules_text)
    for rel, body in (docs or {}).items():
        p = os.path.join(root, rel)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, "w", encoding="utf-8") as f:
            f.write(body)


def make_fake_claude(bin_dir, stdout="", stderr="", exit_code=0):
    """PATH の先頭に置く偽 claude — 与えた stdout / stderr を出して exit する。"""
    os.makedirs(bin_dir, exist_ok=True)
    path = os.path.join(bin_dir, "claude")
    script = "#!/bin/sh\n"
    if stdout:
        script += "cat <<'TOOLHINT_FAKE_OUT'\n%s\nTOOLHINT_FAKE_OUT\n" % stdout
    if stderr:
        script += "cat <<'TOOLHINT_FAKE_ERR' >&2\n%s\nTOOLHINT_FAKE_ERR\n" % stderr
    script += "exit %d\n" % exit_code
    with open(path, "w", encoding="utf-8") as f:
        f.write(script)
    os.chmod(path, os.stat(path).st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
    return path


def git_backed(layer_dir):
    """層 dir を git 化して backup 警告を出さない状態にする (健全な doctor 用)。"""
    subprocess.run(["git", "-C", layer_dir, "init", "-q"], check=True,
                   capture_output=True, timeout=30)
    subprocess.run(["git", "-C", layer_dir, "add", "rules.yaml", "docs"],
                   check=True, capture_output=True, timeout=30)
    subprocess.run(["git", "-C", layer_dir, "-c", "user.name=t",
                    "-c", "user.email=t@example.invalid",
                    "commit", "-q", "-m", "init"],
                   check=True, capture_output=True, timeout=30)


def load_cli_module():
    """cli/toolhint を module として読み込む (表描画関数の単体テスト用)。"""
    loader = importlib.machinery.SourceFileLoader("toolhint_cli", CLI)
    spec = importlib.util.spec_from_loader("toolhint_cli", loader)
    mod = importlib.util.module_from_spec(spec)
    loader.exec_module(mod)
    return mod


def table_rows(stdout):
    """list 出力の表部分 (ヘッダ行以降) を {ID: 行} で返す。"""
    lines = stdout.splitlines()
    head = [i for i, l in enumerate(lines) if l.startswith("ID ")]
    assert head, "表のヘッダが無い: %r" % stdout
    body = lines[head[0] + 2:]  # ヘッダ + 罫線の次から
    return {l.split()[0]: l for l in body if l.strip()}


# ---------------------------------------------------------------------------
# list — ことばきっかけ (event: prompt) を含む層でも表が出る
# ---------------------------------------------------------------------------

def test_list_with_prompt_rule_exits_zero_and_renders_table():
    with tempfile.TemporaryDirectory() as td:
        home = os.path.join(td, "home")
        cwd = os.path.join(home, "work")
        os.makedirs(cwd)
        g = os.path.join(td, "g")
        make_layer(g,
                   "rules:\n"
                   "  - id: p1\n    event: prompt\n    keywords: デプロイ\n"
                   "    doc: docs/a.md\n"
                   "  - id: t1\n    tool: Bash\n    match: \\bgrep\\b\n"
                   "    doc: docs/a.md\n",
                   docs={"docs/a.md": "x\n"})
        p = run_cli(["list", "--cwd", cwd], home, g)
        assert p.returncode == 0, (p.returncode, p.stdout, p.stderr)
        assert "Traceback" not in p.stderr, p.stderr
        rows = table_rows(p.stdout)
        assert set(rows) == {"p1", "t1"}, rows
        # 見出しに EVENT / KEYWORDS 列がある
        header = [l for l in p.stdout.splitlines() if l.startswith("ID ")][0]
        for col in ("ID", "LAYER", "EVENT", "TOOL", "MATCH", "KEYWORDS", "DOC"):
            assert col in header.split(), header
        # ことばきっかけ: EVENT=prompt、TOOL/MATCH は "-"、KEYWORDS に語が出る
        p1 = rows["p1"].split()
        assert p1[1:5] == ["global", "prompt", "-", "-"], p1
        assert "デプロイ" in rows["p1"], rows["p1"]
        assert "docs/a.md [ok]" in rows["p1"], rows["p1"]
        # 操作きっかけ: EVENT=tool、TOOL/MATCH に値、KEYWORDS は "-"
        t1 = rows["t1"].split()
        assert t1[1:6] == ["global", "tool", "Bash", "\\bgrep\\b", "-"], t1


def test_list_prompt_only_layer_and_find_case_annotation():
    """ことばきっかけだけの層 (GUI で 1 本作った直後の形) でも落ちない。
    find / case は KEYWORDS 列に括弧で添える。"""
    with tempfile.TemporaryDirectory() as td:
        home = os.path.join(td, "home")
        cwd = os.path.join(home, "work")
        os.makedirs(cwd)
        g = os.path.join(td, "g")
        make_layer(g,
                   "rules:\n"
                   "  - id: only\n    event: prompt\n    keywords: deploy, release\n"
                   "    find: word\n    case: sensitive\n    doc: docs/d.md\n",
                   docs={"docs/d.md": "d\n"})
        p = run_cli(["list", "--cwd", cwd], home, g)
        assert p.returncode == 0, (p.returncode, p.stdout, p.stderr)
        rows = table_rows(p.stdout)
        assert list(rows) == ["only"], rows
        line = rows["only"]
        assert "deploy, release" in line, line
        assert "find: word" in line and "case: sensitive" in line, line


def test_list_prompt_rule_without_doc_and_disabled():
    """doc なし (inject だけ) + disable 中のことばきっかけでも表が出る。"""
    with tempfile.TemporaryDirectory() as td:
        home = os.path.join(td, "home")
        cwd = os.path.join(home, "work")
        os.makedirs(cwd)
        g = os.path.join(td, "g")
        make_layer(g,
                   "rules:\n"
                   "  - id: nodoc\n    event: prompt\n    keywords: リリース\n"
                   "    inject: 手順を確認\n    enabled: \"false\"\n")
        p = run_cli(["list", "--cwd", cwd], home, g)
        assert p.returncode == 0, (p.returncode, p.stdout, p.stderr)
        rows = table_rows(p.stdout)
        assert "nodoc" in rows, rows
        assert "(disable 中)" in rows["nodoc"], rows["nodoc"]
        assert rows["nodoc"].rstrip().endswith("-"), rows["nodoc"]  # DOC 列は "-"


def test_list_no_rules_and_tool_only_layer():
    with tempfile.TemporaryDirectory() as td:
        home = os.path.join(td, "home")
        cwd = os.path.join(home, "work")
        os.makedirs(cwd)
        g = os.path.join(td, "g")
        # 層なし → ルールなし
        p = run_cli(["list", "--cwd", cwd], home, g)
        assert p.returncode == 0, (p.stdout, p.stderr)
        assert "ルールなし" in p.stdout, p.stdout
        # 操作きっかけだけの層 → 従来どおり表が出る (match 省略は "-")
        make_layer(g, "rules:\n  - id: a\n    tool: Bash\n    doc: docs/a.md\n",
                   docs={"docs/a.md": "A\n"})
        p = run_cli(["list", "--cwd", cwd], home, g)
        assert p.returncode == 0, (p.stdout, p.stderr)
        a = table_rows(p.stdout)["a"].split()
        assert a[1:6] == ["global", "tool", "Bash", "-", "-"], a


def test_list_broken_layer_says_unreadable_not_empty():
    """ルールファイルが engine パーサで読めない層は丸ごと読み飛ばされる — list は
    「ルールなし」だけで終わらず、層の行に読めない理由 (core の parse_error) を出す。"""
    with tempfile.TemporaryDirectory() as td:
        home = os.path.join(td, "home")
        cwd = os.path.join(home, "work")
        os.makedirs(cwd)
        g = os.path.join(td, "g")
        make_layer(g,
                   "rules:\n"
                   "  - id: good\n    tool: Bash\n    match: foo\n    doc: docs/a.md\n"
                   "  - id: bad\n    tool: Bash\n    match: [unquoted]\n    doc: docs/a.md\n",
                   docs={"docs/a.md": "A\n"})
        p = run_cli(["list", "--cwd", cwd], home, g)
        assert p.returncode == 0, (p.returncode, p.stdout, p.stderr)
        assert "Traceback" not in p.stderr, p.stderr
        layer_line = [l for l in p.stdout.splitlines() if l.strip().startswith("global ")][0]
        assert "(あり)" in layer_line, layer_line
        assert "読めないため読み飛ばされている" in layer_line, layer_line
        assert "rules.yaml" in layer_line and "line" in layer_line, layer_line
        # 読み飛ばされた層のルールは一覧に出ない (engine と同じ)
        assert "ルールなし" in p.stdout, p.stdout
        # 健全な層では注記が付かない
        make_layer(g, "rules:\n  - id: good\n    tool: Bash\n    match: foo\n    doc: docs/a.md\n",
                   docs={"docs/a.md": "A\n"})
        p = run_cli(["list", "--cwd", cwd], home, g)
        assert p.returncode == 0, (p.stdout, p.stderr)
        layer_line = [l for l in p.stdout.splitlines() if l.strip().startswith("global ")][0]
        assert "読み飛ばされている" not in layer_line, layer_line
        assert "good" in table_rows(p.stdout), p.stdout


def test_render_table_fills_none_and_aligns_wide_chars():
    """表描画は None / 空文字を "-" に落とし、全角を 2 桁として列を揃える。"""
    cli = load_cli_module()
    out = cli.render_table([["ab", None, ""], ["デプロイ", "x", "y"]],
                           ["A", "B", "C"])
    lines = out.splitlines()
    assert lines[2].split() == ["ab", "-", "-"], lines
    # B 列は両行とも同じ表示桁から始まる (全角 4 文字 = 8 桁として揃える)
    col_b_row2 = cli._display_width(lines[2][:lines[2].index("-")])
    col_b_row3 = cli._display_width(lines[3][:lines[3].index("x")])
    assert col_b_row2 == col_b_row3 == cli._display_width("デプロイ") + 2, lines


# ---------------------------------------------------------------------------
# add --ai — 失敗理由を握り潰さない (stderr が空なら stdout の末尾)
# ---------------------------------------------------------------------------

def test_add_ai_failure_shows_stdout_when_stderr_empty():
    with tempfile.TemporaryDirectory() as td:
        home = os.path.join(td, "home")
        cwd = os.path.join(home, "work")
        os.makedirs(cwd)
        g = os.path.join(td, "g")
        fake_bin = os.path.join(td, "bin")
        make_fake_claude(fake_bin, stdout="Not logged in · Please run /login",
                         exit_code=1)
        p = run_cli(["add", "--ai", "grep を使ったら rg を勧めて",
                     "--layer", "global", "--yes", "--cwd", cwd],
                    home, g, path_prepend=fake_bin)
        assert p.returncode == 1, (p.returncode, p.stdout, p.stderr)
        assert "claude -p が失敗 (exit=1)" in p.stderr, p.stderr
        assert "Not logged in" in p.stderr, p.stderr
        assert not os.path.exists(os.path.join(g, "rules.yaml"))  # 何も書かない


def test_add_ai_failure_prefers_stderr_and_handles_silence():
    with tempfile.TemporaryDirectory() as td:
        home = os.path.join(td, "home")
        cwd = os.path.join(home, "work")
        os.makedirs(cwd)
        g = os.path.join(td, "g")
        # stderr があればそちら (stdout のノイズは出さない)
        fake_bin = os.path.join(td, "bin1")
        make_fake_claude(fake_bin, stdout="partial output",
                         stderr="API error: rate limited", exit_code=2)
        p = run_cli(["add", "--ai", "x", "--layer", "global", "--yes",
                     "--cwd", cwd], home, g, path_prepend=fake_bin)
        assert p.returncode == 1, (p.returncode, p.stdout, p.stderr)
        assert "exit=2" in p.stderr and "rate limited" in p.stderr, p.stderr
        assert "partial output" not in p.stderr, p.stderr
        # 両方空でも「(出力なし …)」で理由欄が空にならない
        fake_bin2 = os.path.join(td, "bin2")
        make_fake_claude(fake_bin2, exit_code=1)
        p = run_cli(["add", "--ai", "x", "--layer", "global", "--yes",
                     "--cwd", cwd], home, g, path_prepend=fake_bin2)
        assert p.returncode == 1, (p.returncode, p.stdout, p.stderr)
        assert "出力なし" in p.stderr, p.stderr


def test_add_ai_success_with_fake_claude_writes_rule():
    """偽 claude が起案 JSON を返せば、プレビュー → 層へ追記まで通る。"""
    with tempfile.TemporaryDirectory() as td:
        home = os.path.join(td, "home")
        cwd = os.path.join(home, "work")
        os.makedirs(cwd)
        g = os.path.join(td, "g")
        proposal = {"id": "prefer-rg", "tool": "Bash", "match": "\\bgrep\\b",
                    "doc_name": "prefer-rg.md",
                    "doc_content": "# rg\n\ngrep より rg を使う。\n",
                    "inject": None}
        fake_bin = os.path.join(td, "bin")
        make_fake_claude(fake_bin, stdout=json.dumps(proposal, ensure_ascii=False))
        p = run_cli(["add", "--ai", "grep を使ったら rg を勧めて",
                     "--layer", "global", "--yes", "--cwd", cwd],
                    home, g, path_prepend=fake_bin)
        assert p.returncode == 0, (p.returncode, p.stdout, p.stderr)
        assert "追記した:" in p.stdout, p.stdout
        with open(os.path.join(g, "rules.yaml"), encoding="utf-8") as f:
            rules_text = f.read()
        assert 'id: "prefer-rg"' in rules_text, rules_text
        assert os.path.isfile(os.path.join(g, "docs", "prefer-rg.md"))
        # 実 HOME 側には何も作っていない
        assert not os.path.exists(os.path.join(home, ".claude", "toolhint"))


# ---------------------------------------------------------------------------
# ことばきっかけ (event: prompt) — add --event prompt / rule update --keywords /
# test --event prompt。層は temp HOME + TOOLHINT_GLOBAL の一時 dir
# ---------------------------------------------------------------------------

def _isolated(td):
    home = os.path.join(td, "home")
    cwd = os.path.join(home, "work")
    os.makedirs(cwd)
    return home, cwd, os.path.join(td, "g")


def parsed_rules(layer_dir):
    """層の rules.yaml を engine パーサで読み戻す (無ければ [])。"""
    path = os.path.join(layer_dir, "rules.yaml")
    if not os.path.isfile(path):
        return []
    with open(path, encoding="utf-8") as f:
        return toolhint.parse_rules_yaml(f.read())


def test_add_prompt_with_doc_writes_rule_and_doc():
    """add --event prompt --keywords + --doc-name/--doc-content — ルールと doc が書ける。"""
    with tempfile.TemporaryDirectory() as td:
        home, cwd, g = _isolated(td)
        p = run_cli(["add", "--event", "prompt", "--id", "deploy-docs",
                     "--keywords", "デプロイ, deploy",
                     "--doc-name", "deploy.md",
                     "--doc-content", "デプロイ前チェックリスト\n",
                     "--layer", "global", "--cwd", cwd], home, g)
        assert p.returncode == 0, (p.returncode, p.stdout, p.stderr)
        assert "追記した: %s" % os.path.join(g, "rules.yaml") in p.stdout, p.stdout
        assert "doc     : %s" % os.path.join(g, "docs", "deploy.md") in p.stdout, p.stdout
        # engine パーサと往復一致。find / case の既定はキーを置かない (正準形)
        assert parsed_rules(g) == [{"id": "deploy-docs", "event": "prompt",
                                    "keywords": "デプロイ, deploy",
                                    "doc": "docs/deploy.md"}], parsed_rules(g)
        with open(os.path.join(g, "docs", "deploy.md"), encoding="utf-8") as f:
            assert f.read() == "デプロイ前チェックリスト\n"
        # 実 HOME 側には何も作っていない
        assert not os.path.exists(os.path.join(home, ".claude", "toolhint"))
        # list に EVENT=prompt / KEYWORDS で出る
        p = run_cli(["list", "--cwd", cwd], home, g)
        assert p.returncode == 0, (p.stdout, p.stderr)
        row = table_rows(p.stdout)["deploy-docs"].split()
        assert row[1:5] == ["global", "prompt", "-", "-"], row
        # --event を省略した add は従来どおり操作きっかけ (同じ層に同居できる)
        p = run_cli(["add", "--id", "t1", "--tool", "Bash", "--match", r"\bgrep\b",
                     "--doc-name", "g.md", "--doc-content", "use rg\n",
                     "--layer", "global", "--cwd", cwd], home, g)
        assert p.returncode == 0, (p.returncode, p.stdout, p.stderr)
        assert parsed_rules(g)[-1] == {"id": "t1", "tool": "Bash",
                                       "match": r"\bgrep\b", "doc": "docs/g.md"}


def test_add_prompt_inject_only_with_find_and_case():
    """add --event prompt は doc を作らず --inject だけでも作れる。--find word / --case sensitive は
    そのまま書き、--find substring / --case insensitive (既定) はキーを置かない。"""
    with tempfile.TemporaryDirectory() as td:
        home, cwd, g = _isolated(td)
        p = run_cli(["add", "--event", "prompt", "--id", "rel",
                     "--keywords", "リリース", "--inject", "手順を確認 ({id})",
                     "--find", "word", "--case", "sensitive", "--every", "always",
                     "--mode", "inline", "--layer", "global", "--cwd", cwd], home, g)
        assert p.returncode == 0, (p.returncode, p.stdout, p.stderr)
        assert "doc     : なし" in p.stdout, p.stdout
        assert parsed_rules(g) == [{"id": "rel", "event": "prompt",
                                    "keywords": "リリース", "find": "word",
                                    "case": "sensitive", "inject": "手順を確認 ({id})",
                                    "mode": "inline", "every": "always"}], parsed_rules(g)
        assert not os.path.isdir(os.path.join(g, "docs"))  # doc は作らない
        p = run_cli(["add", "--event", "prompt", "--id", "plain",
                     "--keywords", "移行", "--inject", "移行手順",
                     "--find", "substring", "--case", "insensitive",
                     "--layer", "global", "--cwd", cwd], home, g)
        assert p.returncode == 0, (p.returncode, p.stdout, p.stderr)
        assert parsed_rules(g)[-1] == {"id": "plain", "event": "prompt",
                                       "keywords": "移行", "inject": "移行手順"}
        # 書いたルールは test --event prompt で発火する (大小区別 / 語単位が効く)
        p = run_cli(["test", "--event", "prompt", "リリース する", "--cwd", cwd], home, g)
        assert p.returncode == 0 and "1 件マッチ" in p.stdout, (p.stdout, p.stderr)
        assert "[toolhint] 手順を確認 (rel)" in p.stdout, p.stdout


def test_add_prompt_rejects_tool_match_and_missing_args():
    """add --event prompt に --tool / --match は「event: prompt のルールに
    tool は使えない (操作きっかけ専用のキー)」で拒否・ファイル無変更。必須の欠落も拒否。"""
    with tempfile.TemporaryDirectory() as td:
        home, cwd, g = _isolated(td)
        base = ["add", "--event", "prompt", "--id", "x", "--keywords", "a",
                "--inject", "b", "--layer", "global", "--cwd", cwd]
        for extra, frag in [(["--tool", "Bash"], "event: prompt のルールに tool は使えない (操作きっかけ専用のキー)"),
                            (["--match", "grep"], "event: prompt のルールに match は使えない (操作きっかけ専用のキー)")]:
            p = run_cli(base + extra, home, g)
            assert p.returncode == 1, (extra, p.returncode, p.stdout, p.stderr)
            assert frag in p.stderr, (extra, p.stderr)
        # 必須の欠落 — keywords / (doc-name+doc-content | inject) / doc-content 片落ち
        for args, frag in [
                (["add", "--event", "prompt", "--id", "x", "--inject", "b"], "--keywords"),
                (["add", "--event", "prompt", "--id", "x", "--keywords", "a"],
                 "--doc-name --doc-content (または --inject)"),
                (["add", "--event", "prompt", "--id", "x", "--keywords", "a",
                  "--doc-name", "d.md"], "--doc-content"),
                (["add", "--event", "prompt", "--keywords", "a", "--inject", "b"], "--id"),
        ]:
            p = run_cli(args + ["--layer", "global", "--cwd", cwd], home, g)
            assert p.returncode == 1, (args, p.returncode, p.stdout, p.stderr)
            assert "add --event prompt には" in p.stderr and frag in p.stderr, (args, p.stderr)
        assert not os.path.exists(os.path.join(g, "rules.yaml"))
        assert not os.path.exists(os.path.join(g, "docs"))


def test_add_tool_rejects_prompt_only_flags_and_ai_with_prompt():
    """add: --event prompt 無しの --keywords / --find / --case は拒否。
    --ai は操作きっかけ専用 — --event prompt を添えても claude を呼ばず拒否。"""
    with tempfile.TemporaryDirectory() as td:
        home, cwd, g = _isolated(td)
        base = ["add", "--id", "x", "--tool", "Bash", "--match", "a",
                "--doc-name", "a.md", "--doc-content", "b", "--layer", "global",
                "--cwd", cwd]
        for extra in (["--keywords", "a"], ["--find", "word"], ["--case", "sensitive"],
                      ["--event", "tool", "--keywords", "a"]):
            p = run_cli(base + extra, home, g)
            assert p.returncode == 1, (extra, p.returncode, p.stdout, p.stderr)
            assert "--event prompt のときだけ使える" in p.stderr, (extra, p.stderr)
        # --ai + ことばきっかけ: 偽 claude が呼ばれたら成功 JSON を返す設定にしておき、
        # 呼ばれていない (= 何も書かれない) ことで確かめる
        fake_bin = os.path.join(td, "bin")
        make_fake_claude(fake_bin, stdout=json.dumps(
            {"id": "z", "tool": "Bash", "match": "z", "doc_name": "z.md",
             "doc_content": "z", "inject": None}))
        for extra in (["--event", "prompt"], ["--keywords", "a"]):
            p = run_cli(["add", "--ai", "x", "--layer", "global", "--yes", "--cwd", cwd]
                        + extra, home, g, path_prepend=fake_bin)
            assert p.returncode == 1, (extra, p.returncode, p.stdout, p.stderr)
            assert "--ai は操作きっかけ専用" in p.stderr, (extra, p.stderr)
        assert not os.path.exists(os.path.join(g, "rules.yaml"))


def test_rule_update_keywords_find_case_roundtrip():
    """rule update --keywords / --find / --case でことばきっかけを編集。
    substring / insensitive はキーを外す (既定へ戻す)。"""
    with tempfile.TemporaryDirectory() as td:
        home, cwd, g = _isolated(td)
        make_layer(g,
                   "rules:\n"
                   "  - id: p-word\n    event: prompt\n    keywords: 本番\n"
                   "    doc: docs/p.md\n",
                   docs={"docs/p.md": "P\n"})
        p = run_cli(["rule", "update", "p-word", "--keywords", "本番, ほんばん",
                     "--find", "word", "--case", "sensitive", "--cwd", cwd], home, g)
        assert p.returncode == 0, (p.returncode, p.stdout, p.stderr)
        assert p.stdout.startswith("更新した: p-word (global 層"), p.stdout
        assert "  keywords: 本番, ほんばん" in p.stdout, p.stdout
        assert parsed_rules(g) == [{"id": "p-word", "event": "prompt",
                                    "keywords": "本番, ほんばん", "doc": "docs/p.md",
                                    "find": "word", "case": "sensitive"}], parsed_rules(g)
        # keywords だけ (find / case は据え置き)
        p = run_cli(["rule", "update", "p-word", "--keywords", "本番", "--cwd", cwd],
                    home, g)
        assert p.returncode == 0, (p.returncode, p.stdout, p.stderr)
        assert parsed_rules(g)[0]["keywords"] == "本番"
        assert parsed_rules(g)[0]["find"] == "word"
        # 既定へ戻す
        p = run_cli(["rule", "update", "p-word", "--find", "substring",
                     "--case", "insensitive", "--cwd", cwd], home, g)
        assert p.returncode == 0, (p.returncode, p.stdout, p.stderr)
        assert parsed_rules(g) == [{"id": "p-word", "event": "prompt",
                                    "keywords": "本番", "doc": "docs/p.md"}], parsed_rules(g)
        # 同じ内容なら変更なし
        p = run_cli(["rule", "update", "p-word", "--find", "substring", "--cwd", cwd],
                    home, g)
        assert p.returncode == 0 and p.stdout.startswith("変更なし"), (p.stdout, p.stderr)
        # 編集後の語で test --event prompt が発火する
        p = run_cli(["test", "--event", "prompt", "本番に出す", "--cwd", cwd], home, g)
        assert p.returncode == 0 and "1 件マッチ" in p.stdout, (p.stdout, p.stderr)
        assert "- p-word (global)" in p.stdout, p.stdout


def test_keywords_fullwidth_comma_splits_into_words_and_fires():
    """全角カンマ `，` (U+FF0C) も `,` / `、` と同じ区切り — add / rule update で
    渡した "本番，ほんばん" は 2 語として扱われ、どちらの語でも test --event prompt が
    発火する。`，` だけの指定は「区切り文字のみ」として add / update とも拒否・無変更。"""
    # 分割は engine の 1 箇所 (CLI / core は独自に分割しない)
    assert toolhint.split_prompt_keywords("本番，ほんばん") == ["本番", "ほんばん"]
    assert toolhint.split_prompt_keywords("a, b、c，d") == ["a", "b", "c", "d"]
    assert toolhint.split_prompt_keywords("，， ，") == []
    with tempfile.TemporaryDirectory() as td:
        home, cwd, g = _isolated(td)
        p = run_cli(["add", "--event", "prompt", "--id", "prod",
                     "--keywords", "本番，ほんばん", "--inject", "本番手順を確認 ({id})",
                     "--layer", "global", "--cwd", cwd], home, g)
        assert p.returncode == 0, (p.returncode, p.stdout, p.stderr)
        # 保存は書いたまま (分割は判定時)。engine パーサで読み戻して 2 語に割れる
        rules = parsed_rules(g)
        assert rules == [{"id": "prod", "event": "prompt", "keywords": "本番，ほんばん",
                          "inject": "本番手順を確認 ({id})"}], rules
        assert toolhint.split_prompt_keywords(rules[0]["keywords"]) == ["本番", "ほんばん"]
        # どちらの語でも発火し、`，` を含む発言でなくてよい
        for utter in ("本番に出す", "ほんばんに出す"):
            p = run_cli(["test", "--event", "prompt", utter, "--cwd", cwd], home, g)
            assert p.returncode == 0 and "1 件マッチ" in p.stdout, (utter, p.stdout, p.stderr)
            assert "- prod (global)" in p.stdout, (utter, p.stdout)
            assert "[toolhint] 本番手順を確認 (prod)" in p.stdout, (utter, p.stdout)
        p = run_cli(["test", "--event", "prompt", "おはよう", "--cwd", cwd], home, g)
        assert p.returncode == 0 and p.stdout.startswith("マッチなし"), (p.stdout, p.stderr)
        # rule update --keywords でも同じ区切り
        p = run_cli(["rule", "update", "prod", "--keywords", "デプロイ，deploy", "--cwd", cwd],
                    home, g)
        assert p.returncode == 0, (p.returncode, p.stdout, p.stderr)
        assert parsed_rules(g)[0]["keywords"] == "デプロイ，deploy", parsed_rules(g)
        p = run_cli(["test", "--event", "prompt", "deploy now", "--cwd", cwd], home, g)
        assert p.returncode == 0 and "- prod (global)" in p.stdout, (p.stdout, p.stderr)
        p = run_cli(["test", "--event", "prompt", "本番に出す", "--cwd", cwd], home, g)
        assert p.returncode == 0 and p.stdout.startswith("マッチなし"), (p.stdout, p.stderr)
        # `，` だけ = 区切り文字のみ → add / update とも拒否、ファイル無変更
        with open(os.path.join(g, "rules.yaml"), encoding="utf-8") as f:
            before = f.read()
        frag = "keywords に有効な要素がない (区切り文字のみ)"
        for args in (["add", "--event", "prompt", "--id", "only", "--keywords", "，，",
                      "--inject", "x", "--layer", "global"],
                     ["rule", "update", "prod", "--keywords", "， ，"]):
            p = run_cli(args + ["--cwd", cwd], home, g)
            assert p.returncode == 1, (args, p.returncode, p.stdout, p.stderr)
            assert frag in p.stderr, (args, p.stderr)
        with open(os.path.join(g, "rules.yaml"), encoding="utf-8") as f:
            assert f.read() == before


def test_rule_update_rejects_prompt_keys_on_tool_rule_and_vice_versa():
    """rule update: 操作きっかけに --keywords/--find/--case は「操作きっかけのルールに
    keywords は使えない」で拒否・無変更。ことばきっかけに --tool/--pattern も対称に拒否。"""
    with tempfile.TemporaryDirectory() as td:
        home, cwd, g = _isolated(td)
        text = ("rules:\n"
                "  - id: t1\n    tool: Bash\n    match: grep\n    doc: docs/a.md\n"
                "  - id: p1\n    event: prompt\n    keywords: デプロイ\n"
                "    doc: docs/a.md\n")
        make_layer(g, text, docs={"docs/a.md": "A\n"})
        for args, frag in [
                (["t1", "--keywords", "x"], "操作きっかけのルールに keywords は使えない"),
                (["t1", "--find", "word"], "操作きっかけのルールに find は使えない"),
                (["t1", "--find", "substring"], "操作きっかけのルールに find は使えない"),
                (["t1", "--case", "insensitive"], "操作きっかけのルールに case は使えない"),
                (["t1", "--frequency", "always", "--keywords", "x"],
                 "操作きっかけのルールに keywords は使えない"),
                (["p1", "--tool", "Bash"], "event: prompt のルールに tool は使えない (操作きっかけ専用のキー)"),
                (["p1", "--pattern", "x"], "event: prompt のルールに match は使えない (操作きっかけ専用のキー)"),
                (["p1", "--pattern", ""], "event: prompt のルールに match は使えない (操作きっかけ専用のキー)"),
        ]:
            p = run_cli(["rule", "update"] + args + ["--cwd", cwd], home, g)
            assert p.returncode == 1, (args, p.returncode, p.stdout, p.stderr)
            assert frag in p.stderr, (args, p.stderr)
        with open(os.path.join(g, "rules.yaml"), encoding="utf-8") as f:
            assert f.read() == text  # 1 バイトも変わらない
        # 項目なしの案内に新フラグが載る
        p = run_cli(["rule", "update", "p1", "--cwd", cwd], home, g)
        assert p.returncode == 1 and "--keywords" in p.stderr, (p.stdout, p.stderr)
        # --frequency / --scope はどちらの種別にも効く
        p = run_cli(["rule", "update", "p1", "--frequency", "always", "--cwd", cwd],
                    home, g)
        assert p.returncode == 0, (p.returncode, p.stdout, p.stderr)
        assert parsed_rules(g)[1]["every"] == "always"


def test_test_event_prompt_match_and_no_match():
    """test --event prompt は tool の test と同じ体裁 — 「N 件マッチ」/
    「マッチなし (event=prompt, input='…')」。"""
    with tempfile.TemporaryDirectory() as td:
        home, cwd, g = _isolated(td)
        make_layer(g,
                   "rules:\n"
                   "  - id: deploy-docs\n    event: prompt\n    keywords: デプロイ, deploy\n"
                   "    doc: docs/deploy.md\n"
                   "  - id: t1\n    tool: Bash\n    match: デプロイ\n    doc: docs/deploy.md\n",
                   docs={"docs/deploy.md": "D\n"})
        p = run_cli(["test", "--event", "prompt", "そろそろデプロイしたい", "--cwd", cwd],
                    home, g)
        assert p.returncode == 0, (p.returncode, p.stdout, p.stderr)
        lines = p.stdout.splitlines()
        assert lines[0] == "1 件マッチ (every 抑制は無視・state 不変):", lines
        assert lines[1] == "- deploy-docs (global)", lines
        assert lines[2] == "    [toolhint] この話題の docs: %s — 必要なら読む" \
            % os.path.join(g, "docs", "deploy.md"), lines
        # 操作きっかけ (t1 は match: デプロイ) は発言の dry-run では不発
        assert "t1" not in p.stdout, p.stdout
        p = run_cli(["test", "--event", "prompt", "なにもない", "--cwd", cwd], home, g)
        assert p.returncode == 0, (p.returncode, p.stdout, p.stderr)
        assert p.stdout.strip() == "マッチなし (event=prompt, input='なにもない')", p.stdout
        # --event prompt に --tool は使えない
        p = run_cli(["test", "--event", "prompt", "--tool", "Bash", "x", "--cwd", cwd],
                    home, g)
        assert p.returncode == 1 and "--tool は使えない" in p.stderr, (p.stdout, p.stderr)
        # state は書かない (dry-run)
        assert not os.path.exists(os.path.join(g, "state"))


def test_test_tool_no_match_hints_prompt_rules_only_when_present():
    """test (操作きっかけ) が 0 件で、層マージ後にことばきっかけが
    あるときだけ末尾に 1 行の案内。無ければ従来どおり 1 行のまま。"""
    hint_head = "この層にはことばきっかけが"
    hint_tail = "件ある — 発言に対する dry-run は `toolhint test --event prompt \"<発言>\"`"
    with tempfile.TemporaryDirectory() as td:
        home, cwd, g = _isolated(td)
        # 操作きっかけだけの層 → 案内なし
        make_layer(g, "rules:\n  - id: t1\n    tool: Bash\n    match: grep\n    doc: docs/a.md\n",
                   docs={"docs/a.md": "A\n"})
        p = run_cli(["test", "デプロイ", "--cwd", cwd], home, g)
        assert p.returncode == 0, (p.returncode, p.stdout, p.stderr)
        assert p.stdout.strip() == "マッチなし (tool=Bash, input='デプロイ')", p.stdout
        # ことばきっかけだけの層 (GUI で 1 本作った直後の形) → 案内 1 行
        make_layer(g, "rules:\n  - id: p1\n    event: prompt\n    keywords: デプロイ\n"
                      "    doc: docs/a.md\n",
                   docs={"docs/a.md": "A\n"})
        p = run_cli(["test", "デプロイ", "--cwd", cwd], home, g)
        assert p.returncode == 0, (p.returncode, p.stdout, p.stderr)
        lines = p.stdout.splitlines()
        assert lines == ["マッチなし (tool=Bash, input='デプロイ')",
                         "%s 1 %s" % (hint_head, hint_tail)], lines
        # 件数は層マージ後 — project 層が同 id で上書きした global 行は数えない。
        # 操作きっかけがマッチしたときは案内を出さない
        proj_layer = os.path.join(cwd, ".claude", "toolhint")
        make_layer(g, "rules:\n"
                      "  - id: p1\n    event: prompt\n    keywords: デプロイ\n    doc: docs/a.md\n"
                      "  - id: p2\n    event: prompt\n    keywords: リリース\n    inject: R\n"
                      "  - id: t1\n    tool: Bash\n    match: grep\n    doc: docs/a.md\n",
                   docs={"docs/a.md": "A\n"})
        make_layer(proj_layer, "rules:\n  - id: p1\n    event: prompt\n    keywords: 本番\n"
                               "    inject: P\n")
        p = run_cli(["test", "デプロイ", "--cwd", cwd], home, g)
        assert p.returncode == 0, (p.returncode, p.stdout, p.stderr)
        assert p.stdout.splitlines()[-1] == "%s 2 %s" % (hint_head, hint_tail), p.stdout
        p = run_cli(["test", "grep -r foo .", "--cwd", cwd], home, g)
        assert p.returncode == 0, (p.returncode, p.stdout, p.stderr)
        assert "1 件マッチ" in p.stdout and hint_head not in p.stdout, p.stdout
        # --event prompt 側の dry-run には案内は付かない
        p = run_cli(["test", "--event", "prompt", "なにもない", "--cwd", cwd], home, g)
        assert p.returncode == 0 and hint_head not in p.stdout, (p.stdout, p.stderr)


# ---------------------------------------------------------------------------
# doctor — plugin の行は健全時にも出る
# ---------------------------------------------------------------------------

def _healthy_layer(td):
    g = os.path.join(td, "g")
    make_layer(g, "rules:\n  - id: a\n    tool: Bash\n    doc: docs/a.md\n",
               docs={"docs/a.md": "A\n"})
    git_backed(g)
    return g


def _plugin_registry(td, snapshot_bytes, version="0.1.0"):
    ip = os.path.join(td, "cache", "toolhint", "toolhint", version)
    os.makedirs(os.path.join(ip, "scripts"), exist_ok=True)
    with open(os.path.join(ip, "scripts", "toolhint.py"), "wb") as f:
        f.write(snapshot_bytes)
    reg = os.path.join(td, "installed_plugins.json")
    with open(reg, "w", encoding="utf-8") as f:
        json.dump({"version": 2, "plugins": {"toolhint@toolhint": [
            {"scope": "user", "installPath": ip, "version": version}]}}, f)
    return reg


def test_doctor_healthy_shows_plugin_line():
    with tempfile.TemporaryDirectory() as td:
        home = os.path.join(td, "home")
        cwd = os.path.join(home, "work")
        os.makedirs(cwd)
        g = _healthy_layer(td)
        with open(ENGINE, "rb") as f:
            engine_bytes = f.read()
        reg = _plugin_registry(td, engine_bytes, version="0.1.0")
        p = run_cli(["doctor", "--cwd", cwd], home, g,
                    extra_env={"TOOLHINT_INSTALLED_PLUGINS": reg})
        assert p.returncode == 0, (p.returncode, p.stdout, p.stderr)
        lines = p.stdout.strip().splitlines()
        assert lines[-1] == "ok — 問題なし (全層とも健全)", lines
        plugin = [l for l in lines if l.startswith("plugin: ")]
        assert plugin == ["plugin: 0.1.0 (最新)"], lines


def test_doctor_stale_plugin_line_and_warning():
    with tempfile.TemporaryDirectory() as td:
        home = os.path.join(td, "home")
        cwd = os.path.join(home, "work")
        os.makedirs(cwd)
        g = _healthy_layer(td)
        reg = _plugin_registry(td, b"# old snapshot\n", version="0.1.0")
        p = run_cli(["doctor", "--cwd", cwd], home, g,
                    extra_env={"TOOLHINT_INSTALLED_PLUGINS": reg})
        assert p.returncode == 0, (p.returncode, p.stdout, p.stderr)  # 警告どまり
        assert "plugin: 0.1.0 (stale" in p.stdout, p.stdout
        assert "注意" in p.stdout and "plugin update" in p.stdout, p.stdout
        assert p.stdout.strip().splitlines()[-1].startswith("ok — 問題なし (注意"), \
            p.stdout


def test_doctor_without_plugin_registry_says_not_installed():
    with tempfile.TemporaryDirectory() as td:
        home = os.path.join(td, "home")
        cwd = os.path.join(home, "work")
        os.makedirs(cwd)
        # 健全 (git 化済み) → 「未インストール」+ ok の 2 行
        g = _healthy_layer(td)
        p = run_cli(["doctor", "--cwd", cwd], home, g)
        assert p.returncode == 0, (p.returncode, p.stdout, p.stderr)
        lines = p.stdout.strip().splitlines()
        assert lines[-1] == "ok — 問題なし (全層とも健全)", lines
        assert any(l.startswith("plugin: 未インストール") for l in lines), lines
        # 注意あり (backup なし) の経路でも plugin の行は出る
        g2 = os.path.join(td, "g2")
        make_layer(g2, "rules:\n  - id: a\n    tool: Bash\n    doc: docs/a.md\n",
                   docs={"docs/a.md": "A\n"})
        p = run_cli(["doctor", "--cwd", cwd], home, g2)
        assert p.returncode == 0, (p.returncode, p.stdout, p.stderr)
        assert "backup なし" in p.stdout, p.stdout
        assert any(l.startswith("plugin: 未インストール")
                   for l in p.stdout.splitlines()), p.stdout


def test_doctor_unreadable_registry_shows_plugin_line_before_warning():
    with tempfile.TemporaryDirectory() as td:
        home = os.path.join(td, "home")
        cwd = os.path.join(home, "work")
        os.makedirs(cwd)
        g = _healthy_layer(td)
        reg = os.path.join(td, "installed_plugins.json")
        with open(reg, "w", encoding="utf-8") as f:
            f.write("{not json")
        p = run_cli(["doctor", "--cwd", cwd], home, g,
                    extra_env={"TOOLHINT_INSTALLED_PLUGINS": reg})
        assert p.returncode == 0, (p.returncode, p.stdout, p.stderr)  # 警告どまり
        lines = p.stdout.splitlines()
        idx = [i for i, l in enumerate(lines) if l.startswith("plugin: 不明")]
        assert idx, lines
        assert lines[idx[0] + 1].startswith("  注意 ") and \
            "installed_plugins.json" in lines[idx[0] + 1], lines


def test_plugin_lines_uses_core_summary_or_falls_back():
    """core の plugin.summary をそのまま出す。summary の無い版の core でも
    installs / warnings から 1 行組み立てて "plugin:" 行が消えない。"""
    cli = load_cli_module()
    assert cli.plugin_lines({"summary": "0.5.0 (最新)", "installs": [],
                             "warnings": []}) == ["plugin: 0.5.0 (最新)"]
    # summary なし + installs あり
    lines = cli.plugin_lines({"installs": [{"version": "0.4.0", "stale": True}],
                              "warnings": ["w1"]})
    assert lines[0].startswith("plugin: 0.4.0 (stale") and lines[1] == "  注意 w1", lines
    assert cli.plugin_lines({"installs": [{"version": "0.4.0", "stale": False}],
                             "warnings": []}) == ["plugin: 0.4.0 (最新)"]
    # summary なし + installs なし
    assert cli.plugin_lines({})[0].startswith("plugin: 未インストール")
    assert cli.plugin_lines(None)[0].startswith("plugin: 未インストール")
    assert cli.plugin_lines({"warnings": ["読めない"]})[0].startswith("plugin: 不明")


def test_doctor_problem_still_exits_one_with_plugin_line():
    with tempfile.TemporaryDirectory() as td:
        home = os.path.join(td, "home")
        cwd = os.path.join(home, "work")
        os.makedirs(cwd)
        g = os.path.join(td, "g")
        make_layer(g, "rules:\n  - id: a\n    tool: Bash\n    doc: docs/gone.md\n")
        p = run_cli(["doctor", "--cwd", cwd], home, g)
        assert p.returncode == 1, (p.returncode, p.stdout, p.stderr)
        assert "NG" in p.stdout and "gone.md" in p.stdout, p.stdout
        assert any(l.startswith("plugin: ") for l in p.stdout.splitlines()), p.stdout


# ---------------------------------------------------------------------------
# docs — 手順書のコマンドが「書いてある場所」から解決できる
#   インストールは 2 経路 (A: GitHub から直接 = ~/.claude/plugins/marketplaces/toolhint/、
#   B: 手元に clone)。README「30 秒で試す」と getting-started の相対パスは clone の
#   親ディレクトリ基準の `./toolhint/...` で進め、§5 で自分のプロジェクトへ cd した後は
#   絶対パスに切り替える
# ---------------------------------------------------------------------------

DOC_README = os.path.join(REPO_ROOT, "README.md")
DOC_GUIDE = os.path.join(REPO_ROOT, "docs", "getting-started.md")


def read_text(path):
    with open(path, encoding="utf-8") as f:
        return f.read()


def sh_blocks(text):
    """markdown 中の ```sh フェンスの中身を [(開始行番号, 本文)] で返す。"""
    out, lines, i = [], text.splitlines(), 0
    while i < len(lines):
        if lines[i].strip() == "```sh":
            start, body = i + 1, []
            i += 1
            while i < len(lines) and lines[i].strip() != "```":
                body.append(lines[i])
                i += 1
            out.append((start, "\n".join(body)))
        i += 1
    return out


def guide_section(text, num):
    """getting-started の「## <num>. 」節の本文 (次の ## まで) を返す。"""
    start = text.index("\n## %d. " % num)
    nxt = text.find("\n## ", start + 1)
    return text[start:nxt if nxt >= 0 else len(text)]


def test_docs_relative_clone_paths_exist_in_repo():
    # `./toolhint/<rest>` は clone の親ディレクトリ基準 — <rest> は repo 内に実在する
    for path in (DOC_README, DOC_GUIDE):
        refs = set(re.findall(r"\./toolhint/([A-Za-z0-9_./-]+)", read_text(path)))
        assert refs, path
        for rest in refs:
            target = os.path.join(REPO_ROOT, rest.rstrip("."))
            assert os.path.exists(target), (path, rest)


def readme_section(text, heading):
    """README の「## <heading>」節の本文 (次の ## まで) を返す。"""
    start = text.index("\n## " + heading)
    nxt = text.find("\n## ", start + 1)
    return text[start:nxt if nxt >= 0 else len(text)]


def test_readme_quickstart_has_two_install_routes():
    # 「30 秒で試す」: 経路 A (GitHub 直接) と経路 B (clone) の両方があり、
    # どのブロックにも素の cd が無い。経路 B は場所の宣言つきで ./toolhint/ 相対
    text = read_text(DOC_README)
    qs = readme_section(text, "30 秒で試す")
    blocks = [body for _, body in sh_blocks(qs)]
    assert blocks, qs
    for body in blocks:
        for line in body.splitlines():
            assert not line.strip().startswith("cd "), line
    joined = "\n".join(blocks)
    # 経路 A: GitHub 直接の 2 コマンド + CLI の場所 (Claude Code の clone 先) + 認証の注記
    assert "claude plugin marketplace add AI-Driven-R-D-Dept/toolhint" in joined, joined
    assert "claude plugin install toolhint@toolhint" in joined, joined
    assert "~/.claude/plugins/marketplaces/toolhint/cli/toolhint" in qs, qs
    assert "認証" in qs, qs
    # 経路 A が経路 B より先に出る (推奨の順)
    assert qs.index("### 経路 A") < qs.index("### 経路 B"), qs
    # 経路 B: clone → local marketplace add。場所の宣言つきで ./toolhint/ 相対
    assert "git clone https://github.com/AI-Driven-R-D-Dept/toolhint.git toolhint" in joined, \
        joined
    assert "claude plugin marketplace add ./toolhint" in joined, joined
    assert "親ディレクトリ" in joined, joined
    assert "./toolhint/cli/toolhint" in qs, qs


def test_readme_first_rule_commands_run_as_written():
    # 「30 秒で試す」の最初のルール (add → test → doctor) は書いてあるまま隔離環境で通る
    text = read_text(DOC_README)
    qs = readme_section(text, "30 秒で試す")
    cmds = [argv for argv, _ in doc_commands(qs)]
    kinds = [argv[1] for argv in cmds]
    assert "add" in kinds and "test" in kinds and "doctor" in kinds, kinds
    with tempfile.TemporaryDirectory() as td:
        home, cwd, g = _isolated(td)
        for argv in cmds:
            p = _run_doc_command(argv, home, g, cwd)
            assert p.returncode == 0, (argv, p.returncode, p.stdout, p.stderr)
            if argv[1] == "test":
                assert "1 件マッチ" in p.stdout, p.stdout


def test_guide_stays_in_clone_parent_outside_section5():
    # §5 (自分のプロジェクトへ cd する節) 以外の sh ブロックに素の cd 行が無く、
    # engine / manager の直叩きは ./toolhint/ 相対で書かれている
    text = read_text(DOC_GUIDE)
    s5 = guide_section(text, 5)
    outside = text.replace(s5, "")
    for start, body in sh_blocks(outside):
        for line in body.splitlines():
            s = line.strip()
            assert not s.startswith("cd "), (start, line)
            for token in ("engine/scripts/toolhint.py", "manager/server.mjs"):
                if token in s:
                    assert "./toolhint/" + token in s, (start, line)


def test_guide_section5_uses_absolute_engine_path():
    # §5 は cd 後 — ./toolhint/ 相対パスは使わず、hook 直叩きは絶対パスで書く
    text = read_text(DOC_GUIDE)
    s5 = guide_section(text, 5)
    blocks = sh_blocks(s5)
    assert blocks, s5
    hook_lines = []
    for start, body in blocks:
        assert "./toolhint/" not in body, (start, body)
        hook_lines += [l for l in body.splitlines()
                       if "engine/scripts/toolhint.py" in l]
    assert hook_lines, "§5 に hook 直叩きの例が無い"
    for l in hook_lines:
        assert re.search(r'"?/[^\s"]*engine/scripts/toolhint\.py"? --event=prompt', l), l
    # 節の本文でも「絶対パス」で指すことを言っている
    assert "絶対パス" in s5, s5


def test_prompt_hook_example_runs_from_project_dir_by_absolute_path():
    # §5 の例そのもの: 自分のプロジェクトの dir を cwd にして、clone 先の絶対パスで
    # engine を --event=prompt で叩くと、ことばきっかけが発火する
    with tempfile.TemporaryDirectory() as td:
        home = os.path.join(td, "home")
        proj = os.path.join(td, "myproj")
        os.makedirs(proj)
        g = os.path.join(td, "g")
        make_layer(g,
                   "rules:\n  - id: dep\n    event: prompt\n    keywords: デプロイ\n"
                   "    doc: docs/dep.md\n",
                   docs={"docs/dep.md": "デプロイ前チェックリスト\n"})
        env = os.environ.copy()
        env["HOME"] = home
        env["TOOLHINT_GLOBAL"] = g
        env.pop("TOOLHINT_DEBUG", None)
        payload = json.dumps({"session_id": "s1", "cwd": proj,
                              "prompt": "そろそろデプロイしたい"}, ensure_ascii=False)
        assert os.path.isabs(ENGINE)
        p = subprocess.run([sys.executable, ENGINE, "--event=prompt"], input=payload,
                           capture_output=True, text=True, env=env, cwd=proj, timeout=30)
        assert p.returncode == 0, (p.returncode, p.stdout, p.stderr)
        out = json.loads(p.stdout.strip().splitlines()[0])
        ctx = out["hookSpecificOutput"]["additionalContext"]
        assert "dep.md" in ctx, ctx
        # 同じ相対パスは、そのプロジェクトの dir からは解決できない (§5 で絶対パスにする理由)
        assert not os.path.exists(os.path.join(proj, "toolhint", "engine",
                                               "scripts", "toolhint.py"))


# ---------------------------------------------------------------------------
# docs — ことばきっかけの CLI (add --event prompt / rule update --keywords /
# test --event prompt) と公開レシピ (TOOLHINT_ALLOWED_HOSTS) / 注入 1 回の条件が
# README / getting-started / glossary で同じ文言になっている。書いてある例は
# 実際に走らせて、出力例が実物と一致することも見る
# ---------------------------------------------------------------------------

DOC_GLOSSARY = os.path.join(REPO_ROOT, "docs", "glossary.md")

PROMPT_CLI_PHRASES = (
    'add --event prompt --id X --keywords "<a, b>"',
    'rule update <id> --keywords "…"',
    'test --event prompt "<発言>"',
)
PROMPT_TEST_HINT_DOC = ("この層にはことばきっかけが N 件ある — 発言に対する dry-run は "
                        '`toolhint test --event prompt "<発言>"`')
PROMPT_ADD_SYNOPSIS = (
    'toolhint add --event prompt --id X --keywords "<a, b>" [--find substring|word|regex] '
    '[--case sensitive|insensitive] (--doc-name X --doc-content Y | --inject "…") '
    '[--every session|always] [--mode pointer|inline] [--layer global|project] '
    '[--scope …] [--yes]')


def guide_subsection(section_text, heading):
    """節の中の「### <heading>」小節 (次の ### まで)。"""
    start = section_text.index("\n### " + heading)
    nxt = section_text.find("\n### ", start + 1)
    return section_text[start:nxt if nxt >= 0 else len(section_text)]


def doc_commands(text):
    """markdown の ```sh ブロックから `toolhint …` の行を順に集める。
    返り値は [(argv, 期待出力の行 or None)] — 期待出力は sh ブロック直後の
    プレーン ``` ブロック (ブロック内の最後のコマンドに対応づける)。
    `\\` 継続行は 1 行に結合し、`#` 以降のコメントは落とす。"""
    lines = text.splitlines()
    out, i = [], 0
    while i < len(lines):
        if lines[i].strip() != "```sh":
            i += 1
            continue
        i += 1
        body = []
        while i < len(lines) and lines[i].strip() != "```":
            body.append(lines[i])
            i += 1
        i += 1  # 閉じフェンス
        joined, cur = [], ""
        for l in body:
            if l.rstrip().endswith("\\"):
                cur += l.rstrip()[:-1]
                continue
            joined.append(cur + l)
            cur = ""
        cmds = [shlex.split(l, comments=True) for l in joined
                if l.strip().startswith("toolhint ")]
        # 直後のプレーンブロック
        j = i
        while j < len(lines) and not lines[j].strip():
            j += 1
        expected = None
        if j < len(lines) and lines[j].strip() == "```":
            j += 1
            expected = []
            while j < len(lines) and lines[j].strip() != "```":
                expected.append(lines[j])
                j += 1
        for k, argv in enumerate(cmds):
            out.append((argv, expected if k == len(cmds) - 1 else None))
    return out


def _run_doc_command(argv, home, g, cwd):
    assert argv[0] == "toolhint", argv
    return run_cli(argv[1:], home, g, cwd=cwd)


def _stdout_matches(p, expected, proj):
    exp = [l.replace("/path/to/project", proj) for l in expected
           if not l.startswith("[toolhint] project 層は backup 未設定")]
    assert p.stdout.splitlines() == exp, (p.stdout, exp)


def test_readme_feature_table_lists_prompt_cli():
    text = read_text(DOC_README)
    row = [l for l in text.splitlines() if l.startswith("| CLI `cli/toolhint`")]
    assert len(row) == 1, row
    row = row[0]
    for phrase in PROMPT_CLI_PHRASES:
        assert phrase in row, (phrase, row)
    # 「CLI にはまだ無い」の旧文言が残っていない
    assert "まだ無い" not in row, row
    # agent 起案 (「ことばで頼む」) は GUI のみ、と言っている
    assert "ことばで頼む" in row and "GUI のみ" in row, row


def test_guide_section5_prompt_subsection_has_spec_commands():
    text = read_text(DOC_GUIDE)
    sub = guide_subsection(guide_section(text, 5), "ことばきっかけ")
    # 作成の形と、CLI の実物 (--id 必須) が一致
    assert PROMPT_ADD_SYNOPSIS in sub, sub
    # 編集の形と拒否文言 (core の実物と同じ)
    assert 'toolhint rule update <id> --keywords "…" [--find …] [--case …]' in sub, sub
    assert "操作きっかけのルールに keywords は使えない (ことばきっかけ専用のキー)" in sub, sub
    assert "event: prompt のルールに tool は使えない (操作きっかけ専用のキー)" in sub, sub
    assert "--keywords は --event prompt のときだけ使える" in sub, sub
    # dry-run の出力体裁 (tool の test と同じ) と 案内 1 行
    assert "マッチなし (event=prompt, input='そろそろデプロイしたい')" in sub, sub
    assert "件マッチ (every 抑制は無視・state 不変):" in sub, sub
    assert PROMPT_TEST_HINT_DOC in sub, sub
    # §3 にも同じ案内文が 1 行 (逐語一致)
    assert PROMPT_TEST_HINT_DOC in guide_section(text, 3)
    # 実行例が sh ブロックにある
    cmds = "\n".join(body for _, body in sh_blocks(sub))
    assert "toolhint add --event prompt" in cmds, cmds
    assert "toolhint rule update deploy-docs --keywords" in cmds, cmds
    assert 'toolhint test --event prompt "そろそろデプロイしたい"' in cmds, cmds
    # 旧文言 (CLI に無い) が消えている
    assert "まだ無い" not in sub, sub


def test_docs_prompt_phrases_match_cli_help_and_messages():
    """docs が引用する引数・拒否文言・案内文は CLI / core の実物と一字一句同じ。"""
    with tempfile.TemporaryDirectory() as td:
        home, cwd, g = _isolated(td)
        # 引数の名前は --help に全部ある
        p = run_cli(["add", "--help"], home, g)
        for flag in ("--event {tool,prompt}", "--keywords LIST",
                     "--find {substring,word,regex}", "--case {sensitive,insensitive}",
                     "--doc-name", "--doc-content", "--inject", "--every {session,always}",
                     "--mode {pointer,inline}", "--layer {global,project}", "--scope",
                     "--yes"):
            assert flag in p.stdout, (flag, p.stdout)
        p = run_cli(["rule", "update", "--help"], home, g)
        for flag in ("--keywords LIST", "--find {substring,word,regex}",
                     "--case {sensitive,insensitive}"):
            assert flag in p.stdout, (flag, p.stdout)
        p = run_cli(["test", "--help"], home, g)
        assert "--event {tool,prompt}" in p.stdout, p.stdout
        # 案内文の実物 (N を数字にしたもの) と docs の型が一致
        make_layer(g, "rules:\n  - id: p1\n    event: prompt\n    keywords: デプロイ\n"
                      "    inject: P\n")
        p = run_cli(["test", "x", "--cwd", cwd], home, g)
        assert p.stdout.splitlines()[-1] == PROMPT_TEST_HINT_DOC.replace(" N ", " 1 "), p.stdout


KEYWORD_DELIMS_DOC = "`,` / `、` / `，` 区切り"


def test_docs_and_help_list_three_keyword_delimiters():
    """keywords の区切りは `,` / `、` / `，` の 3 種 — README の機能表・getting-started §5・
    glossary・CLI の --help (add / rule update)・engine の記法説明が同じ 3 種を書き、
    旧表記 (2 種だけ) が残っていない。docs が引く拒否文言は core の実物と同じ。"""
    text = read_text(DOC_GUIDE)
    sub = guide_subsection(guide_section(text, 5), "ことばきっかけ")
    assert KEYWORD_DELIMS_DOC in sub, sub
    assert "keywords に有効な要素がない (区切り文字のみ)" in sub, sub
    row = [l for l in read_text(DOC_README).splitlines()
           if l.startswith("| CLI `cli/toolhint`")][0]
    assert KEYWORD_DELIMS_DOC in row, row
    assert KEYWORD_DELIMS_DOC in read_text(DOC_GLOSSARY)
    engine_readme = read_text(os.path.join(REPO_ROOT, "engine", "README.md"))
    assert KEYWORD_DELIMS_DOC in engine_readme, "engine/README.md の keywords 記法"
    for path in (DOC_GUIDE, DOC_README, DOC_GLOSSARY,
                 os.path.join(REPO_ROOT, "engine", "README.md")):
        assert "`,` / `、` 区切り" not in read_text(path), (path, "旧表記 (2 種) が残っている")
    # CLI の --help (argparse が折り返すので空白を潰して比べる)
    with tempfile.TemporaryDirectory() as td:
        home, cwd, g = _isolated(td)
        for argv in (["add", "--help"], ["rule", "update", "--help"]):
            p = run_cli(argv, home, g)
            assert p.returncode == 0, (argv, p.stdout, p.stderr)
            flat = re.sub(r"\s+", " ", p.stdout)
            assert KEYWORD_DELIMS_DOC in flat, (argv, flat)
        # core の拒否文言 (docs が引用したもの) は実物と同じ
        p = run_cli(["add", "--event", "prompt", "--id", "x", "--keywords", "、,，",
                     "--inject", "y", "--layer", "global", "--cwd", cwd], home, g)
        assert p.returncode == 1, (p.returncode, p.stdout, p.stderr)
        assert "keywords に有効な要素がない (区切り文字のみ)" in p.stderr, p.stderr


def test_guide_section3_prompt_dry_run_example_runs():
    """§3: ルールが空の状態で `toolhint test --event prompt "…"` を打つと、
    書いてある出力例と一字一句同じになる。"""
    text = read_text(DOC_GUIDE)
    s3 = guide_section(text, 3)
    cmds = [(argv, exp) for argv, exp in doc_commands(s3) if argv[1] == "test"]
    assert any("--event" in argv and "prompt" in argv for argv, _ in cmds), cmds
    with tempfile.TemporaryDirectory() as td:
        home, cwd, g = _isolated(td)
        cwd = os.path.realpath(cwd)
        for argv, expected in cmds:
            p = _run_doc_command(argv, home, g, cwd)
            assert p.returncode == 0, (argv, p.returncode, p.stdout, p.stderr)
            assert expected, argv
            _stdout_matches(p, expected, cwd)


def test_guide_section5_examples_run_as_written():
    """§5 の CLI 例 (操作きっかけの add → ことばきっかけの add / rule update /
    test --event prompt → list / test) を書いてある順にそのまま自分のプロジェクト dir で
    実行すると全部通り、出力例 (dry-run) は実物と一字一句同じ。`add --ai` は
    claude が要るので飛ばす。"""
    text = read_text(DOC_GUIDE)
    s5 = guide_section(text, 5)
    cmds = [(argv, exp) for argv, exp in doc_commands(s5)
            if not (argv[1] == "add" and "--ai" in argv)]
    kinds = [tuple(argv[1:3]) for argv, _ in cmds]
    assert ("add", "--id") in kinds and ("add", "--event") in kinds, kinds
    assert ("rule", "update") in kinds and ("test", "--event") in kinds, kinds
    assert ("list",) == kinds[-2][:1] and ("test",) == kinds[-1][:1], kinds
    with tempfile.TemporaryDirectory() as td:
        home, proj, g = _isolated(td)
        proj = os.path.realpath(proj)  # CLI は cwd を実パスで出す (symlink 越しの temp dir 対策)
        checked = 0
        for argv, expected in cmds:
            p = _run_doc_command(argv, home, g, proj)
            assert p.returncode == 0, (argv, p.returncode, p.stdout, p.stderr)
            if expected is not None:
                _stdout_matches(p, expected, proj)
                checked += 1
        assert checked >= 3, checked  # add (操作) / test --event prompt / test の出力例
        # ことばきっかけの編集が効いている (rules.yaml を engine パーサで読み戻す)
        rules = {r["id"]: r for r in parsed_rules(os.path.join(proj, ".claude", "toolhint"))}
        assert rules["deploy-docs"]["event"] == "prompt", rules
        assert "リリース" in rules["deploy-docs"]["keywords"], rules
        assert rules["use-rg"]["tool"] == "Bash", rules
        # 実 HOME 側には何も作っていない
        assert not os.path.exists(os.path.join(home, ".claude", "toolhint"))


def test_glossary_defines_prompt_dry_run():
    text = read_text(DOC_GLOSSARY)
    assert "**dry-run**" in text, text
    assert 'toolhint test --event prompt "<発言>"' in text, text
    for phrase in PROMPT_CLI_PHRASES:
        assert phrase in text, (phrase, text)


def test_guide_remote_recipe_includes_allowed_hosts():
    text = read_text(DOC_GUIDE)
    sup = guide_subsection(guide_section(text, 4), "補足")
    cmd_lines = [l for _, body in sh_blocks(sup) for l in body.splitlines()
                 if "manager/server.mjs" in l]
    assert cmd_lines, sup
    for l in cmd_lines:
        assert "HOST=0.0.0.0" in l and "TOOLHINT_TOKEN=" in l, l
        assert "TOOLHINT_ALLOWED_HOSTS=" in l, l
        assert "./toolhint/manager/server.mjs" in l, l
    # 注記 (HOST=0.0.0.0 は許可名にならない / 自ホスト名・localhost 以外は 403)
    assert re.search(r"HOST=0\.0\.0\.0.*TOOLHINT_ALLOWED_HOSTS.*列挙が要る", sup, re.S), sup
    assert "自ホスト名・localhost 以外は 403" in sup, sup
    # 403 の本文は server.mjs の実物と同じ
    server = read_text(os.path.join(REPO_ROOT, "manager", "server.mjs"))
    assert "この Host は許可されていない: " in server and \
        "(必要なら TOOLHINT_ALLOWED_HOSTS で追加)" in server, "server.mjs の 403 文言"
    assert "この Host は許可されていない" in sup and \
        "(必要なら TOOLHINT_ALLOWED_HOSTS で追加)" in sup, sup


def test_guide_has_publish_and_global_only_subsections():
    # README から移した「サブパス配下で公開」「全体層だけを扱うモード」は §4 の補足として
    # 残り、公開系の注意 (TOOLHINT_ALLOWED_HOSTS / 403 / HOST=0.0.0.0) を保っている。
    # README 側は GUI の行から getting-started §4 へ誘導する
    text = read_text(DOC_GUIDE)
    s4 = guide_section(text, 4)
    sub = guide_subsection(s4, "補足: GUI をサブパス配下で公開する")
    assert "TOOLHINT_ALLOWED_HOSTS" in sub and "403" in sub and "HOST=0.0.0.0" in sub, sub
    assert "\n### 補足: 全体層だけを扱うモード" in s4, s4
    assert "TOOLHINT_GLOBAL_ONLY" in s4, s4
    readme = read_text(DOC_README)
    gui_row = [l for l in readme.splitlines() if l.startswith("| GUI (manager)")]
    assert len(gui_row) == 1 and "getting-started" in gui_row[0], gui_row


def test_guide_troubleshoot_has_403_entry():
    text = read_text(DOC_GUIDE)
    s8 = guide_section(text, 8)
    assert "### 403" in s8 and "TOOLHINT_ALLOWED_HOSTS" in s8, s8


def test_guide_section2_has_ten_second_window_note():
    text = read_text(DOC_GUIDE)
    s2 = guide_section(text, 2)
    idx = s2.index("注入は 1 回だけ")
    after = s2[idx:idx + 600]
    assert "10 秒以内" in after and "後着扱い" in after and "注入されない" in after, after


# ---------------------------------------------------------------------------
# runner
# ---------------------------------------------------------------------------

def main():
    if shutil.which("git") is None:
        print("git が無いため doctor 健全系のテストは走らない (git を入れること)")
    tests = [(n, f) for n, f in sorted(globals().items())
             if n.startswith("test_") and callable(f)]
    passed, failed = 0, 0
    for name, fn in tests:
        try:
            fn()
        except Exception as e:
            failed += 1
            print("FAIL %s: %r" % (name, e))
        else:
            passed += 1
            print("PASS %s" % name)
    print("---")
    print("%d passed, %d failed, %d total" % (passed, failed, passed + failed))
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
