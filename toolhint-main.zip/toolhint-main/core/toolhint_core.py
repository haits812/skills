#!/usr/bin/env python3
"""toolhint core — 操作へ紐づけた docs (注入ルール) の管理面 (機械操作の単一窓口)。

manager (GUI server) と cli/toolhint がこの JSON 契約を叩く:

  list     --cwd <path>
      → {"layers":[{"name","dir","exists","parse_error"}...],
         "rules":[{"id","tool","match","doc","inject","mode","every","enabled",
                   "event","keywords","find","case",
                   "layer","overridden","doc_abs","doc_exists"}...],
         "layer_errors":[{"layer","file","error"}...]}
      parse_error は、その層のルールファイル (rules.yaml / rules-scoped.yaml)
      が engine パーサで読めないときの理由 ("<ファイル名>: line N: ..." —
      2 本とも壊れていれば "; " 連結)。健全な層・層なしでは null。engine は
      そういう層を丸ごと読み飛ばすので、その層の rules は 0 件になる —
      「壊れて読み飛ばされている」と「ルールが無い」の区別はこのキーで付ける。
      layer_errors は同じ情報のファイル単位の一覧 (layer = 層名、file =
      絶対パス、error = 理由)。正常時は []。
      enabled は engine 同様 `enabled: "false"` のみ false (既定 true)。
      disabled ルールも一覧には残す (GUI のトグル表示用)。
      layer は "global" | "project" | "layers.d/<名前>" (追加層)。並びは
      engine と同じ読み順 layers.d/* (辞書順) → global → project で、
      overridden は「後の層 (より手元) に同 id がある」。
      event は共通判別 (engine rule_event) の正規化値 "tool"|"prompt"。
      keywords/find/case は prompt ルールの生値透過 (tool ルールでは null)。
      適用範囲つきのルールだけ "scope" キーが増える (無いルールでは省略 —
      この形式を知らない読み手の出力が 1 バイトも変わらないようにするため)。
  dry-run  --cwd <path> --tool <tool> --input <文字列> [--event tool|prompt]
      → {"matches":[{"id","layer","text"}...]}   (state の読み書きは一切しない。
      enabled: false のルールは engine 同様マッチ対象外)
      --tool 経路は event: tool のルールのみ対象。--event=prompt では --tool
      不要 — <input> をユーザー発言として event: prompt のルールのみ判定
      (マッチは engine の rule_matches_prompt — 二重実装しない)。
      --cwd は層の解決だけでなく scope (適用範囲) の判定にもそのまま効く。
  add-rule --layer global|project --cwd <path> --rule <JSON> [--doc-content <文字列>]
      → {"ok":true,"rules_path":"...","doc_path":"..."} / {"ok":false,"error":"..."}
      --doc-content あり = 新規 doc 作成 (従来)。省略時は rule の doc が層内に
      実在することを要求 — 既存 doc への「きっかけ追加」に使う。
      rule は event: tool (既定) / event: prompt (keywords 必須) のどちらも受ける
      (キー制約は validate_event_keys)。doc の無いルールは inject 必須
      (inject が {doc} を参照しないこと。doc_path は null、--doc-content は不可)。
      書き込み先は scope の有無で決まる (scope 付き = rules-scoped.yaml /
      無し = rules.yaml)。id の重複検査は層の 2 ファイルをまたいで行う。
  update-rule --cwd <path> --id <id> --patch <JSON> [--layer global|project]
      → {"ok":true,"layer","rules_path","rule":{...},"changed":bool}
      patch は {tool,match,doc,inject,mode,every,keywords,find,case,scope} の
      部分 JSON (値 null で match/inject/mode/every/find/case/scope をキーごと
      削除)。doc の変更は層内の実在 doc のみ。event の patch は不可 (種別は固定)。
      合成後ルールは event 別に再検証 — prompt への tool patch / tool への
      keywords patch は拒否 (もう一方の種別専用のキーは patch の値が null でも
      拒否 — 「変更なし」で通さない)。
      scope を付けた / 外したときはルール行が層内のファイル間を移動する
      (rules.yaml ⇄ rules-scoped.yaml。rules_path は移動後のファイル)。
      --layer 省略時は id を両層から探す (両層にあればエラーで --layer を要求)。
      書換は層ロック + atomic write + read-back 検証で、対象ファイル全体を
      正準形へ再直列化する (コメント非保存 — README 宣言)。
  rm-rule  --cwd <path> --id <id> [--layer global|project]
      → {"ok":true,"layer","rules_path","removed":{...}}
      ルール行だけを消す (rules.yaml / rules-scoped.yaml のどちらにあっても)。
      doc ファイルは消さない (参照が無くなった doc は doctor が孤児として報告する)。
  enable-rule / disable-rule --cwd <path> --id <id> [--layer global|project]
      → {"ok":true,"layer","rules_path","id","enabled":bool,"changed":bool}
      disable は `enabled: "false"` を書き、engine が注入対象から除外する。
      enable は enabled キーを外す (既定 = enabled の正準形)。冪等。
  docs     --cwd <path>
      → {"docs":[{"name","path_abs","layer":"global|project","exists",
                  "inject_only":false,
                  "body_excerpt" (先頭 120 字 / doc 不在なら null),
                  "triggers":[{"id","tool","match","every","mode","enabled",
                               "layer"}...],
                  "inject_count_7d"}...]}
      rules から doc ごとにグループ化 (同じ doc を複数ルールが指せる)。
      層の docs/ に実在するがどのルールからも参照されない doc も triggers:[] で
      含める (*.bak と dotfile は除外)。inject_count_7d は
      <global層>/log/injections.jsonl の直近 7 日分 (ログ不在なら 0)。
      doc を持たないルール (inject の文面だけを届けるルール) もルール 1 件 =
      1 エントリで含める: {"name":null,"path_abs":null,"layer","exists":false,
      "inject_only":true,"body_excerpt":<inject の先頭 120 字>,
      "triggers":[<そのルール 1 件>],"inject_count_7d"}。同じ inject 文面でも
      id が違えば別エントリ。この inject_count_7d は doc 無しの記録
      (doc が null) を rule_id + 層で数える (project 層は記録の cwd がその
      プロジェクトの中にあるものだけ)。
      並びは inject_count_7d 降順 → 名前昇順 (inject_only はルール id を名前と
      して並べる)。
  log      --cwd <path> [--limit <N>]
      → {"entries":[新しい順に N 件]}   (ログ不在なら空。既定 N=50)
  save-doc --cwd <path> --layer global|project --doc-name <name.md> --content <text>
      → {"ok":true,"doc_path":"..."} / {"ok":false,"error":"..."}
      層の docs/ 配下に書き込む。docs/ 外への path traversal は拒否。
      既存ファイルの上書きは旧内容を <doc>.bak に残す。
  export   --cwd <path> [--layer global|project] [--out PATH]
      → {"ok":true,"bundle_path","layer","docs":[...],"rules_count"}
      層の docs/ + ルールファイル (rules.yaml / rules-scoped.yaml のうち実在
      するもの) + manifest.json (format_version, exported_at, layer, doc 一覧)
      だけを tar.gz に bundle。log/ state/ *.bak .lock は含めない。
      rules_count は両ファイルの合計。既定 layer=global、既定出力
      ./toolhint-<layer>-<日付>.tar.gz。
  import   <bundle> --cwd <path> [--layer ...] [--dry-run] [--overwrite]
      → {"ok":true,"dry_run","layer","layer_dir",
         "rules":[{"id","action":"add|skip|overwrite"}...],
         "docs":[{"path","action":"create|unchanged|skip|overwrite"}...]}
      manifest 検証 + member 名検証 (パストラバーサル拒否) の上、層ロック +
      atomic write + read-back 検証で取り込む。id 衝突 (層の 2 ファイルを
      またいで検査)・内容の異なる doc は既定 skip (--overwrite で上書き。
      既存行が変わるファイルは正準形へ再直列化、追記だけのファイルは原文を保つ)。
      取り込み先ファイルは add-rule と同じく scope の有無で決まる。
      --dry-run は計画だけ返し一切書かない。--layer 省略時は manifest の層。
  backup-init --cwd <path> [--layer global|project]
      → {"ok":true,...}  層 dir を git init + .gitignore (state/ log/ *.bak
      .lock) + 初回 commit。以後、書き込み成功ごとに対象ファイルだけを
      auto-commit (best-effort — 失敗しても本体操作は成功のまま)。
      既に repo 内なら断ってスキップ。git 不在/未 init 層は従来どおり .bak のみ。
  doctor   --cwd <path>
      → {"ok":bool,"layers":[...],"plugin":{...},
         "problems_total","warnings_total"}
      両層の rules.yaml parse 可否・rule が指す doc の実在・孤児 doc・
      backup 状態を はっきり報告。問題あり = exit 1。
      問題 (NG): parse 不能 / id なし / event 別の必須キー欠落 / doc 不在 /
      層外 doc / doc も inject も無い (マッチしても注入するものが無い) /
      inject が {doc} を参照するのに doc が無い — いずれも engine が無言で
      スキップするもの。
      注意: 同一層内の id 重複 (どのファイルに何回あるかを添える) / inline の
      doc が engine の上限 (inline_max_bytes — 既定 64 KB、環境変数で変更可)
      を超えている (engine は本文を注入せず場所だけを示す) / scope の置き場所
      と形 / 孤児 doc / backup なし。
      plugin は配布済みスナップショット (installed_plugins.json の
      installPath 配下の scripts/toolhint.py) と repo engine の内容突き
      合わせ — 食い違いは stale 警告 (engine 更新が実 hook に未反映のまま
      管理面と実挙動が無言で食い違う事故の検出)。plugin.status
      ("latest" | "stale" | "not_installed" | "unknown") と表示用 1 行の
      plugin.summary (例 "0.5.0 (最新)") を健全時にも必ず返す — 表示側は
      「plugin: <summary>」の 1 行を常に出せる。registry のパスは環境変数
      TOOLHINT_INSTALLED_PLUGINS で差し替え可 (テスト用)。

- パーサ・マッチ・層発見のロジックは engine (engine/scripts/toolhint.py) から
  sys.path 経由で import して再利用する (二重実装しない)。
- 層のルールファイルは 2 本 — `rules.yaml` と `rules-scoped.yaml` (engine の
  RULES_FILENAMES)。書式も扱いも同じで、scope (適用範囲) 付きのルールを後者に
  置き分ける運用: この形式を知らない古い版の engine は rules.yaml しか読まない
  ため、scope 付きルールが「適用範囲を無視してどこでも発火する」事故が構造的に
  起きない。読み経路 (list / dry-run / docs / doctor) は両方を読み、書き込み系は
  scope の有無で置き先を決める。
- 追加層 (`<global層>/layers.d/<名前>/`) は読み経路 (list / dry-run / docs /
  doctor) にだけ現れる読み取り専用の層 — 書き込み系 (add-rule / update-rule /
  rm-rule / enable / disable / save-doc / import / export / backup-init) の
  --layer は従来どおり global | project のみで、追加層へは書かない。
  そのマシン / プロジェクトだけ止めたいときは、手元の層に同 id で
  `enabled: "false"` のルールを置く (engine の後勝ちマージで無効になる)。
  追加層のルールが参照できる doc は層 dir 配下のみ — 層外を指すルールは
  engine も dry-run も注入しない (doctor は問題として報告する)。
- 依存: python3 標準ライブラリのみ。
- 管理面なので fail-open にはしない — 異常は JSON でエラーを返す
  (traceback を stdout に漏らさない。TOOLHINT_DEBUG=1 で stderr に出す)。
- rules.yaml の既存内容を壊さない: 追記前にバックアップ → engine パーサで
  read-back 検証 → 失敗ならロールバックしてエラー。
- 書き込みはすべて atomic (同一 dir の tmp へ write → fsync → os.replace)。
  中断してもファイルは「旧内容のまま」か「新内容の完成品」のどちらか。
- rules.yaml / docs の read-modify-write は層 dir 直下の .lock (fcntl.flock)
  で core プロセス間を直列化 (lost update 防止)。engine (読み取り側) は
  ロック不要 — atomic rename により常に完成品ファイルしか見えない。
- save-doc / add-rule の成功時、層が git backup 未 init なら stderr に 1 行だけ
  `backup init` を案内する (<層>/state/backup_nudge の mtime で 7 日
  rate-limit)。stdout の JSON 契約には影響しない。
"""

import argparse
import contextlib
import datetime
import io
import json
import os
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
import time

try:
    import fcntl
except ImportError:  # 非 Unix — 対象環境 (macOS/Linux) では常に成功する
    fcntl = None

DEBUG = os.environ.get("TOOLHINT_DEBUG") == "1"

_CORE_DIR = os.path.dirname(os.path.abspath(os.path.realpath(__file__)))
_REPO_ROOT = os.path.dirname(_CORE_DIR)
_ENGINE_SCRIPTS = os.path.join(_REPO_ROOT, "engine", "scripts")
sys.path.insert(0, _ENGINE_SCRIPTS)
import toolhint  # noqa: E402  (engine のパーサ・マッチ・層発見を再利用)


class CoreError(Exception):
    """利用者に見せる管理面のエラー (JSON の error 文字列になる)。"""


# ---------------------------------------------------------------------------
# 層の解決
# ---------------------------------------------------------------------------

def resolve_layers(cwd):
    """(global_dir, project_dir or None, project_default_dir) を返す。

    project_dir は engine の上方向探索で実在する層のみ。見つからない場合、
    追記・表示用の既定位置は <cwd>/.claude/toolhint。
    """
    cwd_abs = os.path.abspath(os.path.expanduser(cwd or "."))
    global_dir = toolhint.find_global_dir()
    project_dir = toolhint.find_project_dir(cwd_abs, global_dir)
    project_default = os.path.join(cwd_abs, ".claude", "toolhint")
    return global_dir, project_dir, project_default


def read_layers(cwd):
    """読み経路 (list / dry-run / docs / doctor) 共通の層の並び。

    engine の merge と同じ読み順 — layers.d/* (名前の辞書順) → global →
    project (後ほど手元が勝つ)。返り値: [(表示名, dir, exists), ...]。
    追加層 (layers.d/<名前>) は読み取り専用の配布物なので書き込み経路
    (_resolve_layer_dir) からは引き続き到達できない。"""
    global_dir, project_dir, project_default = resolve_layers(cwd)
    layers = [(name, d, True) for name, d in toolhint.find_extra_layers(global_dir)]
    layers.append(("global", global_dir, os.path.isdir(global_dir)))
    layers.append(("project", project_dir or project_default,
                   project_dir is not None))
    return layers


# ---------------------------------------------------------------------------
# 書き込みの堅牢化 — atomic write (tmp+fsync+rename) と層ロック (flock)
# ---------------------------------------------------------------------------

def _atomic_write_bytes(path, data):
    """path を原子的に書き換える: 同一 dir の tmp へ write → fsync → os.replace。

    中断 (例外・クラッシュ) しても path は「旧内容のまま」か「新内容の完成品」の
    どちらかにしかならない。失敗時は tmp を掃除して OSError を送出。
    tmp 名は dot 始まり — クラッシュ残骸が docs 一覧 (dotfile 除外) に混ざらない。"""
    dir_ = os.path.dirname(path) or "."
    fd, tmp = tempfile.mkstemp(
        dir=dir_, prefix="." + os.path.basename(path) + ".", suffix=".tmp")
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    except BaseException:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise
    try:  # rename の永続化を早める dir fsync (best-effort)
        dfd = os.open(dir_, os.O_RDONLY)
        try:
            os.fsync(dfd)
        finally:
            os.close(dfd)
    except OSError:
        pass


def _atomic_write(path, text):
    """テキスト版 atomic write (UTF-8)。実体は _atomic_write_bytes。"""
    _atomic_write_bytes(path, text.encode("utf-8"))


@contextlib.contextmanager
def _layer_lock(layer_dir):
    """層 dir 直下の .lock による排他 flock (with 文で使う)。

    rules.yaml / docs の read-modify-write を core プロセス間で直列化して
    lost update を防ぐ。engine (読み取り側) はロック不要 — 書き込みが
    atomic rename なので読み手は常に完成品ファイルしか見えない。
    ロックはプロセス終了 (クラッシュ含む) で kernel が自動解放する。"""
    os.makedirs(layer_dir, exist_ok=True)
    if fcntl is None:  # 対象環境 (macOS/Linux) 外のみ — ロックなしで続行
        yield
        return
    fd = None
    try:
        try:
            fd = os.open(os.path.join(layer_dir, ".lock"), os.O_CREAT | os.O_RDWR)
            fcntl.flock(fd, fcntl.LOCK_EX)
        except OSError as e:
            raise CoreError("層ロック (%s) を取得できない: %s"
                            % (os.path.join(layer_dir, ".lock"), e))
        yield
    finally:
        if fd is not None:
            os.close(fd)  # close で flock も解放される


# ---------------------------------------------------------------------------
# git backup — backup-init と、init 済み層への auto-commit (best-effort)
# ---------------------------------------------------------------------------

GITIGNORE_PATTERNS = ("state/", "log/", "*.bak", ".lock")

# commit 系の共通フラグ: 環境の user 設定・gpg 署名設定に依存しない
_GIT_IDENTITY = ("-c", "user.name=toolhint",
                 "-c", "user.email=toolhint@localhost",
                 "-c", "commit.gpgsign=false")


def _git_toplevel(path):
    """path を含む git repo の toplevel。repo 外・git 不在なら None (例外なし)。"""
    try:
        p = subprocess.run(["git", "-C", path, "rev-parse", "--show-toplevel"],
                           capture_output=True, text=True, timeout=15)
    except (OSError, subprocess.SubprocessError):
        return None
    if p.returncode != 0:
        return None
    return p.stdout.strip() or None


def _git(layer_dir, args, identity=False):
    """層 dir で git を実行。失敗は CoreError (backup-init の本経路用)。"""
    cmd = ["git", "-C", layer_dir]
    if identity:
        cmd += list(_GIT_IDENTITY)
    cmd += args
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
    except (OSError, subprocess.SubprocessError) as e:
        raise CoreError("git %s の実行に失敗: %s" % (args[0], e))
    if p.returncode != 0:
        raise CoreError("git %s が失敗 (exit=%d): %s"
                        % (args[0], p.returncode,
                           (p.stderr or p.stdout).strip()[-300:]))
    return p


def _auto_commit(layer_dir, paths, message):
    """backup-init 済み (層 dir 直下に .git) の層で、書き込み対象ファイルだけを
    add + commit する。完全 best-effort — 失敗しても本体操作は成功のまま
    (stderr に 1 行だけ出す)。git 未 init の層では何もしない (従来どおり .bak)。"""
    layer_abs = os.path.abspath(layer_dir)
    if not os.path.isdir(os.path.join(layer_abs, ".git")):
        return
    rels = []
    for p in paths:
        rel = os.path.relpath(os.path.abspath(p), layer_abs)
        if rel.split(os.sep, 1)[0] != "..":  # 層外は commit 対象にしない
            rels.append(rel)
    if not rels:
        return
    base = ["git", "-C", layer_abs]
    try:
        subprocess.run(base + ["add", "--"] + rels, capture_output=True,
                       text=True, timeout=30, check=True)
        staged = subprocess.run(base + ["diff", "--cached", "--quiet", "--"] + rels,
                                capture_output=True, timeout=30)
        if staged.returncode == 0:
            return  # 変更なし (同一内容の書き込み等) — 空 commit を作らない
        subprocess.run(base + list(_GIT_IDENTITY)
                       + ["commit", "-q", "-m", message, "--"] + rels,
                       capture_output=True, text=True, timeout=30, check=True)
    except Exception as e:
        try:
            sys.stderr.write(
                "[toolhint] auto-commit 失敗 (本体の書き込みは成功): %s\n" % e)
        except Exception:
            pass


BACKUP_NUDGE_INTERVAL_SEC = 7 * 86400  # 未 backup ナッジの rate-limit (7 日)


def _nudge_backup_if_needed(layer_abs, layer_name):
    """save-doc / add-rule 成功時: 層が git backup 未 init なら stderr へ 1 行だけ
    `backup init` を案内する。<層>/state/backup_nudge の mtime で 7 日 rate-limit。
    完全 best-effort — 失敗しても本体操作の結果 (stdout の JSON) に影響しない。"""
    try:
        if os.path.isdir(os.path.join(layer_abs, ".git")):
            return  # backup-init 済み (auto-commit が守る)
        marker = os.path.join(layer_abs, "state", "backup_nudge")
        try:
            if time.time() - os.path.getmtime(marker) < BACKUP_NUDGE_INTERVAL_SEC:
                return  # rate-limit 内
        except OSError:
            pass  # marker 不在 = 初回
        if _git_toplevel(layer_abs):
            return  # 既存 repo の内側 — repo の履歴が守る (doctor の "repo" と同じ扱い)
        os.makedirs(os.path.dirname(marker), exist_ok=True)
        _atomic_write(marker, "%d\n" % int(time.time()))
        sys.stderr.write(
            "[toolhint] %s 層は backup 未設定 (履歴は上書き前の .bak 1 世代のみ) — "
            "`toolhint backup init --layer %s` で git 化 (この案内は 7 日に 1 回)\n"
            % (layer_name, layer_name))
    except Exception:
        pass


def cmd_backup_init(cwd, layer_name):
    """層 dir を git 化 (init + .gitignore + 初回 commit)。既に repo 内なら断ってスキップ。"""
    layer_name = layer_name or "global"
    layer_abs = _resolve_layer_dir(cwd, layer_name)
    if shutil.which("git") is None:
        raise CoreError(
            "git が見つからない — backup init には git が必要 (現状どおり .bak 退避で運用される)")
    try:
        os.makedirs(layer_abs, exist_ok=True)
    except OSError as e:
        raise CoreError("層 dir を作れない: %s" % e)
    top = _git_toplevel(layer_abs)
    if top is not None:
        if os.path.realpath(top) == os.path.realpath(layer_abs):
            return {"ok": True, "already": True, "layer": layer_name,
                    "layer_dir": layer_abs,
                    "message": "既に git 管理下 (auto-commit 有効): %s" % layer_abs}
        return {"ok": True, "skipped": True, "layer": layer_name,
                "layer_dir": layer_abs,
                "message": ("既に git repo (%s) の内側 — repo の履歴が守るため"
                            "層単体の git 化はしない" % top)}
    with _layer_lock(layer_abs):
        _git(layer_abs, ["init", "-q"])
        gi_path = os.path.join(layer_abs, ".gitignore")
        try:
            if os.path.isfile(gi_path):
                with open(gi_path, "r", encoding="utf-8") as f:
                    gi_text = f.read()
                lines = [l.strip() for l in gi_text.splitlines()]
                missing = [pat for pat in GITIGNORE_PATTERNS if pat not in lines]
                if missing:  # 既存 .gitignore は壊さず不足分だけ足す
                    base = gi_text if gi_text.endswith("\n") or gi_text == "" \
                        else gi_text + "\n"
                    _atomic_write(gi_path, base + "\n".join(missing) + "\n")
            else:
                _atomic_write(gi_path, "\n".join(GITIGNORE_PATTERNS) + "\n")
        except OSError as e:
            raise CoreError(".gitignore を書けない: %s" % e)
        _git(layer_abs, ["add", "--", "."])
        _git(layer_abs, ["commit", "-q", "-m", "toolhint backup init"],
             identity=True)
    return {"ok": True, "initialized": True, "layer": layer_name,
            "layer_dir": layer_abs,
            "message": ("git 化した: %s (以後、書き込み成功ごとに auto-commit)"
                        % layer_abs)}


# ---------------------------------------------------------------------------
# list
# ---------------------------------------------------------------------------

def _rule_entry(rule, layer_name, layer_dir, overridden):
    doc = rule.get("doc")
    doc_abs = os.path.abspath(os.path.join(layer_dir, doc)) if doc else None
    entry = {
        "id": rule.get("id"),
        "tool": rule.get("tool"),
        "match": rule.get("match"),
        "doc": doc,
        "inject": rule.get("inject"),
        "mode": rule.get("mode", "pointer"),
        "every": rule.get("every", "session"),
        "enabled": toolhint.rule_enabled(rule),
        "event": toolhint.rule_event(rule),  # 正規化 "tool" | "prompt"
        "keywords": rule.get("keywords"),
        "find": rule.get("find"),
        "case": rule.get("case"),
        "layer": layer_name,
        "overridden": overridden,
        "doc_abs": doc_abs,
        "doc_exists": bool(doc_abs) and os.path.isfile(doc_abs),
    }
    # 適用範囲つきのルールだけキーを増やす — scope を知らない読み手 (旧 GUI 等)
    # から見て、従来のルールの JSON が 1 バイトも変わらないようにする
    if rule.get("scope"):
        entry["scope"] = rule["scope"]
    return entry


def _parse_rules_file(rules_path):
    """層のルールファイル 1 本を engine パーサで読む (読み経路用・例外を返り値に畳む)。

    返り値: (ルール list, None) / 読めなければ (None, 理由文字列)。
    ファイル不在は ([], None)。理由は engine パーサの文言そのまま
    (構文の問題なら "line N: ..." の行番号つき)。"""
    if not os.path.isfile(rules_path):
        return [], None
    try:
        with open(rules_path, "r", encoding="utf-8") as f:
            return toolhint.parse_rules_yaml(f.read()), None
    except Exception as e:  # MiniYamlError のほか、文字コード・権限の問題も同じ扱い
        return None, str(e)


def _layer_parse_errors(layer_dir):
    """層のルールファイル (rules.yaml / rules-scoped.yaml) のうち engine パーサで
    読めないものを [(絶対パス, 理由), ...] で返す (健全なら [])。
    engine はどちらか 1 本でも読めなければ層全体を読み飛ばすので、この一覧が
    空でない層のルールは 1 件も効いていない。"""
    out = []
    for path in _layer_rules_paths(os.path.abspath(layer_dir)):
        _rules, err = _parse_rules_file(path)
        if err is not None:
            out.append((path, err))
    return out


def cmd_list(cwd):
    ordered = read_layers(cwd)  # layers.d/* → global → project (engine と同じ読み順)
    layers = []
    layer_errors = []
    for name, d, exists in ordered:
        errs = _layer_parse_errors(d) if exists else []
        layers.append({
            "name": name, "dir": d, "exists": exists,
            "parse_error": "; ".join("%s: %s" % (os.path.basename(p), e)
                                     for p, e in errs) or None,
        })
        for p, e in errs:
            layer_errors.append({"layer": name, "file": p, "error": e})
    loaded = [(name, d, toolhint.load_rules(d) if exists else [])
              for name, d, exists in ordered]

    rules = []
    for i, (name, d, rlist) in enumerate(loaded):
        # 後の層 (より手元) に同 id があれば上書きされている — 上書きされた行も
        # 一覧には残す (GUI が「どの層の設定が効いているか」を出せるように)
        later_ids = set()
        for _n, _d, later in loaded[i + 1:]:
            later_ids.update(r["id"] for r in later)
        for r in rlist:
            rules.append(_rule_entry(r, name, d, overridden=r["id"] in later_ids))
    return {"layers": layers, "rules": rules, "layer_errors": layer_errors}


# ---------------------------------------------------------------------------
# dry-run
# ---------------------------------------------------------------------------

def cmd_dry_run(cwd, tool_name, input_str, event="tool"):
    """state の読み書きなし・every 抑制を無視して全マッチを返す。

    event="tool" (既定): --input は tool_input の command 相当の生文字列 —
    engine と同じく {"command": <input>} を JSON 文字列化した対象に match を
    かける。対象は event: tool のルールのみ。
    event="prompt": --input をユーザー発言として event: prompt のルールのみ
    判定する (マッチは engine の rule_matches_prompt — 二重実装しない)。

    scope (適用範囲) 付きのルールは --cwd を「その場所で作業している」と
    見なして判定する — engine が hook payload の cwd で行う判定と同じ。
    """
    global_dir, project_dir, _ = resolve_layers(cwd)
    cwd_abs = os.path.abspath(os.path.expanduser(cwd or "."))
    flat = None
    if event != "prompt":
        flat = toolhint.flatten_tool_input({"command": input_str})
    # merge_layers が layers.d/* → global → project の読み順で解決する (engine と同一)。
    # 層スキャンは 1 回だけ行い merge と層名解決で共有する
    extras = toolhint.find_extra_layers(global_dir)
    merged = toolhint.merge_layers(global_dir, project_dir, extras)
    layer_names = toolhint.layer_name_map(global_dir, project_dir, extras)

    matches = []
    for rid, (rule, layer_dir) in merged.items():
        if toolhint.rule_event(rule) != event:
            continue  # tool 経路と prompt 経路は相互不発 (engine と同じ絞り)
        if event == "prompt":
            if not toolhint.rule_matches_prompt(rule, input_str, cwd_abs):
                continue
        elif not toolhint.rule_matches(rule, tool_name, flat, cwd_abs):
            continue
        layer_name = toolhint.layer_display_name(layer_dir, layer_names)
        # 追加層のルールは層 dir 配下の doc のみ (engine と同じ制限で判定する)
        text = toolhint.build_text(
            rule, layer_dir,
            restrict_doc=toolhint.is_extra_layer_name(layer_name))
        if text is None:  # doc 不在・層外等で発火できないルール (engine が stderr 警告済み)
            continue
        matches.append({"id": rid, "layer": layer_name,
                        "text": "[toolhint] " + text})
    return {"matches": matches}


# ---------------------------------------------------------------------------
# 注入ログの読み出し (engine が書く <global層>/log/injections.jsonl)
# ---------------------------------------------------------------------------

def _load_log_entries(global_dir):
    """injections.jsonl をファイル順 (古い順) で返す。不在なら []。
    壊れた行 (ローテーション断片等) は読み飛ばす。"""
    path = os.path.join(global_dir, "log", "injections.jsonl")
    entries = []
    try:
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                except ValueError:
                    continue
                if isinstance(obj, dict):
                    entries.append(obj)
    except OSError:
        return []
    return entries


def _parse_ts(ts):
    """engine の ISO8601 UTC ("...Z") を aware datetime に。読めなければ None。"""
    if not isinstance(ts, str):
        return None
    try:
        dt = datetime.datetime.fromisoformat(ts.replace("Z", "+00:00"))
    except ValueError:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=datetime.timezone.utc)
    return dt


def _recent_log_entries(global_dir, days=7):
    """直近 days 日の注入記録 (ts が読めない行は除く)。ファイル順。"""
    cutoff = (datetime.datetime.now(datetime.timezone.utc)
              - datetime.timedelta(days=days))
    out = []
    for e in _load_log_entries(global_dir):
        dt = _parse_ts(e.get("ts"))
        if dt is None or dt < cutoff:
            continue
        out.append(e)
    return out


def _doc_inject_counts(recent):
    """doc 絶対パス → 注入回数 (recent = 直近 7 日の記録)。doc 無しの記録は
    数えない (それは _inject_only_count が rule_id + 層で数える)。"""
    counts = {}
    for e in recent:
        doc = e.get("doc")
        if not doc:
            continue
        counts[doc] = counts.get(doc, 0) + 1
    return counts


def _inject_only_count(recent, rule_id, layer_name, layer_dir):
    """doc を持たないルールの注入回数 — doc 無しの記録 (doc が null) を
    rule_id + 層で数える。project 層は記録の cwd がそのプロジェクト
    (層 dir <root>/.claude/toolhint の root) の中にあるものだけ数える —
    別プロジェクトの同 id のルールの記録を混ぜない。"""
    root = None
    if layer_name == "project":
        root = os.path.abspath(os.path.join(layer_dir, os.pardir, os.pardir))
    n = 0
    for e in recent:
        if e.get("doc") or e.get("rule_id") != rule_id \
                or e.get("layer") != layer_name:
            continue
        if root is not None:
            cwd = e.get("cwd")
            if not isinstance(cwd, str) or not cwd:
                continue
            cwd_abs = os.path.abspath(cwd)
            if cwd_abs != root and not cwd_abs.startswith(root + os.sep):
                continue
        n += 1
    return n


def cmd_log(cwd, limit):
    global_dir, _, _ = resolve_layers(cwd)
    entries = _load_log_entries(global_dir)
    entries.reverse()  # 新しい順
    return {"entries": entries[:max(0, limit)]}


# ---------------------------------------------------------------------------
# docs — rules を doc ごとにグループ化 + 孤児 doc + 7 日集計
# ---------------------------------------------------------------------------

def _doc_entry(path_abs, layer_name, counts):
    exists = os.path.isfile(path_abs)
    excerpt = None
    if exists:
        try:
            with open(path_abs, "r", encoding="utf-8", errors="replace") as f:
                excerpt = f.read(120)
        except OSError:
            excerpt = None
    return {"name": os.path.basename(path_abs), "path_abs": path_abs,
            "layer": layer_name, "exists": exists, "inject_only": False,
            "body_excerpt": excerpt,
            "triggers": [], "inject_count_7d": counts.get(path_abs, 0)}


def _trigger_entry(rule, layer_name):
    """docs の triggers[] 1 件 (list の rule エントリより短い表示用の形)。"""
    return {
        "id": rule.get("id"), "tool": rule.get("tool"),
        "match": rule.get("match"), "every": rule.get("every", "session"),
        "mode": rule.get("mode", "pointer"),
        "enabled": toolhint.rule_enabled(rule),
        "event": toolhint.rule_event(rule),
        "keywords": rule.get("keywords"), "find": rule.get("find"),
        "case": rule.get("case"), "layer": layer_name}


def _inject_only_entry(rule, layer_name, layer_dir, recent):
    """doc を持たないルール 1 件 = 1 エントリ。届くのは inject の文面だけなので
    その先頭 120 字を body_excerpt に置く (inject も無いルールは null —
    engine は何も注入せずスキップし、doctor が問題として報告する)。"""
    inject = rule.get("inject")
    return {"name": None, "path_abs": None, "layer": layer_name,
            "exists": False, "inject_only": True,
            "body_excerpt": str(inject)[:120] if inject else None,
            "triggers": [_trigger_entry(rule, layer_name)],
            "inject_count_7d": _inject_only_count(
                recent, rule.get("id"), layer_name, layer_dir)}


def cmd_docs(cwd):
    global_dir, _project_dir, _ = resolve_layers(cwd)
    # 追加層 (layers.d/*) の docs も一覧に出す — 読み取り専用の配布物として
    layers = [(name, d) for name, d, exists in read_layers(cwd) if exists]
    recent = _recent_log_entries(global_dir)
    counts = _doc_inject_counts(recent)  # doc 絶対パス → 直近 7 日の注入回数

    docs = {}  # path_abs → entry
    inject_only = []  # doc を持たないルール (ルール 1 件 = 1 エントリ)
    # 1) rules から doc ごとにグループ化 (同じ doc を複数ルールが指せる)
    for layer_name, layer_dir in layers:
        rules = toolhint.load_rules(layer_dir) if os.path.isdir(layer_dir) else []
        for r in rules:
            doc = r.get("doc")
            if not doc:
                # inject の文面だけを届けるルール — doc の一覧には無いが、
                # ルールとしては存在し注入もする。同じ文面でも id が違えば別の 1 件
                inject_only.append(
                    _inject_only_entry(r, layer_name, layer_dir, recent))
                continue
            path_abs = os.path.abspath(os.path.join(layer_dir, doc))
            entry = docs.get(path_abs)
            if entry is None:
                entry = _doc_entry(path_abs, layer_name, counts)
                docs[path_abs] = entry
            entry["triggers"].append(_trigger_entry(r, layer_name))
    # 2) 層の docs/ に実在するがどのルールからも参照されない doc (triggers:[])
    for layer_name, layer_dir in layers:
        docs_root = os.path.join(layer_dir, "docs")
        if not os.path.isdir(docs_root):
            continue
        for root, _dirs, files in os.walk(docs_root):
            for fn in sorted(files):
                if fn.startswith(".") or fn.endswith(".bak"):
                    continue  # save-doc の退避や dotfile はノイズなので除外
                path_abs = os.path.abspath(os.path.join(root, fn))
                if path_abs not in docs:
                    docs[path_abs] = _doc_entry(path_abs, layer_name, counts)

    def sort_name(d):
        # inject_only エントリは name が無い — ルール id を名前として並べる
        return d["name"] if d["name"] is not None else (d["triggers"][0]["id"] or "")

    ordered = sorted(list(docs.values()) + inject_only,
                     key=lambda d: (-d["inject_count_7d"], sort_name(d)))
    return {"docs": ordered}


# ---------------------------------------------------------------------------
# save-doc — 層の docs/ 配下へ書き込み (.bak 退避 / traversal 拒否)
# ---------------------------------------------------------------------------

def cmd_save_doc(cwd, layer_name, doc_name, content):
    if layer_name not in ("global", "project"):
        raise CoreError("--layer は global | project のいずれか")
    if not doc_name:
        raise CoreError("--doc-name が空")
    global_dir, project_dir, project_default = resolve_layers(cwd)
    layer_dir = global_dir if layer_name == "global" else (project_dir or project_default)
    layer_abs = os.path.abspath(layer_dir)
    docs_root = os.path.join(layer_abs, "docs")
    doc_abs = os.path.abspath(os.path.join(docs_root, doc_name))
    if not doc_abs.startswith(docs_root + os.sep):
        raise CoreError("doc-name は docs/ 配下を指すこと: %r" % doc_name)
    try:
        with _layer_lock(layer_abs):
            os.makedirs(os.path.dirname(doc_abs), exist_ok=True)
            if os.path.isfile(doc_abs):
                shutil.copy2(doc_abs, doc_abs + ".bak")  # 旧内容を退避してから上書き
            _atomic_write(doc_abs, content)
            _auto_commit(layer_abs, [doc_abs],
                         "toolhint save-doc: %s"
                         % os.path.relpath(doc_abs, layer_abs))
    except OSError as e:
        raise CoreError("doc を書き込めない: %s" % e)
    _nudge_backup_if_needed(layer_abs, layer_name)
    return {"ok": True, "doc_path": doc_abs}


# ---------------------------------------------------------------------------
# add-rule — ミニ YAML subset で追記 + read-back 検証
# ---------------------------------------------------------------------------

RULE_KEYS = ("id", "tool", "match", "doc", "inject", "mode", "every", "enabled",
             "event", "keywords", "find", "case", "scope")
# match は任意 — engine と同じ契約 (省略時 = この tool のすべての操作にマッチ)。
# tool / keywords の必須は event 別 (validate_event_keys が担う)。
# doc は inject があれば省略可 (_validate_doc_or_inject が担う — doctor と同じ判定)。
# scope は任意 — 付けると作業ディレクトリが glob パターンに一致する場所だけで発火
REQUIRED_KEYS = ("id",)

# 改行系の制御文字 (str.splitlines の行境界)。\n は \\n にエスケープするので除外
_FORBIDDEN_CHARS = "\r\x0b\x0c\x1c\x1d\x1e\x85\u2028\u2029"


# scope (作業ディレクトリの glob パターン) に入れられない文字 — 制御文字全般。
# パスに現れず、rules.yaml の 1 行値としても壊れるため書かせない
_CONTROL_CHAR_RE = re.compile(r"[\x00-\x1f\x7f]")


def rules_filename(rule):
    """ルールを置くファイル名 — scope 付きは rules-scoped.yaml、無しは rules.yaml。

    分けてある理由はこの形式を知らない古い版の engine への配慮 (module
    docstring 参照)。判定はキーの有無だけで、値の中身は見ない。"""
    return toolhint.SCOPED_RULES_FILENAME if rule.get("scope") \
        else toolhint.RULES_FILENAME


def _layer_rules_paths(layer_abs):
    """層のルールファイルの絶対パス (engine の読み順と同じ並び)。"""
    return [os.path.join(layer_abs, name) for name in toolhint.RULES_FILENAMES]


def _yaml_quote(value, key):
    """engine の lenient エスケープ仕様 (\\n \\t \\" \\\\ のみ) と往復一致する
    double quote 値を作る。"""
    for ch in _FORBIDDEN_CHARS:
        if ch in value:
            raise CoreError(
                "キー %r の値に使用できない改行系文字 %r が含まれる" % (key, ch))
    escaped = (value.replace("\\", "\\\\").replace('"', '\\"')
               .replace("\n", "\\n").replace("\t", "\\t"))
    return '"%s"' % escaped


def serialize_rule(rule):
    """1 ルールを engine のミニ YAML subset で必ず読み戻せるブロックにする。"""
    lines = []
    for key in RULE_KEYS:
        if key not in rule:
            continue
        prefix = "  - " if not lines else "    "
        lines.append("%s%s: %s" % (prefix, key, _yaml_quote(rule[key], key)))
    return "\n".join(lines) + "\n"


def validate_event_keys(rule):
    """event 別のキー制約の共通検証 — add-rule / update-rule (合成後) /
    import (bundle) / doctor の 4 経路で共用する。

    - event=prompt: keywords 必須 (find=regex 以外は分割後の有効要素 1+)・
      tool/match 禁止・find/case の値検証・find=regex は keywords を
      re.compile 検証
    - event 無し/tool: tool 必須・keywords/find/case 禁止・tool/match の
      re.compile 検証 (従来検証の維持)
    - scope (event 共通・任意): 空でない・制御文字を含まないこと。engine は
      不正な scope のルールを読み飛ばさず「どこでも一致しない」に倒すので
      fatal ではないが、黙って発火しないルールになるため問題として報告する

    返り値: [(msg, fatal)] の list (空 = 健全)。fatal=True は engine が
    load 時にルールごと無言で読み飛ばすもの (doctor は fatal で後続の doc 検査を
    打ち切る)。管理面 (add/update/import) は 1 件でもあれば拒否する。"""
    problems = []
    if "scope" in rule:
        scope_raw = rule["scope"]
        if not isinstance(scope_raw, str) or scope_raw.strip() == "":
            problems.append(
                ("scope が空 — 適用範囲を絞れず、engine はどの作業場所にも"
                 "一致させない (このルールはどこでも発火しない)", False))
        elif _CONTROL_CHAR_RE.search(scope_raw):
            problems.append(
                ("scope に制御文字が含まれる — 作業ディレクトリのパスに現れない"
                 "ため、このルールはどこでも発火しない", False))
    ev_raw = rule.get("event")
    if ev_raw is not None and str(ev_raw).strip() not in ("tool", "prompt"):
        problems.append(
            ("event %r は tool | prompt のいずれかでない — engine は tool 扱いにする"
             % ev_raw, False))
    if toolhint.rule_event(rule) == "prompt":
        for key in ("tool", "match"):
            if key in rule:
                problems.append(
                    ("event: prompt のルールに %s は使えない (操作きっかけ専用のキー)"
                     % key, False))
        keywords = rule.get("keywords")
        if not keywords:
            problems.append(
                ("event: prompt のルールに keywords がない — engine は無言でスキップする",
                 True))
        else:
            find_raw = rule.get("find")
            find = "substring"
            if find_raw is not None:
                if str(find_raw).strip() in toolhint.VALID_FINDS:
                    find = str(find_raw).strip()
                else:
                    problems.append(
                        ("find %r は substring | word | regex のいずれかでない — "
                         "engine は substring 扱いにする" % find_raw, False))
            if find == "regex":
                try:
                    re.compile(keywords)
                except re.error as e:
                    problems.append(
                        ("keywords が正規表現として不正 (find: regex): %s — "
                         "マッチ評価時に毎回スキップされる" % e, False))
            elif not toolhint.split_prompt_keywords(keywords):
                problems.append(
                    ("keywords に有効な要素がない (区切り文字のみ) — "
                     "engine は無言でスキップする", True))
        case_raw = rule.get("case")
        if case_raw is not None and str(case_raw).strip() != "sensitive":
            problems.append(
                ("case %r は sensitive のみ (大小無視は case キーを省略) — "
                 "engine は既定 (大小無視) 扱いにする" % case_raw, False))
    else:
        for key in ("keywords", "find", "case"):
            if key in rule:
                problems.append(
                    ("操作きっかけのルールに %s は使えない (ことばきっかけ専用のキー)"
                     % key, False))
        if not rule.get("tool"):
            problems.append(("tool がない — engine は無言でスキップする", True))
        for key in ("tool", "match"):
            if key not in rule:
                continue  # match は省略可 (省略時 = この tool のすべての操作)
            try:
                re.compile(rule[key])
            except re.error as e:
                problems.append(
                    ("%s が正規表現として不正 (%s) — マッチ評価時に毎回スキップされる"
                     % (key, e), False))
    return problems


def _validate_doc_or_inject(rule):
    """doc の無いルールは inject の文面だけを注入する — その inject も無い /
    inject が {doc} を参照している、のどちらもマッチ時に注入するものが作れず
    engine は無言でスキップする (doctor と同じ判定)。管理面は書く前に拒否する。"""
    if rule.get("doc"):
        return
    inject = rule.get("inject")
    if not inject:
        raise CoreError(
            "rule に doc も inject もない — マッチしても注入するものが無い"
            " (doc か inject のどちらかは必須)")
    if "{doc}" in str(inject):
        raise CoreError(
            "doc が無いのに inject が {doc} を参照している — doc を指定するか、"
            "inject から {doc} を外すこと")


def validate_rule(rule):
    if not isinstance(rule, dict):
        raise CoreError("rule は JSON オブジェクトであること")
    unknown = sorted(set(rule) - set(RULE_KEYS))
    if unknown:
        raise CoreError("rule に未知のキー: %s (許可: %s)"
                        % (", ".join(unknown), ", ".join(RULE_KEYS)))
    for key in REQUIRED_KEYS:
        if key not in rule:
            raise CoreError("rule に必須キー %r がない" % key)
    for key, value in rule.items():
        if not isinstance(value, str) or value == "":
            raise CoreError("キー %r の値は空でない文字列であること" % key)
    if rule.get("mode", "pointer") not in ("pointer", "inline"):
        raise CoreError("mode は pointer | inline のいずれか")
    if rule.get("every", "session") not in ("session", "always"):
        raise CoreError("every は session | always のいずれか")
    if rule.get("enabled", "true") not in ("true", "false"):
        raise CoreError('enabled は "true" | "false" (文字列) のいずれか')
    problems = validate_event_keys(rule)
    if problems:
        raise CoreError(problems[0][0])
    _validate_doc_or_inject(rule)
    if "doc" in rule and os.path.isabs(rule["doc"]):
        raise CoreError("doc は層ディレクトリからの相対パスであること")


def cmd_add_rule(layer_name, cwd, rule_json, doc_content):
    if layer_name not in ("global", "project"):
        raise CoreError("--layer は global | project のいずれか")
    try:
        rule = json.loads(rule_json)
    except ValueError as e:
        raise CoreError("--rule の JSON が不正: %s" % e)
    validate_rule(rule)

    global_dir, project_dir, project_default = resolve_layers(cwd)
    layer_dir = global_dir if layer_name == "global" else (project_dir or project_default)
    layer_abs = os.path.abspath(layer_dir)
    # 置き先は scope の有無で決まる (scope 付き = rules-scoped.yaml)
    rules_path = os.path.join(layer_abs, rules_filename(rule))

    # doc は層ディレクトリ配下に限定 (管理面からの path traversal 防止)。
    # doc の無いルール (inject の文面だけ) は doc ファイルに一切触らない
    doc_abs = None
    if "doc" in rule:
        doc_abs = os.path.abspath(os.path.join(layer_abs, rule["doc"]))
        if not doc_abs.startswith(layer_abs + os.sep):
            raise CoreError("doc は層ディレクトリ配下を指すこと: %r" % rule["doc"])
    elif doc_content is not None:
        raise CoreError(
            "doc の無いルールに --doc-content は使えない — 本文を doc として"
            "置くなら rule の doc も指定すること")

    block = serialize_rule(rule)  # 書けない値はここで CoreError (ファイルに触る前)

    # 以降の read-modify-write 全体を層ロックで直列化 (並行 add-rule の lost update 防止)
    with _layer_lock(layer_abs):
        # 層の全ルールファイルを engine パーサで事前検証しつつ読む
        # (追記先が壊れていないこと + id 重複検査を 2 ファイルまたぎで行うため)
        try:
            files = _load_layer_rules(layer_abs)
        except CoreError as e:
            raise CoreError(
                "既存のルールファイルが engine パーサで読めないため安全に"
                "追記できない: %s" % e)
        original = next(o for p, o, _r in files if p == rules_path)
        existing = next(r for p, _o, r in files if p == rules_path)

        # 同層の id 重複はエラー (もう一方のファイルにある id も重複扱い —
        # 同 id が層内に 2 行あると engine のマージで片方が黙って消える)
        for _p, _o, rules in files:
            for r in rules:
                if r.get("id") == rule["id"]:
                    raise CoreError("id %r は %s 層に既に存在する"
                                    % (rule["id"], layer_name))

        # doc ファイル:
        #   --doc-content 省略時 = 実在する doc への「きっかけ追加」— 実在を要求
        #   --doc-content あり   = 既存と同一内容なら再利用、異なればエラー、無ければ作成
        created_doc = False
        if doc_abs is None:
            pass  # doc の無いルール — doc ファイルは作らない・要求しない
        elif doc_content is None:
            if not os.path.isfile(doc_abs):
                raise CoreError(
                    "--doc-content 省略時は doc が層内に実在すること: %s" % doc_abs)
        elif os.path.exists(doc_abs):
            with open(doc_abs, "r", encoding="utf-8") as f:
                if f.read() != doc_content:
                    raise CoreError("doc が既に存在し内容が異なる: %s" % doc_abs)
        else:
            os.makedirs(os.path.dirname(doc_abs), exist_ok=True)
            try:
                _atomic_write(doc_abs, doc_content)
            except OSError as e:
                raise CoreError("doc を書き込めない: %s" % e)
            created_doc = True

        # 追記 (バックアップ = original を保持し、失敗時ロールバック)
        if original is None:
            new_text = "rules:\n" + block
        else:
            base = original if original.endswith("\n") or original == "" else original + "\n"
            new_text = base + "\n" + block

        def rollback():
            try:
                if original is None:
                    if os.path.exists(rules_path):
                        os.remove(rules_path)
                else:
                    _atomic_write(rules_path, original)
                if created_doc and os.path.exists(doc_abs):
                    os.remove(doc_abs)
            except OSError:
                pass

        try:
            _atomic_write(rules_path, new_text)
        except OSError as e:
            rollback()
            raise CoreError("rules.yaml を書き込めない: %s" % e)

        # read-back 検証: engine のパーサで読み戻し、既存ルール不変 + 追記ルール一致
        try:
            with open(rules_path, "r", encoding="utf-8") as f:
                after = toolhint.parse_rules_yaml(f.read())
            ok = (len(after) == len(existing) + 1
                  and after[:len(existing)] == existing
                  and after[-1] == rule)
        except Exception as e:
            rollback()
            raise CoreError("read-back 検証で engine パーサが失敗 (ロールバック済み): %s" % e)
        if not ok:
            rollback()
            raise CoreError("read-back 検証で内容不一致 (ロールバック済み)")

        _auto_commit(layer_abs, [p for p in (rules_path, doc_abs) if p],
                     "toolhint add-rule: %s" % rule["id"])

    _nudge_backup_if_needed(layer_abs, layer_name)
    return {"ok": True, "rules_path": rules_path, "doc_path": doc_abs}


# ---------------------------------------------------------------------------
# export / import — 層 bundle (tar.gz: manifest.json + rules.yaml + docs/)
# ---------------------------------------------------------------------------

BUNDLE_FORMAT_VERSION = 1
_BUNDLE_MEMBER_MAX_BYTES = 16 * 1024 * 1024  # doc 1 ファイルの上限 (テキスト前提)
_BUNDLE_TOTAL_MAX_BYTES = 64 * 1024 * 1024   # bundle 全体の展開上限 (bomb 対策)
_BUNDLE_MAX_MEMBERS = 10_000                 # member 数の上限 (0 byte member 洪水対策)


def _resolve_layer_dir(cwd, layer_name, must_exist=False):
    """layer 名 → 層 dir の絶対パス。project 未発見時は <cwd>/.claude/toolhint。"""
    if layer_name not in ("global", "project"):
        raise CoreError("--layer は global | project のいずれか")
    global_dir, project_dir, project_default = resolve_layers(cwd)
    layer_dir = global_dir if layer_name == "global" \
        else (project_dir or project_default)
    layer_abs = os.path.abspath(layer_dir)
    if must_exist and not os.path.isdir(layer_abs):
        raise CoreError("%s 層のディレクトリが存在しない: %s" % (layer_name, layer_abs))
    return layer_abs


def _layer_doc_relpaths(layer_dir):
    """層の docs/ 配下の通常ファイルの相対パス (docs/... 表記、"/" 区切り) を
    ソート済みで返す。dotfile・dot dir・*.bak は除外 (cmd_docs と同じ基準)。"""
    docs_root = os.path.join(layer_dir, "docs")
    rels = []
    if not os.path.isdir(docs_root):
        return rels
    for root, dirs, files in os.walk(docs_root):
        dirs[:] = [d for d in dirs if not d.startswith(".")]
        for fn in files:
            if fn.startswith(".") or fn.endswith(".bak"):
                continue
            rel = os.path.relpath(os.path.join(root, fn), layer_dir)
            rels.append(rel.replace(os.sep, "/"))
    return sorted(rels)


def _utc_now_iso():
    return datetime.datetime.now(datetime.timezone.utc).strftime(
        "%Y-%m-%dT%H:%M:%SZ")


def cmd_export(cwd, layer_name, out_path):
    layer_name = layer_name or "global"
    layer_abs = _resolve_layer_dir(cwd, layer_name, must_exist=True)
    with _layer_lock(layer_abs):  # 書き込みと重ならない一貫スナップショット
        # 層のルールファイルは 2 本 — 実在するものを両方 bundle に入れる
        # (rules-scoped.yaml を落とすと、その doc だけが届く「孤児 doc 入り
        #  bundle」になる)。format_version は据え置き: rules-scoped.yaml を
        # 知らない旧版の _read_bundle は未知 member として はっきり拒否するので、
        # 黙って一部だけ取り込まれる事故は起きない
        rules_files = []  # [(bundle member 名, bytes), ...]
        rules_count = 0
        for path in _layer_rules_paths(layer_abs):
            if not os.path.isfile(path):
                continue
            with open(path, "rb") as f:
                data = f.read()
            try:
                rules_count += len(
                    toolhint.parse_rules_yaml(data.decode("utf-8")))
            except (UnicodeDecodeError, toolhint.MiniYamlError) as e:
                raise CoreError(
                    "%s が engine パーサで読めないため export しない"
                    " (doctor で確認): %s" % (os.path.basename(path), e))
            rules_files.append((os.path.basename(path), data))
        doc_rels = _layer_doc_relpaths(layer_abs)
        doc_bodies = []
        for rel in doc_rels:
            try:
                with open(os.path.join(layer_abs, rel.replace("/", os.sep)),
                          "rb") as f:
                    doc_bodies.append((rel, f.read()))
            except OSError as e:
                raise CoreError("doc を読めない: %s" % e)
    if not rules_files and not doc_rels:
        raise CoreError(
            "export する対象がない (ルールファイルも docs/ も無い): %s" % layer_abs)

    manifest = {"format_version": BUNDLE_FORMAT_VERSION, "tool": "toolhint",
                "exported_at": _utc_now_iso(), "layer": layer_name,
                "docs": doc_rels, "rules_count": rules_count}
    if not out_path:
        out_path = "toolhint-%s-%s.tar.gz" % (
            layer_name, datetime.date.today().strftime("%Y%m%d"))
    out_abs = os.path.abspath(os.path.expanduser(out_path))
    mtime = int(datetime.datetime.now(datetime.timezone.utc).timestamp())

    def add_bytes(tf, name, data):
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mtime = mtime
        info.mode = 0o644
        info.uid = info.gid = 0
        info.uname = info.gname = ""
        tf.addfile(info, io.BytesIO(data))

    tmp = None
    try:  # bundle も atomic に書く (tmp → fsync → rename)
        fd, tmp = tempfile.mkstemp(
            dir=os.path.dirname(out_abs) or ".",
            prefix="." + os.path.basename(out_abs) + ".", suffix=".tmp")
        with os.fdopen(fd, "wb") as fobj:
            with tarfile.open(fileobj=fobj, mode="w:gz") as tf:
                add_bytes(tf, "manifest.json",
                          (json.dumps(manifest, ensure_ascii=False, indent=2)
                           + "\n").encode("utf-8"))
                for name, data in rules_files:
                    add_bytes(tf, name, data)
                for rel, data in doc_bodies:
                    add_bytes(tf, rel, data)
            fobj.flush()
            os.fsync(fobj.fileno())
        os.replace(tmp, out_abs)
        tmp = None
    except OSError as e:
        raise CoreError("bundle を書き込めない: %s" % e)
    finally:
        if tmp is not None:
            try:
                os.remove(tmp)
            except OSError:
                pass
    return {"ok": True, "bundle_path": out_abs, "layer": layer_name,
            "docs": doc_rels, "rules_count": rules_count}


def _safe_member_name(name):
    """tar member 名の検証 (パストラバーサル対策)。安全な相対名を返す。"""
    if name.startswith("./"):
        name = name[2:]
    if name.startswith("/") or "\\" in name:
        raise CoreError(
            "bundle member 名が不正 (絶対パス/バックスラッシュ): %r" % name)
    parts = name.split("/")
    if any(p in ("", ".", "..") for p in parts):
        raise CoreError("bundle member 名が不正 (パストラバーサル): %r" % name)
    return name


def _read_bundle(bundle_path):
    """tar.gz を安全に読む (ファイルへは一切展開しない — 内容をメモリで検証)。
    返り値: (manifest, {ルールファイル名: text}, {doc_rel: bytes})。
    ルールファイルは rules.yaml と rules-scoped.yaml (どちらも任意)。"""
    if not os.path.isfile(bundle_path):
        raise CoreError("bundle が見つからない: %s" % bundle_path)
    manifest_raw = None
    rules_texts = {}
    docs = {}
    total = 0
    members = 0
    try:
        tf = tarfile.open(bundle_path, mode="r:*")
    except (tarfile.TarError, OSError) as e:
        raise CoreError("bundle を tar として開けない: %s" % e)
    try:
        with tf:
            for m in tf:
                # サイズ上限 (m.size 合計) だけでは 0 byte member を大量に並べた
                # ヘッダ洪水をすり抜ける — 件数でも先に打ち切る (OOM/ハング対策。
                # dir member も tarfile 内部の index に蓄積されるので dir 含めて数える)
                members += 1
                if members > _BUNDLE_MAX_MEMBERS:
                    raise CoreError(
                        "bundle の member 数が上限 (%d) を超える" % _BUNDLE_MAX_MEMBERS)
                if m.isdir():
                    dn = m.name.strip("/")
                    if dn not in ("", "."):
                        _safe_member_name(dn)  # dir 名も検証だけはする
                    continue
                if not m.isfile():
                    raise CoreError(
                        "bundle に通常ファイル以外の member: %r — 拒否"
                        " (symlink/hardlink/デバイス等)" % m.name)
                name = _safe_member_name(m.name)
                if m.size > _BUNDLE_MEMBER_MAX_BYTES:
                    raise CoreError(
                        "bundle member %r が大きすぎる (%d bytes)" % (name, m.size))
                total += m.size
                if total > _BUNDLE_TOTAL_MAX_BYTES:
                    raise CoreError("bundle の展開サイズが上限を超える")
                data = tf.extractfile(m).read()
                if name == "manifest.json":
                    manifest_raw = data
                elif name in toolhint.RULES_FILENAMES:
                    try:
                        rules_texts[name] = data.decode("utf-8")
                    except UnicodeDecodeError as e:
                        raise CoreError("bundle の %s が UTF-8 でない: %s"
                                        % (name, e))
                elif name.startswith("docs/"):
                    docs[name] = data
                else:
                    raise CoreError(
                        "bundle に想定外の member: %r"
                        " (manifest.json / %s / docs/* のみ)"
                        % (name, " / ".join(toolhint.RULES_FILENAMES)))
    except tarfile.TarError as e:
        raise CoreError("bundle の読み取りに失敗: %s" % e)
    if manifest_raw is None:
        raise CoreError("bundle に manifest.json がない")
    try:
        manifest = json.loads(manifest_raw.decode("utf-8"))
    except (ValueError, UnicodeDecodeError) as e:
        raise CoreError("manifest.json が読めない: %s" % e)
    if not isinstance(manifest, dict):
        raise CoreError("manifest.json はオブジェクトであること")
    fv = manifest.get("format_version")
    if fv != BUNDLE_FORMAT_VERSION:
        raise CoreError("未対応の format_version: %r (このバージョンの対応: %d)"
                        % (fv, BUNDLE_FORMAT_VERSION))
    if manifest.get("layer") not in ("global", "project"):
        raise CoreError("manifest の layer が不正: %r" % manifest.get("layer"))
    mdocs = manifest.get("docs")
    if not isinstance(mdocs, list) or sorted(mdocs) != sorted(docs):
        raise CoreError("manifest の doc 一覧と bundle の中身が一致しない")
    return manifest, rules_texts, docs


def _validate_bundle_rules(rules, layer_abs):
    seen = set()
    for i, r in enumerate(rules):
        rid = r.get("id")
        if not rid:
            raise CoreError("bundle の rules.yaml: ルール #%d に id がない" % (i + 1))
        if rid in seen:
            raise CoreError("bundle の rules.yaml: id %r が重複" % rid)
        seen.add(rid)
        for msg, _fatal in validate_event_keys(r):  # event 別の共通検証
            raise CoreError("bundle の rules.yaml: ルール %r: %s" % (rid, msg))
        doc = r.get("doc")
        if doc is not None:
            if os.path.isabs(doc):
                raise CoreError(
                    "bundle の rules.yaml: ルール %r の doc が絶対パス: %r" % (rid, doc))
            doc_abs = os.path.abspath(os.path.join(layer_abs, doc))
            if not doc_abs.startswith(layer_abs + os.sep):
                raise CoreError(
                    "bundle の rules.yaml: ルール %r の doc が層外を指す: %r" % (rid, doc))


def _serialize_rule_full(rule):
    """import 用 — RULE_KEYS 先行で、engine パーサ由来の未知キーも落とさず
    engine subset へ直列化する (serialize_rule は既知キーのみなので使わない)。"""
    keys = [k for k in RULE_KEYS if k in rule] \
        + [k for k in rule if k not in RULE_KEYS]
    lines = []
    for key in keys:
        prefix = "  - " if not lines else "    "
        lines.append("%s%s: %s" % (prefix, key, _yaml_quote(rule[key], key)))
    return "\n".join(lines) + "\n"


def _load_rules_file(rules_path):
    """rules.yaml → (原文 or None, ルール list)。読めなければ CoreError。"""
    if not os.path.isfile(rules_path):
        return None, []
    with open(rules_path, "r", encoding="utf-8") as f:
        original = f.read()
    try:
        return original, toolhint.parse_rules_yaml(original)
    except toolhint.MiniYamlError as e:
        raise CoreError(
            "%s が engine パーサで読めない — 先に doctor で確認して"
            "直すこと: %s" % (rules_path, e))


def _load_layer_rules(layer_abs):
    """層のルールファイルをすべて読む → [(path, 原文 or None, ルール list), ...]
    (engine の読み順)。1 本でも読めなければ CoreError — 書き込み前に止める。"""
    return [(path,) + _load_rules_file(path)
            for path in _layer_rules_paths(layer_abs)]


def _plan_import(layer_abs, existing_rules, bundle_rules, bundle_docs, overwrite):
    """何をどうするかの計画 (dry-run と実 apply で共通)。"""
    existing_ids = {r.get("id") for r in existing_rules}
    rule_actions = []
    for r in bundle_rules:
        if r["id"] in existing_ids:
            action = "overwrite" if overwrite else "skip"
        else:
            action = "add"
        rule_actions.append({"id": r["id"], "action": action})
    doc_actions = []
    for rel in sorted(bundle_docs):
        dest = os.path.join(layer_abs, rel.replace("/", os.sep))
        if not os.path.exists(dest):
            action = "create"
        else:
            try:
                with open(dest, "rb") as f:
                    same = f.read() == bundle_docs[rel]
            except OSError:
                same = False
            if same:
                action = "unchanged"
            else:
                action = "overwrite" if overwrite else "skip"
        doc_actions.append({"path": rel, "action": action})
    return rule_actions, doc_actions


def _appended_or_canonical_text(original, old_rules, new_rules):
    """1 ルールファイルの新テキスト。

    末尾への追記だけなら原文 + ブロック追記 (手書きコメントを保存する従来経路)、
    既存行が変わる (上書き・削除・移動) なら全体を正準形へ再直列化する。"""
    if new_rules[:len(old_rules)] == old_rules:
        added = "\n".join(_serialize_rule_full(r)
                          for r in new_rules[len(old_rules):])
        if original is None:
            return "rules:\n" + added
        base = original if (original.endswith("\n") or original == "") \
            else original + "\n"
        return base + "\n" + added if added else base
    return _canonical_rules_text(new_rules)


def _plan_import_files(layer_abs, files, bundle_rules, add_ids, ow_ids):
    """取り込み後の「ファイル → ルール list」を作る。

    置き先は rules_filename (scope の有無) — bundle 側で scope が付いた /
    外れたルールも、この層では正しいファイルへ着地する。上書きで置き先が
    変わらないものは元の位置のまま差し替える (並びと手書きコメントの保存)。"""
    by_id = {r["id"]: r for r in bundle_rules}
    new_by_path = {}
    placed = set()  # その場で差し替えできた上書き id
    for path, _original, rules in files:
        out = []
        for r in rules:
            rid = r.get("id")
            if rid in ow_ids:
                incoming = by_id[rid]
                if os.path.join(layer_abs, rules_filename(incoming)) == path:
                    out.append(incoming)  # 同じファイル — その場で差し替え
                    placed.add(rid)
                continue  # 置き先が変わるものはここで落とし、下で移動先へ足す
            out.append(r)
        new_by_path[path] = out
    for r in bundle_rules:  # 新規 + 置き先が変わった上書きを末尾へ
        rid = r["id"]
        if rid not in add_ids and not (rid in ow_ids and rid not in placed):
            continue
        new_by_path[os.path.join(layer_abs, rules_filename(r))].append(r)
    return new_by_path


def cmd_import(cwd, bundle_path, layer_name, dry_run, overwrite):
    bundle_abs = os.path.abspath(os.path.expanduser(bundle_path))
    manifest, rules_texts, bundle_docs = _read_bundle(bundle_abs)
    layer_name = layer_name or manifest["layer"]
    layer_abs = _resolve_layer_dir(cwd, layer_name)
    bundle_rules = []
    for name in toolhint.RULES_FILENAMES:  # bundle も 2 本立て (どちらも任意)
        if name not in rules_texts:
            continue
        try:
            bundle_rules += toolhint.parse_rules_yaml(rules_texts[name])
        except toolhint.MiniYamlError as e:
            raise CoreError("bundle の %s が engine パーサで読めない: %s"
                            % (name, e))
    _validate_bundle_rules(bundle_rules, layer_abs)
    # 直列化できない値はここで落とす (どこにも書く前)
    for r in bundle_rules:
        _serialize_rule_full(r)

    def result(rule_actions, doc_actions, dry):
        return {"ok": True, "dry_run": dry, "layer": layer_name,
                "layer_dir": layer_abs, "rules": rule_actions, "docs": doc_actions}

    if dry_run:  # 完全無副作用 — 層 dir もロックファイルも作らない
        # id 衝突の検査は層の 2 ファイルをまたぐ (add-rule と同じ基準)
        existing = [r for _p, _o, rules in _load_layer_rules(layer_abs)
                    for r in rules]
        ra, da = _plan_import(layer_abs, existing, bundle_rules, bundle_docs,
                              overwrite)
        return result(ra, da, True)

    with _layer_lock(layer_abs):
        files = _load_layer_rules(layer_abs)
        originals = {path: original for path, original, _r in files}
        current = {path: rules for path, _o, rules in files}
        existing = [r for _p, _o, rules in files for r in rules]
        rule_actions, doc_actions = _plan_import(
            layer_abs, existing, bundle_rules, bundle_docs, overwrite)
        add_ids = {ra["id"] for ra in rule_actions if ra["action"] == "add"}
        ow_ids = {ra["id"] for ra in rule_actions if ra["action"] == "overwrite"}
        # ファイルごとの取り込み後 list → 変わるファイルだけ書く
        new_by_path = _plan_import_files(layer_abs, files, bundle_rules,
                                         add_ids, ow_ids)
        rule_plan = {path: rules for path, rules in new_by_path.items()
                     if rules != current[path]}
        texts = {path: _appended_or_canonical_text(
            originals[path], current[path], rules)
            for path, rules in rule_plan.items()}

        written = []  # (path, 旧 bytes or None) — 失敗時 rollback 用
        changed = []

        def rollback():
            for path, old in reversed(written):
                try:
                    if old is None:
                        os.remove(path)
                    else:
                        _atomic_write_bytes(path, old)
                except OSError:
                    pass
            for path in rule_plan:
                try:
                    if originals[path] is None:
                        if os.path.exists(path):
                            os.remove(path)
                    else:
                        _atomic_write(path, originals[path])
                except OSError:
                    pass

        try:
            for da in doc_actions:
                if da["action"] not in ("create", "overwrite"):
                    continue
                dest = os.path.join(layer_abs, da["path"].replace("/", os.sep))
                old = None
                os.makedirs(os.path.dirname(dest), exist_ok=True)
                if os.path.isfile(dest):
                    with open(dest, "rb") as f:
                        old = f.read()
                    shutil.copy2(dest, dest + ".bak")  # save-doc と同じ退避
                _atomic_write_bytes(dest, bundle_docs[da["path"]])
                written.append((dest, old))
                changed.append(dest)
            for path, text in texts.items():
                _atomic_write(path, text)
                changed.append(path)
                with open(path, "r", encoding="utf-8") as f:
                    after = toolhint.parse_rules_yaml(f.read())
                if after != rule_plan[path]:
                    raise CoreError("read-back 検証で内容不一致 (%s)"
                                    % os.path.basename(path))
        except Exception as e:
            rollback()
            raise CoreError("import に失敗しロールバックした: %s" % e)
        if changed:
            _auto_commit(layer_abs, changed,
                         "toolhint import: %s" % os.path.basename(bundle_abs))
    return result(rule_actions, doc_actions, False)


# ---------------------------------------------------------------------------
# rule CRUD — update / rm / enable / disable (正準形へ再直列化して書き換える)
#
# 書換は必ず 層ロック + atomic write + engine パーサでの read-back 検証。
# rules.yaml 全体を正準形 (全値 double quote・機械管理) へ再直列化するため
# 手書きコメントは保存されない (README で宣言済み)。
# ---------------------------------------------------------------------------

UPDATABLE_KEYS = ("tool", "match", "doc", "inject", "mode", "every",
                  "keywords", "find", "case",
                  "scope")  # event の patch は不可 (種別固定)
REMOVABLE_KEYS = ("match", "inject", "mode", "every",
                  "find", "case", "scope")  # patch 値 null で削除可 (既定へ戻す)


def _canonical_rules_text(rules):
    """ルール list 全体を正準形の rules.yaml テキストへ再直列化する。"""
    return "rules:\n" + "\n".join(_serialize_rule_full(r) for r in rules)


def _layer_has_rule(layer_abs, rule_id):
    """層 (2 本のルールファイル) のどこかに rule_id があるか。"""
    return any(r.get("id") == rule_id
               for _p, _o, rules in _load_layer_rules(layer_abs)
               for r in rules)


def _locate_rule(cwd, rule_id, layer_name):
    """rule_id を含む層を解決 → (layer_name, layer_abs)。

    --layer 指定ありならその層のみを見る。省略時は project → global の順に
    探し、両層に同 id があれば --layer を要求 (どちらを書き換えるか曖昧)。
    層の中では rules.yaml / rules-scoped.yaml の両方を見る。"""
    if not rule_id:
        raise CoreError("--id が空")
    if layer_name is not None:
        layer_abs = _resolve_layer_dir(cwd, layer_name)
        if not _layer_has_rule(layer_abs, rule_id):
            raise CoreError("id %r は %s 層に存在しない" % (rule_id, layer_name))
        return layer_name, layer_abs
    found = []
    for name in ("project", "global"):
        layer_abs = _resolve_layer_dir(cwd, name)
        if _layer_has_rule(layer_abs, rule_id):
            found.append((name, layer_abs))
    if not found:
        raise CoreError("id %r はどの層にも存在しない" % rule_id)
    if len(found) > 1:
        raise CoreError(
            "id %r が global / project 両層に存在する — --layer で指定すること"
            % rule_id)
    return found[0]


def _rewrite_rules(cwd, layer_name, rule_id, transform, commit_msg,
                   relocate=False):
    """rule_id を含む層のルールファイルを書き換える共通経路。

    transform(rules, idx, layer_abs) — rules は「rule_id があるファイル」の
    ルール list のコピー。新しい list を返す。変更が無ければ書かない
    (changed=False)。書換は 層ロック + atomic write + read-back 検証 +
    失敗ロールバック (複数ファイルを触る場合はまとめてロールバックする)。

    relocate=True (update-rule) では、transform 後のルールの置き先
    (rules_filename — scope の有無で決まる) が今のファイルと違えば、その
    ルール行だけを層内のもう一方のファイルへ移す。scope を付けた / 外した
    ときに rules.yaml ⇄ rules-scoped.yaml を行き来させるための経路で、
    同じファイルに居る他のルールは動かさない (手で置いた行を勝手に移動しない)。
    移動や削除で空になったファイルは `rules:` だけを残す (消さない) — engine に
    とって 0 件と同義で無害な一方、削除はロールバックと並行読みを複雑にするため。

    返り値: (layer_name, layer_abs, rules_path, layer_rules, changed)。
    rules_path は編集後のルールがあるファイル (移動したなら移動先)、
    layer_rules は書換後の層全体のルール list。"""
    layer_name, layer_abs = _locate_rule(cwd, rule_id, layer_name)
    with _layer_lock(layer_abs):
        # ロック取得後に読み直す (並行変更に負けない)
        files = _load_layer_rules(layer_abs)
        originals = {path: original for path, original, _r in files}
        current = {path: rules for path, _o, rules in files}
        src_path = idx = None
        for path, _o, rules in files:
            idx = next((i for i, r in enumerate(rules)
                        if r.get("id") == rule_id), None)
            if idx is not None:
                src_path = path
                break
        if src_path is None:
            raise CoreError("id %r は %s 層に存在しない (並行変更?)"
                            % (rule_id, layer_name))

        new_src = transform([dict(r) for r in current[src_path]], idx, layer_abs)
        plan = {}  # 書き換えるファイルだけ path → 新しいルール list
        rules_path = src_path
        if relocate:
            edited = next((r for r in new_src if r.get("id") == rule_id), None)
            if edited is not None:
                want = os.path.join(layer_abs, rules_filename(edited))
                if want != src_path:  # scope の付け外しでファイル間を移動する
                    new_src = [r for r in new_src if r.get("id") != rule_id]
                    # 移動先に同 id が居る異常状態 (手編集で両ファイルに同 id が
                    # ある etc.) では、その行を落として 1 行に畳む (自己修復)
                    plan[want] = [r for r in current[want]
                                  if r.get("id") != rule_id] + [edited]
                    rules_path = want
        if new_src != current[src_path]:
            plan[src_path] = new_src
        if not plan:
            return (layer_name, layer_abs, rules_path,
                    [r for _p, _o, rs in files for r in rs], False)
        # 直列化不能な値はここで CoreError (どのファイルにも触る前)
        texts = {path: _canonical_rules_text(rules)
                 for path, rules in plan.items()}

        def rollback():
            for path in plan:
                try:
                    if originals[path] is None:
                        if os.path.exists(path):
                            os.remove(path)
                    else:
                        _atomic_write(path, originals[path])
                except OSError:
                    pass

        try:
            for path, text in texts.items():
                _atomic_write(path, text)
        except OSError as e:
            rollback()
            raise CoreError("ルールファイルを書き込めない: %s" % e)
        for path, rules in plan.items():
            try:
                with open(path, "r", encoding="utf-8") as f:
                    after = toolhint.parse_rules_yaml(f.read())
            except Exception as e:
                rollback()
                raise CoreError(
                    "read-back 検証で engine パーサが失敗 (ロールバック済み): %s" % e)
            if after != rules:
                rollback()
                raise CoreError("read-back 検証で内容不一致 (ロールバック済み)")
        _auto_commit(layer_abs, sorted(plan), commit_msg)
        layer_rules = [r for path in current
                       for r in plan.get(path, current[path])]
    return layer_name, layer_abs, rules_path, layer_rules, True


def cmd_update_rule(cwd, layer_name, rule_id, patch_json):
    try:
        patch = json.loads(patch_json)
    except ValueError as e:
        raise CoreError("--patch の JSON が不正: %s" % e)
    if not isinstance(patch, dict) or not patch:
        raise CoreError("--patch は空でない JSON オブジェクトであること")
    unknown = sorted(set(patch) - set(UPDATABLE_KEYS))
    if unknown:
        raise CoreError("更新できないキー: %s (許可: %s)"
                        % (", ".join(unknown), ", ".join(UPDATABLE_KEYS)))
    for key, value in patch.items():
        if value is None:
            if key not in REMOVABLE_KEYS:
                raise CoreError("キー %r は削除 (null) できない (削除可: %s)"
                                % (key, ", ".join(REMOVABLE_KEYS)))
            continue
        if not isinstance(value, str) or value == "":
            raise CoreError(
                "キー %r の値は空でない文字列 (または削除の null) であること" % key)

    def transform(rules, idx, layer_abs):
        rule = rules[idx]
        # もう一方の種別専用のキーは、値が null (削除) でも拒否する — 削除は
        # 元々無いキーの no-op で「変更なし」として通ってしまい、種別違いの
        # 指定が黙って受理されたように見えるため (合成後検証と同じ文言)
        if toolhint.rule_event(rule) == "prompt":
            foreign = [k for k in ("tool", "match") if k in patch]
            if foreign:
                raise CoreError(
                    "event: prompt のルールに %s は使えない (操作きっかけ専用のキー)"
                    % foreign[0])
        else:
            foreign = [k for k in ("keywords", "find", "case") if k in patch]
            if foreign:
                raise CoreError(
                    "操作きっかけのルールに %s は使えない (ことばきっかけ専用のキー)"
                    % foreign[0])
        for key, value in patch.items():
            if value is None:
                rule.pop(key, None)
            else:
                rule[key] = value
        # 合成後の検証 — engine が正しく読める・発火できるルールであること。
        # event 別の共通検証で混種 patch (prompt へ tool/match, tool へ
        # keywords/find/case) もここで拒否する
        if rule.get("mode", "pointer") not in ("pointer", "inline"):
            raise CoreError("mode は pointer | inline のいずれか")
        if rule.get("every", "session") not in ("session", "always"):
            raise CoreError("every は session | always のいずれか")
        problems = validate_event_keys(rule)
        if problems:
            raise CoreError(problems[0][0])
        _validate_doc_or_inject(rule)  # doc 無しは inject 必須 ({doc} 参照不可)
        doc = rule.get("doc")
        if doc is not None:
            if os.path.isabs(doc):
                raise CoreError("doc は層ディレクトリからの相対パスであること")
            doc_abs = os.path.abspath(os.path.join(layer_abs, doc))
            if not doc_abs.startswith(layer_abs + os.sep):
                raise CoreError("doc は層ディレクトリ配下を指すこと: %r" % doc)
            if "doc" in patch and not os.path.isfile(doc_abs):
                raise CoreError(
                    "変更後の doc が層内に実在しない: %s (add-rule の"
                    "「きっかけ追加」と同じ契約)" % doc_abs)
        rules[idx] = rule
        return rules

    # relocate=True — scope の付け外しでルール行を rules.yaml ⇄
    # rules-scoped.yaml へ移す (置き先は rules_filename が決める)
    layer_name, _, rules_path, new_rules, changed = _rewrite_rules(
        cwd, layer_name, rule_id, transform,
        "toolhint update-rule: %s" % rule_id, relocate=True)
    updated = next(r for r in new_rules if r.get("id") == rule_id)
    return {"ok": True, "layer": layer_name, "rules_path": rules_path,
            "rule": updated, "changed": changed}


def cmd_rm_rule(cwd, layer_name, rule_id):
    removed_holder = []

    def transform(rules, idx, _layer_abs):
        removed_holder.append(rules.pop(idx))
        return rules

    layer_name, _, rules_path, _, _ = _rewrite_rules(
        cwd, layer_name, rule_id, transform,
        "toolhint rm-rule: %s" % rule_id)
    # doc ファイルは消さない — 参照が無くなった doc は doctor が孤児として報告
    return {"ok": True, "layer": layer_name, "rules_path": rules_path,
            "removed": removed_holder[0]}


def cmd_set_rule_enabled(cwd, layer_name, rule_id, enabled):
    def transform(rules, idx, _layer_abs):
        if enabled:
            rules[idx].pop("enabled", None)  # 正準形: キーなし = enabled
        else:
            rules[idx]["enabled"] = "false"
        return rules

    layer_name, _, rules_path, _, changed = _rewrite_rules(
        cwd, layer_name, rule_id, transform,
        "toolhint %s: %s" % ("enable-rule" if enabled else "disable-rule",
                                rule_id))
    return {"ok": True, "layer": layer_name, "rules_path": rules_path,
            "id": rule_id, "enabled": enabled, "changed": changed}


# ---------------------------------------------------------------------------
# doctor — 両層の parse 可否・doc 実在・孤児 doc・backup 状態を はっきり報告
# ---------------------------------------------------------------------------

# 絶対パスに一致し得る scope パターンの先頭文字 (作業ディレクトリは常に "/" 始まり)
_SCOPE_HEAD_CHARS = ("/", "*", "?", "[")


def _scope_placement_warnings(rules, rules_path):
    """1 ルールファイル分の scope 警告 (doctor 用。どれも exit code は変えない)。

    - scope 付きなのに rules.yaml にいる: 動きはするが置き分けに反する。
      この形式を知らない古い版の engine はそのファイルを読むため、適用範囲を
      無視して発火してしまう (手編集・古い bundle の取り込みで起きる)
    - 絶対パスに一致し得ないパターン: 作業ディレクトリは常に "/" 始まりなので、
      "/" でもワイルドカードでも始まらない scope はどこでも発火しない"""
    out = []
    in_plain_file = os.path.basename(rules_path) == toolhint.RULES_FILENAME
    for i, r in enumerate(rules):
        scope = r.get("scope")
        if not scope:
            continue
        label = "ルール %r" % r.get("id") if r.get("id") else "ルール #%d" % (i + 1)
        if in_plain_file:
            out.append(
                "%s は scope 付きなのに %s にある — %s へ移すこと "
                "(この形式を知らない古い版の engine はここを読むため、適用範囲を"
                "無視して発火する)"
                % (label, toolhint.RULES_FILENAME, toolhint.SCOPED_RULES_FILENAME))
        if not str(scope).startswith(_SCOPE_HEAD_CHARS):
            out.append(
                "%s の scope %r は絶対パスに一致しない — 作業ディレクトリは"
                " \"/\" 始まりなので、パターンも \"/\" かワイルドカード"
                " (* ? [) で始めること (今はどこでも発火しない)" % (label, scope))
    return out


# inline (本文ごと注入) の doc の上限 — engine が持つ値 (inline_max_bytes:
# 環境変数で変更可) に合わせ、engine 側に無ければこの既定を使う
INLINE_DOC_WARN_BYTES = getattr(toolhint, "DEFAULT_INLINE_MAX_BYTES", 64 * 1024)


def _inline_doc_limit():
    """doctor が inline の doc の大きさを見る上限 (バイト)。engine と同じ値。"""
    fn = getattr(toolhint, "inline_max_bytes", None)
    if callable(fn):
        try:
            return int(fn())
        except Exception:
            pass
    return INLINE_DOC_WARN_BYTES


def _human_size(n):
    if n >= 1024 * 1024:
        return "%.1f MB" % (n / (1024.0 * 1024.0))
    return "%d KB" % ((n + 1023) // 1024)


def _duplicate_id_warnings(tagged_rules):
    """同一層内の id 重複を注意として返す (id ごとに 1 件)。

    tagged_rules は [(rule, ファイル名), ...] (engine の読み順)。engine のマージは
    同 id の最後の 1 行だけを残すので、他の行は黙って消える。層をまたぐ後勝ちは
    仕様だが、層の中 (とくに同じファイルの中) の重複は書き間違いのことが多い —
    どのファイルに何回あるかを添えて示す。"""
    id_files = {}
    for r, fname in tagged_rules:
        rid = r.get("id")
        if rid:
            id_files.setdefault(rid, []).append(fname)
    out = []
    for rid, files in id_files.items():
        if len(files) < 2:
            continue
        per_file = ["%s に %d 回" % (fname, files.count(fname))
                    for fname in toolhint.RULES_FILENAMES if fname in files]
        same_file = any(files.count(fname) >= 2 for fname in set(files))
        out.append(
            "id %r がこの層に 2 回以上ある (%s) — engine は最後の 1 行だけを"
            "使い、他は黙って無視する%s"
            % (rid, ", ".join(per_file),
               " (同じファイル内の重複は書き間違いの可能性が高い — 意図した"
               " 1 行だけを残すこと)" if same_file else ""))
    return out


def _doctor_layer(name, layer_dir, exists, check_backup=True):
    entry = {"name": name, "dir": layer_dir, "exists": exists,
             "backup": None, "problems": [], "warnings": []}
    if not exists:
        return entry
    layer_abs = os.path.abspath(layer_dir)
    problems, warnings = entry["problems"], entry["warnings"]
    tagged = []  # [(rule, ファイル名), ...] (engine の読み順)
    parse_ok = True
    # 層のルールファイルは 2 本 (rules.yaml / rules-scoped.yaml) — engine は
    # どちらが壊れても層ごと読み飛ばすので、両方を同じ扱いで検査する
    for rules_path in _layer_rules_paths(layer_abs):
        parsed, err = _parse_rules_file(rules_path)
        if err is not None:
            parse_ok = False
            problems.append(
                "%s が engine パーサで読めない — 層全体が無言で"
                "読み飛ばされる (fail-open): %s"
                % (os.path.basename(rules_path), err))
            continue
        warnings += _scope_placement_warnings(parsed, rules_path)
        tagged += [(r, os.path.basename(rules_path)) for r in parsed]
    if parse_ok:
        warnings += _duplicate_id_warnings(tagged)
        referenced = set()
        for i, (r, _fname) in enumerate(tagged):
            rid = r.get("id")
            label = "ルール %r" % rid if rid else "ルール #%d" % (i + 1)
            if not rid:
                problems.append("%s に id がない — engine は無言でスキップする" % label)
                continue
            # event 別の共通検証 (tool 必須 / keywords 必須 / regex compile 等)。
            # prompt rule を「tool が無い」問題にしない
            fatal = False
            for msg, is_fatal in validate_event_keys(r):
                problems.append("%s: %s" % (label, msg))
                fatal = fatal or is_fatal
            if fatal:
                continue  # engine が読み飛ばすルール — 後続の doc 検査は不要
            if "enabled" in r and \
                    str(r["enabled"]).strip().lower() not in ("true", "false"):
                problems.append(
                    "%s の enabled が true|false でない (%r) — engine は "
                    "enabled 扱いにする (disable のつもりなら効いていない)"
                    % (label, r["enabled"]))
            doc = r.get("doc")
            inject = r.get("inject")
            if not doc:
                # doc が無いルールは inject の文面だけを注入する。その inject も
                # 無い / inject が {doc} を参照している — どちらもマッチ時に
                # 注入するものが作れず、engine は無言でスキップする
                if not inject:
                    problems.append(
                        "%s に doc も inject もない — マッチしても注入するものが"
                        "無く、engine は無言でスキップする" % label)
                elif "{doc}" in str(inject):
                    problems.append(
                        "%s の inject が {doc} を参照するのに doc がない — "
                        "マッチしても engine は無言でスキップする" % label)
                continue
            if os.path.isabs(doc):
                problems.append(
                    "%s の doc が絶対パス (%r) — 層からの相対パスであること"
                    % (label, doc))
                continue
            doc_abs = os.path.abspath(os.path.join(layer_abs, doc))
            # 包含判定は realpath (engine の doc_within_layer と同じ) — `../` だけで
            # なく層内 symlink 経由の層外参照も層外として報告する
            if not toolhint.doc_within_layer(doc_abs, layer_abs):
                problems.append("%s の doc が層外を指す: %r (実体: %s)"
                                % (label, doc, os.path.realpath(doc_abs)))
                continue
            referenced.add(doc_abs)
            if not os.path.isfile(doc_abs):
                problems.append(
                    "%s の doc が実在しない: %s — マッチしても注入されず無言で"
                    "スキップされる" % (label, doc_abs))
                continue
            if str(r.get("mode", "pointer")).strip() == "inline":
                # inline はマッチのたびに doc 本文をそのまま注入する。上限を超える
                # doc は engine が本文を注入せず場所だけを示すので、inline の
                # つもりが効いていない — 注意として示す
                limit = _inline_doc_limit()
                try:
                    size = os.path.getsize(doc_abs)
                except OSError:
                    size = 0
                if size > limit:
                    env_name = getattr(toolhint, "INLINE_MAX_ENV", None)
                    warnings.append(
                        "%s の doc %s は %s — inline の上限 %s を超えるので、"
                        "engine は本文を注入せず場所だけを示す (mode: pointer と"
                        "同じ扱い)。mode を pointer にするか doc を分割すること%s"
                        % (label, doc, _human_size(size), _human_size(limit),
                           (" (上限は環境変数 %s で変更できる)" % env_name)
                           if env_name else ""))
        for rel in _layer_doc_relpaths(layer_abs):
            if os.path.abspath(os.path.join(layer_abs, rel.replace("/", os.sep))) \
                    not in referenced:
                warnings.append("孤児 doc (どのルールからも参照されない): %s" % rel)
    # backup 状態 (git 有無)。追加層 (layers.d/*) は外から配布される読み取り専用の
    # 層で、この管理面から書き込まない — backup の有無は問わない (check_backup=False)
    if not check_backup:
        return entry
    if os.path.isdir(os.path.join(layer_abs, ".git")):
        entry["backup"] = "git"
    elif _git_toplevel(layer_abs):
        entry["backup"] = "repo"
    else:
        entry["backup"] = "none"
        warnings.append(
            "backup なし — 履歴は上書き前の .bak 1 世代のみ"
            + (" (`toolhint backup init` 一発で git 化)"
               if name == "global" else ""))
    return entry


def _doctor_plugin_check():
    """配布済み plugin スナップショットの stale 検査。

    claude plugin install は engine をその時点の版でコピーするため、repo の
    engine を更新しても既存インストールの実 hook は変わらない — 管理面
    (disable 等) と実挙動が無言で食い違う。installed_plugins.json の
    installPath 配下の scripts/toolhint.py と repo の engine を突き合わせ、
    内容が違えば stale 警告を返す。検査自体の失敗は doctor を壊さない。
    """
    # status / summary は健全時にも必ず入れる — 表示側が「plugin: <summary>」の
    # 1 行を常に出せるように (検査した事実が見えないと、stale でない時に plugin を
    # 見たのかどうか分からない)
    entry = {"installs": [], "warnings": [], "status": "not_installed",
             "summary": "未インストール (claude plugin としての toolhint@toolhint が"
                        "見つからない — hooks を手動配線しているなら正常)"}
    reg_path = os.environ.get("TOOLHINT_INSTALLED_PLUGINS") or os.path.join(
        os.path.expanduser("~"), ".claude", "plugins", "installed_plugins.json")
    entry["registry"] = reg_path
    if not os.path.isfile(reg_path):
        return entry
    try:
        with open(reg_path, "r", encoding="utf-8") as f:
            reg = json.load(f)
        installs = (reg.get("plugins") or {}).get("toolhint@toolhint") or []
    except (ValueError, OSError, AttributeError) as e:
        entry["warnings"].append(
            "installed_plugins.json が読めない — plugin stale 検査をスキップ: %s" % e)
        entry["status"] = "unknown"
        entry["summary"] = "不明 (installed_plugins.json が読めない — 検査をスキップ)"
        return entry
    repo_engine = os.path.join(_ENGINE_SCRIPTS, "toolhint.py")
    try:
        with open(repo_engine, "rb") as f:
            repo_bytes = f.read()
    except OSError:
        # repo の engine が読めない環境では検査しない
        entry["status"] = "unknown"
        entry["summary"] = "不明 (repo の engine が読めない — 検査をスキップ)"
        return entry
    for inst in installs:
        if not isinstance(inst, dict) or not inst.get("installPath"):
            continue
        ip = inst["installPath"]
        info = {"installPath": ip, "version": inst.get("version"), "stale": False}
        snap = os.path.join(ip, "scripts", "toolhint.py")
        try:
            with open(snap, "rb") as f:
                same = f.read() == repo_bytes
        except OSError:
            same = False
        if not same:
            info["stale"] = True
            entry["warnings"].append(
                "配布済み plugin (version %s) が repo の engine と食い違う"
                " (stale): %s — GUI/CLI の変更が実セッションの hook に反映"
                "されていない。`claude plugin update toolhint@toolhint`"
                " (不可なら uninstall → install) で差し替える"
                % (inst.get("version") or "?", ip))
        entry["installs"].append(info)
    if entry["installs"]:
        versions = []
        for info in entry["installs"]:
            v = str(info.get("version") or "?")
            if v not in versions:
                versions.append(v)
        if any(info["stale"] for info in entry["installs"]):
            entry["status"] = "stale"
            entry["summary"] = "%s (stale — repo の engine と食い違う)" % ", ".join(versions)
        else:
            entry["status"] = "latest"
            entry["summary"] = "%s (最新)" % ", ".join(versions)
    return entry


def cmd_doctor(cwd):
    layers = [
        _doctor_layer(name, d, exists,
                      check_backup=name in ("global", "project"))
        for name, d, exists in read_layers(cwd)
    ]
    plugin = _doctor_plugin_check()
    problems_total = sum(len(l["problems"]) for l in layers)
    warnings_total = sum(len(l["warnings"]) for l in layers) \
        + len(plugin["warnings"])
    return {"ok": problems_total == 0, "layers": layers, "plugin": plugin,
            "problems_total": problems_total, "warnings_total": warnings_total}


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------

def _emit(obj, code=0):
    sys.stdout.write(json.dumps(obj, ensure_ascii=False) + "\n")
    return code


def main(argv=None):
    parser = argparse.ArgumentParser(
        prog="toolhint_core", description="toolhint 管理 core (JSON 窓口)")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("list", help="2 層のマージ一覧を JSON で返す")
    p.add_argument("--cwd", default=".")

    p = sub.add_parser("dry-run", help="state を触らず全マッチを JSON で返す")
    p.add_argument("--cwd", default=".")
    p.add_argument("--event", default="tool", choices=["tool", "prompt"],
                   help="tool (既定) = 操作きっかけ / prompt = ことばきっかけ")
    p.add_argument("--tool", default=None,
                   help="--event=tool で必須 (--event=prompt では不要)")
    p.add_argument("--input", required=True,
                   help="tool_input の command 相当の生文字列 "
                        "(--event=prompt ではユーザー発言)")

    p = sub.add_parser("add-rule", help="rules.yaml へ追記 (+ doc 作成)")
    p.add_argument("--layer", required=True, choices=["global", "project"])
    p.add_argument("--cwd", default=".")
    p.add_argument("--rule", required=True, help="ルールの JSON 文字列")
    p.add_argument("--doc-content", default=None,
                   help="省略時は実在する doc への「きっかけ追加」")

    p = sub.add_parser("docs", help="doc ごとのグループ化一覧 (孤児 doc 含む)")
    p.add_argument("--cwd", default=".")

    p = sub.add_parser("log", help="注入ログを新しい順に返す")
    p.add_argument("--cwd", default=".")
    p.add_argument("--limit", type=int, default=50)

    p = sub.add_parser("save-doc", help="層の docs/ 配下へ doc を書き込む (.bak 退避)")
    p.add_argument("--cwd", default=".")
    p.add_argument("--layer", required=True, choices=["global", "project"])
    p.add_argument("--doc-name", required=True)
    p.add_argument("--content", required=True)

    p = sub.add_parser("export", help="層の docs/ + rules.yaml を tar.gz bundle に")
    p.add_argument("--cwd", default=".")
    p.add_argument("--layer", default="global", choices=["global", "project"])
    p.add_argument("--out", default=None,
                   help="出力先 (既定 ./toolhint-<layer>-<日付>.tar.gz)")

    p = sub.add_parser("import", help="bundle を層へ取り込む (id 衝突は既定 skip)")
    p.add_argument("bundle")
    p.add_argument("--cwd", default=".")
    p.add_argument("--layer", default=None, choices=["global", "project"],
                   help="取り込み先 (既定は bundle の manifest の層)")
    p.add_argument("--dry-run", action="store_true",
                   help="計画だけ返して一切書かない")
    p.add_argument("--overwrite", action="store_true",
                   help="id/doc 衝突を bundle 側で上書き")

    p = sub.add_parser("update-rule",
                       help="既存ルールの一部キーを更新 (正準形へ再直列化)")
    p.add_argument("--cwd", default=".")
    p.add_argument("--layer", default=None, choices=["global", "project"],
                   help="省略時は id を両層から探す (両層にあればエラー)")
    p.add_argument("--id", required=True)
    p.add_argument("--patch", required=True,
                   help="更新キーの JSON (tool/match/doc/inject/mode/every/"
                        "keywords/find/case/scope。値 null で match/inject/mode/"
                        "every/find/case/scope を削除)")

    p = sub.add_parser("rm-rule",
                       help="ルールを削除 (doc は消さない — 孤児は doctor が報告)")
    p.add_argument("--cwd", default=".")
    p.add_argument("--layer", default=None, choices=["global", "project"])
    p.add_argument("--id", required=True)

    p = sub.add_parser("enable-rule", help="ルールを有効化 (enabled キーを外す)")
    p.add_argument("--cwd", default=".")
    p.add_argument("--layer", default=None, choices=["global", "project"])
    p.add_argument("--id", required=True)

    p = sub.add_parser("disable-rule",
                       help="ルールを無効化 (enabled: false — engine が注入対象から除外)")
    p.add_argument("--cwd", default=".")
    p.add_argument("--layer", default=None, choices=["global", "project"])
    p.add_argument("--id", required=True)

    p = sub.add_parser("backup-init",
                       help="層 dir を git 化 (以後、書き込み成功ごと auto-commit)")
    p.add_argument("--cwd", default=".")
    p.add_argument("--layer", default="global", choices=["global", "project"])

    p = sub.add_parser("doctor", help="両層の健全性を報告 (問題あり = exit 1)")
    p.add_argument("--cwd", default=".")

    # 書き込み系は {"ok":false,...} で返す
    ok_style = ("add-rule", "save-doc", "export", "import", "backup-init", "update-rule", "rm-rule", "enable-rule",
                "disable-rule")
    args = parser.parse_args(argv)
    try:
        if args.command == "list":
            return _emit(cmd_list(args.cwd))
        if args.command == "dry-run":
            if args.event == "tool" and not args.tool:
                raise CoreError("--tool が必要 (--event=prompt のときのみ省略可)")
            return _emit(cmd_dry_run(args.cwd, args.tool, args.input,
                                     args.event))
        if args.command == "add-rule":
            return _emit(cmd_add_rule(args.layer, args.cwd,
                                      args.rule, args.doc_content))
        if args.command == "docs":
            return _emit(cmd_docs(args.cwd))
        if args.command == "log":
            return _emit(cmd_log(args.cwd, args.limit))
        if args.command == "save-doc":
            return _emit(cmd_save_doc(args.cwd, args.layer,
                                      args.doc_name, args.content))
        if args.command == "export":
            return _emit(cmd_export(args.cwd, args.layer, args.out))
        if args.command == "import":
            return _emit(cmd_import(args.cwd, args.bundle, args.layer,
                                    args.dry_run, args.overwrite))
        if args.command == "update-rule":
            return _emit(cmd_update_rule(args.cwd, args.layer,
                                         args.id, args.patch))
        if args.command == "rm-rule":
            return _emit(cmd_rm_rule(args.cwd, args.layer, args.id))
        if args.command == "enable-rule":
            return _emit(cmd_set_rule_enabled(args.cwd, args.layer,
                                              args.id, True))
        if args.command == "disable-rule":
            return _emit(cmd_set_rule_enabled(args.cwd, args.layer,
                                              args.id, False))
        if args.command == "backup-init":
            return _emit(cmd_backup_init(args.cwd, args.layer))
        if args.command == "doctor":
            result = cmd_doctor(args.cwd)
            return _emit(result, 0 if result["ok"] else 1)
        return _emit({"error": "unknown command %r" % args.command}, 2)
    except CoreError as e:
        if args.command in ok_style:
            return _emit({"ok": False, "error": str(e)}, 1)
        return _emit({"error": str(e)}, 1)
    except Exception as e:  # 予期しない例外も traceback を stdout に漏らさない
        if DEBUG:
            import traceback
            traceback.print_exc()
        msg = "%s: %s" % (type(e).__name__, e)
        if args.command in ok_style:
            return _emit({"ok": False, "error": msg}, 1)
        return _emit({"error": msg}, 1)


if __name__ == "__main__":
    sys.exit(main())
