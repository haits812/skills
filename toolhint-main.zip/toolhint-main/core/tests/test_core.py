#!/usr/bin/env python3
"""toolhint core のテスト。

- 依存ゼロ (python3 標準ライブラリのみ)、assert ベース
- `python3 core/tests/test_core.py` 一発で全件実行し PASS/FAIL 集計を出力
- 方式: core はサブプロセス (JSON 契約そのものを検証)。read-back の照合は
  engine のパーサを import して行い、hook 発火はサブプロセスで実際に動かして確認する
"""

import datetime
import io
import json
import os
import subprocess
import sys
import tarfile
import tempfile
import time

TESTS_DIR = os.path.dirname(os.path.abspath(__file__))
CORE_DIR = os.path.dirname(TESTS_DIR)
REPO_ROOT = os.path.dirname(CORE_DIR)
CORE = os.path.join(CORE_DIR, "toolhint_core.py")
ENGINE = os.path.join(REPO_ROOT, "engine", "scripts", "toolhint.py")

sys.path.insert(0, os.path.join(REPO_ROOT, "engine", "scripts"))
import toolhint  # noqa: E402


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def run_core(args, global_dir, extra_env=None):
    env = os.environ.copy()
    env["TOOLHINT_GLOBAL"] = global_dir
    env.pop("TOOLHINT_DEBUG", None)
    # doctor の plugin stale 検査が実 HOME の installed_plugins.json を読んで
    # テスト結果が環境依存にならないよう、既定は不在パスへ隔離する
    env["TOOLHINT_INSTALLED_PLUGINS"] = os.path.join(
        global_dir, "_no_installed_plugins.json")
    if extra_env:
        env.update(extra_env)
    return subprocess.run([sys.executable, CORE] + args,
                          capture_output=True, text=True, env=env, timeout=60)


def jout(p, expect_exit=0):
    assert p.returncode == expect_exit, \
        "exit=%d stdout=%r stderr=%r" % (p.returncode, p.stdout, p.stderr)
    lines = p.stdout.strip().splitlines()
    assert len(lines) == 1, "stdout は 1 行 JSON のはず: %r" % p.stdout
    return json.loads(lines[0])


def run_engine_hook(payload, global_dir, args=None):
    env = os.environ.copy()
    env["TOOLHINT_GLOBAL"] = global_dir
    env.pop("TOOLHINT_DEBUG", None)
    return subprocess.run([sys.executable, ENGINE] + (args or []),
                          input=json.dumps(payload, ensure_ascii=False),
                          capture_output=True, text=True, env=env, timeout=30)


def make_layer(root, rules_text, docs=None):
    os.makedirs(root, exist_ok=True)
    with open(os.path.join(root, "rules.yaml"), "w", encoding="utf-8") as f:
        f.write(rules_text)
    for rel, body in (docs or {}).items():
        p = os.path.join(root, rel)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, "w", encoding="utf-8") as f:
            f.write(body)


def read(path):
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def add_rule(global_dir, layer, cwd, rule, doc_content, expect_exit=0):
    p = run_core(["add-rule", "--layer", layer, "--cwd", cwd,
                  "--rule", json.dumps(rule, ensure_ascii=False),
                  "--doc-content", doc_content], global_dir)
    return jout(p, expect_exit)


# ---------------------------------------------------------------------------
# list — 層と上書き表示
# ---------------------------------------------------------------------------

def test_list_layers_and_override():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        proj_root = os.path.join(td, "proj")
        proj_layer = os.path.join(proj_root, ".claude", "toolhint")
        cwd = os.path.join(proj_root, "sub")  # サブディレクトリから上方向探索
        make_layer(g,
                   "rules:\n"
                   "  - id: x\n    tool: Bash\n    match: foo\n    doc: docs/x.md\n"
                   "  - id: gonly\n    tool: Bash\n    match: foo\n    inject: G\n",
                   docs={"docs/x.md": "global doc\n"})
        make_layer(proj_layer,
                   "rules:\n  - id: x\n    tool: Bash\n    match: foo\n    inject: P\n")
        os.makedirs(cwd, exist_ok=True)

        data = jout(run_core(["list", "--cwd", cwd], g))
        layers = {l["name"]: l for l in data["layers"]}
        assert layers["global"]["dir"] == g and layers["global"]["exists"] is True
        assert layers["project"]["dir"] == proj_layer
        assert layers["project"]["exists"] is True

        rules = {(r["layer"], r["id"]): r for r in data["rules"]}
        assert len(data["rules"]) == 3, data["rules"]  # 上書きされた global 行も含む
        gx = rules[("global", "x")]
        assert gx["overridden"] is True
        assert gx["doc"] == "docs/x.md"
        assert gx["doc_abs"] == os.path.join(g, "docs", "x.md")
        assert gx["doc_exists"] is True
        assert gx["mode"] == "pointer" and gx["every"] == "session"  # 既定値
        px = rules[("project", "x")]
        assert px["overridden"] is False and px["inject"] == "P"
        assert px["doc"] is None and px["doc_abs"] is None and px["doc_exists"] is False
        assert rules[("global", "gonly")]["overridden"] is False


def test_list_no_project_layer():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        cwd = os.path.join(td, "empty")
        os.makedirs(cwd)
        make_layer(g, "rules:\n  - id: a\n    tool: Bash\n    inject: A\n")
        data = jout(run_core(["list", "--cwd", cwd], g))
        layers = {l["name"]: l for l in data["layers"]}
        assert layers["project"]["exists"] is False
        assert layers["project"]["dir"] == os.path.join(cwd, ".claude", "toolhint")
        assert [r["id"] for r in data["rules"]] == ["a"]


# ---------------------------------------------------------------------------
# dry-run — マッチ + state 不変 + every 抑制の無視
# ---------------------------------------------------------------------------

def test_dry_run_matches_and_no_state():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        proj_root = os.path.join(td, "proj")
        proj_layer = os.path.join(proj_root, ".claude", "toolhint")
        make_layer(g,
                   "rules:\n"
                   "  - id: grep-rule\n    tool: Bash\n    match: \\bgrep\\b\n"
                   "    doc: docs/s.md\n"
                   "  - id: other\n    tool: Edit\n    inject: NOPE\n",
                   docs={"docs/s.md": "body\n"})
        make_layer(proj_layer,
                   "rules:\n  - id: proj-rule\n    tool: Bash\n    match: grep\n"
                   "    inject: PROJ {id}\n")
        os.makedirs(os.path.join(proj_root, "sub"), exist_ok=True)

        args = ["dry-run", "--cwd", os.path.join(proj_root, "sub"),
                "--tool", "Bash", "--input", "grep -r foo ."]
        data = jout(run_core(args, g))
        by_id = {m["id"]: m for m in data["matches"]}
        assert set(by_id) == {"grep-rule", "proj-rule"}, data
        assert by_id["grep-rule"]["layer"] == "global"
        assert by_id["proj-rule"]["layer"] == "project"
        assert by_id["proj-rule"]["text"] == "[toolhint] PROJ proj-rule"
        abs_doc = os.path.join(g, "docs", "s.md")
        assert by_id["grep-rule"]["text"] == \
            "[toolhint] この操作の docs: %s — 必要なら読む" % abs_doc

        # every=session (既定) でも 2 回目が同じ結果 = 抑制を無視
        data2 = jout(run_core(args, g))
        assert data2 == data
        # state を一切書かない
        assert not os.path.exists(os.path.join(g, "state"))

        # tool 不一致はマッチなし
        data3 = jout(run_core(["dry-run", "--cwd", os.path.join(proj_root, "sub"),
                               "--tool", "Write", "--input", "grep foo"], g))
        assert data3 == {"matches": []}


# ---------------------------------------------------------------------------
# add-rule — 新規生成 / 追記 + engine パーサ read-back / 重複エラー
# ---------------------------------------------------------------------------

def test_add_rule_creates_new_rules_yaml():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")  # 層ディレクトリ自体が未作成
        cwd = os.path.join(td, "w")
        os.makedirs(cwd)
        rule = {"id": "new-rule", "tool": "Bash", "match": "\\brg\\b",
                "doc": "docs/new-rule.md"}
        out = add_rule(g, "global", cwd, rule, "rg の使い方\n")
        assert out["ok"] is True
        assert out["rules_path"] == os.path.join(g, "rules.yaml")
        assert out["doc_path"] == os.path.join(g, "docs", "new-rule.md")
        text = read(out["rules_path"])
        assert text.startswith("rules:\n"), text
        parsed = toolhint.parse_rules_yaml(text)  # engine パーサで読み戻せる
        assert parsed == [rule], parsed
        assert read(out["doc_path"]) == "rg の使い方\n"


def test_add_rule_appends_and_engine_readback_roundtrip():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        cwd = os.path.join(td, "w")
        os.makedirs(cwd)
        make_layer(g,
                   "# コメント付きの既存ファイル\n"
                   "rules:\n"
                   "  - id: keep\n    tool: Bash\n    match: foo\n    inject: KEEP\n",
                   docs={})
        # クォート・バックスラッシュ・改行・タブ入りの値が往復一致するか
        rule = {"id": "tricky", "tool": "Bash",
                "match": "\\bgrep\\b.*\"quo\\\"ted\"",
                "doc": "docs/tricky.md",
                "inject": "line1\nline2\ttabbed {doc}",
                "mode": "inline", "every": "always"}
        out = add_rule(g, "global", cwd, rule, "# tricky\n本文\n")
        assert out["ok"] is True
        parsed = toolhint.parse_rules_yaml(read(out["rules_path"]))
        assert len(parsed) == 2
        assert parsed[0] == {"id": "keep", "tool": "Bash", "match": "foo",
                             "inject": "KEEP"}  # 既存が無傷
        assert parsed[1] == rule, parsed[1]  # 完全往復


def test_add_rule_duplicate_id_error_keeps_file():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        cwd = os.path.join(td, "w")
        os.makedirs(cwd)
        rule = {"id": "dup", "tool": "Bash", "match": "x", "doc": "docs/dup.md"}
        assert add_rule(g, "global", cwd, rule, "v1\n")["ok"] is True
        before = read(os.path.join(g, "rules.yaml"))
        out = add_rule(g, "global", cwd, rule, "v2\n", expect_exit=1)
        assert out["ok"] is False and "dup" in out["error"], out
        assert read(os.path.join(g, "rules.yaml")) == before  # 無変更
        assert read(os.path.join(g, "docs", "dup.md")) == "v1\n"  # doc も無傷


def test_add_rule_project_layer_created_at_cwd():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        cwd = os.path.join(td, "proj")
        os.makedirs(cwd)
        rule = {"id": "p1", "tool": "Bash", "match": "deploy",
                "doc": "docs/p1.md", "inject": "DEPLOY MEMO"}
        out = add_rule(g, "project", cwd, rule, "deploy 手順\n")
        layer = os.path.join(cwd, ".claude", "toolhint")
        assert out["ok"] is True
        assert out["rules_path"] == os.path.join(layer, "rules.yaml")
        # list が project 層として認識する
        data = jout(run_core(["list", "--cwd", cwd], g))
        layers = {l["name"]: l for l in data["layers"]}
        assert layers["project"]["exists"] is True
        assert [r["id"] for r in data["rules"] if r["layer"] == "project"] == ["p1"]


def test_add_rule_match_optional():
    # match は任意 — engine と同じ契約 (省略時 = この tool のすべての操作)
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        cwd = os.path.join(td, "w")
        os.makedirs(cwd)
        rule = {"id": "nm", "tool": "Bash", "doc": "docs/nm.md"}
        out = add_rule(g, "global", cwd, rule, "match なし docs\n")
        assert out["ok"] is True, out
        parsed = toolhint.parse_rules_yaml(read(out["rules_path"]))
        assert parsed == [rule], parsed  # match キーなしで往復一致
        # dry-run: この tool のどんな入力にもマッチ
        dr = jout(run_core(["dry-run", "--cwd", cwd, "--tool", "Bash",
                            "--input", "anything at all"], g))
        assert [m["id"] for m in dr["matches"]] == ["nm"], dr
        abs_doc = os.path.join(g, "docs", "nm.md")
        assert dr["matches"][0]["text"] == \
            "[toolhint] この操作の docs: %s — 必要なら読む" % abs_doc
        # engine の hook でも発火する
        p = run_engine_hook({"session_id": "nm-1", "cwd": cwd, "tool_name": "Bash",
                             "tool_input": {"command": "whatever"},
                             "hook_event_name": "PreToolUse"}, g)
        assert p.returncode == 0, p.stderr
        ctx = json.loads(p.stdout.strip())["hookSpecificOutput"]["additionalContext"]
        assert ctx == dr["matches"][0]["text"], ctx


def test_add_rule_invalid_inputs_are_json_errors():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        cwd = os.path.join(td, "w")
        os.makedirs(cwd)
        # 不正 JSON
        p = run_core(["add-rule", "--layer", "global", "--cwd", cwd,
                      "--rule", "{not json", "--doc-content", "x"], g)
        out = jout(p, expect_exit=1)
        assert out["ok"] is False and "JSON" in out["error"]
        assert "Traceback" not in p.stdout
        # 不正正規表現
        out = add_rule(g, "global", cwd,
                       {"id": "bad", "tool": "Bash", "match": "[",
                        "doc": "docs/bad.md"}, "x", expect_exit=1)
        assert out["ok"] is False and "正規表現" in out["error"]
        # doc の層外参照
        out = add_rule(g, "global", cwd,
                       {"id": "esc", "tool": "Bash", "match": "x",
                        "doc": "../escape.md"}, "x", expect_exit=1)
        assert out["ok"] is False and "配下" in out["error"]
        assert not os.path.exists(os.path.join(g, "rules.yaml"))  # 何も書かれない


# ---------------------------------------------------------------------------
# docs — doc ごとのグループ化 / 孤児 doc / 不在 doc / 7 日集計
# ---------------------------------------------------------------------------

def write_log(global_dir, entries):
    log_dir = os.path.join(global_dir, "log")
    os.makedirs(log_dir, exist_ok=True)
    with open(os.path.join(log_dir, "injections.jsonl"), "w",
              encoding="utf-8") as f:
        for e in entries:
            f.write((e if isinstance(e, str)
                     else json.dumps(e, ensure_ascii=False)) + "\n")


def iso(days_ago):
    dt = (datetime.datetime.now(datetime.timezone.utc)
          - datetime.timedelta(days=days_ago))
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")


def test_docs_grouping_orphan_and_missing():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        proj_root = os.path.join(td, "proj")
        proj_layer = os.path.join(proj_root, ".claude", "toolhint")
        long_body = "あ" * 200
        make_layer(g,
                   "rules:\n"
                   "  - id: r1\n    tool: Bash\n    match: grep\n    doc: docs/x.md\n"
                   "  - id: r2\n    tool: Bash\n    match: rg\n    doc: docs/x.md\n"
                   "    every: always\n    mode: inline\n"
                   "  - id: r3\n    tool: Bash\n    match: gone\n    doc: docs/gone.md\n"
                   "  - id: textonly\n    tool: Bash\n    inject: T\n",  # doc なし
                   docs={"docs/x.md": long_body,
                         "docs/orphan.md": "orphan body\n",
                         "docs/.hidden.md": "dot\n",
                         "docs/old.md.bak": "bak\n"})
        make_layer(proj_layer,
                   "rules:\n  - id: p1\n    tool: Bash\n    match: foo\n"
                   "    doc: docs/p.md\n",
                   docs={"docs/p.md": "project doc\n"})

        data = jout(run_core(["docs", "--cwd", proj_root], g))
        by_path = {d["path_abs"]: d for d in data["docs"]}
        # x.md: 2 ルールが同じ doc を指す → 1 エントリに triggers 2 件
        x = by_path[os.path.join(g, "docs", "x.md")]
        assert x["name"] == "x.md" and x["layer"] == "global"
        assert x["exists"] is True
        assert x["body_excerpt"] == "あ" * 120  # 先頭 120 字
        assert x["inject_count_7d"] == 0  # ログ不在なら 0
        trig = {t["id"]: t for t in x["triggers"]}
        assert set(trig) == {"r1", "r2"}, x["triggers"]
        assert trig["r1"]["every"] == "session" and trig["r1"]["mode"] == "pointer"
        assert trig["r2"]["every"] == "always" and trig["r2"]["mode"] == "inline"
        assert trig["r2"]["tool"] == "Bash" and trig["r2"]["match"] == "rg"
        assert trig["r1"]["layer"] == "global"
        # 不在 doc を指すルールも一覧される (exists:false, body_excerpt:null)
        gone = by_path[os.path.join(g, "docs", "gone.md")]
        assert gone["exists"] is False and gone["body_excerpt"] is None
        assert [t["id"] for t in gone["triggers"]] == ["r3"]
        # 孤児 doc は triggers:[] で含める。dotfile と *.bak は除外
        orphan = by_path[os.path.join(g, "docs", "orphan.md")]
        assert orphan["triggers"] == [] and orphan["exists"] is True
        assert os.path.join(g, "docs", ".hidden.md") not in by_path
        assert os.path.join(g, "docs", "old.md.bak") not in by_path
        # project 層の doc も layer 付きで含める
        p = by_path[os.path.join(proj_layer, "docs", "p.md")]
        assert p["layer"] == "project"
        assert p["triggers"][0]["layer"] == "project"
        # doc のエントリは inject_only: false
        assert all(d["inject_only"] is False for d in data["docs"] if d["path_abs"])
        # doc を持たないルールは inject_only のエントリ (ルール 1 件 = 1 エントリ) で現れる
        io = [d for d in data["docs"] if d["inject_only"]]
        assert [d["triggers"][0]["id"] for d in io] == ["textonly"], io
        assert io[0]["name"] is None and io[0]["path_abs"] is None
        assert io[0]["exists"] is False and io[0]["layer"] == "global"
        assert io[0]["body_excerpt"] == "T" and io[0]["inject_count_7d"] == 0
        assert len(data["docs"]) == 5, [d["path_abs"] for d in data["docs"]]


def test_docs_inject_only_rules():
    """doc を持たないルール (inject の文面だけ) — ルール 1 件 = 1 エントリで載り
    (同じ文面でも id が違えば別)、body_excerpt は inject の先頭 120 字、
    inject_count_7d は doc 無しの記録を rule_id + 層で数える (project 層は
    記録の cwd がそのプロジェクトの中のものだけ)。list の doc 無しルールと
    1 対 1 に対応する。"""
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        proj_root = os.path.join(td, "proj")
        proj_layer = os.path.join(proj_root, ".claude", "toolhint")
        proj_sub = os.path.join(proj_root, "sub")
        other_root = os.path.join(td, "other")
        os.makedirs(proj_sub)
        long_inject = "い" * 200
        make_layer(g,
                   "rules:\n"
                   "  - id: r1\n    tool: Bash\n    match: grep\n    doc: docs/x.md\n"
                   "  - id: t1\n    tool: Bash\n    match: grep\n    inject: SAME\n"
                   "  - id: t2\n    tool: Bash\n    match: ls\n    inject: SAME\n"
                   "    every: always\n    mode: inline\n"
                   "  - id: kw\n    event: prompt\n    keywords: リリース\n"
                   "    inject: \"%s\"\n"
                   "  - id: none\n    tool: Bash\n    match: cat\n" % long_inject,
                   docs={"docs/x.md": "body\n"})
        make_layer(proj_layer,
                   "rules:\n  - id: p\n    event: prompt\n    keywords: デプロイ\n"
                   "    inject: P\n")
        doc_abs = os.path.join(g, "docs", "x.md")
        e = lambda days, rid, layer, cwd, doc=None: {
            "ts": iso(days), "session_id": "s", "cwd": cwd, "tool_name": "Bash",
            "rule_id": rid, "layer": layer, "doc": doc}
        write_log(g, [
            e(1, "r1", "global", proj_root, doc_abs),
            e(1, "t1", "global", proj_root),
            e(2, "t1", "global", other_root),      # global は cwd を問わない
            e(8, "t1", "global", proj_root),       # 7 日より古い → 数えない
            e(1, "t1", "global", proj_root, doc_abs),  # doc 付きは doc 側の数
            e(0, "t2", "global", proj_root),
            e(1, "p", "project", proj_sub),        # プロジェクトの中 (サブ dir)
            e(1, "p", "project", proj_root),
            e(1, "p", "project", other_root),      # 別プロジェクト → 数えない
            e(1, "p", "project", None),            # cwd 不明 → 数えない
        ])
        data = jout(run_core(["docs", "--cwd", proj_sub], g))
        io = {d["triggers"][0]["id"]: d for d in data["docs"] if d["inject_only"]}
        assert sorted(io) == ["kw", "none", "p", "t1", "t2"], sorted(io)
        for d in io.values():
            assert d["name"] is None and d["path_abs"] is None
            assert d["exists"] is False and len(d["triggers"]) == 1
        # 同じ文面でも id が違えば別エントリ (trigger の中身はそのルールのもの)
        assert io["t1"]["body_excerpt"] == "SAME" and io["t2"]["body_excerpt"] == "SAME"
        assert io["t2"]["triggers"][0]["every"] == "always"
        assert io["t2"]["triggers"][0]["mode"] == "inline"
        assert io["kw"]["triggers"][0]["event"] == "prompt"
        assert io["kw"]["triggers"][0]["keywords"] == "リリース"
        assert io["kw"]["body_excerpt"] == "い" * 120  # 先頭 120 字
        assert io["none"]["body_excerpt"] is None      # inject も無い → null
        assert io["p"]["layer"] == "project"
        # 注入回数: doc 無しの記録を rule_id + 層で (project は cwd がその中のものだけ)
        assert io["t1"]["inject_count_7d"] == 2, io["t1"]
        assert io["t2"]["inject_count_7d"] == 1
        assert io["kw"]["inject_count_7d"] == 0 and io["none"]["inject_count_7d"] == 0
        assert io["p"]["inject_count_7d"] == 2, io["p"]
        # doc 側は doc の絶対パス一致 (t1 の doc 付き記録も x.md に数える)
        x = [d for d in data["docs"] if d["path_abs"] == doc_abs][0]
        assert x["inject_only"] is False and x["inject_count_7d"] == 2, x
        # 並び: inject_count_7d 降順 → 名前昇順 (inject_only は id を名前として)
        names = [d["name"] or d["triggers"][0]["id"] for d in data["docs"]]
        assert names == ["p", "t1", "x.md", "t2", "kw", "none"], names
        # list の doc 無しルールと 1 対 1
        lst = jout(run_core(["list", "--cwd", proj_sub], g))
        docless = sorted(r["id"] for r in lst["rules"] if not r["doc"])
        assert docless == sorted(io), (docless, sorted(io))
        # 別プロジェクトから見ると、その cwd の記録だけ (1 件)
        os.makedirs(os.path.join(other_root, ".claude", "toolhint"))
        make_layer(os.path.join(other_root, ".claude", "toolhint"),
                   "rules:\n  - id: p\n    event: prompt\n    keywords: デプロイ\n"
                   "    inject: P2\n")
        data2 = jout(run_core(["docs", "--cwd", other_root], g))
        p2 = [d for d in data2["docs"] if d["inject_only"]
              and d["triggers"][0]["id"] == "p"][0]
        assert p2["inject_count_7d"] == 1 and p2["body_excerpt"] == "P2", p2


def test_docs_inject_count_7d_and_log_command():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        cwd = os.path.join(td, "w")
        os.makedirs(cwd)
        make_layer(g,
                   "rules:\n  - id: r1\n    tool: Bash\n    match: grep\n"
                   "    doc: docs/x.md\n",
                   docs={"docs/x.md": "body\n"})
        doc_abs = os.path.join(g, "docs", "x.md")
        e = lambda days, sid, doc: {"ts": iso(days), "session_id": sid,
                                    "cwd": cwd, "tool_name": "Bash",
                                    "rule_id": "r1", "layer": "global",
                                    "doc": doc}
        write_log(g, [
            e(8, "s-old", doc_abs),        # 7 日より古い → 集計外
            e(2, "s-a", doc_abs),
            "{broken json",                 # 壊れた行は読み飛ばす
            e(1, "s-b", doc_abs),
            e(0, "s-c", None),              # doc なし注入 → doc 集計外
        ])
        data = jout(run_core(["docs", "--cwd", cwd], g))
        x = [d for d in data["docs"] if d["path_abs"] == doc_abs][0]
        assert x["inject_count_7d"] == 2, x

        # log: 新しい順に limit 件 (壊れた行は含まれない)
        data = jout(run_core(["log", "--cwd", cwd, "--limit", "2"], g))
        assert [en["session_id"] for en in data["entries"]] == ["s-c", "s-b"], data
        data = jout(run_core(["log", "--cwd", cwd, "--limit", "100"], g))
        assert len(data["entries"]) == 4
        assert data["entries"][-1]["session_id"] == "s-old"
        # ログ不在なら空
        g2 = os.path.join(td, "g2")
        make_layer(g2, "rules:\n  - id: a\n    tool: Bash\n    inject: A\n")
        assert jout(run_core(["log", "--cwd", cwd], g2)) == {"entries": []}


# ---------------------------------------------------------------------------
# add-rule --doc-content 省略 — 実在 doc への「きっかけ追加」
# ---------------------------------------------------------------------------

def test_add_rule_doc_content_omitted():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        cwd = os.path.join(td, "w")
        os.makedirs(cwd)
        make_layer(g, "rules:\n  - id: r1\n    tool: Bash\n    match: grep\n"
                      "    doc: docs/x.md\n",
                   docs={"docs/x.md": "existing body\n"})
        # 実在 doc → OK (内容は不変のまま、きっかけだけ追加)
        rule = {"id": "r2", "tool": "Bash", "match": "\\brg\\b", "doc": "docs/x.md"}
        p = run_core(["add-rule", "--layer", "global", "--cwd", cwd,
                      "--rule", json.dumps(rule)], g)
        out = jout(p)
        assert out["ok"] is True
        assert out["doc_path"] == os.path.join(g, "docs", "x.md")
        assert read(out["doc_path"]) == "existing body\n"  # 本文は触らない
        parsed = toolhint.parse_rules_yaml(read(out["rules_path"]))
        assert parsed[-1] == rule, parsed
        # 不在 doc → {"ok":false} で rules.yaml は無変更
        before = read(os.path.join(g, "rules.yaml"))
        p = run_core(["add-rule", "--layer", "global", "--cwd", cwd,
                      "--rule", json.dumps({"id": "r3", "tool": "Bash",
                                            "match": "x", "doc": "docs/nothere.md"})], g)
        out = jout(p, expect_exit=1)
        assert out["ok"] is False and "実在" in out["error"], out
        assert read(os.path.join(g, "rules.yaml")) == before
        assert not os.path.exists(os.path.join(g, "docs", "nothere.md"))


# ---------------------------------------------------------------------------
# save-doc — docs/ 配下への書き込み / .bak 退避 / traversal 拒否
# ---------------------------------------------------------------------------

def test_save_doc_write_bak_and_traversal():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        cwd = os.path.join(td, "proj")
        os.makedirs(cwd)
        save = lambda layer, name, content: run_core(
            ["save-doc", "--cwd", cwd, "--layer", layer,
             "--doc-name", name, "--content", content], g)
        # 新規作成 (global 層。docs/ dir も無ければ作られる)
        out = jout(save("global", "new.md", "v1\n"))
        assert out["ok"] is True
        assert out["doc_path"] == os.path.join(g, "docs", "new.md")
        assert read(out["doc_path"]) == "v1\n"
        assert not os.path.exists(out["doc_path"] + ".bak")  # 新規は .bak なし
        # 上書きは .bak に旧内容を残す
        out = jout(save("global", "new.md", "v2\n"))
        assert out["ok"] is True
        assert read(out["doc_path"]) == "v2\n"
        assert read(out["doc_path"] + ".bak") == "v1\n"
        # project 層は <cwd>/.claude/toolhint/docs に書かれる
        out = jout(save("project", "p.md", "proj\n"))
        assert out["doc_path"] == os.path.join(cwd, ".claude", "toolhint",
                                               "docs", "p.md")
        assert read(out["doc_path"]) == "proj\n"
        # path traversal は拒否 (docs/ の外に何も書かれない)
        for evil in ("../escape.md", "../../etc/evil.md", "/tmp/abs.md"):
            out = jout(save("global", evil, "x"), expect_exit=1)
            assert out["ok"] is False and "docs/" in out["error"], out
        assert not os.path.exists(os.path.join(g, "escape.md"))
        assert sorted(os.listdir(os.path.join(g, "docs"))) == \
            ["new.md", "new.md.bak"]
        # docs 配下のサブディレクトリは OK
        out = jout(save("global", "sub/deep.md", "deep\n"))
        assert read(os.path.join(g, "docs", "sub", "deep.md")) == "deep\n"


# ---------------------------------------------------------------------------
# e2e — add-rule で書いた rules.yaml を engine の hook が実際に読んで発火する
# ---------------------------------------------------------------------------

def test_add_rule_then_engine_hook_fires():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        cwd = os.path.join(td, "w")
        os.makedirs(cwd)
        rule = {"id": "use-rg", "tool": "Bash", "match": "\\bgrep\\b",
                "doc": "docs/use-rg.md",
                "inject": "USE RG ({id}): {doc} を読む"}
        out = add_rule(g, "global", cwd, rule, "grep より rg を使う\n")
        assert out["ok"] is True

        payload = {"session_id": "e2e-1", "cwd": cwd, "tool_name": "Bash",
                   "tool_input": {"command": "grep -r foo ."},
                   "hook_event_name": "PreToolUse"}
        p = run_engine_hook(payload, g)
        assert p.returncode == 0, p.stderr
        hook_out = json.loads(p.stdout.strip())
        ctx = hook_out["hookSpecificOutput"]["additionalContext"]
        abs_doc = os.path.join(g, "docs", "use-rg.md")
        assert ctx == "[toolhint] USE RG (use-rg): %s を読む" % abs_doc, ctx

        # dry-run のプレビューと hook の実注入が一致する
        dr = jout(run_core(["dry-run", "--cwd", cwd, "--tool", "Bash",
                            "--input", "grep -r foo ."], g))
        assert dr["matches"][0]["text"] == ctx


# ---------------------------------------------------------------------------
# atomic write + flock — 中断で元ファイル無傷 / 並行 read-modify-write で更新消失なし
# ---------------------------------------------------------------------------

sys.path.insert(0, CORE_DIR)
import toolhint_core  # noqa: E402


def _broken_fsync(fd):
    raise OSError("simulated crash before rename")


def test_atomic_write_interruption_keeps_original():
    with tempfile.TemporaryDirectory() as td:
        target = os.path.join(td, "rules.yaml")
        with open(target, "w", encoding="utf-8") as f:
            f.write("original\n")
        # 中断 (fsync 失敗 = rename 前のクラッシュ相当) → 元ファイル無傷 + tmp 残骸なし
        real_fsync = os.fsync
        os.fsync = _broken_fsync
        try:
            try:
                toolhint_core._atomic_write(target, "new content\n")
                raised = False
            except OSError:
                raised = True
        finally:
            os.fsync = real_fsync
        assert raised
        assert read(target) == "original\n"
        assert os.listdir(td) == ["rules.yaml"], os.listdir(td)
        # 正常系: 完成品に置き換わり tmp 残骸なし
        toolhint_core._atomic_write(target, "v2\n")
        assert read(target) == "v2\n"
        assert os.listdir(td) == ["rules.yaml"], os.listdir(td)


def test_save_doc_interrupted_write_keeps_original():
    # コマンド経路 (cmd_save_doc) でも書き込み中断で既存 doc が無傷なこと
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        cwd = os.path.join(td, "w")
        os.makedirs(cwd)
        old_env = os.environ.get("TOOLHINT_GLOBAL")
        os.environ["TOOLHINT_GLOBAL"] = g
        real_fsync = os.fsync
        try:
            out = toolhint_core.cmd_save_doc(cwd, "global", "a.md", "v1\n")
            assert out["ok"] is True
            os.fsync = _broken_fsync
            try:
                try:
                    toolhint_core.cmd_save_doc(cwd, "global", "a.md", "v2\n")
                    raised = False
                except toolhint_core.CoreError:
                    raised = True
            finally:
                os.fsync = real_fsync
            assert raised
            doc = os.path.join(g, "docs", "a.md")
            assert read(doc) == "v1\n"  # 旧内容のまま
            assert sorted(os.listdir(os.path.dirname(doc))) == \
                ["a.md", "a.md.bak"], os.listdir(os.path.dirname(doc))  # tmp なし
        finally:
            os.fsync = real_fsync
            if old_env is None:
                os.environ.pop("TOOLHINT_GLOBAL", None)
            else:
                os.environ["TOOLHINT_GLOBAL"] = old_env


def test_flock_concurrent_add_rule_no_lost_update():
    # 並行 8 プロセスの add-rule (read-modify-write) — 全ルールが残ること
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        cwd = os.path.join(td, "w")
        os.makedirs(cwd)
        env = os.environ.copy()
        env["TOOLHINT_GLOBAL"] = g
        env.pop("TOOLHINT_DEBUG", None)
        n = 8
        procs = []
        for i in range(n):
            rule = {"id": "conc-%d" % i, "tool": "Bash", "match": "x%d" % i,
                    "doc": "docs/conc-%d.md" % i}
            procs.append(subprocess.Popen(
                [sys.executable, CORE, "add-rule", "--layer", "global",
                 "--cwd", cwd, "--rule", json.dumps(rule),
                 "--doc-content", "body %d\n" % i],
                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                text=True, env=env))
        for p in procs:
            so, se = p.communicate(timeout=60)
            assert p.returncode == 0, (so, se)
            assert json.loads(so.strip())["ok"] is True, so
        parsed = toolhint.parse_rules_yaml(read(os.path.join(g, "rules.yaml")))
        assert sorted(r["id"] for r in parsed) == \
            sorted("conc-%d" % i for i in range(n)), parsed


def test_flock_add_rule_blocks_until_lock_released():
    import fcntl
    import time
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        cwd = os.path.join(td, "w")
        os.makedirs(cwd)
        os.makedirs(g)
        env = os.environ.copy()
        env["TOOLHINT_GLOBAL"] = g
        env.pop("TOOLHINT_DEBUG", None)
        lock_fd = os.open(os.path.join(g, ".lock"), os.O_CREAT | os.O_RDWR)
        fcntl.flock(lock_fd, fcntl.LOCK_EX)
        try:
            rule = {"id": "blocked", "tool": "Bash", "match": "y",
                    "doc": "docs/blocked.md"}
            p = subprocess.Popen(
                [sys.executable, CORE, "add-rule", "--layer", "global",
                 "--cwd", cwd, "--rule", json.dumps(rule),
                 "--doc-content", "b\n"],
                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                text=True, env=env)
            time.sleep(0.8)
            assert p.poll() is None, p.stdout.read()  # ロック保持中は完了しない
        finally:
            fcntl.flock(lock_fd, fcntl.LOCK_UN)
            os.close(lock_fd)
        so, se = p.communicate(timeout=30)  # 解放後は完走する
        assert p.returncode == 0, (so, se)
        assert json.loads(so.strip())["ok"] is True, so
        assert toolhint.parse_rules_yaml(read(os.path.join(g, "rules.yaml")))[0] \
            == rule


# ---------------------------------------------------------------------------
# export / import — round-trip / dry-run 無副作用 / 衝突 skip / 不正 bundle 拒否
# ---------------------------------------------------------------------------

def write_noise(layer_dir):
    """bundle に入ってはいけないノイズ (state/ log/ .lock) を層に置く。"""
    os.makedirs(os.path.join(layer_dir, "state"), exist_ok=True)
    with open(os.path.join(layer_dir, "state", "s.json"), "w",
              encoding="utf-8") as f:
        f.write("{}")
    os.makedirs(os.path.join(layer_dir, "log"), exist_ok=True)
    with open(os.path.join(layer_dir, "log", "injections.jsonl"), "w",
              encoding="utf-8") as f:
        f.write("{}\n")
    with open(os.path.join(layer_dir, ".lock"), "w", encoding="utf-8") as f:
        pass


def test_export_import_roundtrip():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        cwd = os.path.join(td, "w")
        os.makedirs(cwd)
        rules_text = ("rules:\n"
                      "  - id: r1\n    tool: Bash\n    match: grep\n"
                      "    doc: docs/x.md\n"
                      "  - id: r2\n    tool: Bash\n    inject: T\n")
        make_layer(g, rules_text,
                   docs={"docs/x.md": "本文 x\n", "docs/sub/y.md": "y\n",
                         "docs/x.md.bak": "old\n", "docs/.hidden.md": "dot\n"})
        write_noise(g)

        bundle = os.path.join(td, "b.tar.gz")
        out = jout(run_core(["export", "--cwd", cwd, "--layer", "global",
                             "--out", bundle], g))
        assert out["ok"] is True and out["bundle_path"] == bundle
        assert out["rules_count"] == 2
        assert out["docs"] == ["docs/sub/y.md", "docs/x.md"]
        # bundle の中身は manifest + rules.yaml + docs/ のみ (ノイズ・bak・dotfile なし)
        with tarfile.open(bundle, "r:gz") as tf:
            names = sorted(m.name for m in tf.getmembers())
            assert names == ["docs/sub/y.md", "docs/x.md",
                             "manifest.json", "rules.yaml"], names
            manifest = json.loads(
                tf.extractfile("manifest.json").read().decode("utf-8"))
            assert manifest["format_version"] == 1
            assert manifest["layer"] == "global"
            assert manifest["docs"] == ["docs/sub/y.md", "docs/x.md"]
            assert "exported_at" in manifest
            assert tf.extractfile("rules.yaml").read().decode("utf-8") == rules_text

        # 空の別 global 層へ import → 完全往復
        g2 = os.path.join(td, "g2")
        out = jout(run_core(["import", bundle, "--cwd", cwd,
                             "--layer", "global"], g2))
        assert out["ok"] is True and out["dry_run"] is False
        assert {r["id"]: r["action"] for r in out["rules"]} == \
            {"r1": "add", "r2": "add"}
        assert {d["path"]: d["action"] for d in out["docs"]} == \
            {"docs/x.md": "create", "docs/sub/y.md": "create"}
        assert toolhint.parse_rules_yaml(read(os.path.join(g2, "rules.yaml"))) \
            == toolhint.parse_rules_yaml(rules_text)
        assert read(os.path.join(g2, "docs", "x.md")) == "本文 x\n"
        assert read(os.path.join(g2, "docs", "sub", "y.md")) == "y\n"
        # import した層がそのまま engine パーサ互換で発火する
        dr = jout(run_core(["dry-run", "--cwd", cwd, "--tool", "Bash",
                            "--input", "grep foo"], g2))
        assert {m["id"] for m in dr["matches"]} == {"r1", "r2"}, dr


def test_import_dry_run_no_side_effects():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        cwd = os.path.join(td, "w")
        os.makedirs(cwd)
        make_layer(g, "rules:\n  - id: a\n    tool: Bash\n    doc: docs/a.md\n",
                   docs={"docs/a.md": "A\n"})
        bundle = os.path.join(td, "b.tar.gz")
        assert jout(run_core(["export", "--cwd", cwd, "--out", bundle], g))["ok"] \
            is True
        # 未作成の取り込み先 — dry-run は層 dir すら作らない
        g2 = os.path.join(td, "g2")
        out = jout(run_core(["import", bundle, "--cwd", cwd, "--dry-run"], g2))
        assert out["ok"] is True and out["dry_run"] is True
        assert out["layer"] == "global"  # --layer 省略時は manifest の層
        assert out["rules"] == [{"id": "a", "action": "add"}]
        assert out["docs"] == [{"path": "docs/a.md", "action": "create"}]
        assert not os.path.exists(g2)
        # 既存の取り込み先 — 衝突 skip がプレビューされ、ファイルは一切変わらない
        g3 = os.path.join(td, "g3")
        make_layer(g3, "rules:\n  - id: a\n    tool: Bash\n    inject: OLD\n",
                   docs={"docs/a.md": "OLD\n"})
        before_rules = read(os.path.join(g3, "rules.yaml"))
        out = jout(run_core(["import", bundle, "--cwd", cwd, "--dry-run"], g3))
        assert out["rules"] == [{"id": "a", "action": "skip"}]
        assert out["docs"] == [{"path": "docs/a.md", "action": "skip"}]
        assert read(os.path.join(g3, "rules.yaml")) == before_rules
        assert read(os.path.join(g3, "docs", "a.md")) == "OLD\n"
        assert sorted(os.listdir(g3)) == ["docs", "rules.yaml"]  # .lock も作らない


def test_import_conflict_skip_and_overwrite():
    with tempfile.TemporaryDirectory() as td:
        src = os.path.join(td, "src")
        cwd = os.path.join(td, "w")
        os.makedirs(cwd)
        make_layer(src,
                   "rules:\n"
                   "  - id: dup\n    tool: Bash\n    match: SRC\n    doc: docs/d.md\n"
                   "  - id: newr\n    tool: Bash\n    match: NEW\n    doc: docs/n.md\n",
                   docs={"docs/d.md": "v-src\n", "docs/n.md": "n\n"})
        bundle = os.path.join(td, "b.tar.gz")
        assert jout(run_core(["export", "--cwd", cwd, "--out", bundle],
                             src))["ok"] is True

        dest = os.path.join(td, "dest")
        make_layer(dest,
                   "rules:\n  - id: dup\n    tool: Bash\n    match: DEST\n"
                   "    doc: docs/d.md\n",
                   docs={"docs/d.md": "v-dest\n"})
        # 既定: id 衝突と内容の異なる doc は skip、新規だけ入る
        out = jout(run_core(["import", bundle, "--cwd", cwd], dest))
        assert {r["id"]: r["action"] for r in out["rules"]} == \
            {"dup": "skip", "newr": "add"}
        assert {d["path"]: d["action"] for d in out["docs"]} == \
            {"docs/d.md": "skip", "docs/n.md": "create"}
        by_id = {r["id"]: r for r in toolhint.parse_rules_yaml(
            read(os.path.join(dest, "rules.yaml")))}
        assert by_id["dup"]["match"] == "DEST"  # 既存が勝つ
        assert by_id["newr"]["match"] == "NEW"
        assert read(os.path.join(dest, "docs", "d.md")) == "v-dest\n"
        assert read(os.path.join(dest, "docs", "n.md")) == "n\n"
        # 再 import は全 skip/unchanged で無変更 (冪等)
        before = read(os.path.join(dest, "rules.yaml"))
        out = jout(run_core(["import", bundle, "--cwd", cwd], dest))
        assert {r["id"]: r["action"] for r in out["rules"]} == \
            {"dup": "skip", "newr": "skip"}
        assert {d["path"]: d["action"] for d in out["docs"]} == \
            {"docs/d.md": "skip", "docs/n.md": "unchanged"}
        assert read(os.path.join(dest, "rules.yaml")) == before
        # --overwrite: 衝突を bundle 側で上書き (.bak 退避 + read-back 検証)
        out = jout(run_core(["import", bundle, "--cwd", cwd, "--overwrite"],
                            dest))
        assert {r["id"]: r["action"] for r in out["rules"]} == \
            {"dup": "overwrite", "newr": "overwrite"}
        assert {d["path"]: d["action"] for d in out["docs"]} == \
            {"docs/d.md": "overwrite", "docs/n.md": "unchanged"}
        parsed = toolhint.parse_rules_yaml(read(os.path.join(dest, "rules.yaml")))
        by_id = {r["id"]: r for r in parsed}
        assert by_id["dup"]["match"] == "SRC"
        assert by_id["newr"]["match"] == "NEW"
        assert read(os.path.join(dest, "docs", "d.md")) == "v-src\n"
        assert read(os.path.join(dest, "docs", "d.md.bak")) == "v-dest\n"


def test_import_rejects_unsafe_bundle():
    with tempfile.TemporaryDirectory() as td:
        cwd = os.path.join(td, "w")
        os.makedirs(cwd)
        g = os.path.join(td, "g")

        def raw_bundle(path, members):
            with tarfile.open(path, "w:gz") as tf:
                for name, data in members:
                    info = tarfile.TarInfo(name)
                    info.size = len(data)
                    tf.addfile(info, io.BytesIO(data))

        # パストラバーサル member は拒否 (何も書かれない)
        for evil in ("../evil.md", "docs/../../evil.md", "/tmp/evil-abs.md"):
            b = os.path.join(td, "evil.tar.gz")
            manifest = {"format_version": 1, "layer": "global",
                        "exported_at": "2026-01-01T00:00:00Z", "docs": [evil]}
            raw_bundle(b, [("manifest.json",
                            json.dumps(manifest).encode("utf-8")),
                           (evil, b"evil")])
            out = jout(run_core(["import", b, "--cwd", cwd], g), expect_exit=1)
            assert out["ok"] is False, out
        assert not os.path.exists(os.path.join(td, "evil.md"))
        assert not os.path.exists(g)
        # 未対応の format_version も拒否
        b2 = os.path.join(td, "v9.tar.gz")
        raw_bundle(b2, [("manifest.json", json.dumps(
            {"format_version": 9, "layer": "global", "docs": []}).encode("utf-8"))])
        out = jout(run_core(["import", b2, "--cwd", cwd], g), expect_exit=1)
        assert out["ok"] is False and "format_version" in out["error"], out


def test_import_rejects_member_flood():
    """0 byte member を大量に並べた bundle (サイズ上限をすり抜ける DoS) は
    member 数上限で拒否する。"""
    with tempfile.TemporaryDirectory() as td:
        cwd = os.path.join(td, "w")
        os.makedirs(cwd)
        g = os.path.join(td, "g")
        b = os.path.join(td, "flood.tar.gz")
        manifest = {"format_version": 1, "layer": "global",
                    "exported_at": "2026-01-01T00:00:00Z", "docs": []}
        with tarfile.open(b, "w:gz") as tf:
            info = tarfile.TarInfo("manifest.json")
            data = json.dumps(manifest).encode("utf-8")
            info.size = len(data)
            tf.addfile(info, io.BytesIO(data))
            for i in range(10_001):  # 上限 (10_000) 超の 0 byte member
                info = tarfile.TarInfo("docs/%07d.md" % i)
                info.size = 0
                tf.addfile(info)
        out = jout(run_core(["import", b, "--cwd", cwd], g), expect_exit=1)
        assert out["ok"] is False and "member 数" in out["error"], out
        assert not os.path.exists(g)


# ---------------------------------------------------------------------------
# doctor — 壊れ rules.yaml / 欠落 doc は問題 (exit 1)、孤児 doc は警告
# ---------------------------------------------------------------------------

def test_doctor_detects_broken_rules_and_missing_doc():
    with tempfile.TemporaryDirectory() as td:
        cwd = os.path.join(td, "w")
        os.makedirs(cwd)
        # 健全な層 (孤児 doc と backup なしは警告どまり → exit 0)
        g_ok = os.path.join(td, "g_ok")
        make_layer(g_ok, "rules:\n  - id: a\n    tool: Bash\n    doc: docs/a.md\n",
                   docs={"docs/a.md": "A\n", "docs/orphan.md": "O\n"})
        out = jout(run_core(["doctor", "--cwd", cwd], g_ok))
        assert out["ok"] is True and out["problems_total"] == 0
        gl = [l for l in out["layers"] if l["name"] == "global"][0]
        assert gl["problems"] == []
        assert any("orphan.md" in w for w in gl["warnings"]), gl["warnings"]
        assert gl["backup"] == "none"
        # 欠落 doc → 問題 + exit 1
        g_missing = os.path.join(td, "g_missing")
        make_layer(g_missing,
                   "rules:\n  - id: a\n    tool: Bash\n    doc: docs/gone.md\n")
        out = jout(run_core(["doctor", "--cwd", cwd], g_missing), expect_exit=1)
        assert out["ok"] is False
        gl = [l for l in out["layers"] if l["name"] == "global"][0]
        assert any("gone.md" in p and "実在しない" in p for p in gl["problems"]), gl
        # 壊れ rules.yaml → 問題 + exit 1 (engine の無言スキップを はっきり)
        g_broken = os.path.join(td, "g_broken")
        make_layer(g_broken, "totally: broken\nnot yaml at all\n")
        out = jout(run_core(["doctor", "--cwd", cwd], g_broken), expect_exit=1)
        gl = [l for l in out["layers"] if l["name"] == "global"][0]
        assert any("読めない" in p for p in gl["problems"]), gl
        # project 層も検査対象 (健全 global + 壊れ project → exit 1)
        proj_root = os.path.join(td, "proj")
        proj_layer = os.path.join(proj_root, ".claude", "toolhint")
        make_layer(proj_layer,
                   "rules:\n  - id: p\n    tool: Bash\n    doc: docs/nope.md\n")
        out = jout(run_core(["doctor", "--cwd", proj_root], g_ok), expect_exit=1)
        pl = [l for l in out["layers"] if l["name"] == "project"][0]
        assert any("nope.md" in p for p in pl["problems"]), pl


def test_doctor_flags_stale_plugin_snapshot():
    """配布済み plugin スナップショットが repo engine と食い違えば stale 警告
    (警告どまり — exit 0)。同一内容なら警告なし。"""
    import shutil
    with tempfile.TemporaryDirectory() as td:
        cwd = os.path.join(td, "w")
        os.makedirs(cwd)
        g = os.path.join(td, "g")
        make_layer(g, "rules:\n  - id: a\n    tool: Bash\n    doc: docs/a.md\n",
                   docs={"docs/a.md": "A\n"})
        ip = os.path.join(td, "cache", "toolhint", "toolhint", "0.1.0")
        os.makedirs(os.path.join(ip, "scripts"))
        with open(os.path.join(ip, "scripts", "toolhint.py"), "w",
                  encoding="utf-8") as f:
            f.write("# old snapshot\n")
        reg = os.path.join(td, "installed_plugins.json")
        with open(reg, "w", encoding="utf-8") as f:
            json.dump({"version": 2, "plugins": {"toolhint@toolhint": [
                {"scope": "user", "installPath": ip, "version": "0.1.0"}]}}, f)
        env = {"TOOLHINT_INSTALLED_PLUGINS": reg}
        out = jout(run_core(["doctor", "--cwd", cwd], g, extra_env=env))
        assert out["ok"] is True, out  # stale は警告どまり (exit 0)
        assert out["plugin"]["installs"][0]["stale"] is True, out["plugin"]
        assert any("stale" in w and "plugin update" in w
                   for w in out["plugin"]["warnings"]), out["plugin"]
        assert out["warnings_total"] >= 1, out
        # repo engine と同一内容へ差し替えると警告なし
        shutil.copyfile(ENGINE, os.path.join(ip, "scripts", "toolhint.py"))
        out = jout(run_core(["doctor", "--cwd", cwd], g, extra_env=env))
        assert out["plugin"]["warnings"] == [], out["plugin"]
        assert out["plugin"]["installs"][0]["stale"] is False, out["plugin"]
        # registry 不在 (未インストール環境) では検査スキップ・警告なし
        out = jout(run_core(["doctor", "--cwd", cwd], g))
        assert out["plugin"]["installs"] == [] and out["plugin"]["warnings"] == []


# ---------------------------------------------------------------------------
# backup init — git 化 + .gitignore + 初回 commit / 以後の auto-commit
# ---------------------------------------------------------------------------

def git_out(layer_dir, *args):
    p = subprocess.run(["git", "-C", layer_dir] + list(args),
                       capture_output=True, text=True, timeout=30)
    assert p.returncode == 0, (args, p.stdout, p.stderr)
    return p.stdout


def test_backup_init_and_auto_commit():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        cwd = os.path.join(td, "w")
        os.makedirs(cwd)
        make_layer(g, "rules:\n  - id: a\n    tool: Bash\n    doc: docs/a.md\n",
                   docs={"docs/a.md": "A\n", "docs/a.md.bak": "old\n"})
        write_noise(g)

        out = jout(run_core(["backup-init", "--cwd", cwd, "--layer", "global"], g))
        assert out["ok"] is True and out.get("initialized") is True, out
        assert os.path.isdir(os.path.join(g, ".git"))
        gi_lines = read(os.path.join(g, ".gitignore")).splitlines()
        for pat in ("state/", "log/", "*.bak", ".lock"):
            assert pat in gi_lines, gi_lines
        tracked = git_out(g, "ls-files").splitlines()
        assert "rules.yaml" in tracked and "docs/a.md" in tracked
        assert ".gitignore" in tracked
        assert not any(t.startswith(("state/", "log/")) or t.endswith(".bak")
                       or t == ".lock" for t in tracked), tracked
        assert len(git_out(g, "log", "--oneline").splitlines()) == 1
        # 再実行は already (commit は増えない)
        out = jout(run_core(["backup-init", "--cwd", cwd, "--layer", "global"], g))
        assert out["ok"] is True and out.get("already") is True, out
        assert len(git_out(g, "log", "--oneline").splitlines()) == 1

        # save-doc → 対象ファイルだけ auto-commit
        out = jout(run_core(["save-doc", "--cwd", cwd, "--layer", "global",
                             "--doc-name", "b.md", "--content", "B1\n"], g))
        assert out["ok"] is True
        assert len(git_out(g, "log", "--oneline").splitlines()) == 2
        assert "docs/b.md" in git_out(g, "ls-files").splitlines()
        # 同一内容の再 save は空 commit を作らない
        out = jout(run_core(["save-doc", "--cwd", cwd, "--layer", "global",
                             "--doc-name", "b.md", "--content", "B1\n"], g))
        assert out["ok"] is True
        assert len(git_out(g, "log", "--oneline").splitlines()) == 2
        # add-rule → rules.yaml + 新規 doc だけが 1 commit に入る
        rule = {"id": "r2", "tool": "Bash", "match": "zz", "doc": "docs/r2.md"}
        assert add_rule(g, "global", cwd, rule, "R2\n")["ok"] is True
        assert len(git_out(g, "log", "--oneline").splitlines()) == 3
        show = git_out(g, "show", "--name-only", "--pretty=format:", "HEAD").split()
        assert sorted(show) == ["docs/r2.md", "rules.yaml"], show
        # working tree はクリーン (state/log/.bak/.lock は ignore 済み)
        assert git_out(g, "status", "--porcelain").strip() == ""

        # repo 内の project 層は「repo が守る」— 断ってスキップ
        proj_root = os.path.join(td, "proj")
        proj_layer = os.path.join(proj_root, ".claude", "toolhint")
        make_layer(proj_layer, "rules:\n  - id: p\n    tool: Bash\n    inject: P\n")
        p = subprocess.run(["git", "init", "-q", proj_root],
                           capture_output=True, text=True, timeout=30)
        assert p.returncode == 0, p.stderr
        out = jout(run_core(["backup-init", "--cwd", proj_root,
                             "--layer", "project"], g))
        assert out["ok"] is True and out.get("skipped") is True, out
        assert not os.path.isdir(os.path.join(proj_layer, ".git"))


# ---------------------------------------------------------------------------
# rule CRUD — update / rm / enable / disable (正準再直列化 round-trip)
# ---------------------------------------------------------------------------

def test_rule_update_roundtrip():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        cwd = os.path.join(td, "w")
        os.makedirs(cwd)
        make_layer(g,
                   "# このコメントは正準再直列化で消える (README 宣言)\n"
                   "rules:\n"
                   "  - id: r1\n    tool: Bash\n    match: old\n    doc: docs/a.md\n"
                   "    note: keep-unknown\n"
                   "  - id: r2\n    tool: Bash\n    inject: T\n",
                   docs={"docs/a.md": "A\n", "docs/b.md": "B\n"})
        out = jout(run_core(["update-rule", "--cwd", cwd, "--id", "r1",
                             "--patch", json.dumps(
                                 {"match": "\\brg\\b", "every": "always",
                                  "doc": "docs/b.md"})], g))
        assert out["ok"] is True and out["changed"] is True
        assert out["layer"] == "global"
        assert out["rule"]["match"] == "\\brg\\b"
        assert out["rule"]["every"] == "always"
        assert out["rule"]["doc"] == "docs/b.md"
        assert out["rule"]["note"] == "keep-unknown"  # 未知キーも落とさない
        parsed = toolhint.parse_rules_yaml(read(out["rules_path"]))
        assert parsed[0] == out["rule"], parsed  # engine パーサとの完全往復
        assert parsed[1] == {"id": "r2", "tool": "Bash", "inject": "T"}  # 他は無傷
        # patch 値 null で match を外す → tool の全操作にマッチ
        out = jout(run_core(["update-rule", "--cwd", cwd, "--id", "r1",
                             "--patch", json.dumps({"match": None})], g))
        assert out["ok"] is True and "match" not in out["rule"]
        dr = jout(run_core(["dry-run", "--cwd", cwd, "--tool", "Bash",
                            "--input", "anything"], g))
        assert "r1" in {m["id"] for m in dr["matches"]}, dr
        # 同内容 patch は changed:false でファイル無変更
        before = read(os.path.join(g, "rules.yaml"))
        out = jout(run_core(["update-rule", "--cwd", cwd, "--id", "r1",
                             "--patch", json.dumps({"every": "always"})], g))
        assert out["ok"] is True and out["changed"] is False
        assert read(os.path.join(g, "rules.yaml")) == before


def test_rule_update_errors_and_layer_ambiguity():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        proj_root = os.path.join(td, "proj")
        proj_layer = os.path.join(proj_root, ".claude", "toolhint")
        make_layer(g, "rules:\n  - id: both\n    tool: Bash\n    inject: G\n"
                      "  - id: gonly\n    tool: Bash\n    inject: G2\n")
        make_layer(proj_layer,
                   "rules:\n  - id: both\n    tool: Bash\n    inject: P\n")
        # 両層に同 id → --layer 必須
        out = jout(run_core(["update-rule", "--cwd", proj_root, "--id", "both",
                             "--patch", json.dumps({"tool": "Edit"})], g),
                   expect_exit=1)
        assert out["ok"] is False and "--layer" in out["error"], out
        # --layer 指定で解消 (project 側だけ変わり global は無傷)
        out = jout(run_core(["update-rule", "--cwd", proj_root, "--id", "both",
                             "--layer", "project",
                             "--patch", json.dumps({"tool": "Edit"})], g))
        assert out["ok"] is True and out["layer"] == "project"
        assert toolhint.parse_rules_yaml(
            read(os.path.join(proj_layer, "rules.yaml")))[0]["tool"] == "Edit"
        assert toolhint.parse_rules_yaml(
            read(os.path.join(g, "rules.yaml")))[0] == \
            {"id": "both", "tool": "Bash", "inject": "G"}
        # --layer 省略でも一意なら見つかる (global 側)
        out = jout(run_core(["update-rule", "--cwd", proj_root, "--id", "gonly",
                             "--patch", json.dumps({"inject": "NEW"})], g))
        assert out["layer"] == "global" and out["rule"]["inject"] == "NEW"
        # 不正 patch は全部エラーでファイル無変更
        before = read(os.path.join(g, "rules.yaml"))
        for patch, frag in [
                ({"doc": "docs/nothere.md"}, "実在"),   # 変更先 doc は実在必須
                ({"id": "renamed"}, "更新できない"),      # id は更新不可
                ({"enabled": "false"}, "更新できない"),   # enable/disable 専用
                ({"match": "["}, "正規表現"),
                ({"every": "weekly"}, "every"),
                ({"doc": "../esc.md"}, "配下"),
                ({"tool": None}, "削除"),               # tool は削除不可
        ]:
            out = jout(run_core(["update-rule", "--cwd", proj_root,
                                 "--id", "gonly",
                                 "--patch", json.dumps(patch)], g),
                       expect_exit=1)
            assert out["ok"] is False and frag in out["error"], (patch, out)
        assert read(os.path.join(g, "rules.yaml")) == before
        # 不在 id
        out = jout(run_core(["update-rule", "--cwd", proj_root, "--id", "ghost",
                             "--patch", json.dumps({"tool": "Edit"})], g),
                   expect_exit=1)
        assert out["ok"] is False and "存在しない" in out["error"], out


def test_rule_rm_keeps_doc_as_orphan():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        cwd = os.path.join(td, "w")
        os.makedirs(cwd)
        make_layer(g,
                   "rules:\n"
                   "  - id: a\n    tool: Bash\n    match: x\n    doc: docs/a.md\n"
                   "  - id: b\n    tool: Bash\n    inject: B\n",
                   docs={"docs/a.md": "A\n"})
        out = jout(run_core(["rm-rule", "--cwd", cwd, "--id", "a"], g))
        assert out["ok"] is True and out["layer"] == "global"
        assert out["removed"]["id"] == "a"
        assert out["removed"]["doc"] == "docs/a.md"
        parsed = toolhint.parse_rules_yaml(read(os.path.join(g, "rules.yaml")))
        assert [r["id"] for r in parsed] == ["b"], parsed
        # doc は消さない → doctor が孤児として報告 (警告どまり = exit 0)
        assert read(os.path.join(g, "docs", "a.md")) == "A\n"
        doc_out = jout(run_core(["doctor", "--cwd", cwd], g))
        gl = [l for l in doc_out["layers"] if l["name"] == "global"][0]
        assert any("a.md" in w and "孤児" in w for w in gl["warnings"]), gl
        # 最後の 1 件を消しても正準形 (rules: のみ) で engine が読める
        out = jout(run_core(["rm-rule", "--cwd", cwd, "--id", "b"], g))
        assert out["ok"] is True
        assert toolhint.parse_rules_yaml(read(os.path.join(g, "rules.yaml"))) \
            == []
        # 不在 id はエラー
        out = jout(run_core(["rm-rule", "--cwd", cwd, "--id", "ghost"], g),
                   expect_exit=1)
        assert out["ok"] is False and "存在しない" in out["error"], out


def test_rule_disable_enable_engine_exclusion():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        cwd = os.path.join(td, "w")
        os.makedirs(cwd)
        make_layer(g,
                   "rules:\n"
                   "  - id: tgt\n    tool: Bash\n    match: grep\n    inject: TGT\n"
                   "  - id: other\n    tool: Bash\n    match: grep\n"
                   "    inject: OTHER\n")
        # disable → rules.yaml に enabled: "false"
        out = jout(run_core(["disable-rule", "--cwd", cwd, "--id", "tgt"], g))
        assert out["ok"] is True and out["enabled"] is False
        assert out["changed"] is True
        by_id = {r["id"]: r for r in
                 toolhint.parse_rules_yaml(read(os.path.join(g, "rules.yaml")))}
        assert by_id["tgt"]["enabled"] == "false"
        assert "enabled" not in by_id["other"]
        # list には残る (enabled:false — GUI トグル表示用)
        data = jout(run_core(["list", "--cwd", cwd], g))
        lr = {r["id"]: r for r in data["rules"]}
        assert lr["tgt"]["enabled"] is False
        assert lr["other"]["enabled"] is True
        # dry-run と engine 実 hook は disabled を除外
        dr = jout(run_core(["dry-run", "--cwd", cwd, "--tool", "Bash",
                            "--input", "grep foo"], g))
        assert {m["id"] for m in dr["matches"]} == {"other"}, dr
        p = run_engine_hook({"session_id": "dis-1", "cwd": cwd,
                             "tool_name": "Bash",
                             "tool_input": {"command": "grep foo"},
                             "hook_event_name": "PreToolUse"}, g)
        assert p.returncode == 0, p.stderr
        ctx = json.loads(p.stdout.strip())["hookSpecificOutput"]["additionalContext"]
        assert "OTHER" in ctx and "TGT" not in ctx, ctx
        # 冪等: 再 disable は changed:false でファイル無変更
        before = read(os.path.join(g, "rules.yaml"))
        out = jout(run_core(["disable-rule", "--cwd", cwd, "--id", "tgt"], g))
        assert out["ok"] is True and out["changed"] is False
        assert read(os.path.join(g, "rules.yaml")) == before
        # enable → enabled キーが外れ (正準形)、engine が再び注入する
        out = jout(run_core(["enable-rule", "--cwd", cwd, "--id", "tgt"], g))
        assert out["ok"] is True and out["enabled"] is True
        assert out["changed"] is True
        parsed = toolhint.parse_rules_yaml(read(os.path.join(g, "rules.yaml")))
        assert all("enabled" not in r for r in parsed), parsed
        p = run_engine_hook({"session_id": "dis-2", "cwd": cwd,
                             "tool_name": "Bash",
                             "tool_input": {"command": "grep foo"},
                             "hook_event_name": "PreToolUse"}, g)
        assert p.returncode == 0, p.stderr
        ctx = json.loads(p.stdout.strip())["hookSpecificOutput"]["additionalContext"]
        assert "TGT" in ctx and "OTHER" in ctx, ctx
        # add-rule も enabled を受ける ("true"|"false" の文字列のみ)
        rule = {"id": "born-off", "tool": "Bash", "match": "grep",
                "doc": "docs/bo.md", "enabled": "false"}
        assert add_rule(g, "global", cwd, rule, "BO\n")["ok"] is True
        dr = jout(run_core(["dry-run", "--cwd", cwd, "--tool", "Bash",
                            "--input", "grep foo"], g))
        assert "born-off" not in {m["id"] for m in dr["matches"]}, dr
        out = add_rule(g, "global", cwd,
                       {"id": "bad-en", "tool": "Bash", "match": "x",
                        "doc": "docs/bo.md", "enabled": "maybe"}, "BO\n",
                       expect_exit=1)
        assert out["ok"] is False and "enabled" in out["error"], out
        # docs の triggers にも enabled が載る
        docs_out = jout(run_core(["docs", "--cwd", cwd], g))
        bo = [d for d in docs_out["docs"]
              if d["path_abs"] == os.path.join(g, "docs", "bo.md")][0]
        assert bo["triggers"][0]["enabled"] is False, bo


def test_doctor_flags_invalid_enabled():
    with tempfile.TemporaryDirectory() as td:
        cwd = os.path.join(td, "w")
        os.makedirs(cwd)
        g = os.path.join(td, "g")
        make_layer(g, "rules:\n  - id: a\n    tool: Bash\n    inject: A\n"
                      "    enabled: flase\n")  # typo — enabled 扱いになる時限爆弾
        out = jout(run_core(["doctor", "--cwd", cwd], g), expect_exit=1)
        assert out["ok"] is False
        gl = [l for l in out["layers"] if l["name"] == "global"][0]
        assert any("enabled" in p for p in gl["problems"]), gl


# ---------------------------------------------------------------------------
# 未 backup ナッジ — save-doc / add-rule 成功時に stderr 1 行 + 7 日 rate-limit
# ---------------------------------------------------------------------------

def test_backup_nudge_rate_limit():
    NUDGE = "backup init"
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        cwd = os.path.join(td, "w")
        os.makedirs(cwd)
        save = lambda name, content: run_core(
            ["save-doc", "--cwd", cwd, "--layer", "global",
             "--doc-name", name, "--content", content], g)
        # 初回の書き込み成功 → stderr に 1 行だけナッジ + marker 生成
        p = save("a.md", "v1\n")
        assert jout(p)["ok"] is True
        assert len([l for l in p.stderr.splitlines() if NUDGE in l]) == 1, p.stderr
        marker = os.path.join(g, "state", "backup_nudge")
        assert os.path.isfile(marker)
        # 7 日以内の 2 回目 → ナッジなし (rate-limit)
        p = save("a.md", "v2\n")
        assert jout(p)["ok"] is True
        assert NUDGE not in p.stderr, p.stderr
        # marker を 8 日前に backdate → 再びナッジ (add-rule 経路でも出る)
        old = time.time() - 8 * 86400
        os.utime(marker, (old, old))
        rule = {"id": "n1", "tool": "Bash", "match": "x", "doc": "docs/n1.md"}
        p = run_core(["add-rule", "--layer", "global", "--cwd", cwd,
                      "--rule", json.dumps(rule), "--doc-content", "N\n"], g)
        assert jout(p)["ok"] is True
        assert NUDGE in p.stderr, p.stderr
        # 失敗した書き込み (id 重複) はナッジしない
        os.utime(marker, (old, old))
        p = run_core(["add-rule", "--layer", "global", "--cwd", cwd,
                      "--rule", json.dumps(rule), "--doc-content", "N\n"], g)
        assert jout(p, expect_exit=1)["ok"] is False
        assert NUDGE not in p.stderr, p.stderr
        # backup-init 済みの層は backdate してもナッジしない
        assert jout(run_core(["backup-init", "--cwd", cwd,
                              "--layer", "global"], g))["ok"] is True
        os.utime(marker, (old, old))
        p = save("a.md", "v3\n")
        assert jout(p)["ok"] is True
        assert NUDGE not in p.stderr, p.stderr


# ---------------------------------------------------------------------------
# ことばきっかけ (event: prompt) — add / update / dry-run 両 event / doctor /
# export→import 往復 / engine 発火 e2e
# ---------------------------------------------------------------------------

def test_prompt_add_rule_and_dry_run_both_events():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        cwd = os.path.join(td, "w")
        os.makedirs(cwd)
        # tool rule と prompt rule (inline / pointer) を core で追加
        assert add_rule(g, "global", cwd,
                        {"id": "t1", "tool": "Bash", "match": "grep",
                         "doc": "docs/t.md"}, "tool hint\n")["ok"] is True
        rule = {"id": "kw1", "event": "prompt", "keywords": "deploy, デプロイ",
                "doc": "docs/z.md", "mode": "inline"}
        out = add_rule(g, "global", cwd, rule, "デプロイ DB の案内\n2 行目\n")
        assert out["ok"] is True
        parsed = toolhint.parse_rules_yaml(read(out["rules_path"]))
        assert parsed[-1] == rule, parsed  # event/keywords が engine パーサと往復一致
        rule2 = {"id": "kw2", "event": "prompt", "keywords": "(?:cat)|(?:dog)",
                 "find": "regex", "case": "sensitive", "every": "always",
                 "doc": "docs/z.md"}
        p = run_core(["add-rule", "--layer", "global", "--cwd", cwd,
                      "--rule", json.dumps(rule2, ensure_ascii=False)], g)
        assert jout(p)["ok"] is True  # --doc-content 省略 = 既存 doc へのきっかけ追加
        parsed = toolhint.parse_rules_yaml(read(os.path.join(g, "rules.yaml")))
        assert parsed[-1] == rule2, parsed

        # list / docs に新キー (event / keywords / find / case) が透過する
        data = jout(run_core(["list", "--cwd", cwd], g))
        by_id = {r["id"]: r for r in data["rules"]}
        assert by_id["kw1"]["event"] == "prompt"
        assert by_id["kw1"]["keywords"] == "deploy, デプロイ"
        assert by_id["kw1"]["find"] is None and by_id["kw1"]["case"] is None
        assert by_id["kw2"]["find"] == "regex"
        assert by_id["kw2"]["case"] == "sensitive"
        assert by_id["t1"]["event"] == "tool" and by_id["t1"]["keywords"] is None
        docs_out = jout(run_core(["docs", "--cwd", cwd], g))
        z = [d for d in docs_out["docs"]
             if d["path_abs"] == os.path.join(g, "docs", "z.md")][0]
        trig = {t["id"]: t for t in z["triggers"]}
        assert trig["kw1"]["event"] == "prompt"
        assert trig["kw2"]["keywords"] == "(?:cat)|(?:dog)"

        # dry-run --tool: prompt rule は入力に keyword があっても不発
        dr = jout(run_core(["dry-run", "--cwd", cwd, "--tool", "Bash",
                            "--input", "grep デプロイ cat"], g))
        assert {m["id"] for m in dr["matches"]} == {"t1"}, dr
        # dry-run --event=prompt: prompt rule のみ。inline はヘッダ無しで本文
        dp = jout(run_core(["dry-run", "--cwd", cwd, "--event", "prompt",
                            "--input", "デプロイを見せて"], g))
        assert {m["id"] for m in dp["matches"]} == {"kw1"}, dp
        assert dp["matches"][0]["text"] == "[toolhint] デプロイ DB の案内\n2 行目", dp
        # find=regex + case: sensitive。pointer は「この話題の docs」
        dp = jout(run_core(["dry-run", "--cwd", cwd, "--event", "prompt",
                            "--input", "my cat here"], g))
        assert {m["id"] for m in dp["matches"]} == {"kw2"}, dp
        abs_doc = os.path.join(g, "docs", "z.md")
        assert dp["matches"][0]["text"] == \
            "[toolhint] この話題の docs: %s — 必要なら読む" % abs_doc, dp
        dp = jout(run_core(["dry-run", "--cwd", cwd, "--event", "prompt",
                            "--input", "MY CAT HERE"], g))
        assert dp == {"matches": []}, dp  # case: sensitive で大文字は不発
        # dry-run は state を書かない (add-rule の backup_nudge marker のみ)
        assert os.listdir(os.path.join(g, "state")) == ["backup_nudge"]
        # --event=tool (既定) で --tool 無しはエラー
        p = run_core(["dry-run", "--cwd", cwd, "--input", "x"], g)
        out = json.loads(p.stdout.strip().splitlines()[0])
        assert p.returncode == 1 and "--tool" in out["error"], (p.stdout, p.stderr)

        # engine 発火 e2e (prompt): dry-run のプレビューと実 hook 注入が一致
        payload = {"session_id": "pe2e", "cwd": cwd, "prompt": "デプロイを見せて",
                   "hook_event_name": "UserPromptSubmit"}
        p = run_engine_hook(payload, g, args=["--event=prompt"])
        assert p.returncode == 0, p.stderr
        hook_out = json.loads(p.stdout.strip())["hookSpecificOutput"]
        assert hook_out["hookEventName"] == "UserPromptSubmit"
        assert hook_out["additionalContext"] == "[toolhint] デプロイ DB の案内\n2 行目"


def test_prompt_rule_validation_rejections():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        cwd = os.path.join(td, "w")
        os.makedirs(cwd)
        cases = [
            # prompt rule に tool / match は不可・tool rule に keywords/find/case は不可
            ({"id": "a", "event": "prompt", "keywords": "x", "tool": "Bash",
              "doc": "docs/a.md"}, "使えない"),
            ({"id": "a", "event": "prompt", "keywords": "x", "match": "y",
              "doc": "docs/a.md"}, "使えない"),
            ({"id": "a", "tool": "Bash", "keywords": "x", "doc": "docs/a.md"},
             "使えない"),
            ({"id": "a", "tool": "Bash", "find": "word", "doc": "docs/a.md"},
             "使えない"),
            ({"id": "a", "tool": "Bash", "case": "sensitive", "doc": "docs/a.md"},
             "使えない"),
            # keywords 必須・分割後の有効要素 0 (末尾/連続カンマ・区切りのみ) は不正
            ({"id": "a", "event": "prompt", "doc": "docs/a.md"}, "keywords"),
            ({"id": "a", "event": "prompt", "keywords": "、, ,",
              "doc": "docs/a.md"}, "有効な要素"),
            # find / case / event の値検証。find=regex は re.compile 検証
            ({"id": "a", "event": "prompt", "keywords": "x", "find": "fuzzy",
              "doc": "docs/a.md"}, "find"),
            ({"id": "a", "event": "prompt", "keywords": "[", "find": "regex",
              "doc": "docs/a.md"}, "正規表現"),
            ({"id": "a", "event": "prompt", "keywords": "x", "case": "SENSITIVE",
              "doc": "docs/a.md"}, "case"),
            ({"id": "a", "event": "promt", "tool": "Bash", "doc": "docs/a.md"},
             "event"),
        ]
        for rule, frag in cases:
            out = add_rule(g, "global", cwd, rule, "body\n", expect_exit=1)
            assert out["ok"] is False and frag in out["error"], (rule, out)
        assert not os.path.exists(os.path.join(g, "rules.yaml"))  # 何も書かれない


def test_prompt_update_rule_and_mixed_patch_rejection():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        cwd = os.path.join(td, "w")
        os.makedirs(cwd)
        make_layer(g,
                   "rules:\n"
                   "  - id: k\n    event: prompt\n    keywords: \"a, b\"\n"
                   "    doc: docs/k.md\n    mode: inline\n"
                   "  - id: t\n    tool: Bash\n    match: grep\n    doc: docs/k.md\n",
                   docs={"docs/k.md": "K\n"})
        # keywords / find / case の更新 → engine パーサと往復一致
        out = jout(run_core(["update-rule", "--cwd", cwd, "--id", "k",
                             "--patch", json.dumps(
                                 {"keywords": "x, y", "find": "word",
                                  "case": "sensitive"})], g))
        assert out["ok"] is True and out["changed"] is True
        assert out["rule"]["keywords"] == "x, y"
        assert out["rule"]["find"] == "word"
        parsed = toolhint.parse_rules_yaml(read(out["rules_path"]))
        assert parsed[0] == out["rule"], parsed
        # dry-run で word 境界が効く (engine マッチの import 確認)
        dp = jout(run_core(["dry-run", "--cwd", cwd, "--event", "prompt",
                            "--input", "say x now"], g))
        assert {m["id"] for m in dp["matches"]} == {"k"}, dp
        dp = jout(run_core(["dry-run", "--cwd", cwd, "--event", "prompt",
                            "--input", "xyz"], g))
        assert dp == {"matches": []}, dp  # word 境界で不発
        # null で find / case を既定へ戻す (REMOVABLE)
        out = jout(run_core(["update-rule", "--cwd", cwd, "--id", "k",
                             "--patch",
                             json.dumps({"find": None, "case": None})], g))
        assert out["ok"] is True
        assert "find" not in out["rule"] and "case" not in out["rule"]
        # 混種 patch / event patch / 不正値は拒否 — ファイル無変更
        before = read(os.path.join(g, "rules.yaml"))
        for rid, patch, frag in [
                ("k", {"tool": "Bash"}, "使えない"),
                ("k", {"match": "x"}, "使えない"),
                ("t", {"keywords": "a"}, "使えない"),
                ("t", {"find": "word"}, "使えない"),
                ("t", {"case": "sensitive"}, "使えない"),
                ("k", {"event": "tool"}, "更新できない"),
                ("t", {"event": "prompt"}, "更新できない"),
                ("k", {"keywords": "、"}, "有効な要素"),
                ("k", {"keywords": "[", "find": "regex"}, "正規表現"),
                ("k", {"find": "fuzzy"}, "find"),
        ]:
            out = jout(run_core(["update-rule", "--cwd", cwd, "--id", rid,
                                 "--patch",
                                 json.dumps(patch, ensure_ascii=False)], g),
                       expect_exit=1)
            assert out["ok"] is False and frag in out["error"], (rid, patch, out)
        assert read(os.path.join(g, "rules.yaml")) == before


def test_update_rule_rejects_foreign_event_keys_even_when_null():
    """もう一方の種別専用のキーは patch の値が null (削除) でも拒否 —
    元々無いキーの削除は no-op で「変更なし」として通ってしまうため。文言は
    合成後検証と同じ (操作きっかけ側は「操作きっかけのルールに … は使えない」)。"""
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        cwd = os.path.join(td, "w")
        os.makedirs(cwd)
        make_layer(g,
                   "rules:\n"
                   "  - id: k\n    event: prompt\n    keywords: \"a, b\"\n"
                   "    doc: docs/k.md\n"
                   "  - id: t\n    tool: Bash\n    match: grep\n    doc: docs/k.md\n",
                   docs={"docs/k.md": "K\n"})
        before = read(os.path.join(g, "rules.yaml"))
        for rid, patch, frag in [
                ("t", {"keywords": None}, "削除 (null) できない"),  # keywords は必須キー
                ("t", {"find": None}, "操作きっかけのルールに find は使えない"),
                ("t", {"case": None}, "操作きっかけのルールに case は使えない"),
                ("t", {"keywords": "x"}, "操作きっかけのルールに keywords は使えない"),
                ("k", {"match": None}, "event: prompt のルールに match は使えない"),
                ("k", {"tool": "Bash"}, "event: prompt のルールに tool は使えない"),
                # 種別違いのキーと正しいキーの混在も拒否 (部分適用しない)
                ("t", {"every": "always", "case": None},
                 "操作きっかけのルールに case は使えない"),
        ]:
            out = jout(run_core(["update-rule", "--cwd", cwd, "--id", rid,
                                 "--patch", json.dumps(patch)], g),
                       expect_exit=1)
            assert out["ok"] is False and frag in out["error"], (rid, patch, out)
        assert read(os.path.join(g, "rules.yaml")) == before
        # 自分の種別のキーの null は従来どおり (無いキーの削除 = 変更なし)
        out = jout(run_core(["update-rule", "--cwd", cwd, "--id", "k",
                             "--patch", json.dumps({"find": None})], g))
        assert out["ok"] is True and out["changed"] is False, out
        assert read(os.path.join(g, "rules.yaml")) == before


def test_add_rule_without_doc_requires_inject():
    """doc の無いルール (inject の文面だけ) は add-rule で作れる — inject が
    必須で、inject が {doc} を参照する / --doc-content 付きは拒否 (doctor の
    判定と同じ)。書けたルールは engine パーサ・dry-run・hook で使える。"""
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        cwd = os.path.join(td, "w")
        os.makedirs(cwd)
        # 拒否系 — 何も書かれない
        for rule, frag in [
                ({"id": "p", "event": "prompt", "keywords": "リリース"},
                 "doc も inject もない"),
                ({"id": "p", "event": "prompt", "keywords": "リリース",
                  "inject": "see {doc}"}, "{doc}"),
                ({"id": "t", "tool": "Bash", "match": "grep"}, "doc も inject もない"),
        ]:
            out = jout(run_core(["add-rule", "--layer", "global", "--cwd", cwd,
                                 "--rule", json.dumps(rule, ensure_ascii=False)],
                                g), expect_exit=1)
            assert out["ok"] is False and frag in out["error"], (rule, out)
        out = add_rule(g, "global", cwd,
                       {"id": "p", "event": "prompt", "keywords": "リリース",
                        "inject": "手順を確認"}, "body\n", expect_exit=1)
        assert out["ok"] is False and "--doc-content" in out["error"], out
        assert not os.path.exists(os.path.join(g, "rules.yaml"))
        assert not os.path.isdir(os.path.join(g, "docs"))

        # 成功系 — prompt / tool どちらも inject だけで書ける。doc_path は null
        p_rule = {"id": "p", "event": "prompt", "keywords": "リリース",
                  "inject": "手順を確認 ({id})", "every": "always"}
        out = jout(run_core(["add-rule", "--layer", "global", "--cwd", cwd,
                             "--rule", json.dumps(p_rule, ensure_ascii=False)], g))
        assert out["ok"] is True and out["doc_path"] is None, out
        assert out["rules_path"] == os.path.join(g, "rules.yaml")
        t_rule = {"id": "t", "tool": "Bash", "match": "grep", "inject": "rg を使う"}
        out = jout(run_core(["add-rule", "--layer", "global", "--cwd", cwd,
                             "--rule", json.dumps(t_rule, ensure_ascii=False)], g))
        assert out["ok"] is True and out["doc_path"] is None, out
        parsed = toolhint.parse_rules_yaml(read(os.path.join(g, "rules.yaml")))
        assert parsed == [p_rule, t_rule], parsed
        assert not os.path.isdir(os.path.join(g, "docs"))  # doc は作らない
        # list / dry-run / hook で注入文面が inject そのもの
        data = jout(run_core(["list", "--cwd", cwd], g))
        by_id = {r["id"]: r for r in data["rules"]}
        assert by_id["p"]["doc"] is None and by_id["p"]["doc_exists"] is False
        dp = jout(run_core(["dry-run", "--cwd", cwd, "--event", "prompt",
                            "--input", "リリースする"], g))
        assert [(m["id"], m["text"]) for m in dp["matches"]] == \
            [("p", "[toolhint] 手順を確認 (p)")], dp
        dr = jout(run_core(["dry-run", "--cwd", cwd, "--tool", "Bash",
                            "--input", "grep x"], g))
        assert [(m["id"], m["text"]) for m in dr["matches"]] == \
            [("t", "[toolhint] rg を使う")], dr
        p = run_engine_hook({"session_id": "nodoc", "cwd": cwd,
                             "prompt": "リリースする",
                             "hook_event_name": "UserPromptSubmit"},
                            g, args=["--event=prompt"])
        assert p.returncode == 0, p.stderr
        hook_out = json.loads(p.stdout.strip())["hookSpecificOutput"]
        assert hook_out["additionalContext"] == "[toolhint] 手順を確認 (p)", hook_out
        # doctor は健全 (doc 無し + inject あり は問題にしない)
        doc = jout(run_core(["doctor", "--cwd", cwd], g))
        assert doc["problems_total"] == 0, doc
        # update-rule でも同じ判定 — inject を外す / {doc} を参照させるのは拒否
        before = read(os.path.join(g, "rules.yaml"))
        for patch, frag in [({"inject": None}, "doc も inject もない"),
                            ({"inject": "x {doc}"}, "{doc}")]:
            out = jout(run_core(["update-rule", "--cwd", cwd, "--id", "p",
                                 "--patch", json.dumps(patch)], g),
                       expect_exit=1)
            assert out["ok"] is False and frag in out["error"], (patch, out)
        assert read(os.path.join(g, "rules.yaml")) == before
        # doc を後から付ける (実在 doc) と inject の {doc} も通る
        os.makedirs(os.path.join(g, "docs"))
        with open(os.path.join(g, "docs", "r.md"), "w", encoding="utf-8") as f:
            f.write("R\n")
        out = jout(run_core(["update-rule", "--cwd", cwd, "--id", "p",
                             "--patch", json.dumps({"doc": "docs/r.md",
                                                    "inject": "read {doc}"})], g))
        assert out["ok"] is True and out["rule"]["doc"] == "docs/r.md", out


def test_doctor_prompt_event_validation():
    with tempfile.TemporaryDirectory() as td:
        cwd = os.path.join(td, "w")
        os.makedirs(cwd)
        # 健全な prompt rule を「tool が無い」問題にしない
        g_ok = os.path.join(td, "g_ok")
        make_layer(g_ok,
                   "rules:\n  - id: k\n    event: prompt\n    keywords: \"a\"\n"
                   "    doc: docs/k.md\n    mode: inline\n",
                   docs={"docs/k.md": "K\n"})
        out = jout(run_core(["doctor", "--cwd", cwd], g_ok))
        assert out["ok"] is True and out["problems_total"] == 0, out
        # 問題系: keywords 欠落 / 区切りのみ / find=regex の compile 失敗 /
        # prompt への tool 混在 / tool rule への keywords 混在
        g_bad = os.path.join(td, "g_bad")
        make_layer(g_bad,
                   "rules:\n"
                   "  - id: p1\n    event: prompt\n    doc: docs/k.md\n"
                   "  - id: p2\n    event: prompt\n    keywords: \"、,\"\n"
                   "    doc: docs/k.md\n"
                   "  - id: p3\n    event: prompt\n    keywords: \"[\"\n"
                   "    find: regex\n    doc: docs/k.md\n"
                   "  - id: p4\n    event: prompt\n    keywords: \"a\"\n"
                   "    tool: Bash\n    doc: docs/k.md\n"
                   "  - id: t1\n    tool: Bash\n    keywords: \"a\"\n"
                   "    doc: docs/k.md\n",
                   docs={"docs/k.md": "K\n"})
        out = jout(run_core(["doctor", "--cwd", cwd], g_bad), expect_exit=1)
        gl = [l for l in out["layers"] if l["name"] == "global"][0]
        probs = "\n".join(gl["problems"])
        assert "'p1'" in probs and "keywords がない" in probs, probs
        assert "'p2'" in probs and "有効な要素がない" in probs, probs
        assert "'p3'" in probs and "正規表現として不正" in probs, probs
        assert "'p4'" in probs and "tool は使えない" in probs, probs
        assert "'t1'" in probs and "keywords は使えない" in probs, probs


def test_export_import_roundtrip_prompt_rules():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        cwd = os.path.join(td, "w")
        os.makedirs(cwd)
        rules_text = ("rules:\n"
                      "  - id: k\n    event: prompt\n    keywords: \"zu, デプロイ\"\n"
                      "    doc: docs/k.md\n    mode: inline\n"
                      "  - id: t\n    tool: Bash\n    match: grep\n"
                      "    doc: docs/k.md\n")
        make_layer(g, rules_text, docs={"docs/k.md": "本文 K\n"})
        bundle = os.path.join(td, "b.tar.gz")
        out = jout(run_core(["export", "--cwd", cwd, "--layer", "global",
                             "--out", bundle], g))
        assert out["ok"] is True and out["rules_count"] == 2
        g2 = os.path.join(td, "g2")
        out = jout(run_core(["import", bundle, "--cwd", cwd,
                             "--layer", "global"], g2))
        assert out["ok"] is True
        assert {r["id"]: r["action"] for r in out["rules"]} == \
            {"k": "add", "t": "add"}
        assert toolhint.parse_rules_yaml(read(os.path.join(g2, "rules.yaml"))) \
            == toolhint.parse_rules_yaml(rules_text)
        # 取り込んだ層で prompt dry-run が発火する (往復後も意味論が保たれる)
        dp = jout(run_core(["dry-run", "--cwd", cwd, "--event", "prompt",
                            "--input", "デプロイ!"], g2))
        assert [m["id"] for m in dp["matches"]] == ["k"], dp
        assert dp["matches"][0]["text"] == "[toolhint] 本文 K", dp
        # 不正 prompt rule (keywords 欠落) 入り bundle は import で拒否
        g3 = os.path.join(td, "g3")
        make_layer(g3, "rules:\n  - id: bad\n    event: prompt\n"
                       "    doc: docs/k.md\n", docs={"docs/k.md": "K\n"})
        b2 = os.path.join(td, "b2.tar.gz")
        assert jout(run_core(["export", "--cwd", cwd, "--layer", "global",
                              "--out", b2], g3))["ok"] is True
        g4 = os.path.join(td, "g4")
        out = jout(run_core(["import", b2, "--cwd", cwd, "--layer", "global"],
                            g4), expect_exit=1)
        assert out["ok"] is False and "keywords" in out["error"], out
        assert not os.path.exists(g4)


def test_extra_layers_in_list_dry_run_and_docs():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        cwd = os.path.join(td, "w")
        os.makedirs(cwd)
        team = os.path.join(g, "layers.d", "team")
        make_layer(g,
                   "rules:\n  - id: gonly\n    tool: Bash\n    match: foo\n"
                   "    inject: G\n")
        make_layer(team,
                   "rules:\n  - id: t1\n    tool: Bash\n    match: foo\n"
                   "    doc: docs/t.md\n",
                   docs={"docs/t.md": "team body\n", "docs/orphan.md": "O\n"})

        data = jout(run_core(["list", "--cwd", cwd], g))
        layers = {l["name"]: l for l in data["layers"]}
        assert layers["layers.d/team"]["dir"] == team, data["layers"]
        assert layers["layers.d/team"]["exists"] is True
        # 並びは engine の読み順 (layers.d/* → global → project)
        assert [l["name"] for l in data["layers"]] == \
            ["layers.d/team", "global", "project"], data["layers"]
        by_id = {r["id"]: r for r in data["rules"]}
        assert by_id["t1"]["layer"] == "layers.d/team"
        assert by_id["t1"]["doc_abs"] == os.path.join(team, "docs", "t.md")
        assert by_id["t1"]["doc_exists"] is True
        assert by_id["t1"]["overridden"] is False

        # dry-run: 層表示は "layers.d/<名前>"、doc は追加層の中の絶対パス
        dr = jout(run_core(["dry-run", "--cwd", cwd, "--tool", "Bash",
                            "--input", "foo bar"], g))
        m = {x["id"]: x for x in dr["matches"]}
        assert set(m) == {"t1", "gonly"}, dr
        assert m["t1"]["layer"] == "layers.d/team"
        assert m["t1"]["text"] == "[toolhint] この操作の docs: %s — 必要なら読む" \
            % os.path.join(team, "docs", "t.md")

        # docs: 追加層の doc も (孤児 doc 込みで) 一覧に出る
        docs = {d["path_abs"]: d for d in jout(run_core(["docs", "--cwd", cwd], g))["docs"]}
        t_doc = docs[os.path.join(team, "docs", "t.md")]
        assert t_doc["layer"] == "layers.d/team"
        assert [t["id"] for t in t_doc["triggers"]] == ["t1"]
        orphan = docs[os.path.join(team, "docs", "orphan.md")]
        assert orphan["layer"] == "layers.d/team" and orphan["triggers"] == []


def test_extra_layers_override_and_local_disable():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        proj_root = os.path.join(td, "proj")
        proj_layer = os.path.join(proj_root, ".claude", "toolhint")
        os.makedirs(proj_root, exist_ok=True)
        make_layer(os.path.join(g, "layers.d", "team"),
                   "rules:\n"
                   "  - id: x\n    tool: Bash\n    match: foo\n    inject: TEAM\n"
                   "  - id: stop\n    tool: Bash\n    match: foo\n"
                   "    inject: TEAM_STOP\n")
        make_layer(g,
                   "rules:\n"
                   "  - id: x\n    tool: Bash\n    match: foo\n    inject: GLOBAL\n"
                   "  - id: stop\n    tool: Bash\n    enabled: \"false\"\n")

        data = jout(run_core(["list", "--cwd", proj_root], g))
        rows = {(r["layer"], r["id"]): r for r in data["rules"]}
        # 追加層の x は global に上書きされている / global の x は (project 無しなら) 有効
        assert rows[("layers.d/team", "x")]["overridden"] is True
        assert rows[("global", "x")]["overridden"] is False
        # 手元の enabled:false 行も一覧に残る (どこで止めたかが見える)
        assert rows[("global", "stop")]["enabled"] is False
        assert rows[("layers.d/team", "stop")]["enabled"] is True

        dr = jout(run_core(["dry-run", "--cwd", proj_root, "--tool", "Bash",
                            "--input", "foo"], g))
        texts = {m["id"]: m["text"] for m in dr["matches"]}
        assert texts == {"x": "[toolhint] GLOBAL"}, dr  # stop は無効化で消える
        # engine 発火 e2e — core の dry-run と実 hook が一致する
        p = run_engine_hook({"session_id": "ld-core-1", "cwd": proj_root,
                             "tool_name": "Bash", "tool_input": {"command": "foo"},
                             "hook_event_name": "PreToolUse"}, g)
        assert p.returncode == 0, p.stderr
        ctx = json.loads(p.stdout.strip())["hookSpecificOutput"]["additionalContext"]
        assert ctx == "[toolhint] GLOBAL", ctx

        # project 層でも止められる (そのプロジェクトだけ)
        make_layer(proj_layer,
                   "rules:\n  - id: x\n    tool: Bash\n    enabled: \"false\"\n")
        dr = jout(run_core(["dry-run", "--cwd", proj_root, "--tool", "Bash",
                            "--input", "foo"], g))
        assert dr == {"matches": []}, dr
        data = jout(run_core(["list", "--cwd", proj_root], g))
        rows = {(r["layer"], r["id"]): r for r in data["rules"]}
        assert rows[("global", "x")]["overridden"] is True  # project が最後に勝つ


def test_extra_layers_absent_unchanged_and_write_paths_rejected():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        cwd = os.path.join(td, "w")
        os.makedirs(cwd)
        make_layer(g,
                   "rules:\n  - id: a\n    tool: Bash\n    match: foo\n"
                   "    inject: A\n")
        # layers.d 不在: 層は従来の 2 つだけ
        data = jout(run_core(["list", "--cwd", cwd], g))
        assert [l["name"] for l in data["layers"]] == ["global", "project"], data
        # 空 layers.d も同じ
        os.makedirs(os.path.join(g, "layers.d"))
        data2 = jout(run_core(["list", "--cwd", cwd], g))
        assert data2 == data, data2

        # 書き込み経路は global | project のみ — 追加層は指定できない
        make_layer(os.path.join(g, "layers.d", "team"),
                   "rules:\n  - id: t1\n    tool: Bash\n    match: foo\n"
                   "    doc: docs/t.md\n", docs={"docs/t.md": "team\n"})
        rule = json.dumps({"id": "t2", "tool": "Bash", "doc": "docs/t.md"})
        p = run_core(["add-rule", "--layer", "layers.d/team", "--cwd", cwd,
                      "--rule", rule, "--doc-content", "x\n"], g)
        assert p.returncode == 2, p.stdout + p.stderr  # argparse の choices で拒否
        assert "layers.d/team" in p.stderr
        p = run_core(["save-doc", "--cwd", cwd, "--layer", "layers.d/team",
                      "--doc-name", "t.md", "--content", "x"], g)
        assert p.returncode == 2, p.stdout + p.stderr
        # 追加層のルール id は enable/disable でも触れない (層の外にある)
        out = jout(run_core(["disable-rule", "--cwd", cwd, "--id", "t1"], g),
                   expect_exit=1)
        assert out["ok"] is False and "存在しない" in out["error"], out
        # 追加層の中身は無傷
        assert read(os.path.join(g, "layers.d", "team", "rules.yaml")).count("t1") == 1


def test_extra_layer_doc_outside_layer_not_injected():
    # 追加層のルールが層外の doc を指したら dry-run にも出さない (engine と同じ制限)。
    # doctor は「層外」を問題として報告する (包含判定は realpath — 層内 symlink 込み)
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        cwd = os.path.join(td, "w")
        os.makedirs(cwd)
        secret = os.path.join(td, "secret.md")
        with open(secret, "w", encoding="utf-8") as f:
            f.write("TOP SECRET BODY\n")
        team = os.path.join(g, "layers.d", "team")
        make_layer(g, "rules:\n")
        make_layer(team,
                   "rules:\n"
                   "  - id: esc\n    tool: Bash\n    match: foo\n"
                   "    doc: ../../../secret.md\n    mode: inline\n"
                   "  - id: esc-sym\n    tool: Bash\n    match: foo\n"
                   "    doc: docs/link.md\n    mode: inline\n"
                   "  - id: ok\n    tool: Bash\n    match: foo\n    doc: docs/ok.md\n"
                   "    mode: inline\n",
                   docs={"docs/ok.md": "TEAM OK\n"})
        os.symlink(secret, os.path.join(team, "docs", "link.md"))

        dr = jout(run_core(["dry-run", "--cwd", cwd, "--tool", "Bash",
                            "--input", "foo"], g))
        assert [m["id"] for m in dr["matches"]] == ["ok"], dr
        assert "TOP SECRET" not in json.dumps(dr, ensure_ascii=False), dr
        # engine 発火 e2e — 実 hook でも層外 doc は注入されない
        p = run_engine_hook({"session_id": "esc-core-1", "cwd": cwd,
                             "tool_name": "Bash", "tool_input": {"command": "foo"},
                             "hook_event_name": "PreToolUse"}, g)
        ctx = json.loads(p.stdout.strip())["hookSpecificOutput"]["additionalContext"]
        assert ctx == "[toolhint] この操作の docs (ok):\nTEAM OK", ctx

        out = jout(run_core(["doctor", "--cwd", cwd], g), expect_exit=1)
        tl = [l for l in out["layers"] if l["name"] == "layers.d/team"][0]
        assert sum("層外を指す" in p for p in tl["problems"]) == 2, tl["problems"]


def test_doctor_reports_extra_layers():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        cwd = os.path.join(td, "w")
        os.makedirs(cwd)
        make_layer(g, "rules:\n  - id: a\n    tool: Bash\n    doc: docs/a.md\n",
                   docs={"docs/a.md": "A\n"})
        make_layer(os.path.join(g, "layers.d", "team"),
                   "rules:\n  - id: t1\n    tool: Bash\n    doc: docs/gone.md\n")
        out = jout(run_core(["doctor", "--cwd", cwd], g), expect_exit=1)
        tl = [l for l in out["layers"] if l["name"] == "layers.d/team"][0]
        assert any("gone.md" in p and "実在しない" in p for p in tl["problems"]), tl
        # 追加層は外からの配布物 — backup なしの警告は出さない (層の backup は None)
        assert tl["backup"] is None and tl["warnings"] == [], tl
        gl = [l for l in out["layers"] if l["name"] == "global"][0]
        assert gl["backup"] == "none" and gl["problems"] == [], gl


# ---------------------------------------------------------------------------
# 適用範囲 (scope) — 特定のディレクトリ配下でだけ効くルール
# rules.yaml (scope 無し) と rules-scoped.yaml (scope 付き) の 2 ファイル運用
# ---------------------------------------------------------------------------

SCOPED = "rules-scoped.yaml"


def scoped_path(layer_dir):
    return os.path.join(layer_dir, SCOPED)


def read_or_empty(path):
    """未作成のルールファイルは「ルール 0 件」と同義 — 読み比べ用に "" を返す。"""
    return read(path) if os.path.isfile(path) else ""


def test_scope_add_rule_routes_to_scoped_file():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        cwd = os.path.join(td, "work", "alpha")
        os.makedirs(cwd)
        # scope 付き → rules-scoped.yaml へ
        out = add_rule(g, "global", cwd,
                       {"id": "scoped", "tool": "Bash", "match": "foo",
                        "doc": "docs/s.md", "inject": "SCOPED",
                        "scope": "*/work/alpha*"}, "S\n")
        assert out["rules_path"] == scoped_path(g), out
        # scope 無し → rules.yaml へ (従来どおり)
        out2 = add_rule(g, "global", cwd,
                        {"id": "plain", "tool": "Bash", "match": "foo",
                         "doc": "docs/p.md", "inject": "PLAIN"}, "P\n")
        assert out2["rules_path"] == os.path.join(g, "rules.yaml"), out2
        assert "scope" not in read(os.path.join(g, "rules.yaml"))
        assert 'scope: "*/work/alpha*"' in read(scoped_path(g))
        # engine のパーサで両方読み戻せる (往復一致)
        assert [r["id"] for r in toolhint.load_rules(g)] == ["plain", "scoped"]

        # list: 適用範囲つきのルールだけ scope キーが増える
        rows = {r["id"]: r for r in jout(run_core(["list", "--cwd", cwd], g))["rules"]}
        assert rows["scoped"]["scope"] == "*/work/alpha*", rows["scoped"]
        assert "scope" not in rows["plain"], rows["plain"]
        assert rows["scoped"]["layer"] == "global"
        assert rows["scoped"]["doc_exists"] is True

        # id 重複はファイルをまたいで拒否 (同 id 2 行は engine が片方を黙って捨てる)
        dup = add_rule(g, "global", cwd,
                       {"id": "plain", "tool": "Bash", "doc": "docs/p.md",
                        "scope": "*"}, "P\n", expect_exit=1)
        assert dup["ok"] is False and "既に存在する" in dup["error"], dup
        assert read(scoped_path(g)).count("plain") == 0, read(scoped_path(g))


def test_scope_dry_run_and_engine_hook_agree():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        inside = os.path.join(td, "work", "alpha", "sub")
        outside = os.path.join(td, "work", "beta")
        os.makedirs(inside)
        os.makedirs(outside)
        make_layer(g,
                   "rules:\n  - id: plain\n    tool: Bash\n    match: foo\n"
                   "    inject: PLAIN\n")
        with open(scoped_path(g), "w", encoding="utf-8") as f:
            f.write("rules:\n"
                    "  - id: scoped\n    tool: Bash\n    match: foo\n"
                    "    inject: SCOPED\n    scope: \"*/work/alpha*\"\n"
                    "  - id: kw-scoped\n    event: prompt\n    keywords: deploy\n"
                    "    inject: KW_SCOPED\n    scope: \"*/work/alpha*\"\n")

        # dry-run --cwd がそのまま適用範囲の判定に効く
        dr_in = jout(run_core(["dry-run", "--cwd", inside, "--tool", "Bash",
                               "--input", "foo"], g))
        assert {m["id"] for m in dr_in["matches"]} == {"plain", "scoped"}, dr_in
        dr_out = jout(run_core(["dry-run", "--cwd", outside, "--tool", "Bash",
                                "--input", "foo"], g))
        assert {m["id"] for m in dr_out["matches"]} == {"plain"}, dr_out
        # ことばきっかけも同じ
        dp_in = jout(run_core(["dry-run", "--cwd", inside, "--event", "prompt",
                               "--input", "deploy して"], g))
        assert [m["id"] for m in dp_in["matches"]] == ["kw-scoped"], dp_in
        dp_out = jout(run_core(["dry-run", "--cwd", outside, "--event", "prompt",
                                "--input", "deploy して"], g))
        assert dp_out == {"matches": []}, dp_out

        # engine 発火 e2e — core の dry-run と実 hook が一致する
        p = run_engine_hook({"session_id": "sc-1", "cwd": inside,
                             "tool_name": "Bash", "tool_input": {"command": "foo"},
                             "hook_event_name": "PreToolUse"}, g)
        assert p.returncode == 0, p.stderr
        ctx = json.loads(p.stdout.strip())["hookSpecificOutput"]["additionalContext"]
        assert "SCOPED" in ctx and "PLAIN" in ctx, ctx
        p2 = run_engine_hook({"session_id": "sc-2", "cwd": outside,
                              "tool_name": "Bash", "tool_input": {"command": "foo"},
                              "hook_event_name": "PreToolUse"}, g)
        ctx2 = json.loads(p2.stdout.strip())["hookSpecificOutput"]["additionalContext"]
        assert ctx2 == "[toolhint] PLAIN", ctx2


def test_scope_update_rule_moves_between_files():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        cwd = os.path.join(td, "work")
        os.makedirs(cwd)
        add_rule(g, "global", cwd,
                 {"id": "a", "tool": "Bash", "match": "foo", "doc": "docs/a.md",
                  "inject": "A"}, "A\n")
        # 同じ doc への「きっかけ追加」(--doc-content 省略) でもう 1 件
        p = run_core(["add-rule", "--layer", "global", "--cwd", cwd, "--rule",
                      json.dumps({"id": "keep", "tool": "Bash", "match": "foo",
                                  "doc": "docs/a.md", "inject": "KEEP"})], g)
        assert jout(p)["ok"] is True

        # scope を付ける → rules-scoped.yaml へ移動、rules.yaml からは消える
        out = jout(run_core(["update-rule", "--cwd", cwd, "--id", "a",
                             "--patch", '{"scope": "*/work*"}'], g))
        assert out["rules_path"] == scoped_path(g), out
        assert out["rule"]["scope"] == "*/work*" and out["changed"] is True
        assert "id: \"a\"" not in read(os.path.join(g, "rules.yaml"))
        assert "id: \"a\"" in read(scoped_path(g))
        assert "KEEP" in read(os.path.join(g, "rules.yaml"))  # 他の行は動かない
        # 層としては 2 件のまま (取りこぼし・二重化なし)
        assert sorted(r["id"] for r in toolhint.load_rules(g)) == ["a", "keep"]
        assert jout(run_core(["dry-run", "--cwd", cwd, "--tool", "Bash",
                              "--input", "foo"], g))["matches"], "移動後も発火する"

        # scope を外す → rules.yaml へ戻る
        out2 = jout(run_core(["update-rule", "--cwd", cwd, "--id", "a",
                              "--patch", '{"scope": null}'], g))
        assert out2["rules_path"] == os.path.join(g, "rules.yaml"), out2
        assert "scope" not in out2["rule"], out2
        assert "id: \"a\"" in read(os.path.join(g, "rules.yaml"))
        assert "id: \"a\"" not in read(scoped_path(g))
        assert sorted(r["id"] for r in toolhint.load_rules(g)) == ["a", "keep"]

        # scope の値だけ変える (移動なし)
        jout(run_core(["update-rule", "--cwd", cwd, "--id", "a",
                       "--patch", '{"scope": "*/work*"}'], g))
        out3 = jout(run_core(["update-rule", "--cwd", cwd, "--id", "a",
                              "--patch", '{"scope": "*/elsewhere*"}'], g))
        assert out3["rules_path"] == scoped_path(g), out3
        assert out3["rule"]["scope"] == "*/elsewhere*"
        # 範囲外になったので発火しない
        assert [m["id"] for m in jout(run_core(
            ["dry-run", "--cwd", cwd, "--tool", "Bash", "--input", "foo"],
            g))["matches"]] == ["keep"]


def test_scope_rm_enable_disable_find_scoped_file():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        cwd = os.path.join(td, "work")
        os.makedirs(cwd)
        add_rule(g, "global", cwd,
                 {"id": "s1", "tool": "Bash", "match": "foo", "doc": "docs/s.md",
                  "inject": "S1", "scope": "*/work*"}, "S\n")
        # disable / enable は rules-scoped.yaml の中の行を書き換える
        out = jout(run_core(["disable-rule", "--cwd", cwd, "--id", "s1"], g))
        assert out["rules_path"] == scoped_path(g) and out["enabled"] is False, out
        assert 'enabled: "false"' in read(scoped_path(g))
        assert jout(run_core(["dry-run", "--cwd", cwd, "--tool", "Bash",
                              "--input", "foo"], g)) == {"matches": []}
        out = jout(run_core(["enable-rule", "--cwd", cwd, "--id", "s1"], g))
        assert out["enabled"] is True and out["changed"] is True, out
        assert "enabled" not in read(scoped_path(g))
        assert len(jout(run_core(["dry-run", "--cwd", cwd, "--tool", "Bash",
                                  "--input", "foo"], g))["matches"]) == 1
        # rm も scoped ファイルの行を消す (doc は残る = 孤児)
        out = jout(run_core(["rm-rule", "--cwd", cwd, "--id", "s1"], g))
        assert out["rules_path"] == scoped_path(g), out
        assert out["removed"]["scope"] == "*/work*", out
        assert toolhint.load_rules(g) == []
        assert os.path.isfile(os.path.join(g, "docs", "s.md"))
        # もう存在しない id はどの層にも見つからない
        gone = jout(run_core(["disable-rule", "--cwd", cwd, "--id", "s1"], g),
                    expect_exit=1)
        assert gone["ok"] is False and "存在しない" in gone["error"], gone


def test_scope_validation_rejections():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        cwd = os.path.join(td, "work")
        os.makedirs(cwd)
        add_rule(g, "global", cwd,
                 {"id": "base", "tool": "Bash", "doc": "docs/a.md"}, "A\n")
        base = {"id": "bad", "tool": "Bash", "doc": "docs/a.md"}
        # 空 scope
        out = add_rule(g, "global", cwd, dict(base, scope=""), "A\n",
                       expect_exit=1)
        assert out["ok"] is False and "scope" in out["error"], out
        # 制御文字入り scope (改行)
        out = add_rule(g, "global", cwd, dict(base, scope="a\nb"), "A\n",
                       expect_exit=1)
        assert out["ok"] is False and "制御文字" in out["error"], out
        # 文字列でない値
        p = run_core(["add-rule", "--layer", "global", "--cwd", cwd, "--rule",
                      json.dumps(dict(base, scope=123))], g)
        assert jout(p, expect_exit=1)["ok"] is False
        # update-rule でも同じ検証 (空白のみ = 実質空)
        out = jout(run_core(["update-rule", "--cwd", cwd, "--id", "base",
                             "--patch", '{"scope": "   "}'], g), expect_exit=1)
        assert out["ok"] is False and "scope" in out["error"], out
        # 拒否後も層は無傷 (rules-scoped.yaml も作られていない)
        assert [r["id"] for r in toolhint.load_rules(g)] == ["base"]
        assert not os.path.exists(scoped_path(g)), os.listdir(g)
        # ことばきっかけにも scope は付けられる (event 非依存のキー)
        ok = add_rule(g, "global", cwd,
                      {"id": "kw", "event": "prompt", "keywords": "deploy",
                       "doc": "docs/a.md", "scope": "*/work*"}, "A\n")
        assert ok["ok"] is True and ok["rules_path"] == scoped_path(g), ok
        assert jout(run_core(["dry-run", "--cwd", cwd, "--event", "prompt",
                              "--input", "deploy"], g))["matches"], "範囲内で発火"


def test_doctor_and_docs_see_scoped_file():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        cwd = os.path.join(td, "work")
        os.makedirs(cwd)
        make_layer(g, "rules:\n  - id: a\n    tool: Bash\n    doc: docs/a.md\n",
                   docs={"docs/a.md": "A\n", "docs/s.md": "S\n"})
        with open(scoped_path(g), "w", encoding="utf-8") as f:
            f.write("rules:\n  - id: s\n    tool: Bash\n    doc: docs/s.md\n"
                    "    scope: \"*/work*\"\n")
        # docs: scoped ファイルのきっかけも doc に紐づく (孤児にならない)
        docs = {d["path_abs"]: d for d in
                jout(run_core(["docs", "--cwd", cwd], g))["docs"]}
        s_doc = docs[os.path.join(g, "docs", "s.md")]
        assert [t["id"] for t in s_doc["triggers"]] == ["s"], s_doc
        # doctor: 孤児の誤検知なし・問題なし
        out = jout(run_core(["doctor", "--cwd", cwd], g))
        gl = [l for l in out["layers"] if l["name"] == "global"][0]
        assert gl["problems"] == [], gl
        assert not any("s.md" in w for w in gl["warnings"]), gl["warnings"]
        # scoped ファイルの doc 欠落も問題として報告する
        os.remove(os.path.join(g, "docs", "s.md"))
        out = jout(run_core(["doctor", "--cwd", cwd], g), expect_exit=1)
        gl = [l for l in out["layers"] if l["name"] == "global"][0]
        assert any("s.md" in p and "実在しない" in p for p in gl["problems"]), gl
        # scoped ファイルが壊れていれば「層全体が読み飛ばされる」と言う
        with open(scoped_path(g), "w", encoding="utf-8") as f:
            f.write("rules:\n  - id: b\n    tool: Bash\n    nested:\n      x: 1\n")
        out = jout(run_core(["doctor", "--cwd", cwd], g), expect_exit=1)
        gl = [l for l in out["layers"] if l["name"] == "global"][0]
        assert any(SCOPED in p and "読めない" in p for p in gl["problems"]), gl
        # 同 id が層内に 2 行 (手編集) は警告する — engine は片方を黙って捨てる
        with open(scoped_path(g), "w", encoding="utf-8") as f:
            f.write("rules:\n  - id: a\n    tool: Bash\n    doc: docs/a.md\n"
                    "    scope: \"*\"\n")
        out = jout(run_core(["doctor", "--cwd", cwd], g))
        gl = [l for l in out["layers"] if l["name"] == "global"][0]
        assert any("2 回以上" in w for w in gl["warnings"]), gl["warnings"]


def test_export_import_roundtrip_scoped_rules():
    # scope 付きルールは bundle に含まれ、取り込み先でも rules-scoped.yaml へ着地する
    with tempfile.TemporaryDirectory() as td:
        src = os.path.join(td, "src")
        cwd = os.path.join(td, "work")
        os.makedirs(cwd)
        make_layer(src,
                   "rules:\n  - id: plain\n    tool: Bash\n    match: foo\n"
                   "    doc: docs/p.md\n",
                   docs={"docs/p.md": "P\n", "docs/s.md": "S\n"})
        with open(scoped_path(src), "w", encoding="utf-8") as f:
            f.write("rules:\n  - id: scoped\n    tool: Bash\n    match: foo\n"
                    "    doc: docs/s.md\n    scope: \"*/work*\"\n")

        bundle = os.path.join(td, "b.tar.gz")
        out = jout(run_core(["export", "--cwd", cwd, "--layer", "global",
                             "--out", bundle], src))
        assert out["rules_count"] == 2, out  # 2 ファイルの合計
        with tarfile.open(bundle, "r:gz") as tf:
            names = sorted(m.name for m in tf.getmembers())
        assert names == ["docs/p.md", "docs/s.md", "manifest.json",
                         SCOPED, "rules.yaml"], names

        # 空の別層へ取り込む → 2 ファイルとも復元し、置き先も保たれる
        g2 = os.path.join(td, "g2")
        out = jout(run_core(["import", bundle, "--cwd", cwd,
                             "--layer", "global"], g2))
        assert {r["id"]: r["action"] for r in out["rules"]} == \
            {"plain": "add", "scoped": "add"}, out
        assert "scoped" in read(scoped_path(g2))
        assert "scoped" not in read(os.path.join(g2, "rules.yaml"))
        assert sorted(r["id"] for r in toolhint.load_rules(g2)) == \
            ["plain", "scoped"]
        # 取り込んだ層がそのまま適用範囲つきで発火する (孤児 doc にならない)
        assert {m["id"] for m in jout(run_core(
            ["dry-run", "--cwd", cwd, "--tool", "Bash", "--input", "foo"],
            g2))["matches"]} == {"plain", "scoped"}
        assert {m["id"] for m in jout(run_core(
            ["dry-run", "--cwd", td, "--tool", "Bash", "--input", "foo"],
            g2))["matches"]} == {"plain"}
        # 再 import は全 skip で無変更 (冪等 — 2 ファイルまたぎの id 検査)
        before = (read(os.path.join(g2, "rules.yaml")), read(scoped_path(g2)))
        out = jout(run_core(["import", bundle, "--cwd", cwd], g2))
        assert {r["id"]: r["action"] for r in out["rules"]} == \
            {"plain": "skip", "scoped": "skip"}, out
        assert (read(os.path.join(g2, "rules.yaml")), read(scoped_path(g2))) \
            == before


def test_import_places_by_scope_and_checks_both_files():
    with tempfile.TemporaryDirectory() as td:
        src = os.path.join(td, "src")
        cwd = os.path.join(td, "work")
        os.makedirs(cwd)
        # bundle 側: rules.yaml に scope 付きが混じった「置き分けに反する bundle」
        # (旧版が作った bundle・手編集 bundle を想定)
        make_layer(src,
                   "rules:\n"
                   "  - id: mixed\n    tool: Bash\n    match: foo\n"
                   "    doc: docs/a.md\n    scope: \"*/work*\"\n",
                   docs={"docs/a.md": "A\n"})
        bundle = os.path.join(td, "b.tar.gz")
        assert jout(run_core(["export", "--cwd", cwd, "--out", bundle],
                             src))["ok"] is True
        with tarfile.open(bundle, "r:gz") as tf:  # bundle には rules.yaml だけ
            assert SCOPED not in [m.name for m in tf.getmembers()]

        # 取り込み先では scope の有無で置き先が決まる (fail-closed 配置へ矯正)
        g2 = os.path.join(td, "g2")
        jout(run_core(["import", bundle, "--cwd", cwd, "--layer", "global"], g2))
        assert "mixed" in read(scoped_path(g2)), read(scoped_path(g2))
        # rules.yaml は「書くものが無いので作られない」= 置き先が分かれている証拠
        assert "mixed" not in read_or_empty(os.path.join(g2, "rules.yaml"))

        # 既存が rules-scoped.yaml にいても id 衝突として検出する (skip)
        out = jout(run_core(["import", bundle, "--cwd", cwd], g2))
        assert out["rules"] == [{"id": "mixed", "action": "skip"}], out
        out = jout(run_core(["import", bundle, "--cwd", cwd, "--dry-run"], g2))
        assert out["rules"] == [{"id": "mixed", "action": "skip"}], out
        # --overwrite でも 2 行に増えない (置き先のまま差し替え)
        out = jout(run_core(["import", bundle, "--cwd", cwd, "--overwrite"], g2))
        assert out["rules"] == [{"id": "mixed", "action": "overwrite"}], out
        assert [r["id"] for r in toolhint.load_rules(g2)] == ["mixed"]
        assert read(scoped_path(g2)).count("id:") == 1, read(scoped_path(g2))

        # 上書きで scope が外れる bundle → ルール行が rules.yaml へ移る
        src2 = os.path.join(td, "src2")
        make_layer(src2,
                   "rules:\n  - id: mixed\n    tool: Bash\n    match: foo\n"
                   "    doc: docs/a.md\n", docs={"docs/a.md": "A\n"})
        bundle2 = os.path.join(td, "b2.tar.gz")
        jout(run_core(["export", "--cwd", cwd, "--out", bundle2], src2))
        jout(run_core(["import", bundle2, "--cwd", cwd, "--overwrite"], g2))
        assert "mixed" in read(os.path.join(g2, "rules.yaml"))
        assert "mixed" not in read(scoped_path(g2))
        assert [r["id"] for r in toolhint.load_rules(g2)] == ["mixed"]


def test_doctor_warns_scope_placement_and_dead_pattern():
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        cwd = os.path.join(td, "work")
        os.makedirs(cwd)
        # 手編集で rules.yaml に scope 付きが居る + 絶対パスに一致しないパターン
        make_layer(g,
                   "rules:\n"
                   "  - id: misplaced\n    tool: Bash\n    doc: docs/a.md\n"
                   "    scope: \"*/work*\"\n"
                   "  - id: dead\n    tool: Bash\n    doc: docs/a.md\n"
                   "    scope: \"work/*\"\n",
                   docs={"docs/a.md": "A\n"})
        out = jout(run_core(["doctor", "--cwd", cwd], g))  # 警告どまり (exit 0)
        gl = [l for l in out["layers"] if l["name"] == "global"][0]
        assert gl["problems"] == [], gl
        ws = gl["warnings"]
        assert sum("misplaced" in w and SCOPED in w for w in ws) == 1, ws
        assert sum("dead" in w and "絶対パスに一致しない" in w for w in ws) == 1, ws
        # 正しく置かれた scope 付きルールには置き場所の警告を出さない
        make_layer(g, "rules:\n", docs={"docs/a.md": "A\n"})
        with open(scoped_path(g), "w", encoding="utf-8") as f:
            f.write("rules:\n  - id: ok\n    tool: Bash\n    doc: docs/a.md\n"
                    "    scope: \"*/work*\"\n")
        out = jout(run_core(["doctor", "--cwd", cwd], g))
        gl = [l for l in out["layers"] if l["name"] == "global"][0]
        assert not any("scope" in w for w in gl["warnings"]), gl["warnings"]


def test_update_rule_relocate_heals_duplicate_id():
    # 手編集で両ファイルに同 id がある異常状態から scope を付け外ししても、
    # 移動先に 2 行目が生えない (1 行へ畳む)
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        cwd = os.path.join(td, "work")
        os.makedirs(cwd)
        make_layer(g, "rules:\n  - id: dup\n    tool: Bash\n    match: PLAIN\n"
                      "    doc: docs/a.md\n", docs={"docs/a.md": "A\n"})
        with open(scoped_path(g), "w", encoding="utf-8") as f:
            f.write("rules:\n  - id: dup\n    tool: Bash\n    match: SCOPED\n"
                    "    doc: docs/a.md\n    scope: \"*/work*\"\n")
        # doctor は 2 行あることを警告する
        out = jout(run_core(["doctor", "--cwd", cwd], g))
        gl = [l for l in out["layers"] if l["name"] == "global"][0]
        assert any("2 回以上" in w for w in gl["warnings"]), gl["warnings"]
        # rules.yaml 側 (engine の読み順で先) の行に scope を付けて移動させる
        out = jout(run_core(["update-rule", "--cwd", cwd, "--id", "dup",
                             "--patch", '{"scope": "*/work*"}'], g))
        assert out["rules_path"] == scoped_path(g), out
        assert [r["id"] for r in toolhint.load_rules(g)] == ["dup"], \
            toolhint.load_rules(g)
        assert read(scoped_path(g)).count("id:") == 1, read(scoped_path(g))
        assert toolhint.load_rules(g)[0]["match"] == "PLAIN"  # 編集した行が残る


def test_rules_yaml_only_layer_unchanged_core():
    # 後方互換の確認: rules-scoped.yaml が無い層では、読み経路の出力も
    # 書き込み経路の置き先も従来どおり (旧版 engine が読む rules.yaml だけで完結)
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        cwd = os.path.join(td, "work")
        os.makedirs(cwd)
        make_layer(g, "rules:\n  - id: a\n    tool: Bash\n    match: foo\n"
                      "    doc: docs/a.md\n", docs={"docs/a.md": "A\n"})
        lst = jout(run_core(["list", "--cwd", cwd], g))
        assert [l["name"] for l in lst["layers"]] == ["global", "project"], lst
        assert lst["rules"][0] == {
            "id": "a", "tool": "Bash", "match": "foo", "doc": "docs/a.md",
            "inject": None, "mode": "pointer", "every": "session",
            "enabled": True, "event": "tool", "keywords": None, "find": None,
            "case": None, "layer": "global", "overridden": False,
            "doc_abs": os.path.join(g, "docs", "a.md"), "doc_exists": True,
        }, lst["rules"][0]  # scope キーは増えない (1 バイトも変わらない)
        dr = jout(run_core(["dry-run", "--cwd", cwd, "--tool", "Bash",
                            "--input", "foo"], g))
        assert [m["id"] for m in dr["matches"]] == ["a"], dr
        # 書き込み経路も rules.yaml のまま — scoped ファイルは作られない
        add_rule(g, "global", cwd,
                 {"id": "b", "tool": "Bash", "doc": "docs/b.md"}, "B\n")
        jout(run_core(["update-rule", "--cwd", cwd, "--id", "b",
                       "--patch", '{"every": "always"}'], g))
        jout(run_core(["disable-rule", "--cwd", cwd, "--id", "b"], g))
        assert not os.path.exists(scoped_path(g)), os.listdir(g)
        assert [n for n in os.listdir(g) if n.endswith(".yaml")] == ["rules.yaml"], \
            os.listdir(g)


# ---------------------------------------------------------------------------
# list — 読めない層の可視化 (layers[].parse_error / layer_errors)
# ---------------------------------------------------------------------------

def test_list_reports_layer_parse_errors():
    """engine パーサで読めないルールファイルを持つ層は、rules が 0 件になるだけで
    なく parse_error (ファイル名 + 行番号つき理由) と layer_errors で分かること。
    健全な層・層なしでは parse_error が null、layer_errors は []。"""
    with tempfile.TemporaryDirectory() as td:
        g = os.path.join(td, "g")
        proj_root = os.path.join(td, "proj")
        proj_layer = os.path.join(proj_root, ".claude", "toolhint")
        team = os.path.join(g, "layers.d", "team")
        # 健全な状態: parse_error は全層 null、layer_errors は []
        make_layer(g, "rules:\n  - id: g1\n    tool: Bash\n    doc: docs/a.md\n",
                   docs={"docs/a.md": "A\n"})
        make_layer(team, "rules:\n  - id: t1\n    tool: Bash\n    inject: T\n")
        os.makedirs(proj_root)
        data = jout(run_core(["list", "--cwd", proj_root], g))
        assert [l["name"] for l in data["layers"]] == \
            ["layers.d/team", "global", "project"], data["layers"]
        assert all(l["parse_error"] is None for l in data["layers"]), data["layers"]
        assert data["layer_errors"] == [], data
        assert {r["id"] for r in data["rules"]} == {"g1", "t1"}

        # project 層の rules.yaml がクォート漏れで壊れている → その層だけ 0 件 +
        # parse_error / layer_errors。他の層は影響なし
        make_layer(proj_layer,
                   "rules:\n  - id: good\n    tool: Bash\n    match: foo\n"
                   "    doc: docs/a.md\n  - id: bad\n    tool: Bash\n"
                   "    match: [unquoted-bracket]\n    doc: docs/a.md\n")
        data = jout(run_core(["list", "--cwd", proj_root], g))
        layers = {l["name"]: l for l in data["layers"]}
        assert layers["project"]["exists"] is True
        assert layers["project"]["parse_error"] == \
            "rules.yaml: line 8: 構文外の値: '[unquoted-bracket]'", layers["project"]
        assert layers["global"]["parse_error"] is None
        assert layers["layers.d/team"]["parse_error"] is None
        assert data["layer_errors"] == [{
            "layer": "project", "file": os.path.join(proj_layer, "rules.yaml"),
            "error": "line 8: 構文外の値: '[unquoted-bracket]'"}], data["layer_errors"]
        assert {r["id"] for r in data["rules"]} == {"g1", "t1"}, data["rules"]

        # rules.yaml は健全で rules-scoped.yaml だけ壊れていても層ごと読み飛ばされる
        # (engine と同じ) — parse_error は壊れたファイル名で示す
        with open(scoped_path(g), "w", encoding="utf-8") as f:
            f.write("rules:\n  - id: s1\n    tool: Bash\n"
                    "    scope:\n      glob: \"*/proj*\"\n    doc: docs/a.md\n")
        data = jout(run_core(["list", "--cwd", proj_root], g))
        layers = {l["name"]: l for l in data["layers"]}
        assert layers["global"]["parse_error"].startswith(
            "rules-scoped.yaml: line 4: "), layers["global"]
        assert "g1" not in {r["id"] for r in data["rules"]}, data["rules"]
        files = [(e["layer"], os.path.basename(e["file"])) for e in data["layer_errors"]]
        assert files == [("global", "rules-scoped.yaml"), ("project", "rules.yaml")], files

        # 両ファイルとも壊れていれば "; " で連結 (layer_errors はファイルごとに 1 件)
        make_layer(g, "rules:\n  - id: g1\n    tool: Bash\n    doc: docs/a.md\n"
                      "  - id: g2\n    tool: Bash\n    match: {a: b}\n")
        data = jout(run_core(["list", "--cwd", proj_root], g))
        layers = {l["name"]: l for l in data["layers"]}
        pe = layers["global"]["parse_error"]
        assert pe.startswith("rules.yaml: line 7: ") and \
            "; rules-scoped.yaml: line 4: " in pe, pe
        assert [e["layer"] for e in data["layer_errors"]] == \
            ["global", "global", "project"], data["layer_errors"]
        assert all(set(e) == {"layer", "file", "error"} for e in data["layer_errors"])

        # 追加層 (layers.d) が壊れていても同じ形で報告される
        make_layer(team, "just: garbage\n")
        data = jout(run_core(["list", "--cwd", proj_root], g))
        layers = {l["name"]: l for l in data["layers"]}
        assert layers["layers.d/team"]["parse_error"].startswith("rules.yaml: "), layers
        assert any(e["layer"] == "layers.d/team" for e in data["layer_errors"])
        assert data["rules"] == [], data["rules"]


# ---------------------------------------------------------------------------
# doctor — 注入するものが無いルール / 同一ファイル内の id 重複 / 大きい inline doc /
# plugin の 1 行要約
# ---------------------------------------------------------------------------

def test_doctor_flags_rules_with_nothing_to_inject():
    """doc も inject も無いルール・inject が {doc} を参照するのに doc が無いルールは、
    engine がマッチ時に無言でスキップする — doctor は問題 (exit 1) として報告する。
    inject の文面だけのルールは正常。"""
    with tempfile.TemporaryDirectory() as td:
        cwd = os.path.join(td, "w")
        os.makedirs(cwd)
        g = os.path.join(td, "g")
        # 正常: 文面だけのルール (pointer / inline どちらも) → 問題なし
        make_layer(g, "rules:\n"
                      "  - id: text-only\n    tool: Bash\n    inject: TEXT\n"
                      "  - id: text-inline\n    tool: Bash\n    inject: TEXT\n"
                      "    mode: inline\n"
                      "  - id: kw-text\n    event: prompt\n    keywords: deploy\n"
                      "    inject: KW\n")
        out = jout(run_core(["doctor", "--cwd", cwd], g))
        gl = [l for l in out["layers"] if l["name"] == "global"][0]
        assert gl["problems"] == [], gl["problems"]
        # 異常: 注入するものが作れないルール
        make_layer(g, "rules:\n"
                      "  - id: nothing\n    tool: Bash\n"
                      "  - id: docref\n    tool: Bash\n    inject: \"see {doc}\"\n"
                      "  - id: inline-nodoc\n    tool: Bash\n    mode: inline\n"
                      "    inject: \"{doc} body\"\n"
                      "  - id: kw-nothing\n    event: prompt\n    keywords: deploy\n"
                      "  - id: fine\n    tool: Bash\n    doc: docs/a.md\n",
                   docs={"docs/a.md": "A\n"})
        out = jout(run_core(["doctor", "--cwd", cwd], g), expect_exit=1)
        gl = [l for l in out["layers"] if l["name"] == "global"][0]
        by_msg = "\n".join(gl["problems"])
        assert "ルール 'nothing' に doc も inject もない" in by_msg, gl["problems"]
        assert "ルール 'kw-nothing' に doc も inject もない" in by_msg, gl["problems"]
        assert "ルール 'docref' の inject が {doc} を参照するのに doc がない" in by_msg
        assert "ルール 'inline-nodoc' の inject が {doc} を参照するのに doc がない" \
            in by_msg, gl["problems"]
        assert not any("'fine'" in p for p in gl["problems"]), gl["problems"]
        assert out["problems_total"] == 4, out["problems_total"]
        # engine も実際にスキップする (doctor の言うとおり) — 文面だけの fine 以外
        # は dry-run に出ない
        dr = jout(run_core(["dry-run", "--cwd", cwd, "--tool", "Bash",
                            "--input", "anything"], g))
        assert [m["id"] for m in dr["matches"]] == ["fine"], dr


def test_doctor_warns_duplicate_id_in_same_file():
    """同一ファイル内の id 重複は注意 (exit 0) — どのファイルに何回あるかを添え、
    同じファイル内なら書き間違いの可能性を示す。id ごとに 1 件。"""
    with tempfile.TemporaryDirectory() as td:
        cwd = os.path.join(td, "w")
        os.makedirs(cwd)
        g = os.path.join(td, "g")
        make_layer(g, "rules:\n"
                      "  - id: dup\n    tool: Bash\n    match: foo\n    doc: docs/a.md\n"
                      "  - id: dup\n    tool: Bash\n    match: bar\n    doc: docs/a.md\n"
                      "  - id: dup\n    tool: Bash\n    match: baz\n    doc: docs/a.md\n"
                      "  - id: uniq\n    tool: Bash\n    doc: docs/a.md\n",
                   docs={"docs/a.md": "A\n"})
        out = jout(run_core(["doctor", "--cwd", cwd], g))  # 注意どまり (exit 0)
        gl = [l for l in out["layers"] if l["name"] == "global"][0]
        dups = [w for w in gl["warnings"] if "2 回以上" in w]
        assert len(dups) == 1, gl["warnings"]
        assert "id 'dup'" in dups[0] and "rules.yaml に 3 回" in dups[0], dups[0]
        assert "書き間違い" in dups[0], dups[0]
        assert "uniq" not in dups[0]
        # 層のもう一方のファイルとの重複も注意 (ファイルごとの回数つき、
        # 同一ファイル内ではないので書き間違いの注記は付かない)
        make_layer(g, "rules:\n  - id: x\n    tool: Bash\n    doc: docs/a.md\n",
                   docs={"docs/a.md": "A\n"})
        with open(scoped_path(g), "w", encoding="utf-8") as f:
            f.write("rules:\n  - id: x\n    tool: Bash\n    doc: docs/a.md\n"
                    "    scope: \"*/w*\"\n")
        out = jout(run_core(["doctor", "--cwd", cwd], g))
        gl = [l for l in out["layers"] if l["name"] == "global"][0]
        dups = [w for w in gl["warnings"] if "2 回以上" in w]
        assert len(dups) == 1, gl["warnings"]
        assert "rules.yaml に 1 回, rules-scoped.yaml に 1 回" in dups[0], dups[0]
        assert "書き間違い" not in dups[0], dups[0]
        # 重複が無ければ注意なし
        os.remove(scoped_path(g))
        out = jout(run_core(["doctor", "--cwd", cwd], g))
        gl = [l for l in out["layers"] if l["name"] == "global"][0]
        assert not any("2 回以上" in w for w in gl["warnings"]), gl["warnings"]


def test_doctor_warns_large_inline_doc():
    """mode: inline の doc が上限 (既定 64 KB — engine と同じ値) を超えていれば
    注意 (exit 0)。同じ doc でも pointer なら注意なし。上限以内の inline も注意なし。"""
    with tempfile.TemporaryDirectory() as td:
        cwd = os.path.join(td, "w")
        os.makedirs(cwd)
        g = os.path.join(td, "g")
        make_layer(g, "rules:\n"
                      "  - id: big-inline\n    tool: Bash\n    doc: docs/big.md\n"
                      "    mode: inline\n"
                      "  - id: big-pointer\n    tool: Bash\n    doc: docs/big.md\n"
                      "  - id: small-inline\n    tool: Bash\n    doc: docs/small.md\n"
                      "    mode: inline\n"
                      "  - id: kw-big\n    event: prompt\n    keywords: deploy\n"
                      "    doc: docs/huge.md\n    mode: inline\n",
                   docs={"docs/big.md": "X" * (64 * 1024 + 1),
                         "docs/small.md": "Y" * (64 * 1024),
                         "docs/huge.md": "Z" * (1024 * 1024)})
        out = jout(run_core(["doctor", "--cwd", cwd], g))  # 注意どまり (exit 0)
        assert out["ok"] is True and out["problems_total"] == 0, out
        gl = [l for l in out["layers"] if l["name"] == "global"][0]
        big = [w for w in gl["warnings"] if "inline の上限" in w]
        assert len(big) == 2, gl["warnings"]
        assert any("'big-inline'" in w and "docs/big.md" in w and "65 KB" in w
                   and "64 KB" in w and "pointer" in w for w in big), big
        assert any("'kw-big'" in w and "1.0 MB" in w for w in big), big
        assert not any("'big-pointer'" in w or "'small-inline'" in w
                       for w in gl["warnings"]), gl["warnings"]
        assert out["warnings_total"] >= 2
        # engine が環境変数で上限を変えられるなら doctor も同じ値で判定する
        env_name = getattr(toolhint, "INLINE_MAX_ENV", None)
        if env_name and callable(getattr(toolhint, "inline_max_bytes", None)):
            out = jout(run_core(["doctor", "--cwd", cwd], g,
                                extra_env={env_name: str(2 * 1024 * 1024)}))
            gl = [l for l in out["layers"] if l["name"] == "global"][0]
            assert not any("inline の上限" in w for w in gl["warnings"]), gl["warnings"]
            out = jout(run_core(["doctor", "--cwd", cwd], g,
                                extra_env={env_name: "1024"}))
            gl = [l for l in out["layers"] if l["name"] == "global"][0]
            big = [w for w in gl["warnings"] if "inline の上限" in w]
            assert len(big) == 3 and any("'small-inline'" in w and "1 KB" in w
                                         for w in big), gl["warnings"]


def test_doctor_plugin_summary_always_present():
    """plugin の検査結果は健全時にも status / summary の 1 行で必ず返る —
    未インストール / 最新 / stale / registry が読めない。"""
    import shutil
    with tempfile.TemporaryDirectory() as td:
        cwd = os.path.join(td, "w")
        os.makedirs(cwd)
        g = os.path.join(td, "g")
        make_layer(g, "rules:\n  - id: a\n    tool: Bash\n    doc: docs/a.md\n",
                   docs={"docs/a.md": "A\n"})
        # 未インストール (registry 不在)
        out = jout(run_core(["doctor", "--cwd", cwd], g))
        assert out["plugin"]["status"] == "not_installed", out["plugin"]
        assert out["plugin"]["summary"].startswith("未インストール"), out["plugin"]
        # registry はあるが toolhint@toolhint の項目が無い → 未インストール
        reg = os.path.join(td, "installed_plugins.json")
        with open(reg, "w", encoding="utf-8") as f:
            json.dump({"version": 2, "plugins": {}}, f)
        env = {"TOOLHINT_INSTALLED_PLUGINS": reg}
        out = jout(run_core(["doctor", "--cwd", cwd], g, extra_env=env))
        assert out["plugin"]["status"] == "not_installed", out["plugin"]
        # 最新 (スナップショットが repo engine と同一)
        ip = os.path.join(td, "cache", "toolhint", "toolhint", "0.5.0")
        os.makedirs(os.path.join(ip, "scripts"))
        shutil.copyfile(ENGINE, os.path.join(ip, "scripts", "toolhint.py"))
        with open(reg, "w", encoding="utf-8") as f:
            json.dump({"version": 2, "plugins": {"toolhint@toolhint": [
                {"scope": "user", "installPath": ip, "version": "0.5.0"}]}}, f)
        out = jout(run_core(["doctor", "--cwd", cwd], g, extra_env=env))
        assert out["ok"] is True and out["plugin"]["warnings"] == [], out["plugin"]
        assert out["plugin"]["status"] == "latest", out["plugin"]
        assert out["plugin"]["summary"] == "0.5.0 (最新)", out["plugin"]
        # stale (スナップショットが古い)
        with open(os.path.join(ip, "scripts", "toolhint.py"), "w",
                  encoding="utf-8") as f:
            f.write("# old snapshot\n")
        out = jout(run_core(["doctor", "--cwd", cwd], g, extra_env=env))
        assert out["plugin"]["status"] == "stale", out["plugin"]
        assert out["plugin"]["summary"].startswith("0.5.0 (stale"), out["plugin"]
        assert len(out["plugin"]["warnings"]) == 1, out["plugin"]
        # registry が読めない (壊れた JSON) → unknown + 注意
        with open(reg, "w", encoding="utf-8") as f:
            f.write("{not json")
        out = jout(run_core(["doctor", "--cwd", cwd], g, extra_env=env))
        assert out["plugin"]["status"] == "unknown", out["plugin"]
        assert out["plugin"]["summary"].startswith("不明"), out["plugin"]
        assert len(out["plugin"]["warnings"]) == 1, out["plugin"]


# ---------------------------------------------------------------------------
# runner
# ---------------------------------------------------------------------------

def main():
    tests = [(n, f) for n, f in sorted(globals().items())
             if n.startswith("test_") and callable(f)]
    passed, failed = 0, 0
    for name, fn in tests:
        try:
            fn()
        except Exception as e:
            failed += 1
            print("FAIL %s: %r" % (name, e))
        else:
            passed += 1
            print("PASS %s" % name)
    print("---")
    print("%d passed, %d failed, %d total" % (passed, failed, passed + failed))
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
