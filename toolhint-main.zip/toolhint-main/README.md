# toolhint

Claude Code の hook で、**きっかけ** (どの操作・どの発言に反応するか) に紐づけた docs を
agent の context に**注入** (実行の直前に差し込んで見せる) するツール群。
ルールと docs はプレーンファイルで、CLI / GUI の管理面つき。
依存は python3 標準ライブラリのみ (GUI のみ Node.js >= 18)。

## 動作イメージ

ルール 1 つ (`tool: Bash` / `match: \bgrep\b` / `doc: docs/search-tools.md`) を
登録した状態で、agent が `grep -r foo .` を実行しようとすると:

```
# 導入前 — agent はそのまま grep を実行する

# 導入後 — 実行の直前に hook が context を注入し、agent はそれを見てから動く
[toolhint] この操作の docs: ~/.claude/toolhint/docs/search-tools.md — 必要なら読む
```

agent は注入された docs を読んで `rg` に切り替える。実行は一切ブロックしない
(**fail-open** — hook が異常でもツール実行は必ず通る)。

## 30 秒で試す

前提: python3 (3.9 以上。PATH に通っていること) と Claude Code (`claude` CLI)。

### 経路 A: GitHub から直接 (推奨)

どのディレクトリで打ってもよい。2 コマンドで入る:

```sh
claude plugin marketplace add AI-Driven-R-D-Dept/toolhint   # marketplace 名 = toolhint
claude plugin install toolhint@toolhint
```

Claude Code が repo を `~/.claude/plugins/marketplaces/toolhint/` に clone する。
CLI もそこ (`~/.claude/plugins/marketplaces/toolhint/cli/toolhint`) に入っているので、
PATH に足して使う (新しいターミナルでも使うなら、この行をシェルの rc — `~/.zshrc` 等 — に足す):

```sh
export PATH="$HOME/.claude/plugins/marketplaces/toolhint/cli:$PATH"
```

- 更新は `claude plugin marketplace update toolhint && claude plugin update toolhint@toolhint`
- この repo が private の間は、add する側に GitHub の認証 (`gh auth login` 済みか SSH 鍵) が要る
- この clone は Claude Code の管理領域 — 手で編集しない (コードを触るなら経路 B)。
  GUI もこの clone のまま動く (下の「できること」表 — 起動するだけなら手編集にはあたらない)

### 経路 B: 手元に clone (コードを触る・オフラインで入れる)

```sh
git clone https://github.com/AI-Driven-R-D-Dept/toolhint.git toolhint
# 以降このブロックは clone した親ディレクトリ (toolhint/ が見える場所) で実行する
claude plugin marketplace add ./toolhint     # marketplace 名 = toolhint
claude plugin install toolhint@toolhint
```

CLI は `./toolhint/cli/toolhint` (PATH に通すなら `export PATH="$PWD/toolhint/cli:$PATH"` —
rc に足せば新しいターミナルでも使える)。
repo 更新後は `claude plugin update toolhint@toolhint` で実 hook を差し替える。

### 最初のルール

どちらの経路でも同じ。以下 `toolhint` = 上で用意した CLI
(`--layer global` = マシン全体の層。**層** = ルールと docs の置き場):

```sh
toolhint add --layer global --id use-rg --tool Bash --match '\bgrep\b' \
  --doc-name use-rg.md --doc-content 'grep より rg (ripgrep) を使う。'
toolhint test "grep -r foo ."    # dry-run — この入力に何が注入されるか
toolhint doctor                  # hook・ルール・doc の健全性チェック (問題あり = exit 1)
```

これで次の claude セッションから、`grep` を含むコマンドの直前に docs が注入される。
特定プロジェクトだけに効かせて repo にコミットするなら、そのプロジェクトの dir で
`--layer` なしの `add` (project 層が既定)。
注入が一度も出ないときは、まず `python3` が PATH にあるかを疑う
([getting-started §8](docs/getting-started.md#8-トラブルシュート))。

## できること

| 面 | できること |
|---|---|
| hook (engine) | **操作きっかけ** — agent がツールを使う直前に反応 (PreToolUse。tool 名と入力への正規表現) / **ことばきっかけ** — ユーザーの発言に反応 (UserPromptSubmit。keywords)。どちらも fail-open で実行は止めない |
| CLI `cli/toolhint` | `list` (一覧) / `test` (dry-run) / `add` (作成 — 手動指定 or `--ai` で agent 起案 = 要望の一文からルールを下書き) / `rule update・rm・enable・disable` (編集) / `export`・`import` (tar.gz で持ち出し) / `backup init` (層の git 化) / `doctor` (健全性)。ことばきっかけも同じ CLI で — 作成 `add --event prompt --id X --keywords "<a, b>" …` / 編集 `rule update <id> --keywords "…"` / dry-run `test --event prompt "<発言>"` (keywords は `,` / `、` / `，` 区切りで複数 — いずれか 1 つで発火)。ことばきっかけの agent 起案 (「ことばで頼む」) は GUI のみ |
| GUI (manager) | docs 起点の一覧・編集・「ことばで頼む」(agent 起案)・注入テスト・注入の記録 (いつ・どのルールが注入されたかの履歴)。起動は経路 A `node ~/.claude/plugins/marketplaces/toolhint/manager/server.mjs` / 経路 B `node ./toolhint/manager/server.mjs` (clone の親ディレクトリで) → http://127.0.0.1:4517/ (使い方・LAN / VPN 公開・サブパス配下・global 層だけを扱う「全体層モード」は [getting-started §4](docs/getting-started.md#4-manager-gui-の起動)) |

## ルールの書き方 (最小)

ルールは層の `rules.yaml` に 1 エントリ。操作きっかけ (ツール実行の直前に反応):

```yaml
rules:
  - id: use-rg
    tool: Bash              # tool 名への正規表現 (完全一致)
    match: \bgrep\b         # tool への入力への正規表現
    doc: docs/use-rg.md     # 注入する docs (rules.yaml のある dir からの相対)
```

ことばきっかけ (ユーザーの発言に反応):

```yaml
rules:
  - id: deploy-docs
    event: prompt
    keywords: デプロイ, deploy   # いずれか 1 つで発火 (= 一致して注入が走る)
    doc: docs/deploy.md
```

注入は既定で**同一セッション 1 回だけ** — 毎回出すなら `every: always`。
全キー (`inject` 文面テンプレ / `mode: inline` 本文ごと注入 / `scope` 場所の限定) と
YAML の制約は [engine/README.md](engine/README.md)「ルール記法」。

## データの場所

ルールの実体は層ごとの `rules.yaml` + `docs/*.md` (すべてプレーンファイル):

| 層 | 場所 | 用途 |
|---|---|---|
| global | `~/.claude/toolhint/` | マシン全体 (環境変数 `TOOLHINT_GLOBAL` で変更可) |
| project | cwd から上に最初に見つかる `<dir>/.claude/toolhint/` | そのプロジェクト用 — repo にコミットして共有・PR でレビュー |
| 追加層 | `~/.claude/toolhint/layers.d/<名前>/` | チームなどから配られたルールの置き場 — ファイルを置くだけで読まれる (CLI / GUI からは読み取り専用) |

`layers.d/*` → global → project の順にマージし、同じ `id` は後勝ち (= より手元の層が勝つ)。
配られたルールを止めるには、手元の層に同じ `id` で `enabled: "false"` のルールを置く。
特定のディレクトリ配下でだけ効かせる `scope`・追加層の安全制限 (層の外の doc は注入できない) は
[getting-started §6](docs/getting-started.md#6-project-層と-global-層の使い分け)。

## agent にルールを起案させる

`toolhint add --ai "grep を使ったら rg を勧めて"` (操作きっかけ) か GUI の「ことばで頼む」で、
要望の一文からルールと docs を agent が起案する (`claude` CLI ログイン済みが前提)。

## 詳しく

- 導入の詳細 — 手動 hooks 配線・GUI の使い方・バックアップ・トラブルシュート:
  [docs/getting-started.md](docs/getting-started.md)
- ルール記法と hook の仕組み (注入 1 回の条件・二重配線対策): [engine/README.md](engine/README.md)
- この repo で使う言葉の定義: [docs/glossary.md](docs/glossary.md)
- 中身の構成 (engine / core / cli / manager の役割分担):
  [getting-started §9](docs/getting-started.md#9-アーキテクチャ)

## テスト

clone ルート (`cd toolhint`) で。すべて依存ゼロで一発実行:

```sh
python3 engine/tests/test_toolhint.py            # engine (hook 本体)
python3 core/tests/test_core.py                  # core (JSON 契約 + engine 発火 e2e)
python3 cli/tests/test_cli.py                    # CLI (表示・引数の皮)
python3 manager/fixtures/test_mock_contract.py   # GUI mock と real core の契約一致
python3 manager/fixtures/test_savedoc_e2e.py     # GUI 保存経路の実書き込み縦貫 (node 必要)
```

GUI のレイアウト監査は稼働中 server に対して
`cd manager && TOOLHINT_URL=<server URL> npm run e2e:layout`
(playwright 必要。詳細は `manager/e2e/layout-audit.mjs` 冒頭)。

## ライセンス

MIT License — 詳細は [LICENSE](LICENSE)。
