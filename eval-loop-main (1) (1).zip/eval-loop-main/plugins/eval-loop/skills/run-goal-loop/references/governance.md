# Governance — INVARIANTS / ノイズ規則 / 層D / 終了ゲートの根拠

本 skill は「rubric 最適化 (内側) を、rubric 非開示の実受容検証 (外側) で監視し、ズレをラウンド間でだけ
再整合する」composite。最大の危険は**外側ループ自身がグッドハート化する**こと (2 sim の一致を最適化対象に
すると、generator は一致して凡庸な出力を学ぶ)。以下はそれを構造的に防ぐ規範。重複を避けるため、
基盤原則は `run-skill-iter-improve` の INVARIANT 系と `ref-orchestration-primitives` を**継承**する
(再発明しない)。本ファイルは本 skill 固有の運用を定義する。

## 継承する INVARIANT (iter-improve / ref-orchestration-primitives より)

- **INVARIANT 1 (PASS 詐欺)**: 採点モード/閾値/スコープ/評価方法を緩めて通すのは、手段を問わず詐欺。
  本 skill の修正は「制約の追加 / 原文再整合」のみ。緩和は arbiter が一律 ease 判定で落とす。
- **INVARIANT 2 (context 非汚染)**: 判定 fresh Agent に改善履歴・rubric・期待答えを渡さない。
- **goal ≠ proxy**: 最終受け入れは goal verifier の PASS|FAIL + blockers (スコア禁止)。
- **C-3 / C-7 (確証バイアス・過信)**: ヒントを見た者の判定は逆算 CoT で汚染される → 判定は別 context、
  高確信判定ほど外部検証を強める。
- **§1.5 安全終了**: `score>=X` 単独は危険。複合条件 (下記 終了ゲート) で止める。

## 本 skill 固有の役割分離 (単一汚染点の排除)

5 つの判定的役割は**全て別 context**。1 体に兼任させない:

| role | context | 見てよい入力 | 見てはいけない |
|---|---|---|---|
| ground-truth 起草 | fresh Agent | task 原文のみ | criteria / artifact / rubric / 履歴 |
| reception sim | fresh Agent | artifact + persona | criteria / threshold / rubric / inner state / 履歴 |
| goal verifier | fresh Agent | artifact + jobs + 封印 expected | criteria / rubric / 改善履歴 |
| divergence arbiter | fresh Agent | 原文 + 現 criteria + 修正案 | 内側スコア詳細 / 「速く通したい」動機 |
| orchestrator | main | 全部 | (ground-truth は**書かない**、修正は**自己承認しない**) |

orchestrator は全履歴を持つため最も汚染されやすい。よって (a) ground-truth を書かせない (原文だけ見る別 Agent が書く)、
(b) persona を選ばせない (roster 固定・順送りローテーション)、(c) 修正を自己承認させない (arbiter を通す)。

## 層D (anti-leak) — sim を第二の rubric にしない

sim の出力 (具体所見・0-100 値・質問項目・persona prompt・閾値) を criteria/task に**転記しない**。
転記すると generator が次ラウンドで sim を攻略対象にし、グッドハートが一段上に移動する。
- 修正は **×/○ 形式の方向指示 + 原文再アンカー**に翻訳してから入れる (divergence-arbiter.md)。
- 「reception が s2 で AI 臭いと言った」→ そのまま入れない。「○ 各節の論証構造を変える / anchor 原文」に翻訳。
- 先行根拠: seo-blog-prose-evaluator 層D 原則 2 (fresh prompt・閾値・cap 値を writer に流さない)。

## ノイズ規則 (signal vs noise を signal 型ごとに定義)

LLM 採点の per-call jitter は ±3-5pt = **peak-to-peak ~10pt** (ref-orchestration-primitives anti-patterns #9
「judge noise floor ~10点」「3 loop で overall <10pt 改善は noise 内」と整合)。本 skill は**そもそもラウンド間の
数値 delta を改善シグナルに使わない** — 改善判定は boolean (probe/veto) の構造シグナルで行い、数値は当ラウンドの
固定閾値に対するゲートにしか使わない。よって noise floor に振り回されない。型別に判定する: 

| signal | 型 | 判定 |
|---|---|---|
| goal verifier verdict==FAIL | boolean | **常に構造シグナル** (boolean にノイズ band 無し → 必ず修正対象) |
| reception veto==true | boolean | **常に構造シグナル** |
| blind_violated==true | boolean | 当ラウンド即 FAIL |
| reception trust/usefulness/ai_smell | 0-100 | persona ローテーションのため**ラウンド間で数値比較しない**。当ラウンドの固定閾値に対してのみ判定 |
| inner best_score | 0-100 | ±5pt は **boolean 変化を伴わない限りノイズ**。boolean が動いた時だけ best_score も読む |
| reception meta_improvement / probe blockers | free text | 内容を読み、新規 blocker は構造シグナル。称賛のみは無視 |

→ 「reception の数値がラウンド間で揺れた」を artifact のシグナルと誤認しない (persona が変わっただけ)。

## 終了ゲート (2 段: per-round → roster sweep)

**per-round ゲート** (各ラウンドの暫定通過 — 当ラウンドの単一 persona):
```
probe.verdict == PASS  AND probe.blind_violated == false
  AND reception.veto == false  AND reception.trust >= 70  AND reception.usefulness >= 70
  AND inner.best_score >= threshold
```
**roster sweep ゲート** (収束の最終条件 — persona_roster 全員):
```
for every persona p in roster:  sweep[p].veto == false AND sweep[p].trust >= 70 AND sweep[p].usefulness >= 70
（= min over roster が閾値以上）
```
- per-round は roster の 1 persona しか見ない。**単一 persona 通過で収束を宣言してはならない** — 寛容な persona に
  当たったラウンドで gamed artifact が懐疑的/非技術 persona の検証を受けずに通る (reception 軸が 1 サンプルに縮退)。
  最終 artifact は roster 全員の min で守る (roster sweep)。
- `inner.best_score` は内側 rubric 由来 = グッドハート汚染の疑いがあるため**単独では信頼しない**。
  reception roster-min (rubric 非開示) と probe の PASS が**独立な品質バックストップ**になり、3 軸が
  独立に揃って初めて収束とみなす。
- 粗い PASS|FAIL の隙間 (jobs は満たすが凡庸) は reception graded が、reception の主観の隙間は probe の
  機能達成が、内側スコアの汚染は両 sim が、互いに塞ぐ。

**閾値の不変条件 (将来の編集事故への防御)**: reception の **veto 閾値 (trust/usefulness<55, ai_smell≥60) は
収束ゲート閾値 (≥70) 以下**に保つ。veto は致命 floor、ゲートは収束バー。両者を等値化しない —
veto を ≥70 に上げると凡庸な出力で veto が発火し boolean シグナルが汚れ、ゲートを 55 に下げると INVARIANT 1 違反
(緩和)。trust/usefulness ∈ [55,69] は「veto しないがゲートも通さない」中間帯で、これは意図された設計。

## 過剰制約の防止

- 修正は add-only (緩和禁止) なので、ラウンドを重ねると制約が単調増加し infeasible になりうる。
- 1 ラウンド ≤2 件 (INVARIANT 5)。追加前に既存制約との矛盾チェック。
- rounds default 3 (§1.5 の 3 loop 規範)。3 ラウンドで未収束なら、artifact 不足ではなく **criteria 過剰指定**の
  可能性を報告に明記する (無理に通さない)。

## 自己適用の禁止

本 skill を eval-loop 系 skill 自身に向けない (INVARIANT 7: engine と subject の分離)。向けると評価機構を
自分で汚染する。skill の改善は run-skill-iter-improve、本 skill は成果物 artifact 専用。
