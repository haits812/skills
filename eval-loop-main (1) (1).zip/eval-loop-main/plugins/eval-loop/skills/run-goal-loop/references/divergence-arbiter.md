# Divergence Arbiter — Agent prompt

修正をラウンド間で criteria に反映する前に、別 fresh Agent が「task 原文への再整合 (legit)」か
「合格への緩和 (PASS 詐欺)」かを独立判定する。run-x-tweet-arena の人間承認ゲートの**自律版代替**
(iter-improve INVARIANT 8 (実施箇所 Step C-5): 評価経路に触れる変更 / +10pt jump は外部独立判定が必須)。orchestrator は全履歴を
持つ単一汚染点なので、修正の自己承認を禁じ、この arbiter を必ず通す。

---

## orchestrator が修正案を起草するときの形式 (層D 厳守)

各案は以下の 3 要素で書く。**sim の具体所見をそのまま転記しない** — 受け手の体験を自分の言葉で
方向指示に翻訳する:
- **×**: 次ラウンドで避けること (禁止)。
- **○**: 代わりにすること (推奨方向)。
- **anchor**: task 原文のどの一節に再整合するか (「原文「...」」を引用)。sim ではなく原文を根拠にする。

例 (○): `× 主張→理由→比喩の 3 拍子を全 H2 で反復する / ○ 各節の論証構造を変える / anchor: 原文「読者が最後まで読める」`
例 (×, 緩和なので arbiter が落とす): `× trust の閾値を 55 に下げる`（評価方式の緩和 = PASS 詐欺）

## prompt 本体 (run-goal-loop が `<TASK>` / `<PROPOSALS>` / `<CURRENT_CRITERIA>` / `<RUN_DIR>` / `<R>` を置換)

```
あなたは独立した監査者です。下の修正案が「成果物を本来の目的に近づける正当な制約強化」か、
「合格しやすくするための評価の緩和 (PASS 詐欺)」かを 1 件ずつ判定します。提案者とは別人格で、
履歴も忖度も持ちません。迷ったら ease (緩和) 側に倒す — 緩和を legit と誤認する方が害が大きい。

## タスク本来の目的 (原文)
<TASK>

## 現在の評価基準
<CURRENT_CRITERIA>

## 判定する修正案
<PROPOSALS>   ← [{x, o, anchor}]

## 各案を次のどちらかに分類
- legit: 制約の**追加** または 原文目的への**再整合**。成果物に要求を増やす方向。anchor が原文に実在する。
- ease : 次のいずれかに該当 (1 つでも該当なら ease)。
   * threshold / スコア閾値の引き下げ
   * 既存 criteria 項目の削除・無効化
   * 評価対象スコープの縮小 (「ここは見ない」)
   * 評価方法そのものの差し替え・緩和 (sim を甘い persona に変える等)
   * anchor が原文に無い / sim の所見をそのまま目標化しているだけ (原文に再整合していない)

## 出力
JSON で <RUN_DIR>/round-<R>-arbiter.json に Write:
{"verdicts":[{"proposal_index","verdict":"legit|ease","reason":"<観測に基づく1-2文>"}]}
```

---

## orchestrator 側の扱い

- `verdict=="legit"` の案**だけ** criteria_{R+1} に追加。`ease` は破棄し `divergence-log.md` に理由付きで残す。
- 1 ラウンドの追加は **≤2 件** (iter-improve INVARIANT 5: 3 件以上は消化不良で後退、実証 88→72)。
- 追加前に既存制約との矛盾を確認 (別ラウンドの rotated-out persona 由来の制約と衝突しないか)。
  矛盾するなら、より原文に近い方を残す判断を orchestrator が下し、log に記録。
- **緩和は人間 gate でも自律でも一律禁止** (INVARIANT 1)。arbiter が ease と判定したものを覆さない。
