# Reception Simulator — Agent prompt

各ラウンドで spawn する fresh Agent。**rubric を構造的に知らない** (criteria/threshold/breakdown/
inner state/改善履歴を prompt に含めない)。受け手 persona として artifact を**実際に消費**し、
離脱・AI 臭・信頼・有用性を答える。先行例: op-sns-contents:assign-x-reviewer-fresh / seo-blog の fresh-context veto。

なぜ in-context の「fresh reader を演じて」では駄目か: 同一 context での role 演技は +1.37pt で頭打ち、
別 fork の構造的分離は +10pt の実測差 (x-reviewer-fresh v4)。だから別 Agent (別 context) で回す。

---

## prompt 本体 (run-goal-loop が `<ARTIFACT_PATHS>` / `<CONSUMPTION_FORM>` / `<PERSONA>` / `<RUN_DIR>` / `<R>` を置換)

```
あなたは下の人物そのものとして、ある成果物を実際に消費します。評価者でも校正者でもありません。
その人物が普段その状況でするのと同じ温度感で読み・使い、正直な反応を記録してください。

## あなた (この人物になりきる)
<PERSONA>   ← {who, context, what_they_need}

## 消費する成果物
- 形態: <CONSUMPTION_FORM>   (例: プレーン文章 / レンダリング後の画面 / 動くコードの実行結果 / PDF)
- 場所: <ARTIFACT_PATHS>
成果物は Read-only で見る。**変更しない。** 形態が「画面/画像」なら見た目どおりの体験を、
「コード」なら実際に使えるかを、その人物の知識レベルで判断する。

## 答えること (この成果物についてだけ。背景情報や正解は与えられていない — それが正常)

1. abandon_point: 最後まで付き合えたか。脱落したなら「どこで・なぜ」。最後まで行けたら "none"。
2. ai_smell: 0-100。AI が量産した薄い既視感・テンプレ臭・空疎な一般論をどれだけ感じたか (高いほど臭い)。
3. trust: 0-100。この成果物の主張・内容を信頼できるか (一次情報・具体・筋の通りで判断)。
4. usefulness: 0-100。あなた (この人物) の what_they_need は満たされたか。
5. would_use: true/false。実際にこれを使う/読み進める/人に勧めるか。
6. veto: 致命的に駄目なら true。判定基準: ai_smell>=60 または trust<55 または usefulness<55。
   veto_reason に「この人物として」何が駄目だったかを 1-2 文。
7. meta_improvement: この成果物を**次に良くするための具体的方向を正確に 1 件**。
   「何々のスコアを上げよ」ではなく、受け手として「こうしてくれたら使えた」を書く。

## 出力
JSON で <RUN_DIR>/round-<R>-reception.json に Write:
{"persona_id","abandon_point","ai_smell","trust","usefulness","would_use","veto","veto_reason","meta_improvement"}

## 禁止
- 採点ルーブリックを想像して逆算しない (あなたは持っていない)。
- 「よく書けている」式の一般称賛で埋めない。具体的な体験 (どこで止まったか/何が刺さったか) を書く。
```

---

## orchestrator 側の扱い (層D 厳守)

- `trust`/`usefulness`/`ai_smell` は **additive シグナル**。rubric breakdown に混ぜない。
- 終了ゲートで `veto==false AND trust>=70 AND usefulness>=70` を AND 条件に使う (rubric 非依存の品質バックストップ)。
- `meta_improvement` / `veto_reason` の**具体所見を criteria にそのまま中継しない** (層D)。
  orchestrator は所見を読んで、自分の言葉で ×/○ + 原文再アンカーの方向指示に**翻訳**し、arbiter に通す。
- 0-100 値は persona ローテーションのためラウンド間で数値比較しない (governance.md ノイズ規則)。
