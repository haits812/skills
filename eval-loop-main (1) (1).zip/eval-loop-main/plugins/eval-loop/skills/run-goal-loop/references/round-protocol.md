# Round Protocol — Init / Round の詳細手順

SKILL.md Step 1/2 の実装詳細。すべて 1 応答ターン内で連続実行する。
プレースホルダ `<...>` は実値に置換。`RUN_DIR=.mso/goal-loop/<TS>-<slug>`。

## Init (Step 1)

### 1a. RUN_DIR と state.json

```bash
TS=$(date +%Y%m%d-%H%M%S)
SLUG="<task を kebab 1 語に>"
RUN_DIR=".mso/goal-loop/${TS}-${SLUG}"
mkdir -p "$RUN_DIR"
PROJECT_DIR="$(pwd)"
jq -n \
  --arg slug "$SLUG" --arg run_dir "$RUN_DIR" --arg project_dir "$PROJECT_DIR" \
  --arg task "<task 原文>" --arg criteria "<criteria>" \
  --argjson threshold <threshold> --argjson rounds <rounds> --argjson inner_max <inner-max> \
  --arg live "<live>" --argjson started_at "$(date +%s)" \
  '{
    loop_type:"goal", active:true, slug:$slug, run_dir:$run_dir, project_dir:$project_dir,
    task:$task, criteria:$criteria, threshold:$threshold, rounds:$rounds, inner_max:$inner_max,
    live:$live, round:0, started_at:$started_at,
    snapshot_enabled:true, snapshot_ref_prefix:("refs/goal-loop/"+$slug),
    session_id:"<EVAL_LOOP_SESSION_ID>", ended_reason:null
  }' > "$RUN_DIR/state.json"
```

`snapshot_enabled:true` + `snapshot_ref_prefix` を**本 state に**立てるのが要点。これで
`loop-snapshot.sh "$RUN_DIR/state.json" <R>` がラウンド成果物を `refs/goal-loop/<slug>/iter-<R>`
(leaf 名は loop-snapshot.sh 仕様で `iter-` 固定、R はラウンド番号) に凍結する
(fork の skeleton state には無いので、凍結は本ループの責務)。

### 1b. ground-truth 起草 Agent (1 体、main から spawn)

`Agent` ツールで `references/ground-truth-author.md` の prompt を渡す。**入力は task 原文のみ**。
criteria・artifact・rubric・履歴は渡さない (封印の真正性 = 答えを見ていない者が書く)。

prompt 末尾に出力先を明示: `出力を JSON で <RUN_DIR>/ground-truth.json に Write せよ`。
スキーマ: `{jobs:[{id,description}], expected_outcomes:[{job_id,observable}], persona_roster:[{id,who,context,what_they_need}]}`。
persona_roster は `rounds` 本以上 (ローテーション用、artifact の実オーディエンスを張る)。

**Agent の戻りは完了を意味しない** (background 化の実測あり)。`ground-truth.json` が終端に達するまで
共通ゲートで待つ。**Bash ツールに `timeout: 600000` を明示**:

```bash
bash ${CLAUDE_PLUGIN_ROOT}/scripts/wait-eval-files.sh --mode jq \
  --expr '(.jobs|length)>=3 and (.expected_outcomes|length)>0 and (.persona_roster|length)>0' \
  540 "$RUN_DIR/ground-truth.json"
```
- `READY` (`STATUS ok`) を確認してから下の bash へ進む。判定は **STATUS 行のみ**で行い、Agent の戻り報告は使わない。
- `TIMEOUT` なら**同一ターン内でもう 1 回**同じコマンドを呼ぶ (応答を終えて完了通知を待つのは禁止)。2 回目も
  `TIMEOUT`/`pending` なら起草失敗として**中断・報告**する — 空/欠損の ground-truth で sha256 と jq 分離へ進まない
  (sha が「不在の証拠」になり、空の sealed/gt-open で全ラウンドが走る)。

ゲート通過後:
```bash
sha256sum "$RUN_DIR/ground-truth.json" | tee -a "$RUN_DIR/divergence-log.md"   # 改竄検知
# expected_outcomes だけを封印ファイルに分離 (orchestrator も以後読まない)
jq '{expected_outcomes}' "$RUN_DIR/ground-truth.json" > "$RUN_DIR/sealed-expected.json"
jq 'del(.expected_outcomes)' "$RUN_DIR/ground-truth.json" > "$RUN_DIR/gt-open.json"

# persona roster 長の保証 (起草 Agent が rounds 未満しか出さない事故への防御):
NPERSONA=$(jq '.persona_roster | length' "$RUN_DIR/gt-open.json")
if [ "$NPERSONA" -lt <rounds> ]; then
  echo "WARN: persona_roster=$NPERSONA < rounds=<rounds> — ローテーションは modulo で degrade (persona_roster[(R-1) % $NPERSONA])"
fi
```
orchestrator は `gt-open.json` の `jobs`/`persona_roster` のみ参照。`sealed-expected.json` は
goal verifier に**パスだけ**渡す (中身は読まない)。**persona の選択順は roster 固定・順送り** (orchestrator が
artifact を見て persona を選ぶ steering を不能にする)。roster 長 < rounds のときだけ modulo で巡回する。

## Round (Step 2、R=1..rounds)

### 2a. criteria_R

- R=1: `state.json` の `criteria`。
- R>1: `criteria_{R-1}` に前ラウンド arbiter 承認済み追加 (≤2) を連結した文字列。
  追加は `divergence-log.md` の `applied:true` 項目から。

`jq '.round=<R> | .criteria_current="<criteria_R>"' "$RUN_DIR/state.json" > tmp && mv tmp "$RUN_DIR/state.json"`

### 2b. 内側ループ (Skill → eval-loop.run-eval-loop-fork)

内側起動の**直前**に既存 agent state を記録 (識別の保険):
```bash
ls -1 .mso/agents/*/state.json 2>/dev/null | sort > "$RUN_DIR/agents-before-R<R>.txt" || true
```

`Skill` ツール: `skill: eval-loop.run-eval-loop-fork`、`args:` に下記テキスト (run-eval-loop-fork は
`$ARGUMENTS` を自然文で解析する)。**marker は task 本文の末尾に同一行で**埋める — 別ブロックにすると
fork の task 抽出 (4 ラベル field のみ抜く) で非 field メタとして捨てられうるため:
```
<task 原文> [goal-loop slug=<slug> round=<R>/<rounds> artifacts=<成果物パス(カンマ区切り、project_dir 相対)>]
criteria: <criteria_R>
threshold: <threshold>
max: <inner-max>
```
marker `[goal-loop slug=... round=... artifacts=...]` が task 本文に同行で含まれることで内側 state.task に焼かれる
(= agent 識別子 + 目標再注入 + **成果物パス契約**)。`artifacts=` は goal-loop 側が固定する — fork は
`write_targets` を書かないので、これが無いと「内側が何も書いていない」と「書き終えた」を区別する手段がゼロになり、
2c で待つべきパスも決まらない (judges が前ラウンドの artifact を採点して収束しうる)。

**Skill の戻りは完了を意味しない** (`context: fork` の Skill 起動が background 化する実測あり)。内側の完了は
**内側 state の終端でしか観測できない** — 下の待機ゲートで確認する。

内側結果の特定 (marker で jq フィルタ — 最新 mtime に頼らない。`task==""` の judge skeleton は弾かれる):
```bash
find_inner() {
  for f in .mso/agents/*/state.json; do
    [ -f "$f" ] || continue
    jq -e --arg s "slug=<slug> round=<R>/" 'select(.task | contains($s))' "$f" >/dev/null 2>&1 && echo "$f"
  done | head -1
}
INNER_STATE=$(find_inner)
# 空 = 「まだ state が生えていない」可能性 (background 起動)。fallback の前にまず最大 60s 再 poll:
if [ -z "$INNER_STATE" ]; then
  for _ in 1 2 3 4 5 6 7 8 9 10 11 12; do sleep 5; INNER_STATE=$(find_inner); [ -n "$INNER_STATE" ] && break; done
fi
# marker が落ちたときの fallback (codified): 起動前後の agent state 差分で新規 1 件を採る
if [ -z "$INNER_STATE" ]; then
  ls -1 .mso/agents/*/state.json 2>/dev/null | sort > "$RUN_DIR/agents-after-R<R>.txt" || true
  INNER_STATE=$(comm -13 "$RUN_DIR/agents-before-R<R>.txt" "$RUN_DIR/agents-after-R<R>.txt" \
    | while read -r f; do
        [ "$(jq -r '.loop_type' "$f" 2>/dev/null)" = "eval" ] && \
        [ -n "$(jq -r '.task // ""' "$f" 2>/dev/null)" ] && echo "$f"
      done | head -1)
fi
echo "INNER_STATE=$INNER_STATE"
```
**`INNER_STATE=` の出力値を控える** — Bash 呼び出しを跨いで shell 変数は残らないため、**以降の fence の `<INNER_STATE>` はこの出力値にリテラル置換して実行する**。
**fallback で得た state も走行中でありうる** (差分条件は `loop_type==eval` かつ task 非空だけなので、
SubagentStart hook が作った直後の skeleton を掴む)。どちらの経路で得た場合も、次の終端ゲートを必ず通す。
それでも空なら**中断・報告** (推測で先へ進まない)。やり直すときは旧 fork が background で生きている
可能性があるため、同一の成果物パスへ二重に書かせないこと (旧 artifacts を退避してから再起動する)。

内側ループの終端待ち。**Bash ツールに `timeout: 600000` を明示**:
```bash
INNER_STATE="<INNER_STATE>"
bash ${CLAUDE_PLUGIN_ROOT}/scripts/wait-eval-files.sh --mode jq \
  --expr '.active != true and .ended_reason != null' 540 "$INNER_STATE"
```
- `READY` (`STATUS ok`) でだけ次の読み出しへ。`TIMEOUT` なら**同一ターン内でもう 1 回**。2 回目も `TIMEOUT` なら
  内側ループ失敗として**中断・報告** (BEST_SCORE を捏造せず、2c の凍結にも進まない)。
- 判定は **STATUS 行のみ**。Skill の戻りテキストを完了判定に使わない。

```bash
INNER_STATE="<INNER_STATE>"
BEST_SCORE=$(jq -r '.best_score' "$INNER_STATE")
BEST_ITER=$(jq -r '.best_iteration' "$INNER_STATE")
echo "inner: best_score=$BEST_SCORE best_iter=$BEST_ITER state=$INNER_STATE"
```
`// .latest_score` へのフォールバックは**禁止** (走行中の中間 iteration スコアを best として採ってしまう。
終端した状態なら `best_score` が必ず入っている)。
`write_targets` は fork 内側 state には書かれない (非 fork run-eval-loop のみが書く) ため読まない —
代わりに上の `artifacts=` 契約が待つべきパスの正本になる。judges は現 worktree を直接 Read する。

### 2c. 成果物凍結

2b の内側終端ゲートを通過した後でのみ実行する。加えて `artifacts=` の各パスが書き終わっている
(存在 + 非空 + サイズ安定) ことを確認してから凍結する — 書きかけを git ref に焼くと復元点が破損し、
judges も未完成物を採点する。**Bash ツールに `timeout: 600000` を明示**:
```bash
bash ${CLAUDE_PLUGIN_ROOT}/scripts/wait-eval-files.sh --mode artifact 540 <artifacts= の各パス>
```
`TIMEOUT` は**同一ターン内でもう 1 回**。2 回目も `TIMEOUT` なら凍結せず**中断・報告** (未完成の worktree を
`refs/` に焼かない)。`READY` を確認してから:

```bash
CLAUDE_PLUGIN_ROOT=${CLAUDE_PLUGIN_ROOT} bash ${CLAUDE_PLUGIN_ROOT}/scripts/loop-snapshot.sh "$RUN_DIR/state.json" <R>
# → refs/goal-loop/<slug>/iter-<R> に現 worktree を凍結 (回帰時の復元点)
#   leaf 名は loop-snapshot.sh 仕様で iter-<ITER> 固定。<R> をそのまま渡すので iter-<R>。
```
judges は現 worktree (= 内側 last iter) の artifact を直接 Read する。

### 2d. 2 シミュレーション (並列 Agent — 1 メッセージで 2 つ fan-out)

persona index: `PIDX=$(( (R-1) % NPERSONA ))` (NPERSONA は Init 1b で取得。通常 NPERSONA≥rounds なので順送り、
不足時のみ modulo で degrade)。

**reception** (`references/reception-simulator.md`):
- prompt に **artifact パス (実消費形態を明示)** と `persona = gt-open.json の persona_roster[$PIDX]` を埋める。
- **criteria/threshold/rubric/inner state/履歴/task 原文は絶対に渡さない** (reception は blind)。
- 出力先: `<RUN_DIR>/round-<R>-reception.json`。

**goal verifier** (`references/goal-verifier.md`):
- prompt に **task 原文**、`jobs = gt-open.json の jobs`、**封印パス** `<RUN_DIR>/sealed-expected.json` を埋める。
- 出力先: `<RUN_DIR>/round-<R>-probe.json`。

両 Agent は別 context = 独立。並列実行で相互参照不可。**戻りは完了を意味しない** — 出力 JSON の終端待ちは
2e 冒頭のゲートで行う (ここで Read して確認しない)。

### 2e. 乖離分析 + per-round 判定

**Agent の戻りは完了を意味しない**。2 つの sim 出力が終端に達するまで待ってから jq する — 不在のまま読むと
変数が空文字になり、ゲート式が**静かに偽 FAIL** になる (エラーとして表面化しない)。**Bash ツールに
`timeout: 600000` を明示**:
```bash
bash ${CLAUDE_PLUGIN_ROOT}/scripts/wait-eval-files.sh --mode jq \
  --expr '(.error != null) or ((.verdict|type)=="string") or ((.trust|type)=="number" and (.usefulness|type)=="number" and (.veto|type)=="boolean")' \
  540 "$RUN_DIR/round-<R>-reception.json" "$RUN_DIR/round-<R>-probe.json"
```
- 両方 `STATUS ok` のときだけ下の jq へ。`TIMEOUT` は**同一ターン内でもう 1 回**。
- 2 回目も `pending` が残る、または `READY` でも `.error` が非 null (sim 自体の失敗。jq モードは `.error` も終端として
  `ok` を返す) なら、**per-round ゲートを評価せず**中断・報告する。片肺 (probe だけ / reception だけ) で判定しない。
  **空文字を FAIL と解釈しない**。

```bash
INNER_STATE="<INNER_STATE>"
BEST_SCORE=$(jq -r '.best_score' "$INNER_STATE")   # 前 fence の変数は残らない — ここで再導出
RC="$RUN_DIR/round-<R>-reception.json"; PB="$RUN_DIR/round-<R>-probe.json"
VERDICT=$(jq -r '.verdict' "$PB"); VETO=$(jq -r '.veto' "$RC")
TRUST=$(jq -r '.trust' "$RC"); USE=$(jq -r '.usefulness' "$RC")
BLINDV=$(jq -r '.blind_violated // false' "$PB")
echo "probe=$VERDICT veto=$VETO trust=$TRUST use=$USE blind_violated=$BLINDV best=$BEST_SCORE"
```
`blind_violated==true` は即 FAIL 扱い (封印を覗いた)。

**per-round ゲート** (当ラウンドの単一 persona):
`VERDICT==PASS && BLINDV==false && VETO==false && TRUST>=70 && USE>=70 && BEST_SCORE>=threshold`
→ 満たせば**収束候補** → 2g (roster sweep) へ。満たさなければ 2f (修正) へ (R<rounds) / 未収束報告 (R==rounds)。

### 2f. 修正 (per-round 未通過かつ R<rounds)

`references/divergence-arbiter.md` 参照。orchestrator が ≤2 件を ×/○ + 原文再アンカーで起草 →
arbiter Agent が legit/ease 判定 → legit のみ criteria_{R+1} へ。

**Agent の戻りは完了を意味しない**。判定結果が終端に達するまで待つ (**Bash ツールに `timeout: 600000` を明示**):
```bash
bash ${CLAUDE_PLUGIN_ROOT}/scripts/wait-eval-files.sh --mode jq \
  --expr '((.verdicts|length)>0) or (.error != null)' 540 "$RUN_DIR/round-<R>-arbiter.json"
```
`TIMEOUT` は**同一ターン内でもう 1 回**。2 回目も `TIMEOUT`、または `.error` が非 null なら**中断・報告** — criteria 据え置きのまま
黙って R+1 へ進まない (同じ criteria で内側ループを再走させてラウンドを浪費する)。orchestrator が自分で
legit/ease を代行するのも禁止 (INVARIANT 1 の自己承認禁止)。`verdicts` は提案件数と同数あることを確認する。

全件 `divergence-log.md` に追記:
```
## Round <R>
- proposal: ×<禁止> / ○<推奨> (anchor: 原文「...」)
  arbiter: legit|ease — <理由>
  applied: true|false
```
→ R を +1 して 2a へ。

### 2g. roster sweep (収束候補になったときだけ — 最終収束条件)

per-round ゲートを通った artifact は、当ラウンドの 1 persona しか見ていない。**persona_roster 全員**で
reception を 1 回ずつ並列 fan-out し、min が閾値を満たして初めて収束する。
出力先は persona index で**決め打ち**にする (`round-<R>-sweep-<i>.json`, i=0..NPERSONA-1) — glob 待ちでは
「まだ書かれていない persona」を数えられない。

**Agent の戻りは完了を意味しない**。全員ぶんが終端に達するまで待ってから集計する。待たずに glob を集計すると、
早く終わった寛容 persona だけで min が成立し、**懐疑的 persona の検証を受けずに収束を宣言する**
(本 skill 唯一の存在意義である roster worst-case 防御が黙って無効化される)。
**Bash ツールに `timeout: 600000` を明示**:
```bash
NPERSONA=$(jq '.persona_roster | length' "$RUN_DIR/gt-open.json")   # 空変数で待機リストが壊れないよう再導出
# リストは必ず位置パラメータで組む — unquoted $SWEEP 展開は shell 依存で壊れる
# (zsh は word-split せず N パスが 1 個の偽パスになり全 pending、bash は空白入りパスが割れる。実測)
set --; i=0; while [ "$i" -lt "$NPERSONA" ]; do set -- "$@" "$RUN_DIR/round-<R>-sweep-$i.json"; i=$((i+1)); done
bash ${CLAUDE_PLUGIN_ROOT}/scripts/wait-eval-files.sh --mode jq \
  --expr '(.error != null) or ((.trust|type)=="number" and (.usefulness|type)=="number" and (.veto|type)=="boolean")' \
  540 "$@"
```
`TIMEOUT` は**同一ターン内でもう 1 回**。2 回目も `pending` が残る、またはいずれかの `.error` が非 null なら
**収束させず**中断・報告する (欠けた persona を「無かったこと」にして min を取らない)。全員 `STATUS ok` を確認してから:
```bash
# 件数照合 (roster 全員ぶん揃っているときだけ min を取る)。
# 前の fence の位置パラメータは Bash 呼び出しを跨いで残らないので、ここで再構築する
NPERSONA=$(jq '.persona_roster | length' "$RUN_DIR/gt-open.json")
set --; i=0; while [ "$i" -lt "$NPERSONA" ]; do set -- "$@" "$RUN_DIR/round-<R>-sweep-$i.json"; i=$((i+1)); done
n=0; for f in "$@"; do [ -s "$f" ] && n=$((n+1)); done
[ "$n" -eq "$NPERSONA" ] || { echo "ABORT: sweep incomplete ($n/$NPERSONA)"; exit 1; }
MIN_TRUST=$(jq -s 'map(.trust) | min' "$@")
MIN_USE=$(jq -s 'map(.usefulness) | min' "$@")
ANY_VETO=$(jq -s 'any(.veto)' "$@")
echo "sweep: min_trust=$MIN_TRUST min_use=$MIN_USE any_veto=$ANY_VETO n=$NPERSONA"
```
- `ANY_VETO==false && MIN_TRUST>=70 && MIN_USE>=70` → **収束**。Step 3 (live-trial 条件付き) + 報告へ。
- 1 人でも veto / 不足 → 収束させない。その persona の所見を 2f の修正に回す (R<rounds) / 未収束報告 (R==rounds)。
- これにより最終 artifact は「たまたま寛容な persona に当たったラウンド」では通らない (reception 軸を roster 全員の min で守る)。

## 終了時 (state クローズ)

```bash
jq '.active=false | .ended_reason="<converged|max_rounds|...>"' "$RUN_DIR/state.json" > tmp && mv tmp "$RUN_DIR/state.json"
```
