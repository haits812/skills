---
name: run-goal-loop
template: core
description: rubric への過剰最適化 (グッドハート) を避けて成果物を仕上げたい場面で発動。「ゴールループ」「グッドハート対策ループ」で発動。
user-invocable: true
argument-hint: <task> [criteria: ...] [threshold: 70] [rounds: 3] [inner-max: 4] [live: auto|on|off]
allowed-tools: Agent, Skill, Write, Read, Edit, Bash
requires:
  plugins:
    - eval-loop
  skills:
    - eval-loop.run-eval-loop-fork
optional:
  skills:
    - eval-loop.run-skill-live-trial
---

# Run Goal Loop

内側で eval ループ (rubric 最適化) を回しつつ、**rubric を一切見ない独立 fresh シミュレーションを各ラウンド 2 本** ぶつけ、その乖離から rubric/task を**ラウンド間でだけ**再整合する外側ループ。rubric 内の高得点と「実世界での受容・目的達成」のズレ (グッドハート) を検出して潰すのが唯一の目的。

**先に安い代替を検討**: 機能 oracle がある収束タスク (doc/help/API/手順/コピーの大半) では、外側ループより **`/run-eval-loop-fork` の evaluator を `assign-goal-aware-evaluator` に差し替える** (機能 probe を score に焼き込んで弾く) 方が安い。両者を直接比較した実験はあるが N=5・単一審査・2世代・C 側を自身の層D規律で handicap、と交絡が多く**決定的ではない** — 「evaluator が外側ループに勝つ」とは言えない。

**本 skill (外側ループ) を使う場面**: 上記 evaluator では捕まえにくい、**主観支配 / 機能 oracle が効かない / 長時間最適化でグッドハートが再燃しうる高ステークス成果物** (ブランドコピー、オンボーディング体験など)。確実に言えるのは evaluator 差し替えと**対象帯域が違う**こと。方向は確定済みであること。なお外側ループ自体の有効性も rigorous には未実証 (上記実験は決定打ではない)。

**まず最初に読む — 使わない場面 (これに当てはまるなら本 skill を使うな):**
- 単発・収束的・計測可能なタスク → 素の `/run-eval-loop` (本 skill は過程インフレ #20)
- 方向が未決 (どの案が良いか不明) → `/run-best-of-n` か `/wrap-bon-eval` が先
- 真値が市場 oracle (CTR/CVR/実ユーザー) → telemetry/human bridge。**本 skill の 2 シミュレーションも LLM proxy であり、実測の代替ではない** (proxy-only treadmill の一段上にすぎない)
- 改善対象が **skill そのもの** (skill ファイルを編集して育てる) → `/run-skill-iter-improve` (本 skill は単一 artifact を仕上げる。skill ファイルは編集しない)

**絶対ルール (グッドハート再帰の防止 = 本 skill の存在意義):**
1. **シミュレーションは構造的に rubric 非開示** — fresh Agent に criteria/threshold/breakdown/生成履歴/plan を**渡さない**。渡すのは artifact (実消費形態) と persona/jobs のみ。
2. **修正は緩和禁止 (INVARIANT 1)** — threshold 引き下げ / criteria 削除 / スコープ縮小 / 評価方式の差し替えは、いかなる手段でも禁止。修正は「制約の追加 / task 原文への再整合」だけ。
3. **sim 所見を rubric/task に中継しない (層D)** — sim の質問項目・閾値・persona prompt・0-100 値・「s2 で AI 臭い」等の具体所見を criteria に貼り込まない。修正は ×/○ 形式の方向指示のみ、かつ **task 原文に再アンカー** する (sim シグナルに最適化させない)。
4. **判定者は全員別 fresh context** — ground-truth 起草者 ≠ reception ≠ goal 検証 ≠ divergence arbiter ≠ orchestrator。orchestrator は ground-truth を**書かない** (原文だけを見る別 Agent が書いて封印する)。
5. **全ラウンドを 1 応答ターンで実行** — フェーズ間でテキストだけ出して応答を終了しない (inner の SubagentStop / 本 skill の制御が狂う)。**同一ターン内の待機 Bash (待機ゲート) は違反ではない** — 違反なのは応答を終えて完了通知を待つこと。

詳細な根拠と各 role の prompt は `references/` に分離 (段階開示)。本文は手順のみ。

## Decision Record (ref-orchestration-primitives §1.5 — 起動前に埋める)

| 項目 | 値 |
|---|---|
| **Task** | `$ARGUMENTS` の task 原文 |
| **Selected primitive** | nested eval-loop (run-eval-loop-fork) を、rubric 非開示の外側検証ループで包んだ composite |
| **Reason** | 方向は確定済み、polish 段階のみグッドハート保護が要る。rubric が実受容の**既知の弱い proxy** (主観/創作/説得系) のとき外側ループは元が取れる。強い oracle (test/schema/render/source) があるなら rubric は弱 proxy でなく run-eval-loop-fork 単独で足りる |
| **Oracle** | 内側: criteria/rubric (弱い proxy)。外側: rubric 非開示 reception sim + 封印 jobs-to-be-done probe |
| **Context pack** | sims に渡すのは artifact + persona/jobs のみ。criteria/rubric/threshold/履歴は構造的に withhold |
| **Repair gradient** | あり (inner eval-loop が改善、外側が rubric を再整合) |
| **Hard fail** | reception veto / goal probe FAIL / blind_violated |
| **Max loop** | 外側 rounds (default 3) × 内側 inner-max (default 4) |
| **Holdout** | 各ラウンドの 2 sim が holdout 評価者 (generator から構造的に隠れている) |
| **Human gate** | なし (自律)。緩和系修正は別 fresh arbiter の独立判定で代替 (INVARIANT 1 + iter-improve INVARIANT 8: 評価経路に触れる変更/+10pt jump は外部独立判定。Step C-5 はその実施箇所) |
| **Stop condition** | 複合 (§Step 3): probe PASS かつ reception graded gate 通過かつ inner best_score≥threshold |

## 境界 (近接 skill との違い — 重複しない)

- **run-eval-loop / -fork**: rubric を回す内側コンパイラ。本 skill はこれを内側に**使う**。
- **wrap-bon-eval**: 初期方向の探索 (best-of-n→polish)。直交する別軸。本 skill は方向確定後の polish を**グッドハートから守る**。両者は合成可能 (bon-eval が方向を選び、goal-loop が磨きを守る) が、どちらも他方を wrap しない。
- **run-skill-iter-improve**: **skill ファイルを編集して育てる** (target = 再利用機構)。本 skill は**単一 artifact を仕上げる** (skill ファイルは触らない)。ただし anti-Goodhart のガバナンス (PASS 詐欺 INVARIANT 1 / fresh 独立 / goal≠proxy 検証) は iter-improve の INVARIANT 系を継承する (再発明しない)。
- **run-rubric-calibration**: **rubric そのものを人オラクルへ較正する** (人の好みが正解のタスク)。本 skill の criteria 修正は task 原文への再整合のみで、人の好みへの較正はしない。

## アーキテクチャ

- run-goal-loop は **main context**、全ラウンドを **1 ターン inline** 実行。session Stop-hook slot (`.mso/sessions/`) は**占有しない**。
- 内側ループ = **Skill → eval-loop.run-eval-loop-fork** (agent-scoped state、SubagentStop が fork 内でループを駆動)。
  **Skill の戻りは完了を意味しない** (fork 起動が background 化する実測あり) — 完了は内側 state の終端を待機ゲートで確認する (round-protocol §2b)。
- **待機ゲート** — Agent / forked Skill の戻りや報告テキストを完了判定に使わない。完了の唯一の観測手段は**成果物ファイルの終端**で、
  共通ゲート `${CLAUDE_PLUGIN_ROOT}/scripts/wait-eval-files.sh` を **Bash ツールに `timeout: 600000` を明示**して呼ぶ。
  判定は `STATUS <ok|failed|pending>` 行のみ。`TIMEOUT` は同一ターン内でもう 1 回だけ再実行し、2 回目も TIMEOUT なら失敗経路へ。
  **応答を終えて完了通知を待つのは禁止** (絶対ルール 5 に違反する。同一ターン内の待機 Bash は違反ではない)。
- 5 つの role は全て **inline Agent** (別スキルを mint しない — iter-improve Step A と同型。独立性は Agent context 分離で担保):
  ground-truth 起草 / reception sim / goal verifier / divergence arbiter / (収束時) live-trial。
- 状態: `.mso/goal-loop/<TS>-<slug>/` に state.json + ground-truth.json (封印) + divergence-log.md + round 別成果物。
  **best 受け渡し**: fork は snapshot を作らない (skeleton state に `snapshot_enabled` 無し) ため、run-goal-loop 自身が**自分の state** で `snapshot_enabled=true` を立て、各ラウンド後に `loop-snapshot.sh` で worktree を `refs/goal-loop/<slug>/iter-<R>` に凍結する (leaf 名は `loop-snapshot.sh` 仕様で `iter-`、R はラウンド番号)。

## Step 0: 入力解析

`$ARGUMENTS` から抽出。task が不明ならユーザーに確認。

| 項目 | default | 備考 |
|---|---|---|
| task (原文) | 必須 | 判定 Agent (ground-truth 起草 / goal verifier / divergence arbiter) と内側 fork に**逐語**同梱 (T-2.2)。**reception sim には渡さない** (blindness 維持: artifact+persona のみ) |
| criteria | orchestrator がタスク種別から設定 | コード/コンテンツ/クリエイティブで使い分け |
| threshold | 70 | 内側合格ライン。**意図的に family 最低** — 本当のバーは外側 rubric 非開示ゲート。緩いのは仕様 |
| rounds | 3 | 外側上限 (§1.5 の 3 loop 規範) |
| inner-max | 4 | 内側 iteration 上限。3-4 に抑える (>3 は loop 枯渇帯) |
| live | auto | auto=artifact が skill のとき収束時に live-trial / on=必ず / off=しない |

slug = task を短い kebab 1 語に。`TS=$(date +%Y%m%d-%H%M%S)`。

## Step 1: 初期化 + ground-truth 封印

`references/round-protocol.md` の **Init** 節に従う。要点:
1. `.mso/goal-loop/<TS>-<slug>/` を作り state.json を書く (`loop_type:"goal"`, `snapshot_enabled:true`, `snapshot_ref_prefix:"refs/goal-loop/<slug>"`, round 0, max_rounds, task, threshold, live)。
2. **ground-truth 起草 Agent** (`references/ground-truth-author.md`) を spawn。入力は **task 原文のみ** (criteria も artifact も履歴も渡さない)。出力 `ground-truth.json` = `{jobs[], expected_outcomes[], persona_roster[]}` (persona は rounds 本以上)。`git add -N` 相当で改竄検知のため `sha256` をログ。
3. **待機ゲート** — Agent の戻りは完了ではない。`ground-truth.json` の終端 (3 キーが揃う) を確認してから読む (round-protocol §1b)。空/欠損のまま先へ進まない。
4. orchestrator は `jobs` と `persona_roster` のみ読む。**`expected_outcomes` は封印** (goal verifier だけが probe 試行後に開く)。

## Step 2: ラウンドループ (R = 1..rounds)

各ラウンドを `references/round-protocol.md` の **Round** 節どおり 1 ターン内で実行:

1. **criteria_R 決定** — R=1: Step 0 の criteria。R>1: criteria_{R-1} + 前ラウンドで arbiter 承認済みの追加 (≤2 件)。
2. **内側ループ** — `Skill eval-loop.run-eval-loop-fork`、task = `<原文> [goal-loop slug=<slug> round=<R>/<rounds> artifacts=<成果物パス>]` (marker は task **本文末尾に同一行で**埋める — 別ブロックにすると fork の task 抽出で落ちる。agent state 識別 + 目標再注入 + **成果物パス契約**を兼ねる。fork は write_targets を書かないので、待つべきパスは goal-loop 側で固定する)、criteria=criteria_R、threshold、max=inner-max。**戻り≠完了** — marker で内側 agent state を特定し、その state が終端 (`.active != true and .ended_reason != null`) に達するまで待機ゲートで待ってから `best_score`/`best_iteration` を読む (`latest_score` へのフォールバックは禁止 = 走行中の中間スコアを best と誤読する)。marker が落ちた場合は `agents-before` 差分で新規 state を特定 (round-protocol.md §2b — fallback で得た state にも同じ終端ゲートを適用)。
3. **成果物凍結** — 2 の終端ゲート通過後、`artifacts=` の各パスが artifact 終端 (存在 + 非空 + サイズ安定) であることを確認してから `loop-snapshot.sh <goal-state> <R>` で worktree を `refs/goal-loop/<slug>/iter-<R>` に凍結 (回帰時の復元点)。書きかけを ref に焼かない。judges は現 worktree を直接読む。
4. **2 シミュレーション (並列 Agent、1 メッセージで fan-out)** — 戻り≠完了。両 JSON の終端を待機ゲートで確認してから 5 へ (round-protocol §2e 冒頭。片肺判定・空文字 FAIL を防ぐ):
   - **reception** (`references/reception-simulator.md`): 入力 = artifact (実消費形態) + `persona_roster[R-1]` (ローテーション)。rubric 非開示。出力 `round-<R>-reception.json`。
   - **goal verifier** (`references/goal-verifier.md`): 入力 = artifact + `jobs[]` + 封印 `expected_outcomes` ファイルパス。jobs を**原文から再導出**し試行 → 試行ログ後に封印を開く。出力 `round-<R>-probe.json` = `{verdict:PASS|FAIL, blockers[], attempts[], blind_violated}` (**スコア無し**)。
5. **乖離分析** (orchestrator、`references/governance.md` のノイズ規則):
   - goal FAIL / reception veto = **常に構造シグナル** (boolean にノイズ無し)。
   - reception 0-100 = persona ローテーションのため**ラウンド間比較しない**。当ラウンドの固定閾値 (trust/usefulness≥70) に対してのみ判定。
   - inner best_score の ±5pt は、boolean 変化を伴わない限りノイズ。
6. **終了判定** (§Step 3) → 通過なら Step 3、未通過かつ R<rounds なら 7、R==rounds なら未収束報告。
7. **修正** (`references/divergence-arbiter.md`):
   - orchestrator が乖離から **≤2 件**の修正案を **×/○ 形式** + **原文再アンカー**で起草 (層D: sim 所見を中継しない)。
   - **divergence arbiter Agent** (別 fresh) が各案を「原文への再整合 (legit)」か「合格への緩和 (PASS 詐欺)」か独立判定。**戻り≠完了** — `round-<R>-arbiter.json` の終端を待機ゲートで確認してから読む (round-protocol §2f)。判定が取れないまま criteria 据え置きで R+1 へ進まない / orchestrator が判定を代行しない (INVARIANT 1)。
   - 全案 + 判定を `divergence-log.md` に追記。**arbiter が legit としたものだけ** criteria_{R+1} に反映。緩和判定は破棄。
   - 既存制約との矛盾 (別ラウンドの rotated-out persona 由来の制約と衝突しないか) を確認してから追加。

## Step 3: 収束判定 + live-trial + 報告

**per-round ゲート (各ラウンドの暫定通過 — 当ラウンドの単一 persona)**:
```
probe.verdict == PASS  AND probe.blind_violated == false
  AND reception.veto == false  AND reception.trust >= 70  AND reception.usefulness >= 70
  AND inner.best_score >= threshold
```
これを満たしたら**収束候補**。ただし当ラウンドは roster の 1 persona しか見ていない。**単一 persona の通過で収束を宣言してはならない。**

**roster sweep ゲート (収束の最終条件 — 全 persona)**: 収束候補になった artifact に対し、**persona_roster 全員** (当ラウンドで未走の persona を含む) で reception sim を 1 回ずつ fan-out (並列 Agent) し、**全員が** `veto == false AND trust >= 70 AND usefulness >= 70` (= roster の worst-case/min) を満たして初めて**収束**。
- **戻り≠完了。全員ぶんの出力が終端に達するまで待機ゲートで待ち、件数 == roster 長を照合してから min を取る** (round-protocol §2g)。待たずに集計すると早く終わった寛容 persona だけで min が成立し、この防御が黙って無効化される。欠けたまま収束を宣言しない。
- 1 人でも veto/不足なら収束させない。その persona の所見を修正に回し (R<rounds なら Step 2.7)、R==rounds なら未収束として報告。
- 理由: per-round の単一 persona ゲートだけだと、寛容な persona に当たったラウンドで gamed artifact が懐疑的/非技術 persona の検証を受けずに通る (reception 軸が 1 サンプルに縮退する)。最終 artifact は roster 全員の min で守る。

reception の graded 値 (rubric 非開示) が、内側 best_score (グッドハート汚染の疑い) とは**独立な品質バックストップ**。probe (機能) / reception roster-min (受容) / inner best_score (rubric) の 3 軸が独立に揃って初めて収束。

- **live-trial** (`live==on`、または `live==auto` かつ artifact が skill): roster sweep 通過後の artifact に対し最終 fresh-session 受け入れとして `Skill eval-loop.run-skill-live-trial` を 1 回実行 (`<plugin:skill>` 引数)。judgment は live-trial の「goal-proxy 乖離 (完走するが目的を果たさない)」軸を採用。**通常ラウンドでは使わない** (wall-time 43m-4h)。skill 以外の artifact は goal verifier が最終確認。
  - **受領パスを goal-loop 側で固定する**: 起動 args に「judgment を `<RUN_DIR>/live-trial-verdict.json` に `{"verdict":"PASS|FAIL","goal_proxy":"...","error":null}` で Write せよ」を明示し、その終端を待機ゲート (`--mode jq --expr '((.verdict|type)=="string") or (.error != null)'`) で確認する。**Skill の戻りテキストを judgment に使わない** — forked Skill が background 化すると最終受け入れゲートが黙って素通りし、報告だけ「live-trial 実施」と書かれる。
  - wall-time が budget (540s) を大きく超えるため、`READY` (verdict 確定 ∨ `.error` 非 null) が出るまで**同一ターン内でゲートを呼び直し続ける** (各呼び出しは **Bash ツールに `timeout: 600000` を明示**。応答を終えて通知を待つのは禁止)。呼び直しは**機械的上限 27 回** (≒ live-trial の自認上限 4h) — 超えたら未収束として報告する。人の中断が要ると判断した場合も同様。
- **報告**: 最終 artifact パス + ラウンド別 (best_score / reception 要約 / probe verdict / 採用修正) + roster sweep 結果 + `divergence-log.md` パス + 復元コマンド (`git checkout refs/goal-loop/<slug>/iter-<R> -- .`)。未収束時は残存乖離を明示。

## Gotchas

- **fork は snapshot を作らない** (skeleton state に `snapshot_enabled` 無し → `loop-snapshot.sh` 即 exit)。best 受け渡しは run-goal-loop 自身の state での round 凍結に依存する。内側 best_iteration≠last でも fork 内の旧 iter ファイルは復元不能 → 現 worktree (last iter) を採用。内側が threshold 通過なら last≈best、未通過ラウンドは修正して再走するので許容。**ただし「現 worktree = last iteration の完成物」が成立するのは内側 state の終端ゲートと artifact 終端を通過した後だけ** — 走行中の worktree は途中書きで、この許容理由ごと崩れる (Step 2.2/2.3 の順序を飛ばさない)。
- **agent state 識別** — `.mso/agents/*/state.json` は内側ループ・judge Agent で増える。内側は **marker (`slug=`/`round=`) で jq フィルタ**して特定 (最新 mtime だけに頼らない)。
- **session slot 非占有** — `loop-start.sh` を session 用に呼ばない。本 skill の state は `.mso/goal-loop/` (session/agent slot ではない)。よって session Stop hook は本ループに無干渉。
- **observability** — `run-loops-overview` は `.mso/goal-loop/` を走査しない。本ループは inline で 1 ターン完結のため、停止は割り込み (⌃C) かターン終了。状態は `.mso/goal-loop/<run>/state.json` を直接 Read。
- **inline Agent は main context のみ** — 本 skill が fork から呼ばれると Agent が使えず破綻する。必ず main で起動する。
- **judge は artifact に Read-only**。書き込みは各自の output JSON のみ。

## Additional resources

- `references/round-protocol.md` — Init / Round の詳細 bash + 呼び出し手順
- `references/ground-truth-author.md` — ground-truth 起草 Agent prompt
- `references/reception-simulator.md` — reception sim Agent prompt (rubric 非開示)
- `references/goal-verifier.md` — goal 検証 Agent prompt (封印 jobs probe)
- `references/divergence-arbiter.md` — 乖離 arbiter Agent prompt (realign vs ease)
- `references/governance.md` — INVARIANTS / ノイズ規則 / 層D / 終了ゲートの根拠
