---
name: run-eval-loop-fork
template: core
base: run-eval-loop
description: 品質ループの履歴をメイン会話に残したくない場面で発動。「fork ループ」で発動。
user-invocable: true
argument-hint: "<task description> [criteria: 正確性,可読性,...] [threshold: 70] [max: 12]"
allowed-tools: "*"
---

# Eval Loop Fork

eval ループ (2フェーズ: Generator → Evaluator、orchestrator が planner を兼任) を **subagent にフォークして** 実行します。ループの会話履歴がメインコンテキストに蓄積されないため、同一セッションで複数ループを連続実行しても安全です。

## Step 1: 入力解析

ユーザーの入力 `$ARGUMENTS` から以下を抽出:

| 項目 | デフォルト | 例 |
|------|-----------|-----|
| **task** | (必須) | "skillAを実装する" |
| **criteria** | オーケストレーターがタスクに応じて設定 | "テストカバレッジ、エラーハンドリング、可読性" |
| **threshold** | 70 | 70 |
| **max_iterations** | 12 | 12 |

task が不明な場合はユーザーに確認すること。criteria が未指定の場合は、タスクの性質に応じて適切な品質基準を設定する（コードなら正確性・テストカバレッジ等、コンテンツなら意図忠実度・テクスチャ保存等）。

## Step 2: Subagent Orchestrator の spawn

**プロトコル本体は共有正本 `references/orchestrator-protocol.md`（base: run-eval-loop 配下）にある。** subagent は SKILL.md を読めないため、orchestrator（このスキル実行側）が本文を Read して subagent prompt に埋め込む:

```bash
cat ${CLAUDE_PLUGIN_ROOT}/skills/run-eval-loop/references/orchestrator-protocol.md
```

出力の `## Subagent Orchestrator Protocol` 見出し **以降** が subagent prompt の本体。埋め込む前に以下を置換する:

- `<task>` `<criteria>` `<threshold>` `<max_iterations>` … Step 1 で抽出したユーザー入力値（parent が置換）
- `<session_id>` … UserPromptSubmit hook が注入した `EVAL_LOOP_SESSION_ID` の値（parent が置換。subagent には注入されないため parent 側で埋める）
- `<EVAL_LOOP_STATE>` `<EVAL_LOOP_TURNS_DIR>` `<STATE_FILE>` `<TURNS_DIR>` 等 … SubagentStart hook が subagent コンテキストに注入する値。parent は解決できないため **説明文のまま渡す**（subagent 自身が読み取る）
- `${CLAUDE_PLUGIN_ROOT}` … そのまま埋め込む（subagent の shell が解決する）

**Agent ツールで orchestrator subagent を 1 つ spawn する。`model: "opus"` を指定し、prompt に上記で組み立てたプロトコル本体を渡す。**

## Step 3: 結果報告

subagent が完了したら、state.json から結果を取得して報告:

```bash
for f in .mso/agents/*/state.json; do
  [ -f "$f" ] || continue
  jq '{task, active, ended_reason, latest_score, best_score, best_iteration, iteration, threshold}' "$f"
done
```

**finalize backstop**: 該当ループの state が `active: true` のまま残っている場合 (subagent が Step e の finalize を飛ばした / 強制終了)、auto-detect finalize で畳む:

```bash
CLAUDE_PLUGIN_ROOT=${CLAUDE_PLUGIN_ROOT} bash ${CLAUDE_PLUGIN_ROOT}/scripts/loop-cancel.sh "<該当 state.json のパス>"
```

(latest_score >= threshold なら ended_reason=threshold_met、それ以外は cancelled が記録され、iteration も evaluated_iteration から確定する)

報告内容:
- タスク名
- 最終スコア (= quality.overall) と quality.breakdown + plan_implementation
- 完了イテレーション数

## 終端ライフサイクル (finalize)

3 終端すべてで state が `active=false` + `ended_reason` 正値 + iteration 確定 (evaluated_iteration と整合) になるのが正常。`active=true` のまま残った state はループ状態一覧で実行中として出続け、hook の並走 warn が誤発火する。

| 終端 | 誰が finalize するか | state の終値 |
|---|---|---|
| PASS (score >= threshold) | orchestrator subagent が Step e で `loop-cancel.sh "<STATE_FILE>" --reason passed` | active=false / ended_reason=threshold_met / iteration=evaluated_iteration |
| max_iterations 到達 | SubagentStop hook (loop-control.sh) が自動 | active=false / ended_reason=max_iterations / iteration=max 到達値 |
| 中断 (ユーザー停止) | `/run-eval-loop-cancel` → `loop-cancel.sh` | active=false / ended_reason=cancelled (score>=threshold なら threshold_met) |

## 重要なルール

1. **Agent ツールで subagent を spawn する。** メインコンテキストでループを回さない。
2. **subagent に完全なプロトコルを prompt で渡す。** SKILL.md への参照は使えない。
3. **SubagentStop hook がイテレーション制御を行う。** subagent は score < threshold なら応答を終了するだけでよい。
4. **state は `.mso/agents/{agent_id}/` に自動作成される。** SubagentStart hook が `EVAL_LOOP_STATE` (state.json パス) と `EVAL_LOOP_TURNS_DIR` (turns ディレクトリパス) を注入する。subagent はスクリプトを実行する必要はない。
