---
name: run-eval-loop-parallel
template: core
base: run-eval-loop
description: 複数の品質ループを同時に走らせたい場面で発動。「並列ループ」で発動。
user-invocable: true
argument-hint: "<task1 threshold:70; task2 threshold:70 -- semicolon separated>"
allowed-tools: "*"
---
# Eval Loop Parallel

複数の eval ループ (2フェーズ: Generator → Evaluator、orchestrator が planner を兼任) を **並列に** 実行し、結果を統合して報告します。各タスクは独立した subagent orchestrator として spawn され、SubagentStop hook によってループが制御されます。

## Step 1: 入力解析

ユーザーの入力 `$ARGUMENTS` からタスクリストを抽出する。セミコロン `;` で区切られた複数タスク:

```
例: "UIを磨いて70点; APIのエラーハンドリングを70点; ドキュメントを整備して70点"
```

各タスクから以下を特定:
- **task**: 何をするか
- **criteria**: 品質基準 (未指定ならタスク種別に応じて自動設定: コードなら正確性・テストカバレッジ等、コンテンツなら意図忠実度・テクスチャ保存等)
- **threshold**: 目標スコア (指定なければ 70)
- **max_iterations**: 最大イテレーション (デフォルト 12)

## Step 2: 並列 Subagent Orchestrator の spawn

**プロトコル本体は共有正本 `references/orchestrator-protocol.md`（base: run-eval-loop 配下）にある。** subagent は SKILL.md を読めないため、orchestrator（このスキル実行側）が本文を Read して各 subagent prompt に埋め込む:

```bash
cat ${CLAUDE_PLUGIN_ROOT}/skills/run-eval-loop/references/orchestrator-protocol.md
```

出力の `## Subagent Orchestrator Protocol` 見出し **以降** が subagent prompt の本体。タスクごとに以下を置換してから渡す:

- `<task>` `<criteria>` `<threshold>` `<max_iterations>` … Step 1 で各タスクから抽出した値（parent が置換）
- `<session_id>` … UserPromptSubmit hook が注入した `EVAL_LOOP_SESSION_ID` の値（parent が置換。subagent には注入されないため parent 側で埋める）
- `<EVAL_LOOP_STATE>` `<EVAL_LOOP_TURNS_DIR>` `<STATE_FILE>` `<TURNS_DIR>` 等 … SubagentStart hook が各 subagent コンテキストに注入する値。parent は解決できないため **説明文のまま渡す**（subagent 自身が読み取る）
- `${CLAUDE_PLUGIN_ROOT}` … そのまま埋め込む（subagent の shell が解決する）

**各タスクに対して Agent ツールで orchestrator subagent を spawn する。独立したタスクは必ず同一メッセージ内で並列に spawn すること。全 subagent は `model: "opus"` を指定し、prompt に上記で組み立てたプロトコル本体を渡す。**

## Step 3: 結果集約

全 subagent が完了したら、各タスクの結果をまとめて報告:
- 各タスク名
- 最終スコア (= quality.overall) と quality.breakdown + plan_implementation
- 完了イテレーション数

state.json は `.mso/agents/{agent_id}/` に保存されているので、以下で結果を取得:
```bash
for f in .mso/agents/*/state.json; do
  [ -f "$f" ] || continue
  jq '{task, active, ended_reason, latest_score, best_score, best_iteration, iteration, threshold}' "$f"
done
```

**finalize backstop**: 完了した subagent のループの state が `active: true` のまま残っている場合 (subagent が Step e の finalize を飛ばした / 強制終了)、auto-detect finalize で畳む (まだ走っている他 fork の state には触れないこと — agent_id の取り違え注意):

```bash
CLAUDE_PLUGIN_ROOT=${CLAUDE_PLUGIN_ROOT} bash ${CLAUDE_PLUGIN_ROOT}/scripts/loop-cancel.sh "<該当 state.json のパス>"
```

(latest_score >= threshold なら ended_reason=threshold_met、それ以外は cancelled が記録され、iteration も evaluated_iteration から確定する)

## 終端ライフサイクル (finalize)

3 終端すべてで state が `active=false` + `ended_reason` 正値 + iteration 確定 (evaluated_iteration と整合) になるのが正常。`active=true` のまま残った state はループ状態一覧で実行中として出続け、hook の並走 warn が誤発火する。

| 終端 | 誰が finalize するか | state の終値 |
|---|---|---|
| PASS (score >= threshold) | 各 orchestrator subagent が Step e で `loop-cancel.sh "<STATE_FILE>" --reason passed` | active=false / ended_reason=threshold_met / iteration=evaluated_iteration |
| max_iterations 到達 | SubagentStop hook (loop-control.sh) が自動 | active=false / ended_reason=max_iterations / iteration=max 到達値 |
| 中断 (ユーザー停止) | `/run-eval-loop-cancel` → `loop-cancel.sh` | active=false / ended_reason=cancelled (score>=threshold なら threshold_met) |

## 重要なルール

1. **独立したタスクは必ず並列で spawn する。** 直列にしない。
2. **各 subagent に完全なプロトコルを prompt で渡す。** SKILL.md への参照は使えない。
3. **SubagentStop hook がイテレーション制御を行う。** subagent は score < threshold なら応答を終了するだけでよい。
4. **state は `.mso/agents/{agent_id}/` に自動作成される。** SubagentStart hook が `EVAL_LOOP_STATE` (state.json パス) と `EVAL_LOOP_TURNS_DIR` (turns ディレクトリパス) を注入する。subagent はスクリプトを実行する必要はない。
