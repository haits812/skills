#!/usr/bin/env bash
# loop-snapshot.test.sh — loop-snapshot.sh の snapshot / restore / --restore-ref の検証
#
# 特に --restore-ref（セッション跨ぎ再開、agent-harness-jdj）:
# 旧セッションの refs/eval-loop/<sess>/iter-<N> を、別 prefix を持つ新セッションの
# state.json + write_targets 限定で復元できることを検証する。
# fixture は printf 生成（heredoc によるファイル作成は禁止規約）。
set -u

SUT="$(cd "$(dirname "$0")" && pwd)/loop-snapshot.sh"
TMP="$(mktemp -d "${TMPDIR:-/tmp}/loopsnap.XXXXXX")"
trap 'rm -rf "$TMP"' EXIT

PASS=0; FAIL=0
ok(){ echo "  ✓ $1"; PASS=$((PASS+1)); }
fail(){ echo "  ✗ FAIL: $1"; FAIL=$((FAIL+1)); }

[ -f "$SUT" ] || { echo "✗ SUT が無い: $SUT"; exit 1; }

# --- fixture: git repo + 旧セッション state (sessA) ---
REPO="$TMP/repo"
mkdir -p "$REPO"
git -C "$REPO" init -q
git -C "$REPO" -c user.name=t -c user.email=t@t commit -q --allow-empty -m init

mkjson(){ # $1=出力先 $2=prefix $3=targets_json
  printf '{"snapshot_enabled": true, "snapshot_ref_prefix": "%s", "project_dir": "%s", "session_id": "%s", "write_targets": %s}\n' \
    "$2" "$REPO" "${2##*/}" "$3" > "$1"
}
STATE_A="$TMP/stateA.json"
mkjson "$STATE_A" "refs/eval-loop/sessA" '["out.txt"]'

# 1) snapshot: iter 1 / iter 2 で ref が作られる
printf 'v1\n' > "$REPO/out.txt"
out="$(bash "$SUT" "$STATE_A" 1 2>&1)"; rc=$?
git -C "$REPO" rev-parse --verify -q "refs/eval-loop/sessA/iter-1^{commit}" >/dev/null \
  && ok "snapshot iter-1 が ref に凍結される" || fail "iter-1 snapshot 失敗 (rc=$rc): $out"
printf 'v2\n' > "$REPO/out.txt"
bash "$SUT" "$STATE_A" 2 >/dev/null 2>&1
git -C "$REPO" rev-parse --verify -q "refs/eval-loop/sessA/iter-2^{commit}" >/dev/null \
  && ok "snapshot iter-2 が ref に凍結される" || fail "iter-2 snapshot 失敗"

# 2) 既存の --restore (同一 state / prefix 経由) が動く
printf 'v3-dirty\n' > "$REPO/out.txt"
out="$(bash "$SUT" "$STATE_A" 1 --restore 2>&1)"; rc=$?
[ "$rc" -eq 0 ] && [ "$(cat "$REPO/out.txt")" = "v1" ] \
  && ok "--restore で iter-1 の内容 (v1) に戻る" || fail "--restore 失敗 (rc=$rc): $out"

# 3) --restore-ref: 別 prefix の新セッション state から旧 ref を復元できる（セッション跨ぎ）
STATE_B="$TMP/stateB.json"
mkjson "$STATE_B" "refs/eval-loop/sessB" '["out.txt"]'
printf 'v4-dirty\n' > "$REPO/out.txt"
out="$(bash "$SUT" "$STATE_B" --restore-ref "refs/eval-loop/sessA/iter-2" 2>&1)"; rc=$?
[ "$rc" -eq 0 ] && [ "$(cat "$REPO/out.txt")" = "v2" ] \
  && ok "--restore-ref で旧セッション iter-2 (v2) に戻る" || fail "--restore-ref 失敗 (rc=$rc): $out"

# 4) --restore-ref は refs/eval-loop/ 以外を拒否する
out="$(bash "$SUT" "$STATE_B" --restore-ref "refs/heads/main" 2>&1)"; rc=$?
[ "$rc" -ne 0 ] && printf '%s\n' "$out" | grep -q 'refs/eval-loop/' \
  && ok "eval-loop 外の ref を拒否" || fail "ref 空間の制限が効いていない (rc=$rc): $out"

# 5) --restore-ref は存在しない ref で loud に失敗する
out="$(bash "$SUT" "$STATE_B" --restore-ref "refs/eval-loop/nope/iter-9" 2>&1)"; rc=$?
[ "$rc" -ne 0 ] && printf '%s\n' "$out" | grep -q 'not found' \
  && ok "存在しない ref で loud fail" || fail "missing ref が黙って通る (rc=$rc): $out"

# 6) write_targets が空なら復元を拒否する（--restore-ref でも同じ安全弁）
STATE_C="$TMP/stateC.json"
mkjson "$STATE_C" "refs/eval-loop/sessC" '[]'
out="$(bash "$SUT" "$STATE_C" --restore-ref "refs/eval-loop/sessA/iter-1" 2>&1)"; rc=$?
[ "$rc" -ne 0 ] && printf '%s\n' "$out" | grep -q 'write_targets' \
  && ok "write_targets 空で復元拒否" || fail "空 targets の安全弁が効いていない (rc=$rc): $out"

# 7) 引数なし snapshot の従来経路が壊れていない（後方互換）
printf 'v5\n' > "$REPO/out.txt"
out="$(bash "$SUT" "$STATE_A" 3 2>&1)"; rc=$?
[ "$rc" -eq 0 ] && git -C "$REPO" rev-parse --verify -q "refs/eval-loop/sessA/iter-3^{commit}" >/dev/null \
  && ok "従来の snapshot 経路が後方互換" || fail "後方互換が壊れた (rc=$rc): $out"

echo "================================================================"
echo "PASS=$PASS FAIL=$FAIL"
[ "$FAIL" -eq 0 ]
