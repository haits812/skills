#!/usr/bin/env bash
# wait-eval-files.sh [--mode eval|artifact|jq [--expr '<jq 式>']] <budget_sec> <file...>
#
# subagent / forked Skill が書く成果物が「終端」に達するまで待つ共通ゲート。
#
# なぜ必要か: Agent ツールも context: fork の Skill 起動も、この harness では
# background で走ることがある (run_in_background: false を明示しても無視される
# 実測あり: 2026-07-25/26 の live trial 2 回とも primary が Async 起動になった)。
# 「呼び出しが返った = 書き終わった」と仮定すると、まだ走っている最中に
# ファイル不在や書きかけを読んで、失敗誤判定 (eval) や腐ったスコア (generator
# の書きかけ採点) を生む。
#
# mode:
#   eval (既定)  — eval JSON 用。終端 = 数値スコア ∨ .error 非 null。
#                  失敗形 {"score": null, "error": ...} を「未完了」と誤判定して
#                  budget を空焼きしないために .error を終端に含める。
#   artifact     — 任意の生成物 (turn-NNN-generator.md 等) 用。終端 =
#                  存在 + 非空 + サイズが直前 tick から不変 (書きかけ検出)。
#                  JSON でない生成物には成功/失敗の区別が無いので failed は出ない。
#   jq --expr E  — 任意 JSON の状態待ち用 (spawn したループの state.json 等)。
#                  終端 = 存在 + 非空 + jq 式 E が true。
#                  例: --mode jq --expr '.active != true' で「ループ終了」を待つ。
#
# 出力 (呼び出し元はこれだけ読めばよい):
#   STATUS <ok|failed|pending> <path>   ... 各ファイル 1 行
#   READY | TIMEOUT                     ... 最終行
# exit: 0 = 全ファイル終端 (READY) / 3 = budget 満了 (TIMEOUT) / 2 = 引数エラー
#
# budget は必須引数で、Bash ツールの実行上限 (600s) より必ず短くする (推奨 540)。
# 呼び出し側は Bash ツールに timeout: 600000 を明示すること (既定 120s では
# 実測 143-162s の sub-eval を待ち切れない)。TIMEOUT で返ったら、同一ターン内で
# もう一度このスクリプトを呼んでよい (応答を終えて完了通知を待つのは禁止 —
# run-eval-loop の「フェーズ間で応答を終了しない」に違反する)。
set -u

MODE="eval"
EXPR=""
if [ "${1:-}" = "--mode" ]; then
  MODE="${2:-eval}"
  shift 2 || true
fi
if [ "${1:-}" = "--expr" ]; then
  EXPR="${2:-}"
  shift 2 || true
fi
case "$MODE" in
  eval|artifact) ;;
  jq) [ -n "$EXPR" ] || { echo "--mode jq requires --expr '<jq expr>'" >&2; exit 2; } ;;
  *) echo "unknown mode: $MODE" >&2; exit 2 ;;
esac

BUDGET="${1:-540}"
case "$BUDGET" in ''|*[!0-9]*) echo "budget must be a number (got: $BUDGET) — 引数順は [--mode ...] [--expr ...] <budget> <file...>" >&2; exit 2 ;; esac
shift || true
if [ "$#" -lt 1 ]; then
  echo "usage: wait-eval-files.sh [--mode eval|artifact|jq [--expr '<jq expr>']] <budget_sec> <file...>" >&2
  exit 2
fi

# 直前 tick のサイズ台帳 (artifact モードの安定判定用。bash 3.2 に連想配列は
# 無いので "size<TAB>path" 行のファイルで持つ)
PREV="$(mktemp)"
NOW="$(mktemp)"
trap 'rm -f "$PREV" "$NOW"' EXIT
: > "$PREV"

size_of() {
  # macOS (BSD stat) / Linux (GNU stat) 両対応
  stat -f '%z' "$1" 2>/dev/null || stat -c '%s' "$1" 2>/dev/null || echo -1
}

snapshot() {
  : > "$NOW"
  for f in "$@"; do
    if [ -e "$f" ]; then
      printf '%s\t%s\n' "$(size_of "$f")" "$f" >> "$NOW"
    else
      printf '%s\t%s\n' "-1" "$f" >> "$NOW"
    fi
  done
}

is_terminal_eval() {
  [ -s "$1" ] || return 1
  jq -e '((.quality.overall // .score) | type) == "number" or (.error != null)' "$1" >/dev/null 2>&1
}

is_terminal_artifact() {
  # 存在 + 非空 + 直前 tick とサイズ不変 (行単位の完全一致で比較 — パスに
  # 空白があっても行全体で照合されるので安全)
  [ -s "$1" ] || return 1
  line="$(printf '%s\t%s\n' "$(size_of "$1")" "$1")"
  grep -qxF "$line" "$PREV" 2>/dev/null
}

is_terminal_jq() {
  [ -s "$1" ] || return 1
  jq -e "$EXPR" "$1" >/dev/null 2>&1
}

is_terminal() {
  case "$MODE" in
    eval)     is_terminal_eval "$1" ;;
    artifact) is_terminal_artifact "$1" ;;
    jq)       is_terminal_jq "$1" ;;
  esac
}

classify_eval() {
  if [ ! -s "$1" ]; then echo pending; return; fi
  if jq -e '((.quality.overall // .score) | type) == "number"' "$1" >/dev/null 2>&1; then echo ok; return; fi
  if jq -e '.error != null' "$1" >/dev/null 2>&1; then echo failed; return; fi
  echo pending
}

classify_artifact() {
  if is_terminal_artifact "$1"; then echo ok; else echo pending; fi
}

classify_jq() {
  if is_terminal_jq "$1"; then echo ok; else echo pending; fi
}

classify() {
  case "$MODE" in
    eval)     classify_eval "$1" ;;
    artifact) classify_artifact "$1" ;;
    jq)       classify_jq "$1" ;;
  esac
}

start=$(date +%s)
all=0
while :; do
  snapshot "$@"
  all=1
  for f in "$@"; do
    is_terminal "$f" || { all=0; break; }
  done
  cp "$NOW" "$PREV"
  [ "$all" -eq 1 ] && break
  now=$(date +%s)
  [ $(( now - start )) -ge "$BUDGET" ] && break
  sleep 5
done

for f in "$@"; do
  printf 'STATUS %s %s\n' "$(classify "$f")" "$f"
done

if [ "$all" -eq 1 ]; then
  echo READY
  exit 0
fi
echo TIMEOUT
exit 3
